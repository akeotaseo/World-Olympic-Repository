# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import xbmcvfs
import threading
import time
import os
import shutil
import glob
import re

def get_storage_path():
    addon_dir = os.path.dirname(os.path.abspath(__file__))
    config_file = os.path.join(addon_dir, 'path_config.txt')
    if os.path.exists(config_file):
        try:
            with open(config_file, 'r', encoding='utf-8') as f:
                saved_path = f.read().strip()
                if saved_path:
                    translated_path = xbmcvfs.translatePath(saved_path)
                    if not os.path.exists(translated_path):
                        os.makedirs(translated_path)
                    return translated_path
        except:
            pass
    default_path = os.path.join(addon_dir, 'download_subtitles')
    if not os.path.exists(default_path):
        os.makedirs(default_path)
    return default_path

def clean_search_title(raw):
    if not raw:
        return ""
    txt = re.sub(r'\[/?[^\]]+\]', '', raw)
    txt = re.sub(r'(?i)\b(official|trailer|teaser|hd|4k|1080p|720p|full\s*movie|clips?|scenes?)\b', '', txt)
    txt = re.sub(r'[\(\[\{].*?[\)\]\}]', '', txt)
    txt = re.sub(r'[\\/*?:"<>|\-–:|]', ' ', txt)
    txt = " ".join(txt.split()).strip()
    return txt

def watch_and_save_sub(fallback_name):
    addon_dir = os.path.dirname(os.path.abspath(__file__))
    kodi_subs_dir = xbmcvfs.translatePath('special://home/userdata/subs/')
    temp_dir = xbmcvfs.translatePath('special://temp/')
    addon_data_dir = xbmcvfs.translatePath('special://userdata/addon_data/')
    target_folder = get_storage_path()
    icon_path = os.path.join(addon_dir, 'icon.png')
    
    release_name = ""
    
    for _ in range(60):
        if xbmc.getCondVisibility('Window.IsActive(subtitlesearch)'):
            break
        xbmc.sleep(100)

    click_time = time.time() - 3.0

    while xbmc.getCondVisibility('Window.IsActive(subtitlesearch)'):
        click_time = time.time() - 3.0
        lbl2 = xbmc.getInfoLabel('Container(120).ListItem.Label2')
        lbl1 = xbmc.getInfoLabel('Container(120).ListItem.Label')
        for cand in (lbl2, lbl1):
            if not cand or 'ListItem' in cand:
                continue
            clean_c = re.sub(r'\[/?[^\]]+\]', '', cand).replace('\r', ' ').replace('\n', ' ').strip()
            if clean_c and len(clean_c) > 4 and clean_c.lower() not in ['greek', 'english', 'el', 'en', 'ελληνικά', 'αγγλικά']:
                release_name = clean_c
                break
        xbmc.sleep(100)

    search_patterns = [
        os.path.join(target_folder, "*.srt"),
        os.path.join(kodi_subs_dir, "*.srt"),
        os.path.join(temp_dir, "*.srt"),
        os.path.join(addon_data_dir, "service.subtitles.*", "*.srt"),
        os.path.join(addon_data_dir, "service.subtitles.*", "*", "*.srt")
    ]
    
    recent_subs = []
    for _ in range(20):
        xbmc.sleep(250)
        recent_subs = []
        for pattern in search_patterns:
            for f in glob.glob(pattern):
                try:
                    if os.path.getmtime(f) >= click_time:
                        recent_subs.append(f)
                except:
                    pass
        if recent_subs:
            xbmc.sleep(500)
            break

    if recent_subs:
        recent_subs.sort(key=lambda f: (os.path.dirname(f) in [target_folder, kodi_subs_dir], os.path.getmtime(f)), reverse=True)
        found_sub = recent_subs.pop(0)
        
        if found_sub and os.path.exists(found_sub):
            base_name = os.path.basename(found_sub)
            
            chosen_title = ""
            if release_name:
                clean_tags = re.sub(r'\[/?(?:COLOR|B|I|UPPERCASE|LOWERCASE|LIGHT|CR)[^\]]*\]', '', release_name, flags=re.IGNORECASE)
                clean_tags = clean_tags.replace('\r', ' ').replace('\n', ' ')
                clean_tags = re.sub(r'\(\s*\)|\[\s*\]', '', clean_tags)
                clean_tags = re.sub(r'[\\/*?:"<>|]', '', clean_tags).strip()
                clean_tags = " ".join(clean_tags.split())
                clean_tags = re.sub(r'(?i)(?:[\.\s]+(?:srt|txt|el|en))+$', '', clean_tags).strip()
                if len(clean_tags) > 3 and not clean_tags.isdigit():
                    chosen_title = clean_tags

            if not chosen_title:
                chosen_title = fallback_name

            lang_part = ".el" if (".el." in base_name.lower() or "greek" in base_name.lower() or base_name.lower().endswith('.el.srt')) else (".en" if (".en." in base_name.lower() or "english" in base_name.lower()) else "")
            final_name = f"{chosen_title}{lang_part}.srt"

            target_file = os.path.join(target_folder, final_name)
            if os.path.exists(target_file):
                name_part, ext_part = os.path.splitext(final_name)
                counter = 1
                while os.path.exists(os.path.join(target_folder, f"{name_part}_{counter}{ext_part}")):
                    counter += 1
                target_file = os.path.join(target_folder, f"{name_part}_{counter}{ext_part}")

            try:
                shutil.copyfile(found_sub, target_file)
                xbmcgui.Dialog().notification("AutoSniper", f"Αποθηκεύτηκε: {os.path.basename(target_file)}", icon_path, 2500, False)
            except:
                pass

def main():
    xbmc.executebuiltin('Dialog.Close(videoosd, true)')
    xbmc.sleep(150)

    raw_title = (
        xbmc.getInfoLabel('VideoPlayer.TVShowTitle')
        or xbmc.getInfoLabel('VideoPlayer.OriginalTitle')
        or xbmc.getInfoLabel('VideoPlayer.Title')
        or "Subtitle"
    )
    clean_query = clean_search_title(raw_title) or "Subtitle"
    fallback_name = re.sub(r'[^A-Za-z0-9\s\-_]', '', clean_query).strip() or "Subtitle"

    xbmcgui.Window(10000).setProperty('subtitles.searchstring', clean_query)
    xbmcgui.Window(10000).setProperty('SubtitleSearchString', clean_query)

    t = threading.Thread(target=watch_and_save_sub, args=(fallback_name,))
    t.daemon = True
    t.start()

    xbmc.executebuiltin('ActivateWindow(subtitlesearch)')

if __name__ == '__main__':
    main()
