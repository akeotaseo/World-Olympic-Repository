# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs

import threading
import json
import os
import shutil
import glob
import sys
import re
try:
    import urllib.request as urllib_utils
    import urllib.parse as url_parse
except ImportError:
    import urllib2 as urllib_utils
    import urllib as url_parse

temp_video_file = ""
ADDON_ID = "context.subtitles.autosniper"

def get_storage_path():
    addon_dir = os.path.dirname(os.path.abspath(__file__))
    config_file = os.path.join(addon_dir, 'path_config.txt')
    if os.path.exists(config_file):
        try:
            with open(config_file, 'r') as f:
                saved_path = f.read().strip()
                if saved_path:
                    # Μεταφράζει το special:// στην πραγματική διαδρομή του συστήματος
                    translated_path = xbmcvfs.translatePath(saved_path)
                    if not os.path.exists(translated_path):
                        os.makedirs(translated_path)
                    return translated_path
        except:
            pass
    default_path = os.path.join(addon_dir, 'download_subtitles')
    if not os.path.exists(default_path):
        os.makedirs(default_path)
    return default_path


def set_custom_storage_path():
    dialog = xbmcgui.Dialog()
    current_path = get_storage_path()
    new_path = dialog.browse(0, "Επιλογή Φακέλου Αποθήκευσης Υποτίτλων", "video", "", False, False, current_path)
    if new_path and new_path != current_path:
        addon_dir = os.path.dirname(os.path.abspath(__file__))
        config_file = os.path.join(addon_dir, 'path_config.txt')
        try:
            with open(config_file, 'w') as f:
                f.write(new_path)
            dialog.notification("Subtitle Manager", "Ο νέος φάκελος ορίστηκε!", xbmcgui.NOTIFICATION_INFO, 2000)
        except:
            dialog.notification("Subtitle Manager", "Σφάλμα κατά την αποθήκευση.", xbmcgui.NOTIFICATION_ERROR, 2000)

def reset_storage_path_to_default():
    dialog = xbmcgui.Dialog()
    addon_dir = os.path.dirname(os.path.abspath(__file__))
    config_file = os.path.join(addon_dir, 'path_config.txt')
    
    if dialog.yesno("Επιβεβαίωση", "Θέλετε να επαναφέρετε την προεπιλεγμένη διαδρομή αποθήκευσης;"):
        if os.path.exists(config_file):
            try: os.remove(config_file)
            except: pass
        default_path = os.path.join(addon_dir, 'download_subtitles')
        if not os.path.exists(default_path):
            os.makedirs(default_path)
        dialog.notification("Subtitle Manager", "Έγινε επαναφορά στον προεπιλεγμένο φάκελο!", xbmcgui.NOTIFICATION_INFO, 2500)

def run_os_checker(movie_title, movie_year, imdb_id, season, episode):
    try:
        xbmcgui.Window(10000).clearProperty('tmdbmovies.has_el_sub')
        xbmcgui.Window(10000).clearProperty('tmdbmovies.has_en_sub')
        if not movie_title or movie_title == '': return
        if imdb_id and imdb_id != '' and str(imdb_id).startswith('tt'):
            numeric_id = str(imdb_id).replace('tt', '')
            is_tv = season and episode and str(season) != '0' and str(episode) != '0'
            if is_tv: query_path = f"episode-{episode}/imdbid-{numeric_id}/season-{season}"
            else: query_path = f"imdbid-{numeric_id}"
        else:
            query_clean = url_parse.quote(movie_title)
            if movie_year and movie_year != '': query_path = f"query-{query_clean}/year-{movie_year}"
            else: query_path = f"query-{query_clean}"
            
        url = f"https://opensubtitles.org{query_path}"
        req = urllib_utils.Request(url, headers={'User-Agent': 'HotSubtitlesV1'})
        response = urllib_utils.urlopen(req, timeout=5.0)
        if response.getcode() == 200:
            data = json.loads(response.read().decode('utf-8'))
            if isinstance(data, list):
                found_el, found_en = False, False
                norm_lang = {'ell': 'el', 'gre': 'el', 'el': 'el', 'gr': 'el', 'greek': 'el', 'eng': 'en', 'en': 'en', 'english': 'en'}
                for item in data:
                    lang_resolved = norm_lang.get(str(item.get('ISO639', '')).lower().strip()) or norm_lang.get(str(item.get('SubLanguageID', '')).lower().strip())
                    if lang_resolved == 'el': found_el = True
                    if lang_resolved == 'en': found_en = True
                    if found_el and found_en: break
                if found_el: xbmcgui.Window(10000).setProperty('tmdbmovies.has_el_sub', 'true')
                if found_en: xbmcgui.Window(10000).setProperty('tmdbmovies.has_en_sub', 'true')
    except: pass

def auto_stop_and_move(clean_filename):
    global temp_video_file
    addon_dir = os.path.dirname(os.path.abspath(__file__))
    icon_path = os.path.join(addon_dir, 'icon.png')
    
    xbmc.sleep(1000)
    
    # Στέλνουμε την αρχική ειδοποίηση διάρκειας 5 λεπτών
    xbmcgui.Dialog().notification(
        "AutoSniper Subtitles",
        "Αναζήτηση και λήψη υποτίτλων...",
        icon_path,
        300000,
        False
    )

    release_name = ""
    while xbmc.getCondVisibility('Window.IsActive(subtitlesearch)'):
        # Αν κάποιο άλλο πρόσθετο έκλεισε την ειδοποίησή μας, την ξανανοίγουμε αυτόματα
        if not xbmc.getCondVisibility('Window.IsVisible(notification)'):
            xbmcgui.Dialog().notification(
                "AutoSniper Subtitles",
                "Αναζήτηση και λήψη υποτίτλων...",
                icon_path,
                300000,
                False
            )
            
        ui_label = xbmc.getInfoLabel('ListItem.Label2')
        if not ui_label or ui_label == '' or ui_label.lower() in ['greek', 'english', 'el', 'en']:
            ui_label = xbmc.getInfoLabel('Container(100).ListItem.Label2')
        if not ui_label or ui_label == '' or ui_label.lower() in ['greek', 'english', 'el', 'en']:
            temp_lbl = xbmc.getInfoLabel('ListItem.Label')
            if temp_lbl and len(temp_lbl) > 10: ui_label = temp_lbl
        if ui_label and ui_label != '' and 'ListItem' not in ui_label and len(ui_label) > 4:
            release_name = ui_label
        xbmc.sleep(150)

    # Μόλις κλείσει η αναζήτηση υποτίτλων, σβήνουμε ακαριαία την ειδοποίηση
    xbmc.executebuiltin('Dialog.Close(notification, true)')

    xbmc.sleep(600)
    if xbmc.Player().isPlaying():
        xbmc.executebuiltin('PlayerControl(Stop)')
    xbmc.sleep(600)
    
    downloaded_subs = glob.glob(os.path.join(addon_dir, "*.srt"))
    target_folder = get_storage_path()
    
    if downloaded_subs:
        # Ταξινομούμε ώστε αν υπάρχουν δύο, να προτιμήσουμε αυτό που έχει το '.el.' ή το πιο πρόσφατο
        downloaded_subs.sort(key=lambda x: (".el." in os.path.basename(x).lower(), os.path.getmtime(x)), reverse=True)
        
        # Κρατάμε ΜΟΝΟ το πρώτο (καλύτερο) αρχείο, αφού έγινε μία λήψη
        sub_file = downloaded_subs[0]
        base_name = os.path.basename(sub_file)
        
        if release_name and release_name != '' and release_name.lower() not in ['greek', 'english']:
            lang_part = ""
            if ".el." in base_name.lower() or "greek" in base_name.lower() or base_name.lower().endswith('.el.srt'):
                lang_part = ".el"
            elif ".en." in base_name.lower() or "english" in base_name.lower() or base_name.lower().endswith('.en.srt'):
                lang_part = ".en"
            release_clean = "".join([c for c in release_name.replace('.srt', '').replace('.txt', '').strip() if c.isalpha() or c.isdigit() or c in [' ', '.', '-', '_', '+', '[', ']', '(', ')']]).strip()
            # Καθαρίζουμε τυχόν διπλό .el ή .en στο τέλος πριν βάλουμε το δικό μας
            release_clean = re.sub(r'(?i)(\.el|\.en)+$', '', release_clean).strip()
            final_name = f"{release_clean}{lang_part}.srt"

        else:
            lang_part = ".el" if "el" in base_name.lower() or "greek" in base_name.lower() else ".en"
            final_name = f"{clean_filename}{lang_part}.srt"

        target_file = os.path.join(target_folder, final_name)
        if os.path.exists(target_file):
            name_part, ext_part = os.path.splitext(final_name)
            counter = 1
            while os.path.exists(os.path.join(target_folder, f"{name_part}_{counter}{ext_part}")):
                counter += 1
            target_file = os.path.join(target_folder, f"{name_part}_{counter}{ext_part}")
            
        try:
            shutil.copyfile(sub_file, target_file)
        except:
            try:
                shutil.move(sub_file, target_file)
            except:
                pass

        # Σβήνουμε ΟΛΑ τα προσωρινά .srt από τον φάκελο του πρόσθετου ώστε να μη μείνει κανένα διπλό
        for leftover in downloaded_subs:
            try:
                if os.path.exists(leftover):
                    os.remove(leftover)
            except:
                pass

    for _ in range(3):
        if temp_video_file and os.path.exists(temp_video_file) and not temp_video_file.endswith('fake.mp4'):
            try:
                os.remove(temp_video_file)
                break
            except:
                xbmc.sleep(300)


def show_sub_manager_menu(clean_filename, target_folder, global_mode=False):
    dialog = xbmcgui.Dialog()
    existing_subs = glob.glob(os.path.join(target_folder, "*.srt"))
    existing_subs.sort(key=os.path.getmtime, reverse=True)
    
    # Εμφανίζουμε πάντα όλους τους αποθηκευμένους υπότιτλους του φακέλου 
    # (ταξινομημένους από τον πιο πρόσφατο στον πιο παλιό) για να μην χάνεται κανένας στα widgets
    movie_subs = existing_subs
    menu_title = "⚙️ Διαχείριση Υποτίτλων (Όλα τα Αρχεία)"

    while True:
        if not movie_subs:
            dialog.notification("Subtitle Manager", "Δεν βρέθηκαν τοπικοί υπότιτλοι.", xbmcgui.NOTIFICATION_INFO, 2000)
            break
            
        options = ["✖ [ Καθαρισμός Όλων των Αρχείων στον Φάκελο ]"]
        for sub in movie_subs:
            options.append(f"─  Διαγραφή: {os.path.basename(sub)}")
            
        choice = dialog.select(menu_title, options)
        if choice == -1: 
            break
        elif choice == 0:
            if dialog.yesno("Επιβεβαίωση Καθαρισμού", "Θέλετε να αδειάσετε ΟΛΟΚΛΗΡΟ τον φάκελο από όλους τους υπότιτλους;"):
                for sub in movie_subs:
                    try: os.remove(sub)
                    except: pass
                dialog.notification("Subtitle Manager", "Όλα τα αρχεία διαγράφηκαν!", xbmcgui.NOTIFICATION_INFO, 2000)
                break
        elif choice > 0:
            target_sub = movie_subs[choice - 1]
            try:
                if os.path.exists(target_sub): 
                    os.remove(target_sub)
                if target_sub in movie_subs:
                    movie_subs.remove(target_sub)
                dialog.notification("Subtitle Manager", "Ο υπότιτλος διαγράφηκε!", xbmcgui.NOTIFICATION_INFO, 1500)
            except: 
                pass
            xbmc.sleep(200)


def open_browser_subs(search_query):
    dialog = xbmcgui.Dialog()
    query_encoded = url_parse.quote(search_query) if search_query else ""
    
    names = [
        "[B][COLOR white]Subs4Free (Ταινίες)[/COLOR][/B]",
        "[B][COLOR white]Subs4Series (Σειρές)[/COLOR][/B]",
        "[B][COLOR white]GreekSubs[/COLOR][/B]",
        "[B][COLOR white]OpenSubtitles.org[/COLOR][/B]",
        "[B][COLOR white]Subtitles.gr[/COLOR][/B]",
        "[B][COLOR white]TVSubtitles[/COLOR][/B]",
        "[B][COLOR white]YTS-Subs[/COLOR][/B]"
    ]
    
    urls = [
        "https://subs4free.info",
        "https://subs4series.com",
        "https://greeksubs.net",
        "https://opensubtitles.org",
        "http://subtitles.gr",
        "https://tvsubtitles.net",
        "https://yts-subs.com"
    ]

    
    choice = dialog.select(f"Αναζήτηση σε Browser: {search_query}", names)
    
    if choice < 0:
        return
        
    selected_url = urls[choice]
    
    if search_query and xbmc.getCondVisibility('system.platform.windows'):
        try:
            import subprocess
            subprocess.run(['clip'], input=search_query.strip().encode('utf-16le'), check=True)
        except:
            pass
            
    dialog.notification("Browser Search", "Ο τίτλος αντιγράφηκε! Κατεβάστε το αρχείο -> LocalSubtitle", xbmcgui.NOTIFICATION_INFO, 4500)
    
    if xbmc.getCondVisibility('system.platform.android'):
        xbmc.executebuiltin(f'StartAndroidActivity(,android.intent.action.VIEW,,{selected_url})')
    elif xbmc.getCondVisibility('system.platform.windows'):
        try:
            os.startfile(selected_url)
        except:
            import webbrowser
            webbrowser.open(selected_url)
    else:
        import webbrowser
        webbrowser.open(selected_url)

def show_addon_info():
    dialog = xbmcgui.Dialog()
    active_folder_path = get_storage_path()

    info_text = (
        "[B][COLOR orange]AutoSniper Subtitle Manager[/COLOR][/B]\n\n"
        "[B]1. Αυτόματη Λήψη & Αποθήκευση:[/B]\n"
        "Επιλέξτε 'Αναζήτηση & Λήψη Υποτίτλων' για να ψάξετε σε όλους τους παρόχους. Μόλις πατήσετε έναν υπότιτλο, αυτός αποθηκεύεται αυτόματα στον φάκελο λήψεων με το σωστό όνομα.\n\n"
        "[B]2. Αν δεν βρεθεί υπότιτλος:[/B]\n"
        "Δοκιμάστε να αλλάξετε υπηρεσία από το μενού υπηρεσιών ([COLOR orange]a4kSubtitles  Subtitles.gr  Greek Subs[/COLOR]).\n\n"
        "[B]3. Αναζήτηση μέσω Browser (Έσχατη Λύση):[/B]\n"
        "Ανοίγει εξωτερικά sites υποτίτλων στον browser σας και αντιγράφει αυτόματα τον τίτλο της ταινίας/σειράς στη μνήμη (πατήστε Επικόλληση / Ctrl+V στην αναζήτηση του site). Αφού κατεβάσετε το αρχείο .srt, φορτώστε το μέσα στην ταινία από: Υπότιτλοι -> LocalSubtitle -> Browse.\n\n"
        "[B]4. Αλλαγή & Θέση Φακέλου Αποθήκευσης:[/B]\n"
        "Από την επιλογή 'Ρύθμιση Φακέλου Αποθήκευσης' μπορείτε να επιλέξετε οποιονδήποτε δικό σας φάκελο (π.χ. στην επιφάνεια εργασίας ή σε εξωτερικό δίσκο).\n"
        "• [B]Προεπιλεγμένος Φάκελος:[/B]\n"
        "Βρίσκεται μέσα στον φάκελο του πρόσθετου:\n"
        "[COLOR yellow]addons/context.subtitles.autosniper/download_subtitles[/COLOR]\n"
        "• [B]Ενεργός Φάκελος Αποθήκευσης:[/B]\n"
        f"[COLOR yellow]{active_folder_path}[/COLOR]\n\n"
        "[B]5. Διαχείριση & Καθαρισμός:[/B]\n"
        "Από το μενού 'Διαχείριση / Διαγραφή Υποτίτλων' μπορείτε να σβήσετε μεμονωμένα αρχεία ή να αδειάσετε όλο τον φάκελο αποθήκευσης."
    )
    dialog.textviewer("Πληροφορίες & Οδηγίες Χρήσης", info_text)

def main():
    global temp_video_file
    target_folder = get_storage_path()
    
    movie_title = ""
    for _ in range(10):
        # 1. Προτεραιότητα στα καθαρά πεδία της σειράς/ταινίας
        movie_title = xbmc.getInfoLabel('ListItem.TVShowTitle')
        if not movie_title:
            movie_title = xbmc.getInfoLabel('VideoPlayer.TVShowTitle')
        if not movie_title:
            movie_title = xbmc.getInfoLabel('ListItem.OriginalTitle')
        if not movie_title:
            movie_title = xbmc.getInfoLabel('ListItem.Title')
        if not movie_title:
            movie_title = xbmc.getInfoLabel('Container.FolderName')

        # Απορρίπτουμε ονόματα προσθέτων και γενικούς φακέλους
        bad_names = ['blacklodge', 'tmdb helper', 'tmdbhelper', 'themoviedb', 'plugin://', 'σεζόν', 'season']
        if any(bad in movie_title.lower() for bad in bad_names):
            movie_title = ""

        movie_year  = xbmc.getInfoLabel('ListItem.Year')
        imdb_id     = xbmc.getInfoLabel('ListItem.IMDBNumber')
        season      = xbmc.getInfoLabel('ListItem.Season')
        episode     = xbmc.getInfoLabel('ListItem.Episode')

        if movie_title != '':
            xbmc.sleep(100)
            break
        xbmc.sleep(50)

    is_settings_call = False
    if (
        xbmcgui.getCurrentWindowId() == 10001
        or not movie_title
        or movie_title == ''
        or ADDON_ID in movie_title
        or 'autosniper' in movie_title.lower()
        or movie_title == 'context.subtitlesdialog.contextmenu'
    ):
        is_settings_call = True

    if is_settings_call:
        dialog = xbmcgui.Dialog()
        app_options = [
            "✖  Καθολική Διαγραφή Υποτίτλων (Όλες οι Ταινίες)", 
            "⚙  Αλλαγή Φακέλου Αποθήκευσης",
            "↩  Επαναφορά Προεπιλεγμένου Φακέλου",
            "ℹ  Πληροφορίες & Οδηγίες Χρήσης"
        ]
        app_choice = dialog.select("AutoSniper: Διαχείριση & Ρυθμίσεις", app_options)
        if app_choice == 0:
            show_sub_manager_menu("", target_folder, global_mode=True)
        elif app_choice == 1:
            set_custom_storage_path()
        elif app_choice == 2:
            reset_storage_path_to_default()
        elif app_choice == 3:
            show_addon_info()
        return

    base_title = movie_title
    base_title = re.sub(r'^\d+x\d+\s*[\.\-\:]*\s*', '', base_title).strip()
    base_title = re.sub(r'(?i)^(sezon|season|epei?sodio|episode)\s*\d+\s*[\.\-\:]*\s*', '', base_title).strip()
    base_title = re.sub(r'^(Σεζόν|Επεισόδιο)\s*\d+\s*[\.\-\:]*\s*', '', base_title).strip()

    is_tv_show = season and episode and str(season) != '0' and str(episode) != '0' and str(season) != '' and str(episode) != ''
    if is_tv_show:
        search_string = f"{base_title} S{str(season).zfill(2)}E{str(episode).zfill(2)}"
    else:
        search_string = base_title

    search_string = " ".join(search_string.split()).strip()

    greek_to_english = {
        'α': 'a', 'β': 'b', 'γ': 'g', 'δ': 'd', 'ε': 'e', 'ζ': 'z', 'η': 'i', 'θ': 'th',
        'ι': 'i', 'κ': 'k', 'λ': 'l', 'μ': 'm', 'ν': 'n', 'ξ': 'x', 'ο': 'o', 'π': 'p',
        'ρ': 'r', 'σ': 's', 'ς': 's', 'τ': 't', 'υ': 'y', 'φ': 'f', 'χ': 'ch', 'ψ': 'ps', 'ω': 'o',
        'Α': 'A', 'Β': 'B', 'Γ': 'G', 'Δ': 'D', 'Ε': 'E', 'Ζ': 'Z', 'Η': 'I', 'Θ': 'Th',
        'Ι': 'I', 'Κ': 'K', 'Λ': 'L', 'Μ': 'M', 'Ν': 'N', 'Ξ': 'X', 'Ο': 'O', 'Π': 'P',
        'Ρ': 'R', 'Σ': 'S', 'Τ': 'T', 'Υ': 'Y', 'Φ': 'F', 'Χ': 'Ch', 'Ψ': 'Ps', 'Ω': 'O',
        'ά': 'a', 'έ': 'e', 'ή': 'i', 'ί': 'i', 'ό': 'o', 'ύ': 'y', 'ώ': 'o'
    }
    
    filename_parts = []
    for char in search_string:
        filename_parts.append(greek_to_english.get(char, char))
    clean_filename = "".join(filename_parts)
    clean_filename = re.sub(r'[^A-Za-z0-9\s\-_]', '', clean_filename)
    clean_filename = " ".join(clean_filename.split()).strip()

    if not clean_filename or clean_filename == '':
        clean_filename = "Series_Track"

    t = threading.Thread(target=run_os_checker, args=(base_title, movie_year, imdb_id, season, episode))
    t.daemon = True
    t.start()

    dialog = xbmcgui.Dialog()
    main_options = [
        "▶  Αναζήτηση & Λήψη Υποτίτλων",
        "◈  Αναζήτηση μέσω Browser (Εξωτερικά Sites)",
        "⚙  Ρύθμιση Φακέλου Αποθήκευσης",
        "↩  Επαναφορά Προεπιλεγμένου Φακέλου",
        "✖  Διαχείριση / Διαγραφή Υποτίτλων",
        "ℹ  Πληροφορίες & Οδηγίες Χρήσης"
    ]

    
    main_choice = dialog.select(f"Υπότιλοι: {search_string}", main_options)

    if main_choice == 1:
        open_browser_subs(base_title)
        return
    elif main_choice == 2:
        set_custom_storage_path()
        return
    elif main_choice == 3:
        reset_storage_path_to_default()
        return
    elif main_choice == 4:
        show_sub_manager_menu(clean_filename, target_folder, global_mode=False)
        return
    elif main_choice == 5:
        show_addon_info()
        return
    elif main_choice == -1:
        return

    addon_dir = os.path.dirname(os.path.abspath(__file__))
    base_fake_video = os.path.join(addon_dir, 'fake.mp4')
    if not os.path.exists(base_fake_video): return

    temp_video_file = os.path.join(addon_dir, f"{clean_filename}.mp4")
    try: shutil.copyfile(base_fake_video, temp_video_file)
    except: temp_video_file = base_fake_video

    list_item = xbmcgui.ListItem(search_string)
    list_item.setPath(temp_video_file)
    
    info_tag = list_item.getVideoInfoTag()
    info_tag.setTitle(base_title)
    info_tag.setOriginalTitle(base_title)
    
    if is_tv_show:
        info_tag.setMediaType('episode')
        info_tag.setTvShowTitle(base_title)
        info_tag.setSeason(int(season))
        info_tag.setEpisode(int(episode))
    else:
        info_tag.setMediaType('movie')
        
    if movie_year and movie_year.isdigit():
        info_tag.setYear(int(movie_year))
        
    if imdb_id and str(imdb_id).startswith('tt'):
        info_tag.setIMDBNumber(str(imdb_id))
        info_tag.setUniqueIDs({'imdb': str(imdb_id)}, 'imdb')

    tmdb_id = xbmc.getInfoLabel('ListItem.Property(tmdb_id)')
    if tmdb_id:
        info_tag.setUniqueIDs({'imdb': str(imdb_id), 'tmdb': str(tmdb_id)} if imdb_id else {'tmdb': str(tmdb_id)}, 'tmdb')

    xbmc.Player().play(temp_video_file, list_item, windowed=True)
    xbmc.sleep(200)
    
    if xbmc.Player().isPlayingVideo(): 
        xbmc.executebuiltin('PlayerControl(Pause)')
        xbmc.sleep(100)
        xbmc.executebuiltin('Dialog.Close(videoosd, true)')
        xbmc.executebuiltin('Dialog.Close(seekbar, true)')

    xbmcgui.Window(10000).setProperty('subtitles.searchstring', search_string)
    xbmcgui.Window(10000).setProperty('SubtitleSearchString', search_string)
    xbmcgui.Window(10000).setProperty('subtitles.filename', search_string)
    
    m = threading.Thread(target=auto_stop_and_move, args=(clean_filename,))
    m.daemon = True
    m.start()

    xbmc.executebuiltin('ActivateWindow(subtitlesearch)')

if __name__ == '__main__':
    main()
