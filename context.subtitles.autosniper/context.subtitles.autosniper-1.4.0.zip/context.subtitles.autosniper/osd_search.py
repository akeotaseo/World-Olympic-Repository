# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import xbmcvfs
import threading
import time
import os
import shutil
import glob
import re

def get_storage_path():
    addon_dir = os.path.dirname(os.path.abspath(__file__))
    config_file = os.path.join(addon_dir, 'path_config.txt')
    if os.path.exists(config_file):
        try:
            with open(config_file, 'r') as f:
                saved_path = f.read().strip()
                if saved_path:
                    translated_path = xbmcvfs.translatePath(saved_path)
                    if not os.path.exists(translated_path):
                        os.makedirs(translated_path)
                    return translated_path
        except:
            pass
    default_path = os.path.join(addon_dir, 'download_subtitles')
    if not os.path.exists(default_path):
        os.makedirs(default_path)
    return default_path

def watch_and_save_sub(fallback_name):
    addon_dir = os.path.dirname(os.path.abspath(__file__))
    temp_dir = xbmcvfs.translatePath('special://temp/')
    addon_data_dir = xbmcvfs.translatePath('special://userdata/addon_data/')
    icon_path = os.path.join(addon_dir, 'icon.png')
    
    start_time = time.time() - 2
    release_name = ""
    
    for _ in range(50):
        if xbmc.getCondVisibility('Window.IsActive(subtitlesearch)'):
            break
        xbmc.sleep(100)

    while xbmc.getCondVisibility('Window.IsActive(subtitlesearch)'):
        ui_label = xbmc.getInfoLabel('Container(120).ListItem.Label2')
        if not ui_label or ui_label == '' or ui_label.lower() in ['greek', 'english', 'el', 'en']:
            ui_label = xbmc.getInfoLabel('ListItem.Label2')
        if not ui_label or ui_label == '' or ui_label.lower() in ['greek', 'english', 'el', 'en']:
            temp_lbl = xbmc.getInfoLabel('Container(120).ListItem.Label')
            if temp_lbl and len(temp_lbl) > 10:
                ui_label = temp_lbl
                
        if ui_label and ui_label != '' and 'ListItem' not in ui_label and len(ui_label) > 4:
            release_name = ui_label
        xbmc.sleep(150)

    if xbmc.getCondVisibility('Player.Paused'):
        xbmc.executebuiltin('Action(Play)')

    xbmc.sleep(1500)
    
    search_patterns = [
        os.path.join(temp_dir, "*.srt"),
        os.path.join(addon_data_dir, "service.subtitles.*", "*.srt"),
        os.path.join(addon_data_dir, "service.subtitles.*", "*", "*.srt")
    ]
    
    recent_subs = []
    for pattern in search_patterns:
        for f in glob.glob(pattern):
            try:
                if os.path.getmtime(f) >= start_time:
                    recent_subs.append(f)
            except:
                pass

    if recent_subs:
        recent_subs.sort(key=os.path.getmtime, reverse=True)
        found_sub = next(iter(recent_subs), "")
        
        if found_sub and os.path.exists(found_sub):
            target_folder = get_storage_path()
            base_name = os.path.basename(found_sub)
            
            release_clean = ""
            if release_name and release_name.lower() not in ['greek', 'english']:
                clean_tags = re.sub(r'\[/?(?:COLOR|B|I|UPPERCASE|LOWERCASE|LIGHT|CR)[^\]]*\]', '', release_name, flags=re.IGNORECASE)
                clean_tags = re.sub(r'\(\s*\)|\[\s*\]', '', clean_tags)
                release_clean = "".join([c for c in clean_tags.strip() if c.isalpha() or c.isdigit() or c in [' ', '.', '-', '_', '+', '[', ']', '(', ')']]).strip()
                release_clean = " ".join(release_clean.split())
                release_clean = re.sub(r'(?i)(?:[\.\s]+(?:srt|txt|el|en))+$', '', release_clean).strip()

            if release_clean and not release_clean.isdigit() and len(release_clean) > 3:
                lang_part = ".el" if (".el." in base_name.lower() or "greek" in base_name.lower() or base_name.lower().endswith('.el.srt')) else (".en" if (".en." in base_name.lower() or "english" in base_name.lower()) else "")
                final_name = f"{release_clean}{lang_part}.srt"
            else:
                lang_part = ".el" if ("el" in base_name.lower() or "greek" in base_name.lower()) else ".en"
                final_name = f"{fallback_name}{lang_part}.srt"

            target_file = os.path.join(target_folder, final_name)
            if os.path.exists(target_file):
                name_part, ext_part = os.path.splitext(final_name)
                counter = 1
                while os.path.exists(os.path.join(target_folder, f"{name_part}_{counter}{ext_part}")):
                    counter += 1
                target_file = os.path.join(target_folder, f"{name_part}_{counter}{ext_part}")

            try:
                shutil.copyfile(found_sub, target_file)
                xbmcgui.Dialog().notification("AutoSniper", "Ο υπότιτλος αποθηκεύτηκε!", icon_path, 2500, False)
            except:
                pass

def main():
    xbmc.executebuiltin('Dialog.Close(videoosd, true)')
    xbmc.sleep(150)

    raw_title = xbmc.getInfoLabel('VideoPlayer.TVShowTitle') or xbmc.getInfoLabel('VideoPlayer.Title') or "Subtitle"
    fallback_name = re.sub(r'[^A-Za-z0-9\s\-_]', '', raw_title).strip() or "Subtitle"

    t = threading.Thread(target=watch_and_save_sub, args=(fallback_name,))
    t.daemon = True
    t.start()

    xbmc.executebuiltin('ActivateWindow(subtitlesearch)')

if __name__ == '__main__':
    main()
