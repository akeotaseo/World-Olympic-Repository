# -*- coding: utf-8 -*-
# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import xbmcvfs
import threading
import hashlib
import json
import urllib.request
import time
import os
import shutil
import glob
import re


SUB_EXTS = ("*.srt", "*.sub", "*.ass", "*.ssa")


def get_addon_dir():
    return os.path.dirname(os.path.abspath(__file__))


def get_addon_lang():
    lang_file = os.path.join(get_addon_dir(), 'lang_config.txt')
    if os.path.exists(lang_file):
        try:
            with open(lang_file, 'r', encoding='utf-8') as f:
                val = f.read().strip().lower()
                if val in ['el', 'en']:
                    return val
        except Exception:
            pass
    return "el"


def get_storage_path():
    addon_dir = get_addon_dir()
    config_file = os.path.join(addon_dir, 'path_config.txt')
    if os.path.exists(config_file):
        try:
            with open(config_file, 'r', encoding='utf-8') as f:
                saved_path = f.read().strip()
                if saved_path:
                    translated_path = xbmcvfs.translatePath(saved_path)
                    if not os.path.exists(translated_path):
                        os.makedirs(translated_path)
                    return translated_path
        except Exception:
            pass
    default_path = os.path.join(addon_dir, 'download_subtitles')
    if not os.path.exists(default_path):
        os.makedirs(default_path)
    return default_path


def get_file_hash(filepath):
    try:
        hasher = hashlib.md5()
        with open(filepath, 'rb') as f:
            hasher.update(f.read())
        return hasher.hexdigest()
    except Exception:
        return ""


def save_unique_subtitle(src_file, target_folder, final_name):
    src_hash = get_file_hash(src_file)
    if src_hash:
        for ext in SUB_EXTS:
            for existing in glob.glob(os.path.join(target_folder, ext)):
                if os.path.abspath(existing) == os.path.abspath(src_file):
                    continue
                if get_file_hash(existing) == src_hash:
                    return "duplicate", os.path.basename(existing)

    target_file = os.path.join(target_folder, final_name)
    if os.path.abspath(src_file) == os.path.abspath(target_file):
        return "duplicate", os.path.basename(target_file)

    if os.path.exists(target_file):
        name_part, ext_part = os.path.splitext(final_name)
        counter = 2
        while os.path.exists(os.path.join(target_folder, f"{name_part}_{counter}{ext_part}")):
            counter += 1
        target_file = os.path.join(target_folder, f"{name_part}_{counter}{ext_part}")

    shutil.copyfile(src_file, target_file)
    return "saved", os.path.basename(target_file)


def clean_search_title(raw):
    if not raw:
        return ""
    txt = re.sub(r'\[/?[^\]]+\]', '', raw)
    txt = re.sub(r'(?i)\b(official|trailer|teaser|hd|4k|1080p|720p|full\s*movie|clips?|scenes?)\b', '', txt)
    txt = re.sub(r'[\(\[\{].*?[\)\]\}]', '', txt)
    txt = re.sub(r'[\\/*?:"<>|\-–:|]', ' ', txt)
    txt = " ".join(txt.split()).strip()
    return txt


def clean_release_title(raw_release):
    if not raw_release:
        return ""
    clean_tags = re.sub(
        r'\[/?(?:COLOR|B|I|UPPERCASE|LOWERCASE|LIGHT|CR)[^\]]*\]',
        '',
        raw_release,
        flags=re.IGNORECASE
    )
    clean_tags = clean_tags.replace('\r', ' ').replace('\n', ' ')
    clean_tags = re.sub(r'\(\s*\)|\[\s*\]', '', clean_tags)
    clean_tags = re.sub(r'[\\/*?:"<>|]', '', clean_tags).strip()
    clean_tags = " ".join(clean_tags.split())
    clean_tags = re.sub(r'(?i)(?:[\.\s]+(?:srt|sub|ass|ssa|txt|el|en))+$', '', clean_tags).strip()
    if len(clean_tags) > 3 and not clean_tags.isdigit():
        return clean_tags
    return ""


def watch_and_save_sub(fallback_name):
    lang = get_addon_lang()
    addon_dir = get_addon_dir()
    kodi_subs_dir = xbmcvfs.translatePath('special://home/userdata/subs/')
    temp_dir = xbmcvfs.translatePath('special://temp/')
    addon_data_dir = xbmcvfs.translatePath('special://userdata/addon_data/')
    target_folder = get_storage_path()
    icon_path = os.path.join(addon_dir, 'icon.png')

    release_name = ""

    for _ in range(60):
        if xbmc.getCondVisibility('Window.IsActive(subtitlesearch)'):
            break
        xbmc.sleep(100)

    click_time = time.time() - 3.0

    while xbmc.getCondVisibility('Window.IsActive(subtitlesearch)'):
        click_time = time.time() - 3.0
        lbl2 = xbmc.getInfoLabel('Container(120).ListItem.Label2')
        lbl1 = xbmc.getInfoLabel('Container(120).ListItem.Label')
        for cand in (lbl2, lbl1):
            if not cand or 'ListItem' in cand:
                continue
            clean_c = re.sub(r'\[/?[^\]]+\]', '', cand).replace('\r', ' ').replace('\n', ' ').strip()
            if clean_c and len(clean_c) > 4 and clean_c.lower() not in ['greek', 'english', 'el', 'en', 'ελληνικά', 'αγγλικά']:
                release_name = clean_c
                break
        xbmc.sleep(100)

    search_dirs = [
        target_folder,
        kodi_subs_dir,
        temp_dir,
        os.path.join(addon_data_dir, "service.subtitles.*"),
        os.path.join(addon_data_dir, "service.subtitles.*", "*")
    ]

    recent_subs = []
    for _ in range(20):
        xbmc.sleep(250)
        recent_subs = []
        for s_dir in search_dirs:
            for ext in SUB_EXTS:
                for f in glob.glob(os.path.join(s_dir, ext)):
                    try:
                        if os.path.getmtime(f) >= click_time:
                            recent_subs.append(f)
                    except Exception:
                        pass
        if recent_subs:
            xbmc.sleep(500)
            break

    if recent_subs:
        recent_subs.sort(
            key=lambda f: (os.path.dirname(f) in [target_folder, kodi_subs_dir], os.path.getmtime(f)),
            reverse=True
        )
        found_sub = recent_subs.pop(0)

        if found_sub and os.path.exists(found_sub):
            base_name = os.path.basename(found_sub)
            _, ext_raw = os.path.splitext(base_name)
            file_ext = ext_raw.lower() or ".srt"

            chosen_title = clean_release_title(release_name) or fallback_name

            if ".el." in base_name.lower() or "greek" in base_name.lower() or base_name.lower().endswith(f'.el{file_ext}'):
                lang_part = ".el"
            elif ".en." in base_name.lower() or "english" in base_name.lower() or base_name.lower().endswith(f'.en{file_ext}'):
                lang_part = ".en"
            else:
                lang_part = ""

            final_name = f"{chosen_title}{lang_part}{file_ext}"

            try:
                status, saved_name = save_unique_subtitle(found_sub, target_folder, final_name)
                if status == "duplicate":
                    dup_prefix = "Already exists" if lang == "en" else "Υπάρχει ήδη"
                    xbmcgui.Dialog().notification("AutoSniper", f"{dup_prefix}: {saved_name}", icon_path, 2500, False)
                else:
                    saved_prefix = "Saved" if lang == "en" else "Αποθηκεύτηκε"
                    xbmcgui.Dialog().notification("AutoSniper", f"{saved_prefix}: {saved_name}", icon_path, 2500, False)
            except Exception:
                pass


def resolve_english_title(current_title):
    kodi_lang = xbmc.getInfoLabel('System.Language').lower()
    is_non_english_ui = kodi_lang and not kodi_lang.startswith('english')

    if not re.search(r'[^\x00-\x7F]', current_title) and not is_non_english_ui:
        return current_title

    cached_en = xbmcgui.Window(10000).getProperty('autosniper.last_en_title')
    if cached_en and not re.search(r'[^\x00-\x7F]', cached_en):
        return cached_en

    imdb_id = (
        xbmc.getInfoLabel('ListItem.Property(tvshow.imdb_id)')
        or xbmc.getInfoLabel('VideoPlayer.IMDBNumber')
        or xbmc.getInfoLabel('ListItem.IMDBNumber')
        or xbmc.getInfoLabel('ListItem.Property(imdb_id)')
    )
    if imdb_id and str(imdb_id).startswith('tt'):
        host = "v3-cinemeta" + ".strem.io"
        for m_type in ('series', 'movie'):
            try:
                url = "https://" + host + "/meta/" + m_type + "/" + str(imdb_id) + ".json"
                req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
                with urllib.request.urlopen(req, timeout=3.0) as resp:
                    data = json.loads(resp.read().decode('utf-8'))
                    en_name = data.get('meta', {}).get('name', '').strip()
                    if en_name:
                        return en_name
            except Exception:
                pass
    return current_title


def main():
    xbmc.executebuiltin('Dialog.Close(videoosd, true)')
    xbmc.sleep(150)

    season = xbmc.getInfoLabel('VideoPlayer.Season') or xbmc.getInfoLabel('ListItem.Season')
    episode = xbmc.getInfoLabel('VideoPlayer.Episode') or xbmc.getInfoLabel('ListItem.Episode')
    is_tv = season and episode and str(season) != '0' and str(episode) != '0'

    if is_tv:
        raw_title = (
            xbmc.getInfoLabel('ListItem.Property(tvshow.originaltitle)')
            or xbmc.getInfoLabel('VideoPlayer.OriginalTitle')
            or xbmc.getInfoLabel('ListItem.OriginalTitle')
            or xbmc.getInfoLabel('VideoPlayer.TVShowTitle')
            or xbmc.getInfoLabel('ListItem.TVShowTitle')
            or xbmc.getInfoLabel('VideoPlayer.Title')
            or "Subtitle"
        )
    else:
        raw_title = (
            xbmc.getInfoLabel('VideoPlayer.OriginalTitle')
            or xbmc.getInfoLabel('ListItem.OriginalTitle')
            or xbmc.getInfoLabel('VideoPlayer.Title')
            or "Subtitle"
        )

    base_title = re.split(r'\s*[\-\–\:]\s*(?:s\d+[eε]\d+|\d+x\d+)', raw_title, flags=re.IGNORECASE).pop(0).strip()
    base_title = resolve_english_title(base_title)
    clean_base = clean_search_title(base_title) or "Subtitle"

    if is_tv:
        s_pad = str(season).zfill(2)
        e_pad = str(episode).zfill(2)
        clean_query = f"{clean_base} S{s_pad}E{e_pad}"
    else:
        clean_query = clean_base

    fallback_name = re.sub(r'[^A-Za-z0-9\s\-_]', '', clean_query).strip() or "Subtitle"

    try:
        player = xbmc.Player()
        if player.isPlayingVideo():
            playing_item = player.getPlayingItem()
            info_tag = playing_item.getVideoInfoTag()
            info_tag.setOriginalTitle(clean_base)
            if is_tv:
                info_tag.setTvShowTitle(clean_base)
                info_tag.setTitle(clean_query)
            else:
                info_tag.setTitle(clean_base)
            player.updateInfoTag(playing_item)
    except Exception:
        pass

    xbmcgui.Window(10000).setProperty('subtitles.searchstring', clean_query)
    xbmcgui.Window(10000).setProperty('SubtitleSearchString', clean_query)

    t = threading.Thread(target=watch_and_save_sub, args=(fallback_name,))
    t.daemon = True
    t.start()

    xbmc.executebuiltin('ActivateWindow(subtitlesearch)')


if __name__ == '__main__':
    main()
