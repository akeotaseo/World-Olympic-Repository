import xbmc, xbmcgui


def Realdebrid():
    funcs = (click_1, click_2, click_3)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]~ Real Debrid / URL Resolver ~[/COLOR][/B]', 
['[B][COLOR=white]Foto[/COLOR][/B]',

 '[B][COLOR=white]video[/COLOR][/B]',

 '[B][COLOR=white]Site[/COLOR][/B]',
  ])


    if call:
        if call < 0:
            return
        func = funcs[call-3]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('ActivateWindow(10002,"special://home/media/ResolveURL/",return)')

def click_2():
    xbmc.executebuiltin('PlayMedia("plugin://plugin.video.duffyou/?eydhY3Rpb24nOiAncGxheScsICdhdXRob3JfaWQnOiAnVUNJblA2ZzZ0LUpaTzZXd0VZQzRMXzB3JywgJ2F1dGhvcl9uYW1lJzogJ01LQl91aycsICdkdXJhdGlvbic6IDMxNCwgJ2ZhbmFydCc6ICdDOlxcUG9ydGFibGVBcHBzXFxrb2RpXFxrb2RpIFdvcmxkIDIwXFxLb2RpXFxwb3J0YWJsZV9kYXRhXFxhZGRvbnNcXHBsdWdpbi52aWRlby5kdWZmeW91XFxmYW5hcnQuanBnJywgJ2ljb24nOiAnQzpcXFBvcnRhYmxlQXBwc1xca29kaVxca29kaSBXb3JsZCAyMFxcS29kaVxccG9ydGFibGVfZGF0YVxcYWRkb25zXFxwbHVnaW4udmlkZW8uZHVmZnlvdVxccmVzb3VyY2VzXFxtZWRpYVxcbmV3X3NlYXJjaC5wbmcnLCAnaWQnOiAnSHJaY3RPUEd2ZE0nLCAnaXNQbGF5YWJsZSc6IFRydWUsICdsYWJlbCc6ICdIb3cgdG8gYWRkIFJlYWwgRGVicmlkIHRvIFVSTCBSZXNvbHZlciBpbiBLb2RpLCBTUE1DIGFuZCBhbGwgS29kaSBmb3Jrcy4nLCAncGFnZSc6IDEsICdwbG90JzogJ0hvdyB0byBhZGQgUmVhbCBEZWJyaWQgdG8gVVJMIFJlc29sdmVyIGluIEtvZGksIFNQTUMgYW5kIGFsbCBLb2RpIGZvcmtzLltDUl1bQ1JdTUtCX3VrW0NSXVtDUl0nLCAncXVlcnknOiAnaHR0cHM6Ly93d3cueW91dHViZS5jb20vd2F0Y2g/dj1IclpjdE9QR3ZkTScsICd0aHVtYic6ICdodHRwczovL2ludmlkaW91cy5zbm9weXRhLm9yZy92aS9IclpjdE9QR3ZkTS9ocWRlZmF1bHQuanBnJywgJ3RpcG8nOiAndmlkZW8nfQ%3D%3D")')

def click_3():
    xbmc.executebuiltin('RunScript("script.realdebridsite")')


Realdebrid()
