import xbmc, xbmcgui


def CheckFix():
    funcs = (click_1, click_2)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]~ Check Fix ~[/COLOR][/B]', 
['Check Fix [COLOR=red]delete_files[/COLOR]',
 'Check Fix [COLOR=green]addons_list_installation[/COLOR]'])


    if call:
        if call < 0:
            return
        func = funcs[call-2]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('RunScript("special://home/userdata/addon_data/plugin.program.downloader19/delete_files.py")')

def click_2():
    xbmc.executebuiltin('RunScript("special://home/userdata/addon_data/plugin.program.downloader19/addons_list_installation.py")')




CheckFix()
