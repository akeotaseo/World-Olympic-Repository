import xbmc, xbmcgui


def SelectResolveurl():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7, click_8, click_9, click_10, click_11, click_12, click_13)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]  ~ Resolveurl ~[/COLOR][/B]', 
['[B]ResolveURL[/B] : Settings',
 '[COLOR=red]Διαγραφή[/COLOR] addon_data Resolveurl',
 'Εξουσιοδότηση - Επαναφορά Derbid',
 #'[B][COLOR=orange]UpdaterMatrix_4[/COLOR][/B]  Fix Arrow repository',
 #'[B][COLOR=orange]UpdaterMatrix_5[/COLOR][/B]  Εισαγωγή (νέων) διακομιστών του PvrStalker',
 #'[B][COLOR=orange]UpdaterMatrix_6[/COLOR][/B]  TheMovieDb Helper (Up & Players)',
 #'[B][COLOR=red]Tools[/COLOR][/B]',
 #'[B][COLOR=orange]UpdaterMatrix_7[/COLOR][/B]  Διάφορα Fix',
 #'[B][COLOR=orange]UpdaterMatrix_8[/COLOR][/B]  (Fix & skin menu & HomeWidget On)',
 #'[B][COLOR=orange]UpdaterMatrix_9[/COLOR][/B]  Fix Addons33.db',
 #'[B][COLOR=orange]UpdaterMatrix_10[/COLOR][/B]  test',
 #'[B][COLOR=orange]HomeWidget  [COLOR=red]OFF[/COLOR][/B]',
 #'[B][COLOR=orange]Run Downloader Startup[/COLOR][/B]  *if path exists',
 ])


    if call:
        if call < 0:
            return
        func = funcs[call-13]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('PlayMedia("plugin://plugin.video.blacklodge/?action=smuSettings")')

def click_2():
    xbmc.executebuiltin('RunScript("special://home/addons/service.World.Build/service.downloaderstartup/PY/Resolveurl/ResolveurlDialog.py")')

def click_3():
    xbmc.executebuiltin('RunScript("special://home/addons/service.World.Build/service.downloaderstartup/PY/Resolveurl/derbid_authorize.py")')

def click_4():
    xbmc.executebuiltin('RunScript("special://home/addons/service.World.Build/service.downloaderstartup/UpdaterMatrix_4.py")')
    
def click_5():
    xbmc.executebuiltin('RunScript("special://home/addons/service.World.Build/service.downloaderstartup/UpdaterMatrix_5.py")')

def click_6():
    xbmc.executebuiltin('RunScript("special://home/addons/service.World.Build/service.downloaderstartup/UpdaterMatrix_6.py")')
    
def click_7():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.autowidget/folders/py/Programs.py")')

def click_8():
    xbmc.executebuiltin('RunScript("special://home/addons/service.World.Build/service.downloaderstartup/UpdaterMatrix_7.py")')

def click_9():
    xbmc.executebuiltin('RunScript("special://home/addons/service.World.Build/service.downloaderstartup/UpdaterMatrix_8.py")')

def click_10():
    xbmc.executebuiltin('RunScript("special://home/addons/service.World.Build/service.downloaderstartup/UpdaterMatrix_9.py")')

def click_11():
    xbmc.executebuiltin('RunScript("special://home/addons/service.World.Build/service.downloaderstartup/UpdaterMatrix_10.py")')

def click_12():
    xbmc.executebuiltin('RunScript("special://home/addons/service.World.Build/service.downloaderstartup/UpdaterMatrix_100.py")')

def click_13():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloader19/downloader_startup.py")')

SelectResolveurl()
