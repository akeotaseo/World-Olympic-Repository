﻿import xbmc, xbmcgui


def DialogeNotifyWorld():
        
        choice = xbmcgui.Dialog().yesno('[COLOR orange]Notify World[/COLOR]', '[COLOR white]Ανά (οχι και τόσο τακτά...) χρονικά διαστήματα προτείνεται[COLOR green] Γενικός καθαρισμός[/COLOR][CR](Επαναφορά μνήμης ResolverURL, Καθαρισμός Παρόχων, Thumbnails, Packages, temp)[CR][COLOR orange]Θέλετε να τον κάνετε τώρα ;[/COLOR]',
                                        nolabel='[COLOR red]Μπααα.. άλλη φορά[/COLOR]',yeslabel='[COLOR green]Ναι[/COLOR]')

        if choice == 1: [xbmc.executebuiltin('RunScript("special://home/addons/service.World.Build/PY/Tools/NotifyWorld/TotalCleanUpAll.py")'),
                         ]
                         

DialogeNotifyWorld()
