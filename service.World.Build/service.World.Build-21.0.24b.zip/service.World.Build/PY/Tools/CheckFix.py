import xbmc, xbmcgui


def CheckFix():
    funcs = (click1, click2, click3, click4, click5, click6)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]~ Check Fix ~[/COLOR][/B]', 

[ '[B][COLOR=white][B][COLOR grey]Fix build update [/COLOR][/B]',
  '[COLOR blue][B]gui fix [/B][/COLOR]',

 'Check Fix [COLOR=red]delete_files[/COLOR]',
 'Check Fix [COLOR=green]addons_list_installation[/COLOR]',
 'Check Fix [COLOR=orange]Database_Addons33[/COLOR]',
 
 '[COLOR yellow][B]NemesisAio[/COLOR] [B]Fix [/B]'])


    if call:
        if call < 0:
            return
        func = funcs[call-6]
        return func()
    else:
        func = funcs[call]
        return func()
    return 





def click1():
    xbmc.executebuiltin('RunScript("special://home/addons/service.World.Build/PY/FixBuildOLD.py")')

def click2():
    xbmc.executebuiltin('RunScript("special://home/addons/service.World.Build/PY/Tools/guifix.py")')

def click3():
    xbmc.executebuiltin('RunScript("special://home/userdata/addon_data/plugin.program.downloader19/delete_files.py")')

def click4():
    xbmc.executebuiltin('RunScript("special://home/userdata/addon_data/plugin.program.downloader19/addons_list_installation.py")')

def click5():
    xbmc.executebuiltin('RunScript("special://home/addons/service.World.Build/PY/Tools/Database_Addons33_Fix.py")')

def click6():
    xbmc.executebuiltin('RunScript("special://home/addons/service.World.Build/PY/Tools/StreamArmy.py")')

CheckFix()
