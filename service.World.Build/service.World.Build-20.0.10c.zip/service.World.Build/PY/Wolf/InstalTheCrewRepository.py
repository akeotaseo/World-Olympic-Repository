import os, xbmc, xbmcgui

def InstalTheCrewRepository():
        choice = xbmcgui.Dialog().yesno('[COLOR orange]World-Repo Repository[/COLOR]', '[COLOR white]Αν έχετε απεγκαταστήσει το [B][COLOR purple]THE CREW REPO[/COLOR][/B] κάντε το ξανά εγκατάσταση',
                                        nolabel='[COLOR orange]Άκυρο[/COLOR]',yeslabel='[COLOR purple]Εγκατάσταση[/COLOR]')

        if choice == 1: xbmc.executebuiltin('RunScript("special://home/addons/service.World.Build/service.downloaderstartup/InstalTheCrewRepositoryNow.py")')

InstalTheCrewRepository()