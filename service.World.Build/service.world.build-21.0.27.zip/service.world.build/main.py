﻿import os, xbmc, xbmcgui, xbmcvfs


def Installer_Binary_Addons():
    funcs = (action_1, action_2, action_3, action_4, action_5, action_6, action_7)
    selection = xbmcgui.Dialog().select('[B][COLOR=orange]Εγκατάσταση Binary Addons[/COLOR][/B]', 
['[B][COLOR=white]SFTP support[/COLOR][/B]',
 '[B][COLOR=white]Rar archive support[/COLOR][/B]',
 '[B][COLOR=white]Archive support[/COLOR][/B]',
 '[B][COLOR=white]Inputstream Adaptive[/COLOR][/B]',
 '[B][COLOR=white]RTMP Input[/COLOR][/B]',
 '[B][COLOR=white]Inputstream FFmpeg Direct[/COLOR][/B]',
 '[B][COLOR=white]Spectrum[/COLOR][/B]'])

    if selection:
        if selection < 0:
            return 
        func = funcs[selection-7]
        return func()
    else:
        func = funcs[selection]
        return func()
    return 

def action_1():
    xbmc.executebuiltin('InstallAddon(vfs.sftp)')
    xbmc.sleep(100)
    xbmc.executebuiltin('SendClick(11)')
    addon_path = xbmcvfs.translatePath('special://home/addons')
    if xbmc.getCondVisibility('System.HasAddon({})'.format('vfs.sftp')): xbmcgui.Dialog().notification("[B][COLOR orange]World Build Service[/COLOR][/B]", "[COLOR white]Είναι ήδη εγκατεστημένο![/COLOR]", icon='special://home/addons/service.World.Build/icon.png', sound=True)


def action_2():
    xbmc.executebuiltin('InstallAddon(vfs.rar)')
    xbmc.sleep(100)
    xbmc.executebuiltin('SendClick(11)')
    if xbmc.getCondVisibility('System.HasAddon({})'.format('vfs.rar')): xbmcgui.Dialog().notification("[B][COLOR orange]World Build Service[/COLOR][/B]", "[COLOR white]Είναι ήδη εγκατεστημένο![/COLOR]", icon='special://home/addons/service.World.Build/icon.png', sound=True)


def action_3():
    xbmc.executebuiltin('InstallAddon(vfs.libarchive)')
    xbmc.sleep(100)
    xbmc.executebuiltin('SendClick(11)')
    if xbmc.getCondVisibility('System.HasAddon({})'.format('vfs.libarchive')): xbmcgui.Dialog().notification("[B][COLOR orange]World Build Service[/COLOR][/B]", "[COLOR white]Είναι ήδη εγκατεστημένο![/COLOR]", icon='special://home/addons/service.World.Build/icon.png', sound=True)


def action_4():
    xbmc.executebuiltin('InstallAddon(inputstream.adaptive)')
    xbmc.sleep(100)
    xbmc.executebuiltin('SendClick(11)')
    if xbmc.getCondVisibility('System.HasAddon({})'.format('inputstream.adaptive')): xbmcgui.Dialog().notification("[B][COLOR orange]World Build Service[/COLOR][/B]", "[COLOR white]Είναι ήδη εγκατεστημένο![/COLOR]", icon='special://home/addons/service.World.Build/icon.png', sound=True)



def action_5():
    xbmc.executebuiltin('InstallAddon(inputstream.rtmp)')
    xbmc.sleep(100)
    xbmc.executebuiltin('SendClick(11)')
    if xbmc.getCondVisibility('System.HasAddon({})'.format('inputstream.rtmp')): xbmcgui.Dialog().notification("[B][COLOR orange]World Build Service[/COLOR][/B]", "[COLOR white]Είναι ήδη εγκατεστημένο![/COLOR]", icon='special://home/addons/service.World.Build/icon.png', sound=True)


def action_6():
    xbmc.executebuiltin('InstallAddon(inputstream.ffmpegdirect)')
    xbmc.sleep(100)
    xbmc.executebuiltin('SendClick(11)')
    if xbmc.getCondVisibility('System.HasAddon({})'.format('inputstream.ffmpegdirect')): xbmcgui.Dialog().notification("[B][COLOR orange]World Build Service[/COLOR][/B]", "[COLOR white]Είναι ήδη εγκατεστημένο![/COLOR]", icon='special://home/addons/service.World.Build/icon.png', sound=True)

def action_7():
    xbmc.executebuiltin('InstallAddon(visualization.spectrum)')
    xbmc.sleep(100)
    xbmc.executebuiltin('SendClick(11)')
    if xbmc.getCondVisibility('System.HasAddon({})'.format('visualization.spectrum')): xbmcgui.Dialog().notification("[B][COLOR orange]World Build Service[/COLOR][/B]", "[COLOR white]Είναι ήδη εγκατεστημένο![/COLOR]", icon='special://home/addons/service.World.Build/icon.png', sound=True)

Installer_Binary_Addons()

