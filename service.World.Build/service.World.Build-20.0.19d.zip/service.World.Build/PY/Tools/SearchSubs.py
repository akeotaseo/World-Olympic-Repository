import xbmc, xbmcgui, webbrowser


def SearchSubs():
    dialog = xbmcgui.Dialog()
    funcs = (site1, site2, site3, site4, site5, site6, site7, site8, site9, site10, site11)
    xbmcgui.Dialog().ok("[B][COLOR orange]SearchSubs[/COLOR][/B]", "[B][COLOR white]Κατεβάζουμε τους υπότιτλους που επιθυμούμε σε ένα φάκελο και στη συνέχεια τους εισάγουμε από την επιλογή - LocalSubtitle -> [COLOR orange]Browse...[/COLOR][/B]")
    call = dialog.select('[B][COLOR=orange]Αναζήτηση υπότιτλων σε ιστότοπους...[/COLOR][/B]',
    
['[B][COLOR=white]Subs4Free[/COLOR][/B]',
 '[B][COLOR=white]Subs4Series[/COLOR][/B]',
 '[B][COLOR=white]Greeksubs[/COLOR][/B]',
 '[B][COLOR=white]Opensubtitles[/COLOR][/B]',
 '[B][COLOR=white]TVsubtitles[/COLOR][/B]',
 '[B][COLOR=white]Podnapisi[/COLOR][/B]',
 '[B][COLOR=white]Yifysubtitles[/COLOR][/B]',
 '[B][COLOR=white]vipsubs[/COLOR][/B]',
 '[B][COLOR=white]xsubs[/COLOR][/B]',
 '[B][COLOR=white]subtitles.gr[/COLOR][/B]',
 '[B][COLOR=white]subzworld[/COLOR][/B]'])

    if call:
        if call < 0:
            return
        func = funcs[call-11]
        return func()
    else:
        func = funcs[call]
        return func()
    return 

def platform():
    if xbmc.getCondVisibility('system.platform.android'):
        return 'android'
    elif xbmc.getCondVisibility('system.platform.linux'):
        return 'linux'
    elif xbmc.getCondVisibility('system.platform.windows'):
        return 'windows'
    elif xbmc.getCondVisibility('system.platform.osx'):
        return 'osx'
    elif xbmc.getCondVisibility('system.platform.atv2'):
        return 'atv2'
    elif xbmc.getCondVisibility('system.platform.ios'):
        return 'ios'

myplatform = platform()


def site1():
    if myplatform == 'android': opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.subs4free.info/' ) )
    else: opensite = webbrowser . open('https://www.subs4free.info/')

def site2():
    if myplatform == 'android': opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.subs4series.com/' ) )
    else: opensite = webbrowser . open('https://www.subs4series.com/')

def site3():
    if myplatform == 'android': opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://greeksubs.net/' ) )
    else: opensite = webbrowser . open('https://greeksubs.net/')

def site4():
    if myplatform == 'android': opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.opensubtitles.org/el' ) )
    else: opensite = webbrowser . open('https://www.opensubtitles.org/el')

def site5():
    if myplatform == 'android': opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'http://www.tvsubtitles.net/' ) )
    else: opensite = webbrowser . open('http://www.tvsubtitles.net/')

def site6():
    if myplatform == 'android': opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.podnapisi.net/' ) )
    else: opensite = webbrowser . open('https://www.podnapisi.net/')

def site7():
    if myplatform == 'android': opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://yts-subs.com/' ) )
    else: opensite = webbrowser . open('https://yts-subs.com/')

def site8():
    if myplatform == 'android': opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://vipsubs.gr/' ) )
    else: opensite = webbrowser . open('https://vipsubs.gr/')     

def site9():
    if myplatform == 'android': opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'http://www.xsubs.tv/xforum/' ) )
    else: opensite = webbrowser . open('http://www.xsubs.tv/xforum/') 

def site10():
    if myplatform == 'android': opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'http://www.subtitles.gr/' ) )
    else: opensite = webbrowser . open('http://www.subtitles.gr/')

def site11():
    if myplatform == 'android': opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'http://subzworld.tv/' ) )
    else: opensite = webbrowser . open('http://subzworld.tv/')

SearchSubs()
