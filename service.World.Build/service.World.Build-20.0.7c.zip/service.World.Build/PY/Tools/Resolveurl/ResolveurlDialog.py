﻿import os, xbmc, xbmcvfs, xbmcgui, xbmcaddon, shutil, glob

def fixbuildin():
        choice = xbmcgui.Dialog().yesno('[COLOR orange]Διαγραφή addon_data Resolveurl[/COLOR]', 'Με αυτή την επιλογή θα διαγραφούν οι ρυθμίσεις του [COLOR orange]Resolveurl[/COLOR]',
                                        nolabel='[B][COLOR white]Άκυρο...[/COLOR][/B]',yeslabel='[B][COLOR green]Διαγραφή[/COLOR][/B]')

        if choice == 1: [xbmc.executebuiltin('RunScript("special://home/addons/service.World.Build/service.downloaderstartup/PY/Resolveurl/ResolveurlDel.py")'),
                         xbmc.sleep(1000),
                         xbmc.executebuiltin('PlayMedia("plugin://plugin.video.blacklodge/?action=smuSettings")'),
                         xbmc.sleep(1000),
                         xbmc.executebuiltin('RunScript("special://home/addons/service.World.Build/PY/Tools/TempDelete/temp_Delete.py")'),
                         
                         #xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloader19/resources/PY/AutowidgetDelFix.py")'),
                         #xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloader19/resources/PY/InstallAutowidget.py")'),
                         #xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloader19/resources/PY/ThemoviedbhelperDel.py")'),
                         #xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloader19/resources/PY/temp_DeletelFix.py")'),
                         #xbmcgui.Dialog().notification("[B][COLOR orange]Διαγραφή με επιτυχία ![/COLOR][/B]", "[COLOR white]Αναμονή για Reload Profile...[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/rp.png'),
                         #xbmc.executebuiltin('RunPlugin(plugin://plugin.program.G.K.N.Wizard/?mode=forceprofile)'),
                         #xbmc.sleep(2000),
                         #xbmcgui.Dialog().notification("[B][COLOR orange]Reload Profile[/COLOR][/B]", "[COLOR white]Παρακαλώ περιμένετε...[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/reloadprofile.png'),
                         ]

fixbuildin()
