﻿import os, xbmc, xbmcvfs, xbmcgui


def favourites_delete():
        choice = xbmcgui.Dialog().yesno('[COLOR orange]Διαγραφή αγαπημένων[/COLOR]', '[COLOR white]Με αυτή την επιλογή θα διαγραφούν[COLOR red] ΟΛΕΣ[/COLOR] οι συντομεύσεις των αγαπημένων και θα πραγματοποιηθεί επαναφόρτωση του προφίλ, με αποτέλεσμα να παγώσει για λίγα δευτερόλεπτα η εικόνα.[CR][CR]Θέλετε να συνεχίσετε ?[/COLOR]',
                                        nolabel='[B][COLOR white]Όχι[/COLOR][/B]',yeslabel='[B][COLOR white]Ναι[/COLOR][/B]')

        if choice == 1: [xbmcvfs.delete('special://home/userdata/favourites.xml'), xbmcgui.Dialog().notification("[B][COLOR orange]Διαγραφή αγαπημένων με επιτυχία ![/COLOR][/B]",
                         "[COLOR white]Αναμονή για Reload Profile...[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/clean.png'), xbmc.sleep(6000),
                           xbmc.executebuiltin('RunPlugin(plugin://plugin.program.G.K.N.Wizard/?mode=forceprofile)')]


favourites_delete()
