﻿import os, xbmc, xbmcvfs, xbmcgui, xbmcaddon, shutil, glob

def DialogCocoScrapers():
        choice = xbmcgui.Dialog().yesno('[B][COLOR orange]CocoScrapers[/COLOR][/B]', 'Για να λειτουργήσουν τα πρόσθετα [B][COLOR white]Umbrella, Fen κ.α[/COLOR][/B][CR]πρέπει να γίνει εγκατάσταση των[CR][B]CocoScrapers[/B][CR]Για να συνεχίσετε πατήστε [B][COLOR orange]CocoScrapers[/COLOR][/B][CR]',
                                        nolabel='[B][COLOR white]Πίσω[/COLOR][/B]',yeslabel='[B][COLOR orange]CocoScrapers[/COLOR][/B]')

        if choice == 1: [xbmc.executebuiltin('RunScript("special://home/addons/service.World.Build/PY/CocoScrapers/InstalCocoScrapers.py")'),]

DialogCocoScrapers()
