import xbmc, xbmcgui


def CocoScrapers():
    funcs = (click_1, click_2)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]~ CocoScrapers ~[/COLOR][/B]', 
['[B][COLOR=green]---Dialog CocoScrapers---[/COLOR][/B]',
 '[B][COLOR=grey]CocoScrapers Module[/COLOR][/B] Settings'])


    if call:
        if call < 0:
            return
        func = funcs[call-2]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('RunScript("special://home/addons/service.World.Build/PY/CocoScrapers/DialogCocoScrapers.py")')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10001,"plugin://script.module.cocoscrapers/",return)')


CocoScrapers()
