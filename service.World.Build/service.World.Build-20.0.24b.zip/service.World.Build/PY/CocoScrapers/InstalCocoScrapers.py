import os, xbmc, xbmcgui

def InstalCocoScrapers():


    xbmc.executebuiltin('ActivateWindow(10040,"addons://repository.cocoscrapers/xbmc.addon.executable")')

InstalCocoScrapers()                        