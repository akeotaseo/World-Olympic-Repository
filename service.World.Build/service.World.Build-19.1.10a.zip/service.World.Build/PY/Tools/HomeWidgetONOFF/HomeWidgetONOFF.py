import xbmc, xbmcgui


def Introonoff():
    funcs = (click_1, click_2)
    call = xbmcgui.Dialog().select('[B][COLOR=green]ON[/COLOR][/B]/[B][COLOR=red]OFF[/COLOR] HomeWidget[/B]', 
['[COLOR=green]ON[/COLOR]',
 '[COLOR=red] OFF[/COLOR]'])



    if call:
        if call < 0:
            return
        func = funcs[call-2]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('RunScript("special://home/addons/service.World.Build/PY/Tools/HomeWidgetONOFF/HomeWidgetON.py")')

def click_2():
    xbmc.executebuiltin('RunScript("special://home/addons/service.World.Build/PY/Tools/HomeWidgetONOFF/HomeWidgetOFF.py")')

Introonoff()
