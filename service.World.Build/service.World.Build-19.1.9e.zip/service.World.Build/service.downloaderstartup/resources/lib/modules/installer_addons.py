import xbmc

def installAddon():
    for addon_id in addon_list:
      xbmc.executebuiltin('InstallAddon(%s)' % (addon_id))
      xbmc.sleep(100)
      xbmc.executebuiltin('SendClick(11)')
      xbmc.sleep(100)

addon_list = ['plugin.program.downloader19', 'plugin.video.subsmovies', 'plugin.program.autowidget']

