import xbmc, xbmcgui


def CocoScrapersSeren():
    funcs = (click_1, click_2, click_3, click_4)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]~ CocoScrapers/Seren ~[/COLOR][/B]', 
['[B][COLOR=green]---Dialog Coco Scrapers---[/COLOR][/B]',
 '[B][COLOR=silver]CocoScrapers Module[/COLOR][/B] Settings',
 '[B][COLOR=orange]---Dialog Seren Providers---[/COLOR][/B]',
 '[B][COLOR=grey]Εγκατάσταση Παρόχων στο Seren[/COLOR][/B]'])


    if call:
        if call < 0:
            return
        func = funcs[call-4]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('RunScript("special://home/addons/service.World.Build/PY/CocoScrapersSeren/DialogCocoScrapers.py")')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10001,"plugin://script.module.cocoscrapers/")')

def click_3():
    xbmc.executebuiltin('RunScript("special://home/addons/service.World.Build/PY/CocoScrapersSeren/DialogSerenProviders.py")')

def click_4():
    xbmc.executebuiltin('ActivateWindow(10001,"plugin://plugin.program.downloader/seren_package_install")')
CocoScrapersSeren()
