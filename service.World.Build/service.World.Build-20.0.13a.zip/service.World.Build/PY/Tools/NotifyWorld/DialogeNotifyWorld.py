﻿import os, xbmc, xbmcvfs, xbmcgui


def temp_Delete():
        choice = xbmcgui.Dialog().yesno('[COLOR orange]Notify World[/COLOR]', '[COLOR white]Ανά τακτά χρονικά διαστήματα προτείνεται[COLOR blue] Total Clean Up[/COLOR][CR]Θέλετε να προχωρίσετε ?',
                                        nolabel='[B][COLOR white]Όχι[/COLOR][/B]',yeslabel='[B][COLOR green]Ναι[/COLOR][/B]')

        if choice == 1: [xbmc.executebuiltin('PlayMedia("plugin://plugin.program.G.K.N.Wizard/?mode=fullclean")'),
                         xbmc.sleep(1000),
                         xbmc.executebuiltin('RunScript("special://home/addons/service.World.Build/PY/Tools/NotifyWorld/TotalCleanUp.py.py")'),]



temp_Delete()
