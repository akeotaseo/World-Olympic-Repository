﻿import os, xbmc, xbmcvfs, xbmcgui, xbmcaddon, shutil, glob

def fixbuildin():
        choice = xbmcgui.Dialog().yesno('[COLOR orange]Διαγραφή Intro[/COLOR]', 'Επιθυμείτε την διαγραφή του Intro?[CR]',
                                        nolabel='[B][COLOR white]Όχι τώρα...[/COLOR][/B]',yeslabel='[B][COLOR red]Διαγραφή[/COLOR][/B]')

        if choice == 1: [xbmcvfs.delete('special://home/media/KODI-Intro-Video.mp4'), 
                         
                         xbmc.sleep(2000),
                         xbmcgui.Dialog().notification("[B][COLOR orange]Διαγραφή Intro[/COLOR][/B]", "[COLOR white]Ok![/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/clean.png'),]

fixbuildin()
