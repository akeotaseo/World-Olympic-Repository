import os, xbmc, xbmcgui

def install_stalker():
        choice = xbmcgui.Dialog().yesno('[COLOR orange]World-Repo Repository[/COLOR]', '[COLOR white]Αν έχετε απεγκαταστήσει το ??? κάντε το εγκατάσταση απο το [B]"World-Repo Repository"[/B][/COLOR]',
                                        nolabel='[COLOR orange]Άκυρο[/COLOR]',yeslabel='[COLOR lime]Εγκατάσταση[/COLOR]')

        if choice == 1: xbmc.executebuiltin('ActivateWindow(10040,"addons://repository.Worldrepo/xbmc.addon.repository",return)')

install_stalker()
