# plugin.video.scrapee
Scrapee is an all-in-one addon which allows you to watch your favorite movies and TV shows.
