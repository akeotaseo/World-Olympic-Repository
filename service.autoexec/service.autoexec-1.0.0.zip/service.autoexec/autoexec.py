﻿import xbmc



xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloader19/downloader_startup.py")')