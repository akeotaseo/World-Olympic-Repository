﻿import xbmc



xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.elementum/movies/trakt/trending",return)')