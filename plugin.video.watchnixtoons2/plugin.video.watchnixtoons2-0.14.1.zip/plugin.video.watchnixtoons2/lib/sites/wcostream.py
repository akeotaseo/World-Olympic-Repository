import re
import six

from lib.constants import *
from lib.network import request_helper

SITE_SETTINGS = {
    'catalog': {
        'regex': r'''<li(?:\sdata\-id=\"[0-9]+\")?>\s*<a href=\"([^\"]+)\".*?>([^<]+)''',
        'start': '"anime-search"',
        'start_alt': '<div class="clear">',
        'end': '"bartitle"',
    },
    'episode': {
        'regex': '''<a href="([^"]+).*?>([^<]+)''',
        'start': '"catlist-listview"',
        'end': '</ul>',
    },
    'series_search': {
        'regex': r'''<a href="(?P<link>[^"]+).*?>(?P<name>[^<]+)</a>(?P<img>)''',
        'start': 'aramamotoru',
        'end': 'cizgiyazisi',
    },
    'episode_search': {
        'regex': '''<a href="([^"]+)[^>]*>([^<]+)</a''',
        'start': 'submit',
        'end': 'cizgiyazisi',
    },
    'genre': {
        'regex': '''<a.*?"([^"]+).*?>(.*?)</''',
        'start': r'ddmcc">',
        'end': r'</div></div>',
    },
    'thumbnail': {
        'regex': '',
        'start': 'og:image" content="',
        'end': '',
    },
    'page_meta': {
        'regex': 'href="([^"]+)',
        'start': 'class="lalyx"',
        'end': '',
    },
    'page_plot': {
        'regex': r'class=\"iltext\"><p>(.*?)</p>',
        'start': 'katcont',
        'end': '',
    },
    'latest': {
        'url': '',
        'regex': r'''src=\"(?P<img>[^\"]+)\">\s*</a>\s*</div>\s*<div class=\"recent-release-episodes\">\s*<a href=\"(?P<link>[^\"]+)\" rel=\"bookmark\">(?P<name>[^<]+)</a>''',
        'start': '<div class="recent-release">',
        'end': '</ul>',
    },
    'latest_movies': {
        'regex': '''<li><a href="([^"]+).*?>([^<]+)''',
        'start': '"cat-listview cat-listbsize"',
        'end': '</ul>',
    },
    'popular': {
        'regex': '''<a href="([^"]+).*?>([^<]+)''',
        'start': 'class="menustyle">',
        'end': '</div>',
    },
    'parent': {
        'regex': r'class=\"ildate\">\s*<a href=\"([^\"]+)\"(?:[^\>]+)>([^/<]+)</a>',
        'start': '"lalyx"',
        'end': '',
    },
    'chapter': {
        'regex': r'<iframe id=\"(?:[a-zA-Z]+)uploads(?:[0-9]+)\" src=\"([^\"]+)\"',
    }
}

DECODE_SOURCE_REQUIRED = False

def premium_workaround_check( html ):

    """
    checks if there is a work around for current domain
    current workaround will only work if the cat is not 46540
    """

    # get playlist link
    cat_id = re.search(r'<a\s*href=\"/playlist-cat/([0-9]+)/', html).group(1)

    # movie cat has been blocked off
    if cat_id == '46540':
        return False

    media_id = re.search(r'\"\/report\/\?&pid=([0-9]+)', html).group(1)

    if cat_id and media_id:

        playlist_url = BASEURL + '/playlist-cat/' + cat_id
        html = request_helper(playlist_url if playlist_url.startswith('http') else BASEURL + playlist_url).text
        playlist_url = re.search(r'playlist: \"(/playlist-cat-rss/[0-9]+\?[^\"]+)\",', html).group(1)
        if playlist_url:
            rss = request_helper(playlist_url if playlist_url.startswith('http') else BASEURL + playlist_url).text
            video_url = re.search(r'<mediaid>' + six.ensure_str( media_id ) + r'</mediaid>\s*<jwplayer:image>(?:[^<]+)</jwplayer:image>\s*<jwplayer:source file=\"([^\"]+)\"', rss).group(1)
            if video_url:
                return video_url

    return False
