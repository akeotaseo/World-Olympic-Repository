import xbmc, xbmcgui



def Volley():
    funcs = (click_1, click_2,)
    call = xbmcgui.Dialog().select('[B][COLOR=blue]VOLLEY[/COLOR][/B]',
['[COLOR=yellow]Volley  [COLOR orange]Microjen[/COLOR]  [COLORred][B]Daddylive[/COLOR][/B] [COLOR green](Auto-Filter)[/COLOR]',
 '[COLOR=blue]Volley  [COLOR orange]Microjen[/COLOR]   [COLOR red]Live[COLOR white]TV.ru[/COLOR]'
 ])




    if call > -1:
        func = funcs[call]
        return func()
    return 






def click_1():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmcgui.Dialog().notification("[B][COLOR blue]VOLLEY[/COLOR][/B]", "Παρακαλώ περιμένετε...", sound=False, icon='special://home/addons/plugin.image.World/resources/media/addonset foto/volleyball.png')
    
    # 1. Άνοιγμα του μενού του DaddyLive
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.microjen/daddylive?mode=menu&serv_type=sched")')
    
    # ⏱️ Περιμένουμε να φορτώσει το παράθυρο 10025
    timeout = 10
    while not xbmc.getCondVisibility('Window.IsActive(10025)') and timeout > 0:
        xbmc.sleep(200)
        timeout -= 1
        
    xbmc.sleep(1500) # Αέρας για το UI

    # 2. Στέλνουμε το focus στο Φίλτρο (ID 19) στα αριστερά
    xbmc.executebuiltin('SetFocus(19)')
    xbmc.sleep(400)

    # 3. Πατάμε "OK" για να ανοίξει το πληκτρολόγιο
    xbmc.executebuiltin('Action(Select)')
    xbmc.sleep(1200)

    # 4. Πληκτρολόγηση της λέξης "voll"
    # Γράμμα v (id 163)
    xbmc.executebuiltin('SetFocus(163)')
    xbmc.sleep(150)
    xbmc.executebuiltin('Action(Select)')
    xbmc.sleep(150)
    
    # Γράμμα o (id 128)
    xbmc.executebuiltin('SetFocus(128)')
    xbmc.sleep(150)
    xbmc.executebuiltin('Action(Select)')
    xbmc.sleep(150)
    
    # Γράμμα l (id 148)
    xbmc.executebuiltin('SetFocus(148)')
    xbmc.sleep(150)
    xbmc.executebuiltin('Action(Select)')
    xbmc.sleep(150)
    
    # Γράμμα l (id 148)
    xbmc.executebuiltin('SetFocus(148)')
    xbmc.sleep(150)
    xbmc.executebuiltin('Action(Select)')
    xbmc.sleep(150)
    
    # Γράμμα e (id 122)
    xbmc.executebuiltin('SetFocus(122)')
    xbmc.sleep(150)
    xbmc.executebuiltin('Action(Select)')
    xbmc.sleep(150)
    
    # Γράμμα y (id 125)
    xbmc.executebuiltin('SetFocus(125)')
    xbmc.sleep(150)
    
    xbmc.executebuiltin('Action(Select)')
    xbmc.sleep(150)
    
    # 5. Πατάμε το κουμπί "Τέλος" (id 300)
    xbmc.executebuiltin('SetFocus(300)')
    xbmc.sleep(200)
    xbmc.executebuiltin('Action(Select)')
    
    xbmc.sleep(500)
    xbmc.executebuiltin('Action(Right)')
    
    # 6. Ειδοποιήσεις
    xbmcgui.Dialog().notification("[B][COLOR red]Daddylive[/COLOR][/B]", "[COLOR blue]VOLLEY[/COLOR][COLOR gold]BALL[/COLOR]", sound=False, icon='special://home/addons/plugin.image.World/resources/media/addonset foto/volleyball.png')
    xbmc.sleep(4000)
    xbmcgui.Dialog().notification("[B][COLOR orange]They don't always work[/COLOR][/B]", "[COLOR green]Δεν λειτουργούν πάντα...[/COLOR]", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/top/doestworkalltime.png')

def click_2():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloader19/set_setting_LivetvsxACE_off.py")')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.microjen/sporthd?description=Volleyball&iconimage=C%3a%5cPortableApps%5ckodi%5cMy%20Kodi%5cKodi%5cportable_data%5caddons%5cplugin.video.microjen%5cresources%5clib%5cexternal%5csporthd%5cmedia%5clivetv.png&mode=livetvSX_events&name=Volleyball%20(22)&url=sport%7cVolleyball")')
    xbmcgui.Dialog().notification("[B][COLOR=orange]Microjen[/COLOR][/B]", "[COLOR blue]VOLLEY[/COLOR][COLOR gold]BALL[/COLOR]", sound=False, icon='special://home/addons/plugin.video.microjen/resources/lib/external/sporthd\media/livetv.png')
    xbmc.sleep(4000)
    xbmcgui.Dialog().notification("[B][COLOR=orange]Microjen[/COLOR][/B]", "[COLOR blue]VOLLEY[/COLOR][COLOR gold]BALL[/COLOR]", sound=False, icon='special://home/addons/plugin.video.microjen/resources/lib/external/sporthd\media/livetv.png')


Volley()
