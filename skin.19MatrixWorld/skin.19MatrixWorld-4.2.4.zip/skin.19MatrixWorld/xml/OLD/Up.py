﻿import xbmc

def Up():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    #xbmc.executebuiltin("Action(Close)")
    #xbmc.sleep(200)
    #xbmc.executebuiltin("ActivateWindow(Home)")
    #xbmc.sleep(200)
    #xbmc.executebuiltin("ActivateWindow(10040,addons://,return)")
    #xbmc.sleep(5000)
    xbmc.executebuiltin("ActivateWindow(10040,addons://recently_updated)")

Up()
