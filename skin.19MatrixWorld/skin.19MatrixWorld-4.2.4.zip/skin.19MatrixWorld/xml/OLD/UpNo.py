﻿import xbmc

def UpNo():
    ('Dialog.Close(all,true)')
    #xbmc.executebuiltin("ActivateWindow(10040,addons://)")
    #xbmc.sleep(5000)
    #xbmc.executebuiltin("ActivateWindow(Home)")
UpNo()
