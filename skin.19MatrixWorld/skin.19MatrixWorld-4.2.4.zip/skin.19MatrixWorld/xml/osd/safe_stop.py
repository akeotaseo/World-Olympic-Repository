﻿# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import sys

def universal_safe_stop():
    # 🎯 ΔΙΟΡΘΩΣΗ: Έλεγχος του ορίσματος με [-1]
    # 🎯 ΕΛΕΓΧΟΣ ΟΡΙΣΜΑΤΟΣ: Ψάχνει αν το XML έστειλε το σημείωμα για το τρέιλερ
    play_trailer_after = False
    if len(sys.argv) > 1 and 'play_trailer' in sys.argv[-1]:
        play_trailer_after = True

    # 1. Έλεγχος: Αν παίζει βίντεο ή ραδιόφωνο
    is_video = xbmc.Player().isPlayingVideo()
    
    # 2. 🧼 HUB FLUSHES: Σβήνουμε ακαριαία τα strings από τη μνήμη για να ελευθερωθεί η RAM
    xbmc.executebuiltin('Skin.ResetString(HubMovieTrailer)')
    xbmc.executebuiltin('Skin.ResetString(HubTrailerActive)')
    
    # 3. Πατάμε το STOP στο Kodi Core
    xbmc.executebuiltin('PlayerControl(Stop)')
    xbmc.executebuiltin('Action(Stop)')
    
    # 4. Καθαρίζουμε το Property της υπηρεσίας δικτύου για να ξεμπλοκάρει το Skin layout
    xbmcgui.Window(10000).clearProperty('IPServiceRunning')
    
    # 5. ⏳ THE BOX SHIELD: Έξυπνη αναμονή για να προλάβει το Boxάκι να κλείσει τα sockets
    if is_video:
        xbmc.sleep(2000)  # 2 δευτερόλεπτα για βαριά βίντεο/ταινίες/τρέιλερ
    else:
        xbmc.sleep(1500)  # 1.5 δευτερόλεπτο για live ραδιοφωνικά streams
        
    # 6. Εκτελούμε το απαραίτητο UpdateLocalAddons (cURL Ghost Sockets Fix)
    xbmc.executebuiltin('UpdateLocalAddons()')
    
    # 7. 🎯 TRIGGER ΔΙΚΤΥΟΥ: Ξυπνάμε το service να ελέγξει την IP χωρίς να μπουκώνει η C++
    xbmcgui.Window(10000).setProperty('TriggerIPCheck', 'true')
    
    # 8. Επαναφορά της κατάστασης της υπηρεσίας σε Running
    xbmcgui.Window(10000).setProperty('IPServiceRunning', 'true')

    # 9. 🎬 ΕΚΤΕΛΕΣΗ TRAILER: Αν ήμασταν στο Info Dialog, κλείνουμε το παράθυρο και ξεκινάμε το Trailer ΚΑΘΑΡΑ
    if play_trailer_after:
        xbmc.executebuiltin('Dialog.Close(all,true)')
        # Παίρνουμε το info του τρέχοντος ListItem από το Kodi και το αναπαράγουμε
        trailer_url = xbmc.getInfoLabel('ListItem.Trailer')
        if trailer_url:
            xbmc.executebuiltin('PlayMedia(' + trailer_url + ')')

if __name__ == '__main__':
    universal_safe_stop()
