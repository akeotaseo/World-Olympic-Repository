﻿# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import sys
import socket
import importlib

def universal_safe_stop():
    play_trailer_after = False
    if len(sys.argv) > 1 and 'play_trailer' in sys.argv[-1]:
        play_trailer_after = True

    is_video = xbmc.Player().isPlayingVideo()
    
    # 1. Καθαρισμός μνήμης & κλείσιμο τυχόν διαλόγων
    xbmc.executebuiltin('Skin.ResetString(HubMovieTrailer)')
    xbmc.executebuiltin('Skin.ResetString(HubTrailerActive)')
    
    # 2. Αδειάζουμε την ουρά αναπαραγωγής ώστε να μην πηδήξει σε επόμενο νεκρό κανάλι
    xbmc.executebuiltin('Playlist.Clear')
    
    # 3. Στέλνουμε καθαρό PlayerControl(Stop) (χωρίς Python Thread lock)
    xbmc.executebuiltin('PlayerControl(Stop)')
    
    # 4. Ξεμπλοκάρισμα service & άμεσο ξέπλυμα Python sockets
    xbmcgui.Window(10000).clearProperty('IPServiceRunning')
    try:
        importlib.reload(socket)
        socket.setdefaulttimeout(5)
    except:
        pass
    
    # 5. Περιμένουμε μέχρι 2.5 δευτερόλεπτα να κλείσει πραγματικά ο Player (χωρίς να κολλήσει αν αργεί το FFmpeg)
    monitor = xbmc.Monitor()
    max_wait = 2.5 if is_video else 1.5
    waited = 0.0
    while xbmc.Player().isPlaying() and waited < max_wait and not monitor.abortRequested():
        if monitor.waitForAbort(0.25):
            return
        waited += 0.25
        
    # 6. Εκτελούμε UpdateLocalAddons() ΜΟΝΟ αν ο Player έκλεισε καθαρά (αποφεύγει 100% το deadlock!)
    if not xbmc.Player().isPlaying():
        xbmc.executebuiltin('UpdateLocalAddons()')
        
    xbmcgui.Window(10000).setProperty('TriggerIPCheck', 'true')
    xbmcgui.Window(10000).setProperty('IPServiceRunning', 'true')

    # 7. Εκτέλεση Trailer αν ζητήθηκε
    if play_trailer_after:
        xbmc.executebuiltin('Dialog.Close(all,true)')
        trailer_url = xbmc.getInfoLabel('ListItem.Trailer')
        if trailer_url:
            xbmc.executebuiltin('PlayMedia(' + trailer_url + ')')

if __name__ == '__main__':
    universal_safe_stop()
