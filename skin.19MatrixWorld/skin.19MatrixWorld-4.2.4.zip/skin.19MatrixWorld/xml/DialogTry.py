﻿import xbmc, xbmcgui

def DialogTry():

    xbmcgui.Dialog().notification("[B][COLOR orange]Try![/COLOR][/B]", "[COLOR green]Ίσως σταθείτε τυχεροί...[/COLOR]", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/top/dice.gif')
    xbmc.sleep(4000)
    xbmcgui.Dialog().notification("[B][COLOR orange]Try![/COLOR][/B]", "[COLOR green]Ίσως σταθείτε τυχεροί...[/COLOR]", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/top/dice.gif')
    xbmcgui.Dialog().notification("[B][COLOR orange]Try![/COLOR][/B]", "[COLOR green]Ίσως σταθείτε τυχεροί...[/COLOR]", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/top/dice.gif')

DialogTry()
