﻿import xbmc, xbmcgui

def TMDB_Series():
    xbmcgui.Dialog().notification("[B][COLOR green]TMDB Series[/COLOR][/B]", "[COLOR lime]Voted[/COLOR]", sound=False, icon='special://home/addons/plugin.video.themoviedb.helper/icon.png')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.themoviedb.helper/?info=most_voted&tmdb_type=tv")')

TMDB_Series()