# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import urllib.request
import json
import ssl

def _fetch_geo():
    ctx = ssl._create_unverified_context()
    headers = {'User-Agent': 'Mozilla/5.0'}

    # 1η Πηγή: ipwho.is (HTTPS - Πολύ γρήγορο και ακριβές σε VPN)
    try:
        req = urllib.request.Request('https://ipwho.is', headers=headers)
        raw = urllib.request.urlopen(req, timeout=5, context=ctx).read().decode('utf-8')
        d = json.loads(raw)
        if d.get('success'):
            conn = d.get('connection') or {}
            return {
                'ip': d.get('ip', 'N/A'),
                'country': d.get('country', ''),
                'code': d.get('country_code', '').upper(),
                'isp': (conn.get('isp') or conn.get('org') or '').lower(),
                'hosting': False
            }
    except Exception:
        pass

    # 2η Πηγή (Fallback): ipapi.co (HTTPS)
    try:
        req = urllib.request.Request('https://ipapi.co', headers=headers)
        raw = urllib.request.urlopen(req, timeout=5, context=ctx).read().decode('utf-8')
        d = json.loads(raw)
        if d.get('country_name') and not d.get('error'):
            return {
                'ip': d.get('ip', 'N/A'),
                'country': d.get('country_name', ''),
                'code': d.get('country_code', '').upper(),
                'isp': (d.get('org') or '').lower(),
                'hosting': False
            }
    except Exception:
        pass

    # 3η Πηγή (Fallback): ip-api.com
    try:
        req = urllib.request.Request('http://ip-api.com', headers=headers)
        raw = urllib.request.urlopen(req, timeout=5).read().decode('utf-8')
        d = json.loads(raw)
        if d.get('status') == 'success':
            return {
                'ip': d.get('query', 'N/A'),
                'country': d.get('country', ''),
                'code': d.get('countryCode', '').upper(),
                'isp': (d.get('isp') or '').lower(),
                'hosting': d.get('hosting', False)
            }
    except Exception:
        pass

    return None

def check_network_and_vpn():
    win = xbmcgui.Window(10000)
    info = _fetch_geo()

    if info and info['code'] and len(info['code']) == 2:
        ip_addr = info['ip']
        country = info['country'] or info['code']
        country_code = info['code']
        isp = info['isp']
        is_hosting = info['hosting']

        if ip_addr and ip_addr != 'N/A':
            win.setProperty('MyWANIP', ip_addr)

        # Κλειδώνει ΤΑΥΤΟΧΡΟΝΑ σημαία και χώρα από την ίδια πηγή
        win.setProperty('MyCountryCode', country_code.lower())

        vpn_keywords = (
            'datacamp', 'vpn', 'hostroyale', 'm247', 'cdn77', 'hetzner',
            'ovh', 'digitalocean', 'vultr', 'linode', 'choopa', 'leaseweb',
            'tzulo', 'packethub', 'privax', 'nord', 'surfshark', 'proton',
            'mullvad', 'expressvpn', 'cyberghost', 'purevpn', 'private internet'
        )

        if country_code != 'GR' or is_hosting or any(k in isp for k in vpn_keywords):
            win.setProperty('MyVPNState', ' [COLOR lime](VPN)[/COLOR]')
            win.setProperty('MyVPNActive', 'true')
        else:
            win.setProperty('MyVPNState', '')
            win.setProperty('MyVPNActive', 'false')

        color = 'cornflowerblue' if country_code == 'GR' else 'orange'
        win.setProperty('MyRealCountry', f'[COLOR {color}]{country}[/COLOR]')
    else:
        if not win.getProperty('MyRealCountry'):
            win.setProperty('MyRealCountry', '[COLOR cornflowerblue]Greece[/COLOR]')
            win.setProperty('MyCountryCode', 'gr')

check_network_and_vpn()
