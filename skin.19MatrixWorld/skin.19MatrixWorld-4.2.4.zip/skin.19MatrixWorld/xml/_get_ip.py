# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import urllib.request
import json

def check_network_and_vpn(custom_timeout=4):
    try:
        url = 'http://ip-api.com/json'
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        response = urllib.request.urlopen(req, timeout=custom_timeout).read().decode('utf8')
        data = json.loads(response)
        
        if data.get('status') == 'success':
            ip_addr = data.get('query', 'N/A')
            country = data.get('country', 'Greece')
            country_code = data.get('countryCode', 'GR').upper()
            is_hosting = data.get('hosting', False)
            isp = data.get('isp', '').lower()

            if ip_addr != 'N/A':
                xbmcgui.Window(10000).setProperty('MyWANIP', ip_addr)

            if country_code != 'GR' or is_hosting or 'datacamp' in isp or 'vpn' in isp:
                xbmcgui.Window(10000).setProperty('MyVPNState', ' [COLOR lime](VPN)[/COLOR]')
                xbmcgui.Window(10000).setProperty('MyVPNActive', 'true')
            else:
                xbmcgui.Window(10000).setProperty('MyVPNState', '')
                xbmcgui.Window(10000).setProperty('MyVPNActive', 'false')

            if country_code == 'GR':
                formatted_country = '[COLOR cornflowerblue]' + country + '[/COLOR]'
            else:
                formatted_country = '[COLOR orange]' + country + '[/COLOR]'
                
            xbmcgui.Window(10000).setProperty('MyRealCountry', formatted_country)
    except:
        if not xbmcgui.Window(10000).getProperty('MyRealCountry'):
            xbmcgui.Window(10000).setProperty('MyRealCountry', '[COLOR cornflowerblue]Greece[/COLOR]')

check_network_and_vpn()
