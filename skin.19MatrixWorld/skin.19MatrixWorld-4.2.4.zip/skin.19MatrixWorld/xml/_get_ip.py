# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import urllib.request
import sys
# xbmc.executebuiltin('RunScript(special://home/addons/skin.19MatrixWorld/xml/_get_country.py)')
xbmc.executebuiltin('RunScript(special://home/addons/skin.19MatrixWorld/xml/_get_vpn.py)')
xbmcgui.Window(10000).setProperty('IPServiceRunning', 'true')
monitor = xbmc.Monitor()

def get_vpn_status():
    try:
        # 🎯 ΧΡΗΣΗ CLOUDFLARE ΜΟΝΟ ΓΙΑ ΑΚΑΡΙΑΙΟ VPN DETECTION & WAN IP
        url = 'https://1.1.1.1/cdn-cgi/trace'
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        response = urllib.request.urlopen(req, timeout=4).read().decode('utf8')
        
        response = response.replace('\r', '')
        lines = response.split('\n')
        ip_addr = 'N/A'
        country_code = 'Unknown'
        
        for line in lines:
            if line.startswith('ip='):
                ip_addr = line.replace('ip=', '').strip()
            elif line.startswith('loc='):
                country_code = line.split('=')[-1].strip().upper()

        if ip_addr != 'N/A' and ip_addr != '':
            xbmcgui.Window(10000).setProperty('MyWANIP', ip_addr)
            
            if country_code and country_code != 'GR' and country_code != 'UNKNOWN':
                xbmcgui.Window(10000).setProperty('MyVPNState', ' [COLOR lime](VPN)[/COLOR]')
            else:
                xbmcgui.Window(10000).setProperty('MyVPNState', '')
    except:
        pass

# Πρώτο request στο boot
get_vpn_status()

was_playing_anything = False
last_local_ip = xbmc.getInfoLabel('Network.IPAddress')

while not monitor.abortRequested():
    # 🕵️‍♂️ ΑΥΤΟΜΑΤΟΣ ΕΛΕΓΧΟΣ ΑΛΛΑΓΗΣ VPN
    try:
        current_local_ip = xbmc.getInfoLabel('Network.IPAddress')
        if current_local_ip and not current_local_ip == last_local_ip:
            last_local_ip = current_local_ip
            monitor.waitForAbort(1.5)  # Ασφαλές εναλλακτικό αντί για xbmc.sleep
            get_vpn_status()    
    except:
        pass

    # 🎯 ΜΟΛΙΣ ΠΑΤΗΘΕΙ STOP ΣΕ ΟΤΙΔΗΠΟΤΕ (CURL GHOST FIX)
    try:
        if xbmc.Player().isPlaying():
            was_playing_anything = True
        else:
            if was_playing_anything:
                xbmc.log("[World_Updater] Ανιχνεύτηκε STOP. Καθαρισμός sockets cURL.", xbmc.LOGINFO)
                
                # Σωστός καθαρισμός property του Window 10000 μέσω API
                xbmcgui.Window(10000).clearProperty('IPServiceRunning')
                
                xbmc.executebuiltin('UpdateLocalAddons()') 
                was_playing_anything = False
                
                monitor.waitForAbort(1.5)  # Ασφαλές εναλλακτικό αντί για xbmc.sleep
                get_vpn_status() 
                
                # Επαναφορά της κατάστασης running αν το skin τη χρειάζεται μόνιμα αναμμένη
                xbmcgui.Window(10000).setProperty('IPServiceRunning', 'true')
    except:
        pass

    if monitor.waitForAbort(2):
        break

xbmcgui.Window(10000).clearProperty('IPServiceRunning')