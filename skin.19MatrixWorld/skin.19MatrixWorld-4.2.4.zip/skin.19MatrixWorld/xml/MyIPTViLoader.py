﻿import xbmc, xbmcgui

def MyIPTViLoader():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.sleep(500)
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.myiptv/?mode=set_acc&url=XFAN")')
    xbmcgui.Dialog().notification("[B][COLOR orange]MicroJen[/COLOR][/B]", "My[COLOR orangered]IPTV[/COLOR] iLoader", sound=False, icon='https://styles.redditmedia.com/t5_28w7mp/styles/communityIcon_j5m34lvey9041.jpg')
    xbmc.sleep(4000)
    xbmcgui.Dialog().notification("[B][COLOR orange]MicroJen[/COLOR][/B]", "My[COLOR orangered]IPTV[/COLOR] iLoader", sound=False, icon='https://styles.redditmedia.com/t5_28w7mp/styles/communityIcon_j5m34lvey9041.jpg')
MyIPTViLoader()
