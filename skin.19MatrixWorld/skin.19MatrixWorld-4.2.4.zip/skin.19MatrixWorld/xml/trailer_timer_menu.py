﻿import xbmc

def main():
    # 📡 THE DYNAMIC MENU TRIGGER
    # Αυτό το script εκτελείται ΜΟΝΟ όταν πατάς OK πάνω στο κρυφό Button.
    # Δεν ανακατεύεται καθόλου με το PlayMedia, παρά μόνο ανοίγει καθαρά 
    # το Hub 6199 στην επιφάνεια, ξεμπλοκάροντας τη ροή!
    xbmc.executebuiltin('ActivateWindow(6199)')

if __name__ == '__main__':
    main()
