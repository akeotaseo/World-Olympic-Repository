﻿import xbmc, xbmcgui
xbmc.sleep(250) # Περιμένει να εμφανιστεί το μενού της εικόνας
xbmc.executebuiltin('Action(Select)') # Πατάει αυτόματα την "Αναπαραγωγή..."
xbmc.sleep(250)
xbmcgui.Dialog().notification("[COLOR red]Trailer Ταινίας[/COLOR]", "", sound=True, icon='special://home/addons/skin.19MatrixWorld/media/YouTube2.png')