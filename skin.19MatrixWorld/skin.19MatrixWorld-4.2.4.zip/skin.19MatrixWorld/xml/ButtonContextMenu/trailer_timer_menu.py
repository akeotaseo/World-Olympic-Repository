﻿import xbmc

def main():
    # =======================================================================
    # 🚀 THE PURE MENU INJECTION (NO MORE LOOPS - CHECKMATE)
    # Αυτό το script εκτελείται ΜΟΝΟ από την μπάρα ελέγχου (OSD) και το 
    # Κρυφό Button 8046. 
    # Επειδή το βίντεο παίζει ΗΔΗ, ΑΦΑΙΡΕΘΗΚΕ το PlayMedia για να μην ξαναξεκινάει 
    # η ταινία από την αρχή! Ανοίγει μόνο το Hub 6199 «ρολόι»! [1.4]
    # =======================================================================
    
    # 🎯 FORCE FOCUS LOCK: Σιγουρεύουμε ότι η RAM Core «βλέπει» το Widget
    xbmc.executebuiltin('Control.SetFocus(8044)')
    xbmc.sleep(50)

    # 🔥 DIRECT ACTIVATION: Ανοίγουμε το Custom Hub 6199 ακαριαία στην επιφάνεια! [1.4]
    xbmc.executebuiltin('ActivateWindow(6199)')

if __name__ == '__main__':
    main()
