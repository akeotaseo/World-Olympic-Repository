﻿import xbmc
import xbmcgui

def main():
    # ⏱️ 1. ΑΡΧΙΚΟΣ ΑΕΡΑΣ: Περιμένει να ηρεμήσει το μενού
    xbmc.sleep(250) 
    
    # 🛑 2. ΤΟ ΑΠΟΛΥΤΟ STOP: Σβήνουμε το βίντεο οριστικά
    xbmc.executebuiltin('PlayerControl(Stop)')
    xbmc.sleep(200)
    xbmc.executebuiltin('Action(Stop)')
    
    # 🖼️ 3. TRIGGER ΓΙΑ ΤΗ ΦΩΤΟΓΡΑΦΙΑ: Ενημερώνουμε το Skin ότι πατήθηκε το Stop
    # Αυτό θα ανάψει την εικόνα "Movie Trailer" στο XML σου!
    xbmc.executebuiltin('Skin.SetString(TrailerIsStopped, true)')
    
    # 🧼 4. THE PYTHON MEMORY FLUSH: Κρατάμε τη RAM καθαρή
    xbmc.executebuiltin('Skin.ResetString(TrailerCheckID)')
    xbmc.sleep(150)

if __name__ == '__main__':
    main()
