﻿import xbmc

def main():
    xbuiltin = xbmc.executebuiltin
    
    # 🔒 BLACKLODGE INTERNAL PAGE BYPASS (THE FINAL KEY)
    # Αν πατήθηκε η Επόμενη Σελίδα, παίρνουμε τη διαδρομή του επόμενου φακέλου και ανοίγουμε το παράθυρο του πρόσθετου!
    current_title = xbmc.getInfoLabel('ListItem.Title')
    current_label = xbmc.getInfoLabel('ListItem.Label')
    folder_path = xbmc.getInfoLabel('ListItem.FolderPath')
    
    if current_title == '' or 'Next' in current_label or 'Επόμενη' in current_label or 'page' in current_label:
        if folder_path and folder_path != '':
            # Ανοίγει το εσωτερικό παράθυρο του Blacklodge στη Σελίδα 2 κανονικά!
            xbuiltin('ActivateWindow(10025,"{}",return)'.format(folder_path))
        else:
            # Fallback αν δεν βρει το path
            xbuiltin('Action(Select)')
        return # 🔥 Σταματάει εδώ, δεν ανοίγει το Hub, σε πάει καשרάντα μέσα στο πρόσθετο!

    # 🕵️‍♂️ ULTRA TIME COMPILER (DYNAMIC PARSER)
    duration_str = xbmc.getInfoLabel('ListItem.Duration')
    if duration_str and duration_str != '':
        xbmc.executebuiltin('Skin.SetString(HubMovieDuration, {})'.format(duration_str))
        try:
            import datetime
            minutes = 0
            if ":" in duration_str:
                time_parts = duration_str.split(":")
                if len(time_parts) == 3:
                    minutes = (int(time_parts[0]) * 60) + int(time_parts[1])
                elif len(time_parts) == 2:
                    minutes = int(time_parts[0])
            else:
                minutes = int(duration_str)
            
            if minutes > 0:
                end_time = datetime.datetime.now() + datetime.timedelta(minutes=minutes)
                end_time_str = end_time.strftime('%H:%M')
                xbmc.executebuiltin('Skin.SetString(HubMovieEndTime, {})'.format(end_time_str))
        except:
            pass



    # =======================================================================
    # 🧹 1. ΒΙΑΙΟ RAM FLUSH & RESET
    # =======================================================================
    xbuiltin('Skin.ResetString(HubMovieTrailer)')
    xbuiltin('Skin.ResetString(HubTrailerActive)')
    xbmc.sleep(50) 

    if xbmc.Player().isPlayingVideo() or xbmc.getCondVisibility('Player.HasVideo'):
        xbuiltin('PlayerControl(Stop)')
        xbuiltin('Action(Stop)')
        
        # Περιμένουμε ενεργά να "πεθάνει" το προηγούμενο stream
        for _ in range(20): 
            if not xbmc.Player().isPlayingVideo() and not xbmc.getCondVisibility('Player.HasVideo'):
                break
            xbmc.sleep(50)
    
    # 🎯 FORCE FOCUS LOCK
    xbuiltin('Control.SetFocus(8044)')
    xbmc.sleep(50)

    # =======================================================================
    # 🕵️‍♂️ 2. ΠΑΓΙΔΕΥΣΗ ΝΕΟΥ TRAILER
    # =======================================================================
    trailer_url = xbmc.getInfoLabel('ListItem.Trailer')

    # =======================================================================
    # 🎬 3. ΒΗΜΑ Α: ΕΚΚΙΝΗΣΗ ΤΡΑΙΛΕΡ ΣΤΟ BACKGROUND
    # =======================================================================
    if trailer_url and trailer_url != '':
        xbuiltin(f'Skin.SetString(HubMovieTrailer,{trailer_url})')
        xbmc.sleep(30)
        # 🔒 THE WIDGET HANDSHAKE: Κλειδώνουμε στη RAM ότι η εκκίνηση έγινε από το Widget!
        xbmc.executebuiltin('Skin.SetString(HubFromWidget,"true")')

        # Ξεκινάει το stream
        
        xbuiltin(f'PlayMedia("{trailer_url}",1,windowed="true")')
        xbuiltin('Skin.SetString(HubTrailerActive, true)') # 🎯 ΑΝΑΒΟΥΜΕ ΤΗ ΣΦΡΑΓΙΔΑ ΜΕΣΑ ΣΤΟ SCRIPT

        
        # 🔥 ΚΡΙΣΙΜΟ: Περιμένουμε το Resolve και να αρχίσει να τρέχει ο χρόνος του βίντεο.
        # Μόνο τότε είμαστε σίγουροι ότι το Kodi σταμάτησε να ανοιγοκλείνει παράθυρα!
        video_started = False
        for _ in range(40): # Δίνουμε έως 2 δευτερόλεπτα στο addon (π.χ. YouTube) να φέρει εικόνα
            if xbmc.Player().isPlayingVideo() and xbmc.Player().getTime() > 0:
                video_started = True
                break
            xbmc.sleep(200)
            

        # Αν το Kodi πήγε να το πετάξει fullscreen, το μαζεύουμε ΠΡΙΝ ανοίξουμε το Hub
        if xbmc.getCondVisibility('Window.IsActive(fullscreenvideo)'):
            xbuiltin('Action(SmallWindow)')
            xbmc.sleep(100) # Μικρή ανάσα για να κάτσει το UI

    # =======================================================================
    # 📡 🛡️ SMART SUBTITLE CHECKER TRIGGER (Η ΝΕΑ ΑΥΤΟΝΟΜΗ ΓΕΦΥΡΑ)
    # =======================================================================
    # Πυροδοτούμε τον αυτόνομο checker στο παρασκήνιο για να ελέγξει τον server 
    # την ώρα που φορτώνει το Hub, χωρίς να κολλήσει καθόλου η εικόνα!
    xbuiltin('RunScript("special://skin/xml/ButtonContextMenu/os_checker.py")')
    xbmc.sleep(50) # Ελάχιστο sleep να φύγει το thread

    # =======================================================================
    # 🚀 4. ΒΗΜΑ Β: ΤΟ ΤΕΛΙΚΟ ΑΝΟΙΓΜΑ ΤΟΥ HUB 6199 (ΑΦΟΥ ΟΛΑ ΕΧΟΥΝ ΣΤΑΘΕΡΟΠΟΙΗΘΕΙ)
    # =======================================================================
    # Τώρα που το βίντεο παίζει ήδη windowed, ανοίγουμε το Hub και δεν πρόκειται να κλείσει!
    xbuiltin('ActivateWindow(6199)')



if __name__ == '__main__':
    main()

