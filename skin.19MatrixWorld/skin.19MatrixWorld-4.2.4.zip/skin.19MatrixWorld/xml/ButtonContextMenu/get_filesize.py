﻿import os
import xbmc
import re

def main():
    xbuiltin = xbmc.executebuiltin
    
    # 🕵️‍♂️ 1. Διαβάζουμε τη διαδρομή και την παγίδα μνήμης του Skin
    path = xbmc.getInfoLabel('Player.Filenameandpath')
    stream_title = xbmc.getInfoLabel('Skin.String(CurrentStreamTitle)')
    
    if not path:
        xbuiltin('Skin.ResetString(LocalFileSize)')
        return

    # =======================================================================
    # 🌐 ΠΕΡΙΠΤΩΣΗ Α: STREAM / ADDON (Blacklodge / plugin://)
    # =======================================================================
    if "plugin://" in path or not os.path.exists(path):
        if stream_title and stream_title != '':
            title_lower = stream_title.lower()
            
            # 🎯 Ο ΔΙΚΟΣ ΣΟΥ ΚΑΝΟΝΑΣ: Αν ανιχνεύσει SD, 720p, 1080p ή Trailer χωρίς GB/MB
            # προσπερνάει τα μαθηματικά και καρφώνει τη λέξη "Unknown"!
            keywords = ["720p", "1080p", "720", "1080", "sd", "trailer", "multi-resolution", "vixsrc", "vidsrc", "default"]
            if any(key in title_lower for key in keywords) and not any(unit in title_lower for unit in ["gb", "mb"]):
                xbuiltin('Skin.SetString(LocalFileSize, "Unknown")')
                return
            
            # 🕵️‍♂️ ULTRA REGEX SCAN: Ψάχνει dynamic για 2.30GB, 950MB, 1.4GB, 2.30 GB κλπ.
            match = re.search(r'(\d+(?:\.\d+)?)\s*(GB|MB)', stream_title, re.IGNORECASE)
            
            if match:
                size_value = match.group(1)
                size_unit = match.group(2).upper()
                
                # Αν το βρει σε MB, μετατροπή σε GB για ομοιομορφία
                if size_unit == 'MB':
                    try:
                        gb_calc = float(size_value) / 1024
                        xbuiltin(f'Skin.SetString(LocalFileSize, "{gb_calc:.2f} GB")')
                    except:
                        xbuiltin(f'Skin.SetString(LocalFileSize, "{size_value} {size_unit}")')
                else:
                    xbuiltin(f'Skin.SetString(LocalFileSize, "{size_value} GB")')
                return
                
        # Αν δεν βρει τίποτα στην παγίδα, γράφει Unknown για ασφάλεια
        xbuiltin('Skin.SetString(LocalFileSize, "Unknown")')
        return

    # =======================================================================
    # 📦 ΠΕΡΙΠΤΩΣΗ Β: ΤΟΠΙΚΟ ΑΡΧΕΙΟ (Σκληρός Δίσκος / NAS - 100% ΣΤΑΘΕΡΟ)
    # =======================================================================
    try:
        if os.path.exists(path):
            size_bytes = os.path.getsize(path)
            size_gb = size_bytes / (1024 * 1024 * 1024)
            xbuiltin(f'Skin.SetString(LocalFileSize, "{size_gb:.2f} GB")')
    except:
        xbuiltin('Skin.SetString(LocalFileSize, "Unknown")')

if __name__ == '__main__':
    main()
