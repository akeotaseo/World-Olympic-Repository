import xbmc
import xbmcgui

def main():
    # 🤫 1. ΚΛΕΙΔΩΝΟΥΜΕ ΤΟ ΜΕΝΟΥ ΣΕ ΣΤΑΘΕΡΟ ΜΑΥΡΟ ΦΟΝΤΟ ΠΡΙΝ ΑΝΟΙΞΕΙ ΤΟ HUB
    # Αλλάζουμε το MenuBackground σε "Theme" ή "None" για να σβήσει dynamic η θάλασσα του GREEK
    xbmc.executebuiltin('SetProperty(MenuBackground,Theme,Home)')
    xbmc.executebuiltin('Skin.SetString(HubBackgroundLock,True)')
    xbmc.sleep(100) # Μικρό sleep για να προλάβει η C++ Core να καθαρίσει τη μνήμη
    
    
    # 🚀 2. ΑΝΟΙΓΟΥΜΕ ΤΟ ALL IN ONE HUB (WINDOW 7000)
    # Το ανοίγουμε ως κανονικό window (χωρίς το return) για να κρατήσει την κρυστάλλινη HD ανάλυση στα posters!
    xbmc.executebuiltin('ActivateWindow(7000)')
    
    # ⏳ 3. Ο ΠΥΡΗΝΑΣ MONITOR: Το script περιμένει αθόρυβα στο παρασκήνιο όσο το Hub 7000 είναι ανοιχτό
    while xbmc.getCondVisibility('Window.IsVisible(7000)'):
        xbmc.sleep(250)
        
    # 🧼 4. ΜΟΛΙΣ Ο ΧΡΗΣΤΗΣ ΠΑΤΗΣΕΙ EXIT ΚΑΙ ΚΛΕΙΣΕΙ ΤΟ HUB, ΕΠΑΝΑΦΕΡΟΥΜΕ ΤΑ ΠΑΝΤΑ ΣΤΗΝ ΑΡΧΙΚΗ ΚΑΤΑΣΤΑΣΗ
    xbmc.executebuiltin('Skin.Reset(HubBackgroundLock)')
    xbmc.executebuiltin('SetProperty(MenuBackground,Default,Home)')

if __name__ == '__main__':
    main()
