﻿# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import xbmcvfs
import os
import re
import urllib.request
import urllib.parse
import json
import ssl


def set_tmdbh_language(value):
    """Βοηθητική συνάρτηση που αλλάζει ΜΟΝΟ τη γλώσσα στο settings.xml, χωρίς να σβήνει τα υπόλοιπα settings"""
    try:
        tmdbh_id = 'plugin.video.themoviedb.helper'
        tmdbh_settings_xml = xbmcvfs.translatePath(f'special://profile/addon_data/{tmdbh_id}/settings.xml')

        if not xbmcvfs.exists(tmdbh_settings_xml):
            tmdbh_settings_dir = os.path.dirname(tmdbh_settings_xml)
            if not os.path.exists(tmdbh_settings_dir):
                os.makedirs(tmdbh_settings_dir)
            with open(tmdbh_settings_xml, 'w', encoding='utf-8') as f:
                f.write(
                    '<?xml version="1.0" encoding="utf-8" standalone="yes"?>\n'
                    '<settings version="1">\n'
                    f'    <setting id="language">{value}</setting>\n'
                    '</settings>\n'
                )
            return

        with open(tmdbh_settings_xml, 'r', encoding='utf-8') as f:
            xml_content = f.read()

        pattern = r'<setting id="language"[^>]*>.*?</setting>'
        new_setting = f'<setting id="language">{value}</setting>'

        if re.search(pattern, xml_content):
            updated_content = re.sub(pattern, new_setting, xml_content)
        else:
            updated_content = xml_content.replace('</settings>', f'    {new_setting}\n</settings>')

        with open(tmdbh_settings_xml, 'w', encoding='utf-8') as f:
            f.write(updated_content)

    except Exception as e:
        xbmc.log(f"[Master_Build] Αποτυχία dynamic αλλαγής γλώσσας σε {value}: {str(e)}", xbmc.LOGERROR)


def _clean_title(t):
    if not t:
        return ''
    t = re.sub(r'\[COLOR[^\]]*\]|\[/COLOR\]|\[B\]|\[/B\]|\[I\]|\[/I\]', '', t)
    t = re.sub(r'\(\d{4}\)', '', t)
    return t.replace(',', ' ').strip()


def _get_local_tmdb_keys():
    keys = []
    try:
        s_xml = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.themoviedb.helper/settings.xml')
        if xbmcvfs.exists(s_xml):
            with open(s_xml, 'r', encoding='utf-8') as f:
                txt = f.read()
            m = re.search(r'<setting id="tmdb_apikey"[^>]*>([^<]+)</setting>', txt)
            if m and len(m.group(1).strip()) == 32:
                keys.append(m.group(1).strip())
    except Exception:
        pass

    addon_paths = [
        'special://home/addons/plugin.video.themoviedb.helper/resources/lib',
        'special://home/addons/plugin.video.blacklodge/resources/lib',
        'special://home/addons/script.extendedinfo/resources/lib',
    ]
    for ap in addon_paths:
        real_ap = xbmcvfs.translatePath(ap)
        if not os.path.exists(real_ap):
            continue
        for root, _, files in os.walk(real_ap):
            for fn in files:
                if fn.endswith('.py'):
                    try:
                        with open(os.path.join(root, fn), 'r', encoding='utf-8', errors='ignore') as f:
                            content = f.read()
                        for found in re.findall(r'["\']([a-f0-9]{32})["\']', content):
                            if found not in keys:
                                keys.append(found)
                        if len(keys) >= 5:
                            break
                    except Exception:
                        pass
            if len(keys) >= 5:
                break
    return keys


def _resolve_tmdb_id(titles, year):
    tid = (
        xbmc.getInfoLabel('Container(8034).ListItem.UniqueID(tmdb)')
        or xbmc.getInfoLabel('Container(8034).ListItem.Property(tmdb_id)')
        or xbmc.getInfoLabel('Skin.String(HubMovieTMDB)')
    ).strip()
    if tid and tid.isdigit():
        return tid

    keys = _get_local_tmdb_keys()
    if not keys:
        return ''

    ctx = ssl._create_unverified_context()
    host = 'https://api.themoviedb.' + 'org/3/search/movie'

    for api_key in keys:
        for t in titles:
            if not t:
                continue
            q = urllib.parse.quote(t)
            attempts = [
                f'{host}?api_key={api_key}&language=el-GR&query={q}',
                f'{host}?api_key={api_key}&language=en-US&query={q}',
            ]
            if year and year.isdigit():
                attempts.insert(0, f'{host}?api_key={api_key}&language=el-GR&query={q}&year={year}')
                attempts.insert(1, f'{host}?api_key={api_key}&language=en-US&query={q}&year={year}')

            for url in attempts:
                try:
                    req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
                    raw = urllib.request.urlopen(req, timeout=4.0, context=ctx).read().decode('utf-8')
                    data = json.loads(raw)
                    results = data.get('results') or []
                    if results and isinstance(results, list):
                        first = results.pop(0)
                        if isinstance(first, dict) and first.get('id'):
                            return str(first['id'])
                except Exception:
                    continue
    return ''


def main():
    xbuiltin = xbmc.executebuiltin

    # 🔒 BLACKLODGE INTERNAL PAGE BYPASS (Η ΔΟΚΙΜΑΣΜΕΝΗ ΣΥΝΤΑΓΗ)
    current_title = xbmc.getInfoLabel('ListItem.Title')
    current_label = xbmc.getInfoLabel('ListItem.Label')
    folder_path = xbmc.getInfoLabel('ListItem.FolderPath')

    if current_title == '' or 'Next' in current_label or 'Επόμενη' in current_label or 'page' in current_label:
        if folder_path and folder_path != '':
            xbuiltin('ActivateWindow(10025,"{}",return)'.format(folder_path))
        else:
            xbuiltin('Action(Select)')
        return

    # 🎯 FORCE FOCUS LOCK: Κλειδώνουμε το focus στο 8034 για να διαβάσουμε σωστά
    xbuiltin('Control.SetFocus(8034)')
    xbmc.sleep(100)

    # Διαβάζουμε live τα δεδομένα από το Container 8034
    live_orig  = _clean_title(xbmc.getInfoLabel('Container(8034).ListItem.OriginalTitle') or xbmc.getInfoLabel('ListItem.OriginalTitle'))
    live_title = _clean_title(xbmc.getInfoLabel('Container(8034).ListItem.Title') or xbmc.getInfoLabel('ListItem.Title'))
    live_year  = (xbmc.getInfoLabel('Container(8034).ListItem.Year') or xbmc.getInfoLabel('ListItem.Year')).strip()

    best_title = live_orig or live_title
    if not best_title:
        xbmc.log("[Master_Build] Σφάλμα: Δεν βρέθηκαν δεδομένα στο widget 8034!", xbmc.LOGERROR)
        return

    tmdb_id = _resolve_tmdb_id([live_orig, live_title], live_year)

    # Εγγράφουμε τα δεδομένα στα Skin Strings
    xbuiltin(f'Skin.SetString(HubMovieTitle,{live_title or best_title})')
    if live_orig:
        xbuiltin(f'Skin.SetString(HubMovieOrigTitle,{live_orig})')
    xbuiltin(f'Skin.SetString(HubMovieYear,{live_year})')
    if tmdb_id:
        xbuiltin(f'Skin.SetString(HubMovieTMDB,{tmdb_id})')
    xbmc.sleep(100)

    # 🤫 1. ΑΘΟΡΥΒΟ ΚΛΕΙΔΩΜΑ ΣΤΗΝ ΤΙΜΗ 18 ΣΤΗΝ ΑΡΧΗ
    set_tmdbh_language(18)
    xbmc.sleep(200)

    # ⚡ ΑΡΧΙΚΟΣ ΚΑΘΑΡΙΣΜΟΣ
    xbuiltin('Action(Stop)')
    xbuiltin('PlayerControl(Stop)')
    xbmc.sleep(350)

    # ⚙️ ΔΥΝΑΜΙΚΑ ΔΕΔΟΜΕΝΑ
    sound_file = 'special://skin/sounds/BladeRunner.wav'
    icon_file  = 'special://home/addons/skin.19MatrixWorld/media/Media Player.png'
    title_text = '[COLOR white]Επιλέξτε[/COLOR]'
    msg_text   = '[B][COLOR orange]Player[/COLOR][/B]'

    # 1. 🔒 ΚΛΕΙΣΙΜΟ HUB 6199 (Αν είναι ανοιχτό)
    xbuiltin('Dialog.Close(6199)')
    xbmc.sleep(350)

    # 2. 📥 DYNAMIC INJECTION
    xbuiltin(f'Skin.SetString(NotifyTitle,{title_text})')
    xbuiltin(f'Skin.SetString(NotifyMessage,{msg_text})')
    xbuiltin(f'Skin.SetString(NotifyIcon,{icon_file})')
    xbuiltin(f'Skin.SetString(NotifySound,{sound_file})')

    # 🚀 3. DIRECT ΕΝΤΟΛΗ ΜΕ TMDB_ID (Ώστε ο GR Audio να βρίσκει πάντα ροή!)
    if tmdb_id:
        tmd_script = f'plugin.video.themoviedb.helper,play_using,tmdb_type=movie,tmdb_id={tmdb_id},ignore_default=true'
    else:
        tmd_script = f'plugin.video.themoviedb.helper,play_using,tmdb_type=movie,query={best_title},year={live_year},ignore_default=true'

    xbuiltin(f'RunScript({tmd_script})')

    # ⏳ ΔΙΝΟΥΜΕ ΧΡΟΝΟ ΝΑ ΑΝΟΙΞΕΙ ΤΟ ΠΑΡΑΘΥΡΟ ΜΕ ΤΟΥΣ PLAYERS
    xbmc.sleep(800)

    # 🤫 2. ΑΦΟΥ ΑΝΟΙΞΕΙ, ΤΟ ΓΥΡΝΑΜΕ ΠΑΛΙ ΣΤΟ 12 ΑΘΟΡΥΒΑ
    set_tmdbh_language(12)
    xbmc.sleep(200)

    # 🤖 4. ΠΑΡΑΚΑΜΨΗ ΠΑΡΑΘΥΡΟΥ MANALAB
    mana_timeout = 0
    while not xbmc.getCondVisibility('Window.IsVisible(yesnodialog)') and mana_timeout < 15:
        xbmc.sleep(100)
        mana_timeout += 1

    if xbmc.getCondVisibility('Window.IsVisible(yesnodialog)'):
        xbmc.sleep(200)
        xbuiltin('Action(Left)')
        xbmc.sleep(150)
        xbuiltin('Action(Select)')

    xbmc.sleep(400)


if __name__ == '__main__':
    main()
