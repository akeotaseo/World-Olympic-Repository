# -*- coding: utf-8 -*-
import xbmc, xbmcgui, socket, importlib

# 1. Αποθηκεύουμε το παράθυρο και τη θέση που βρισκόταν ο χρήστης
start_win = xbmcgui.getCurrentWindowId()
home_win = xbmcgui.Window(10000)
last_cat_id = xbmc.getInfoLabel('Skin.String(LastFocusedCategory)')

# 2. Κλείνουμε αμέσως το τρέχον παράθυρο και βγάζουμε ειδοποίηση
xbmc.executebuiltin('Dialog.Close(all,true)')
xbmcgui.Dialog().notification('[B][COLOR red]✖ Ακύρωση[/COLOR][/B]', '[COLOR white]Παρακαλώ περιμένετε...[/COLOR]', xbmcgui.NOTIFICATION_INFO, time=2500, sound=False)

# 3. Παρακολουθούμε έως 7 δευτερόλεπτα (70 x 0.1s), με έξυπνη πρόωρη έξοδο
quiet_ticks = 0

for _ in range(70):
	xbmc.sleep(100)
	closed_something = False

	if xbmc.getCondVisibility('Window.IsVisible(okdialog)'):
		xbmc.executebuiltin('Dialog.Close(okdialog,true)')
		closed_something = True
	if xbmc.getCondVisibility('Window.IsVisible(yesnodialog)'):
		xbmc.executebuiltin('Dialog.Close(yesnodialog,true)')
		closed_something = True
	if xbmc.getCondVisibility('Window.IsVisible(selectdialog)'):
		xbmc.executebuiltin('Dialog.Close(selectdialog,true)')
		closed_something = True

	if closed_something:
		quiet_ticks = 0
	else:
		quiet_ticks += 1
		if quiet_ticks >= 10:
			break

# 4. Αφού καθαρίσουν όλοι οι διάλογοι, αν το script άνοιξε άλλο παράθυρο (π.χ. Ρυθμίσεις),
#    μπλοκάρουμε προσωρινά το auto-focus του Home.xml και γυρίζουμε ακριβώς εκεί που ήμασταν
if xbmcgui.getCurrentWindowId() != start_win:
	home_win.setProperty('BlockHomeAutoFocus', 'true')
	xbmc.executebuiltin('Dialog.Close(all,true)')
	xbmc.sleep(100)
	xbmc.executebuiltin('Action(Back)')
	xbmc.sleep(300)
	
	if last_cat_id == '1':
		xbmc.executebuiltin('Control.SetFocus(9000,0,absolute)')
	
	home_win.clearProperty('BlockHomeAutoFocus')

# 5. Ακαριαίος καθαρισμός DNS/Socket της Python (0.001s - μηδέν επιβάρυνση)
try:
	importlib.reload(socket)
	socket.setdefaulttimeout(6)
except:
	pass

xbmcgui.Dialog().notification('[B][COLOR lime]Έτοιμο![/COLOR][/B]', '[COLOR white]Τα παράθυρα έκλεισαν.[/COLOR]', xbmcgui.NOTIFICATION_INFO, time=1500, sound=False)
