﻿import xbmc, xbmcgui
def Backup():
    # xbmc.executebuiltin('Dialog.Close(all,true)')
    # xbmc.executebuiltin('Action(Back)')
    # xbmc.executebuiltin('Dialog.Close(all,true)')
    # xbmc.executebuiltin('ActivateWindow(Home)')
    # xbmc.sleep(1000)
    xbmcgui.Dialog().notification("[B][COLOR orange]Ανακατεύθυνση...[/COLOR][/B]", "[COLOR white][B]--->[/B][/COLOR] [COLOR orange]World Updater - Tools [/COLOR]Back up", sound=False, icon='special://home/addons/plugin.program.downloader19/resources/media/Pleasewait.png')
    xbmc.sleep(4000)
    xbmc.executebuiltin('ActivateWindow(10001,"plugin://plugin.program.downloader19/?description&fanart=C%3a%5cPortableApps%5ckodi%5ckodi%20World%2021%5cKodi%5cportable_data%5caddons%5cplugin.program.downloader19%5cfanart.jpg&icon=special%3a%2f%2fhome%2faddons%2fplugin.program.downloader19%2fresources%2fmedia%2fsave.png&mode=17&name=%ce%91%ce%bd%cf%84%ce%af%ce%b3%cf%81%ce%b1%cf%86%ce%bf%20%ce%b1%cf%83%cf%86%ce%b1%ce%bb%ce%b5%ce%af%ce%b1%cf%82%20%26%20%ce%95%cf%80%ce%b1%ce%bd%ce%b1%cf%86%ce%bf%cf%81%ce%ac%20Build&name2&url&version")')
    xbmc.executebuiltin('ActivateWindow(10001,"plugin://plugin.program.downloader19/?description&fanart=C%3a%5cPortableApps%5ckodi%5ckodi%20World%2021%5cKodi%5cportable_data%5caddons%5cplugin.program.downloader19%5cfanart.jpg&icon=special%3a%2f%2fhome%2faddons%2fplugin.program.downloader19%2fresources%2fmedia%2fsave.png&mode=17&name=%ce%91%ce%bd%cf%84%ce%af%ce%b3%cf%81%ce%b1%cf%86%ce%bf%20%ce%b1%cf%83%cf%86%ce%b1%ce%bb%ce%b5%ce%af%ce%b1%cf%82%20%26%20%ce%95%cf%80%ce%b1%ce%bd%ce%b1%cf%86%ce%bf%cf%81%ce%ac%20Build&name2&url&version")')
    xbmc.executebuiltin('ActivateWindow(10001,"plugin://plugin.program.downloader19/?description&fanart=C%3a%5cPortableApps%5ckodi%5ckodi%20World%2021%5cKodi%5cportable_data%5caddons%5cplugin.program.downloader19%5cfanart.jpg&icon=special%3a%2f%2fhome%2faddons%2fplugin.program.downloader19%2fresources%2fmedia%2fsave.png&mode=17&name=%ce%91%ce%bd%cf%84%ce%af%ce%b3%cf%81%ce%b1%cf%86%ce%bf%20%ce%b1%cf%83%cf%86%ce%b1%ce%bb%ce%b5%ce%af%ce%b1%cf%82%20%26%20%ce%95%cf%80%ce%b1%ce%bd%ce%b1%cf%86%ce%bf%cf%81%ce%ac%20Build&name2&url&version")')


    #xbmc.executebuiltin('Action(Back)')
    #xbmc.executebuiltin('Dialog.Close(all,true)')
    #xbmc.sleep(1000)

Backup()