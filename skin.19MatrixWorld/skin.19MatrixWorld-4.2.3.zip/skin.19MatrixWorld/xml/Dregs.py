﻿import xbmc, xbmcgui

# xbmc.executebuiltin('Dialog.Close(all,true)')
# xbmc.executebuiltin('Action(Back)')
# xbmc.executebuiltin('Dialog.Close(all,true)')
# xbmc.executebuiltin('ActivateWindow(Home)')
# xbmc.sleep(1000)
xbmcgui.Dialog().notification("[B][COLOR orange]Dregs[/COLOR][/B]", "[COLOR white]Fron [/COLOR][COLOR red]Dr[/COLOR]e[COLOR grey]Gs[/COLOR] [COLORcyan]Repository[/COLOR]", sound=False, icon='https://avatars.githubusercontent.com/u/171382214?v=4')
xbmc.sleep(2000)
# xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.mypreferences/?cmd=ActivateWindow(10025%2c%22plugin%3a%2f%2fplugin.program.myselect%2f%3fgroup%3ddregs1-1757664443.6623688%26mode%3dgroup%26refresh%26reload%22)&content_type=video&image=https%3a%2f%2favatars.githubusercontent.com%2fu%2f171382214%3fv%3d4&label=Dregs&mode=650",return)')
xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.myselect/?group=dregs1-1757664443.6623688&mode=group&refresh&reload",return)')
xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.myselect/?group=dregs1-1757664443.6623688&mode=group&refresh&reload")')
xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.myselect/?group=dregs1-1757664443.6623688&mode=group&refresh&reload",return)')
#xbmc.executebuiltin('Action(Back)')
#xbmc.executebuiltin('Dialog.Close(all,true)')
#xbmc.sleep(1000)


