﻿import xbmc, xbmcgui
def Backups():
    # xbmc.executebuiltin('Dialog.Close(all,true)')
    # xbmc.executebuiltin('Action(Back)')
    # xbmc.executebuiltin('Dialog.Close(all,true)')
    # xbmc.executebuiltin('ActivateWindow(Home)')
    # xbmc.sleep(1000)
    xbmcgui.Dialog().notification("[B][COLOR orange]Ανακατεύθυνση...[/COLOR][/B]", "[COLOR white][B]--->[/B][/COLOR] [COLOR blue]G.K.N.Wizard [/COLOR]Back up", sound=False, icon='special://home/addons/plugin.program.downloader19/resources/media/Pleasewait.png')
    xbmc.sleep(4000)
    xbmc.executebuiltin('ActivateWindow(10001,"plugin://plugin.program.G.K.N.Wizard/?mode=maint&name=backup")')
    xbmc.executebuiltin('ActivateWindow(10001,"plugin://plugin.program.G.K.N.Wizard/?mode=maint&name=backup")')
    xbmc.executebuiltin('ActivateWindow(10001,"plugin://plugin.program.G.K.N.Wizard/?mode=maint&name=backup")')


    #xbmc.executebuiltin('Action(Back)')
    #xbmc.executebuiltin('Dialog.Close(all,true)')
    #xbmc.sleep(1000)

Backups()