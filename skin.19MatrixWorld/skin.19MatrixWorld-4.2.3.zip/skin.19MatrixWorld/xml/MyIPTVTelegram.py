﻿import xbmc, xbmcgui

def MyIPTVTelegram():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.sleep(500)
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.downloader/?_id&description&episode_number&fanart&foldername&icon=C%3a%5cPortableApps%5ckodi%5ckodi%20World%2021%5cKodi%5cportable_data%5caddons%5cplugin.program.downloader%5cresources%5cicons%5cxcodes.jpg&mediatype=video&mode=get_remote_xcodes&name=World%20Build%20Telegram%20x-treme%20codes%20(AllTelegram)&name2&page&season_number&url=%7b%22url%22%3a%20%22https%3a%2f%2fraw.githubusercontent.com%2fakeotaseo%2fworld_repo%2fmain%2fUpdater_Matrix%2fXML2%2f%257BAllTelegram%257D2.txt%22%7d")')
    xbmcgui.Dialog().notification("[B]My[COLOR orangered]IPTV[/COLOR][/B]", "World build Telegram x-treme codes", sound=False, icon='https://styles.redditmedia.com/t5_28w7mp/styles/communityIcon_j5m34lvey9041.jpg')
    xbmc.sleep(4000)
    xbmcgui.Dialog().notification("[B]My[COLOR orangered]IPTV[/COLOR][/B]", "World build Telegram x-treme codes", sound=False, icon='https://styles.redditmedia.com/t5_28w7mp/styles/communityIcon_j5m34lvey9041.jpg')
MyIPTVTelegram()
