import xbmc, xbmcgui



def Tennis():
    funcs = (click_1, click_2)
    call = xbmcgui.Dialog().select('[B][COLOR=yellow]TENNIS[/COLOR][/B]',
['[COLOR=blue]TENNIS[/COLOR] (The Loop)',

 '[COLOR=orange]TENNIS[/COLOR] (Microjen)'


 ])




    if call:
        if call < 1:
            return
        func = funcs[call-2]
        return func()
    else:
        func = funcs[call]
        return func()
    return 






def click_1():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.the-loop/get_list/HkYBGxACVkIYBA0HF1YRBA0WDAZbDQsbE0FaAFIBVhUZBxFYMFMbMQxWHFxNRBYSGFwcGE1SCgIa")')
    xbmcgui.Dialog().notification("[B][COLOR green]Loop[/COLOR][/B]", "[COLOR yellow]TENNIS[/COLOR]", sound=False, icon='special://home/addons/plugin.image.World/resources/media/addonset foto/the-loop.png')
    xbmc.sleep(4000)
    xbmcgui.Dialog().notification("[B][COLOR green]Loop[/COLOR][/B]", "[COLOR yellow]TENNIS[/COLOR]", sound=False, icon='special://home/addons/plugin.image.World/resources/media/addonset foto/the-loop.png')
def click_2():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.microjen/sporthd?description=Tennis&iconimage=C%3a%5cPortableApps%5ckodi%5cKODI%20TEST%5cKodi%5cportable_data%5caddons%5cplugin.video.microjen%5cresources%5clib%5cexternal%5csporthd%5cmedia%5clivetv.png&mode=livetvSX_events&name=Tennis%20(63)&url=sport%7cTennis")')
    xbmcgui.Dialog().notification("[B][COLOR orange]Microjen[/COLOR][/B]", "[B][COLOR white]TENNIS[/COLOR][/B]", sound=False, icon='special://home/addons\skin.19MatrixWorld/media/livetv.sx.png')
    xbmc.sleep(4000)
    xbmcgui.Dialog().notification("[B][COLOR orange]Microjen[/COLOR][/B]", "[B][COLOR white]TENNIS[/COLOR][/B]", sound=False, icon='special://home/addons/plugin.video.microjen/resources/lib/external/sporthd\media/livetv.png')
Tennis()
