﻿import xbmc, xbmcgui
xbmc.executebuiltin('Dialog.Close(all,true)')

xbmcgui.Dialog().notification("[B][COLOR green]Thegroove360[/COLOR][/B]", "IPTV", sound=False, icon='special://home/addons/plugin.video.thegroove360/icon.gif')

def DialogThegroove360():



    funcs = (click_1, click_2, click_3)
    call = xbmcgui.Dialog().select('[B][COLOR=green]~ Thegroove360 ~[/COLOR][/B]', 
['[B] [COLOR white] LISTE CERTIFICATE[/COLOR] [/B][B] [COLOR green] on line [/COLOR] [/B]',
 '[B] [COLOR white]LE MAC DEL CHIMICO[/COLOR] [/B]', 
 '[B] [COLOR white]LISTE MAC[/COLOR] [/B]'])


    if call:
        if call < 0:
            return
        func = funcs[call-3]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.thegroove360/thegroove/scripters/Soter/path%3Dilchimico_M3U.php")')
    xbmcgui.Dialog().notification("[B][COLOR orange]Keep calm and just wait[/COLOR][/B]", "[COLOR green]Περιμένετε...[/COLOR]", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/top/Pleasewait.png')
    xbmc.sleep(4000)
    xbmcgui.Dialog().notification("[B][COLOR orange]They don't always work[/COLOR][/B]", "[COLOR green]Δεν λειτουργούν πάντα...[/COLOR]", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/top/doestworkalltime.png')
    xbmc.sleep(4000)

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.thegroove360/thegroove/scripters/Soter/path%3Dilchimico_mac.php")')
    xbmcgui.Dialog().notification("[B][COLOR orange]Keep calm and just wait[/COLOR][/B]", "[COLOR green]Περιμένετε...[/COLOR]", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/top/Pleasewait.png')
    xbmc.sleep(4000)
    xbmcgui.Dialog().notification("[B][COLOR orange]They don't always work[/COLOR][/B]", "[COLOR green]Δεν λειτουργούν πάντα...[/COLOR]", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/top/doestworkalltime.png')
    xbmc.sleep(4000)

def click_3():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.thegroove360/thegroove/scripters/Soter/path%3Diptv_mac.php")')
    xbmcgui.Dialog().notification("[B][COLOR orange]Keep calm and just wait[/COLOR][/B]", "[COLOR green]Περιμένετε...[/COLOR]", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/top/Pleasewait.png')
    xbmc.sleep(4000)
    xbmcgui.Dialog().notification("[B][COLOR orange]They don't always work[/COLOR][/B]", "[COLOR green]Δεν λειτουργούν πάντα...[/COLOR]", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/top/doestworkalltime.png')
    xbmc.sleep(4000)

DialogThegroove360()
