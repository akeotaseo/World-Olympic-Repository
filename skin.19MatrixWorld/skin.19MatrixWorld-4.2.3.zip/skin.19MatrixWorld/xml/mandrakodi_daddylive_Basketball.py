﻿import xbmc, xbmcgui
xbmcgui.Dialog().notification("[B][COLOR orange]Ανακατεύθυνση...[/COLOR][/B]", "[B][COLOR aqua]mandrakodi[/COLOR][/B]--->[COLOR lime]DaddyLive[/COLOR]", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/DaddyLive.jpg')
# xbmc.executebuiltin('Dialog.Close(all,true)')
# xbmc.executebuiltin('Action(Back)')
# xbmc.executebuiltin('Dialog.Close(all,true)')
# xbmc.executebuiltin('ActivateWindow(Home)')

# xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.mandrakodi/?action=getExtData&url=https%3a%2f%2ftest34344.herokuapp.com%2ffilter.php")')
# xbmc.sleep(3000)
# xbmcgui.Dialog().notification("[B][COLOR orange]Ανακατεύθυνση...[/COLOR][/B]", "[B][COLOR aqua]mandrakodi[/COLOR][/B]--->[COLOR lime]DaddyLive[/COLOR]", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/DaddyLive.jpg')
# xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.mandrakodi/?action=getExtData&url=https%3a%2f%2ftest34344.herokuapp.com%2ffilter.php%3fnumTest%3dJOB100")')

# xbmc.sleep(3000)
# xbmcgui.Dialog().notification("[B][COLOR orange]Ανακατεύθυνση...[/COLOR][/B]", "[B][COLOR aqua]mandrakodi[/COLOR][/B]--->[COLOR lime]DaddyLive[/COLOR]", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/DaddyLive.jpg')
xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.mandrakodi/?action=m3u&url=https%3a%2f%2fworld-proxifier.xyz%2fdaddylive%2fplaylist.m3u8%3ftimezone%3dcet")')
xbmc.sleep(3000)
# xbmcgui.Dialog().notification("[B][COLOR orange]Ανακατεύθυνση...[/COLOR][/B]", "[B][COLOR aqua]mandrakodi[/COLOR][/B]--->[COLOR lime]DaddyLive[/COLOR]", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/DaddyLive.jpg')
xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.mandrakodi/?action=getChannel&url=%5bCOLOR%20lime%5dEVENTS%7c%20BASKETBALL%5b%2fCOLOR%5d")')


