﻿import xbmc, xbmcgui
def DialogLiveFootball():
    # xbmc.executebuiltin('Dialog.Close(all,true)')
    # xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.shadow/?all_w=%7b%7d&data&dates=%20&description=Live%20Football&eng_name=%20&episode=%20&fanart=https%3a%2f%2fmylostsoulspace.co.uk%2fimages%2fSports-Icoms%2ffanart.jpg&fav_status=false&heb_name=%20&iconimage=https%3a%2f%2fmylostsoulspace.co.uk%2fimages%2fSports-Icoms%2flivefootball.png&id&image_master&isr=0&last_id&mode=189&mypass&name=%5bCOLOR%20goldenrod%5dLive%20Football%5b%2fCOLOR%5d&original_title=%5bCOLOR%20goldenrod%5dLive%20Football%5b%2fCOLOR%5d&search_db&season=%20&show_original_year=%20&tmdbid=%20&url=https%3a%2f%2fmylostsoulspace.co.uk%2fAddon-1%2fAddon%2ftext%2fAll-Sports-xmls%2flivefootball.xml&video_data=%7b%22title%22%3a%20%22%5bCOLOR%20goldenrod%5dLive%20Football%5b%2fCOLOR%5d%22%2c%20%22mediatype%22%3a%20%22movie%22%2c%20%22TVshowtitle%22%3a%20%22%22%2c%20%22season%22%3a%200%2c%20%22episode%22%3a%200%2c%20%22OriginalTitle%22%3a%20%22%5bCOLOR%20goldenrod%5dLive%20Football%5b%2fCOLOR%5d%22%2c%20%22year%22%3a%20%22%22%2c%20%22rating%22%3a%20%220%22%2c%20%22plot%22%3a%20%22Live%20Football%22%2c%20%22Tag%22%3a%20%22189%22%2c%20%22trailer%22%3a%20%22%22%2c%20%22id%22%3a%20%22%22%7d")')
    # xbmcgui.Dialog().notification("[B][COLOR gold]Asgard[/COLOR][/B]", "[COLOR white]Live Football[/COLOR]", sound=False, icon='special://home/addons/plugin.image.World/resources/media/addonset foto/livefootball-2.png')
    # xbmc.sleep(4000)
    # xbmcgui.Dialog().notification("[B][COLOR gold]Asgard[/COLOR][/B]", "[COLOR white]Live Football[/COLOR]", sound=False, icon='special://home/addons/plugin.image.World/resources/media/addonset foto/livefootball-2.png')
    # xbmc.sleep(4000)
    # xbmcgui.Dialog().notification("[B][COLOR gold]Asgard[/COLOR][/B]", "[COLOR white]Live Football[/COLOR]", sound=False, icon='special://home/addons/plugin.image.World/resources/media/addonset foto/livefootball-2.png')


    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.the-loop/get_list/HkYBGxACVkIYBA0HF1YRBA0WDAZbDQsbE0FaAFIBVhUZBxFYJVEaGQZiFgMRRBEYFVEQGRdXHQwNX0wdBV0b")')
    xbmcgui.Dialog().notification("[B][COLOR green]Loop[/COLOR][/B]", "[COLORyellow][B]Todays Football[/COLOR][/B]", sound=False, icon='special://home/addons/plugin.image.World/resources/media/addonset foto/the-loop.png')
    xbmc.sleep(4000)




DialogLiveFootball()
