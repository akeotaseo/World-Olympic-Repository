﻿import xbmc, xbmcgui
def DialogFootball():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloader19/set_setting_LivetvsxACE_off.py")')
    # xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.dracarys/?category=live_sport&mode=open_site_category&site=livetv&url=https%3a%2f%2flivetv751.me%2fenx%2fallupcomingsports%2f1%2f")')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.microjen/sporthd?description=Football&iconimage=C%3a%5cPortableApps%5ckodi%5cKODI%20TEST%5cKodi%5cportable_data%5caddons%5cplugin.video.microjen%5cresources%5clib%5cexternal%5csporthd%5cmedia%5clivetv.png&mode=livetvSX_events&name=Football%20(36)&url=sport%7cFootball")')
    xbmcgui.Dialog().notification("[B][COLOR orange]Microjen[/COLOR][/B]", "[COLOR white]FOOTBALL[/COLOR]", sound=False, icon='special://home/addons\skin.19MatrixWorld/media/livetv.sx.png')
    xbmc.sleep(4000)
    xbmcgui.Dialog().notification("[B][COLOR orange]Microjen[/COLOR][/B]", "[COLOR white]FOOTBALL[/COLOR]", sound=False, icon='special://home/addons/plugin.video.microjen/resources/lib/external/sporthd\media/livetv.png')

DialogFootball()
