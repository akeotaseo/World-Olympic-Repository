﻿import xbmc

def AddonBrowser():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    #xbmc.sleep(200)
    #xbmc.executebuiltin("ActivateWindow(Home)")
    #xbmc.sleep(1000)
    xbmc.executebuiltin('ActivateWindow(AddonBrowser,return)')

AddonBrowser()
