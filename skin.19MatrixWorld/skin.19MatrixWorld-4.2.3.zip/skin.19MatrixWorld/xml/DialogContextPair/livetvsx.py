import xbmc, xbmcgui, webbrowser


def livetvsx():
    dialog = xbmcgui.Dialog()
    funcs = (site1, site2)

    call = dialog.select('Ανακατεύθυνση σε [B][COLOR=blue]Browser[/COLOR][/B]',
    
['[COLOR=white]livetv.sx/enx/[/COLOR]',
 '[COLOR=white]livetv872.me[/COLOR]'
 ])

    if call:
        if call < 0:
            return
        func = funcs[call-2]
        return func()
    else:
        func = funcs[call]
        return func()
    return 

def platform():
    if xbmc.getCondVisibility('system.platform.android'):
        return 'android'
    elif xbmc.getCondVisibility('system.platform.linux'):
        return 'linux'
    elif xbmc.getCondVisibility('system.platform.windows'):
        return 'windows'
    elif xbmc.getCondVisibility('system.platform.osx'):
        return 'osx'
    elif xbmc.getCondVisibility('system.platform.atv2'):
        return 'atv2'
    elif xbmc.getCondVisibility('system.platform.ios'):
        return 'ios'

myplatform = platform()


def site1():
    if myplatform == 'android': opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://livetv.sx/enx/' ) )
    else: opensite = webbrowser . open('https://livetv.sx/enx/')

def site2():
    if myplatform == 'android': opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://livetv872.me/enx/' ) )
    else: opensite = webbrowser . open('https://livetv872.me/enx/')




livetvsx()