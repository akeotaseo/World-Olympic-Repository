import xbmc, xbmcgui, webbrowser


def alphatv():
    dialog = xbmcgui.Dialog()
    funcs = (site1, site2)
    xbmcgui.Dialog().ok("[B][COLOR blue]ALPHA[/COLOR][/B]", "Πατήστε Εντάξει για να μεταφερθείτε στο site https://www.alphatv.gr")
    call = dialog.select('[B][COLOR blue]ALPHA[/COLOR][/B]',
    
['Μεταφερθείτε στον ALPHA TV'])

    if call:
        if call < 0:
            return
        func = funcs[call-2]
        return func()
    else:
        func = funcs[call]
        return func()
    return 

def platform():
    if xbmc.getCondVisibility('system.platform.android'):
        return 'android'
    elif xbmc.getCondVisibility('system.platform.linux'):
        return 'linux'
    elif xbmc.getCondVisibility('system.platform.windows'):
        return 'windows'
    elif xbmc.getCondVisibility('system.platform.osx'):
        return 'osx'
    elif xbmc.getCondVisibility('system.platform.atv2'):
        return 'atv2'
    elif xbmc.getCondVisibility('system.platform.ios'):
        return 'ios'

myplatform = platform()


def site1():
    if myplatform == 'android': opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.subs4free.info/' ) )
    else: opensite = webbrowser . open('https://www.alphatv.gr/')

def site2():
    if myplatform == 'android': opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.subs4free.info/' ) )
    else: opensite = webbrowser . open('https://www.alphatv.gr/')

alphatv()
