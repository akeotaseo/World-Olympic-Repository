﻿import xbmc, xbmcgui

def MyGroups():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmcgui.Dialog().notification("[B][COLOR orange]Ανακατεύθυνση...[/COLOR][/B]", "[COLOR white][B]--->[/B][/COLOR] [COLOR blue]My Select[/COLOR]", sound=False, icon='special://home/addons/plugin.program.downloader19/resources/media/Pleasewait.png')
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('Action(Back)')
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10000)')
    xbmc.sleep(2000)

    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.mypreferences/?content_type=video&fanart=C%3a%5cPortableApps%5ckodi%5cKODI%20TEST%5cKodi%5cportable_data%5caddons%5cplugin.program.mypreferences%5cfanart.jpg&image=special%3a%2f%2fhome%2faddons%2fplugin.image.World%2fresources%2fmedia%2ffoto%2ftmdb.png&label=My%20Select&mode=400&path=special%3a%2f%2fprofile%2faddon_data%2fplugin.program.mypreferences%5cSuper%20Favourites%5cMy%20Select")')
MyGroups()
