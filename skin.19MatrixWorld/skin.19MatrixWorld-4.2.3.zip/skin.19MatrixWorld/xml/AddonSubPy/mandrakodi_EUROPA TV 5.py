﻿import xbmc, xbmcgui
xbmcgui.Dialog().notification("[B][COLOR orange]Ανακατεύθυνση...[/COLOR][/B]", "[B][COLOR aqua]mandrakodi[/COLOR][/B]--->[COLOR lime]IT[/COLOR]", sound=False, icon='special://home/addons/plugin.image.World/resources/media/flags/Italy..png')
xbmc.executebuiltin('Dialog.Close(all,true)')
xbmc.executebuiltin('Action(Back)')
xbmc.executebuiltin('Dialog.Close(all,true)')
xbmc.executebuiltin('ActivateWindow(Home)')

xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.mandrakodi/?action=getExtData&url=https%3a%2f%2ftest34344.herokuapp.com%2ffilter.php")')
xbmc.sleep(3000)
xbmcgui.Dialog().notification("[B][COLOR orange]Ανακατεύθυνση...[/COLOR][/B]", "[B][COLOR aqua]mandrakodi[/COLOR][/B]--->[COLOR lime]IT[/COLOR]", sound=False, icon='special://home/addons/plugin.image.World/resources/media/flags/Italy..png')
xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.mandrakodi/?action=getExtData&url=https%3a%2f%2ftest34344.herokuapp.com%2ffilter.php%3fnumTest%3dJOB200")')

xbmc.sleep(3000)
xbmcgui.Dialog().notification("[B][COLOR orange]Ανακατεύθυνση...[/COLOR][/B]", "[B][COLOR aqua]mandrakodi[/COLOR][/B]--->[COLOR lime]IT[/COLOR]", sound=False, icon='special://home/addons/plugin.image.World/resources/media/flags/Italy..png')
xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.mandrakodi/?action=getExtData&url=https%3a%2f%2ftest34344.herokuapp.com%2ffilter.php%3fnumTest%3dA1A245")')
xbmc.sleep(3000)
xbmcgui.Dialog().notification("[B][COLOR orange]Ανακατεύθυνση...[/COLOR][/B]", "[B][COLOR aqua]mandrakodi[/COLOR][/B]--->[COLOR lime]IT[/COLOR]", sound=False, icon='special://home/addons/plugin.image.World/resources/media/flags/Italy..png')
xbmc.sleep(3000)
xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.mandrakodi/?action=myresolve&parIn=Italy&url=vavooCh")')
