﻿import xbmc, xbmcgui

def ReSetDataSkin():
    xbmcgui.Dialog().select('[B][COLOR orange]TEST[/COLOR][/B]', ['[COLOR lime]test...[/COLOR]'])
    xbmc.sleep(2000)

    xbmc.executebuiltin('Skin.ResetSettings')
    xbmc.executebuiltin('Dialog.Close(2121)')
    xbmc.sleep(2000)
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.sleep(2000)
    xbmc.executebuiltin('ReloadSkin()')
    xbmc.sleep(10000)
    
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.sleep(2000)
    xbmc.executebuiltin('ActivateWindow(home)')


ReSetDataSkin()
