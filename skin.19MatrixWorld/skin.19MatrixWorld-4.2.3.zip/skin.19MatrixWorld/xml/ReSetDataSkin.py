﻿import os, sys, glob, base64, xbmc, xbmcvfs, xbmcaddon, xbmcgui, shutil, subprocess

    # xbmc.executebuiltin('ReloadSkin()')
    # xbmc.sleep(10000)
xbmc.executebuiltin('Dialog.Close(all,true)')
xbmc.executebuiltin('Action(Back)')
xbmc.executebuiltin('Dialog.Close(all,true)')
xbmc.executebuiltin('ActivateWindow(10000)')
def ReSetDataSkin():

    Dialog_Choice_0()



def Dialog_Choice_0():
        choice = xbmcgui.Dialog().yesno('[B][COLOR orange]World[/COLOR][/B]', 'Επιστροφή στο Προκαθορισμένο [B]HOME MENU[/B].[CR]Θέλετε να εφαρμοστούν οι αλλαγές;',
                                        nolabel='Οχι',yeslabel='Ναι')
        if choice == 1: [xmlskinversion2046(),]
        if choice == 0: [xbmc.executebuiltin('Dialog.Close(all,true)'), xbmc.executebuiltin('Action(Back)'), xbmc.executebuiltin('Dialog.Close(all,true)'), xbmc.executebuiltin('ActivateWindow(10000)'),]

def xmlskinversion2046():
    addon_downloader19       = xbmcaddon.Addon('plugin.program.downloader19')
    setting_downloader19     = addon_downloader19.getSetting
    setting_set_downloader19 = addon_downloader19.setSetting
    if setting_downloader19('xmlskinversion')=='2046':
        xbmcgui.Dialog().ok('[COLOR red] ReSet [/COLOR] Data Skin', 'Η επιλογή αυτή είναι διαθέσιμη μόνο στο Προκαθορισμένο Skin')
    else:
        xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloader19/SkinMenuLAST2.py")')

ReSetDataSkin()
