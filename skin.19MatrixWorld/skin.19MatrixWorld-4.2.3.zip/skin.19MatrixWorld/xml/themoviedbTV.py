﻿import xbmc, xbmcgui

xbmcgui.Dialog().notification("[B][COLOR green]TMDb Helper[/COLOR][/B]", "[COLOR blue]Τηλ. Σειρές[/COLOR]", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/TMDBtv.png')

xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.themoviedb.helper/?info=dir_tv&tmdb_type=None",return)')


