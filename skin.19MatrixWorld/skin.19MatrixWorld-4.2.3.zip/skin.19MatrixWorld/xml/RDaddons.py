﻿import xbmc, xbmcgui

xbmcgui.Dialog().notification("[B][COLOR darkseagreen]Real-Debrid[/COLOR][/B]", "[COLOR deepskyblue]Πρόσθετα[/COLOR]", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/real_debrid.png')

xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.myselect/?group=rd-1667568941.9320223&mode=group&refresh&reload",return)')
