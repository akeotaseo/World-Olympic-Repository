﻿import xbmc, xbmcgui
xbmcgui.Dialog().notification("[B][COLOR orange]Keep calm and just wait[/COLOR][/B]", "[COLOR green]Περιμένετε...[/COLOR]", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/top/Pleasewait.png')



# def CloseButtonLeft():
    # xbmc.executebuiltin('Action(previousmenu)')
xbmc.executebuiltin('Dialog.Close(all,true)')
    # xbmc.executebuiltin('Action(Back)')
    #xbmc.sleep(200)
    #xbmc.executebuiltin("ActivateWindow(Home)")
    #xbmc.sleep(1000)
    # xbmc.executebuiltin('ActivateWindow(AddonBrowser,return)')

# CloseButtonLeft()
