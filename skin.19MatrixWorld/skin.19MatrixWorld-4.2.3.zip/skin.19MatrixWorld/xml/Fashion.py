import xbmc, xbmcgui


def Fashion():
    funcs = (click_1, click_2)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]       Fashion[/COLOR][/B]',
['[COLOR=grey]Fashion TV Player[/COLOR]',
 '[COLOR=grey]FashionTV Adaptive Streams[/COLOR]'])


    if call:
        if call < 1:
            return
        func = funcs[call-2]
        return func()
    else:
        func = funcs[call]
        return func()
    return 






def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.fashiontv.com/",return)')


def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.sportsdevil/?item=title%3dFashionTV%2bAdaptive%2bStreams%26director%3dftv.com%26icon%3dhttps%253A%252F%252Ffiles.fashiontv.com%252Fwp-content%252Fuploads%252F2018%252F02%252Fapple-icon-180x180.png%26cfg%3dhighlights%252Fftv.cfg%26url%3dhttps%253A%252F%252Fpastebin.com%252Fraw%252FpRbWnggL%26type%3drss%26genre%3dHighlights%26definedIn%3dhighlights.cfg&mode=1")')




Fashion()
