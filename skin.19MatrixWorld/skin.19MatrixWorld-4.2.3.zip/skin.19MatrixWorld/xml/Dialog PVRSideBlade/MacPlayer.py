﻿import xbmc, xbmcgui

def MacPlayer():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.downloader/mac_player_main",return)')
    xbmcgui.Dialog().notification("[B][COLOR cornflowerblue]Mac Player[/COLOR][/B]", "   ", sound=False, icon='special://home/addons/plugin.image.World/resources/media/iloveimg-resized(2)/mac.png')
    xbmc.sleep(4000)
MacPlayer()