﻿import xbmc, xbmcgui

def DialogPleaseWaitVavoo():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.koditv/?action=vavoo_to2&extra&page&plot&thumbnail=https%3a%2f%2fyt3.googleusercontent.com%2f3KwDyaSnqXWo8rDiwBTYUM-x1tC7JlhJdghWETP5yA1aaaYUqguvgXaWFq_qKAa0hnCDAE_5kA%3ds900-c-k-c0x00ffffff-no-rj&title=%5bLOWERCASE%5d%5bCAPITALIZE%5d%5bCOLOR%20white%5dcanales%20de%20todos%20los%20paises%5b%2fCAPITALIZE%5d%5b%2fLOWERCASE%5d%5b%2fCOLOR%5d&url=todos")')
    xbmcgui.Dialog().notification("[B][COLOR orange]Keep calm and just wait[/COLOR][/B]", "[COLOR green]Περιμένετε...[/COLOR]", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/top/Pleasewait.png')
    xbmc.sleep(4000)
    xbmcgui.Dialog().notification("[B][COLOR orange]Does' t work all time[/COLOR][/B]", "[COLOR green]Δεν λειτουργούν πάντα...[/COLOR]", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/top/doestworkalltime.png')
    xbmc.sleep(4000)
    xbmcgui.Dialog().notification("koditv", "[B]VAVOO[/B]", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/VAVOO.TO.png')
    xbmc.sleep(4000)

DialogPleaseWaitVavoo()
