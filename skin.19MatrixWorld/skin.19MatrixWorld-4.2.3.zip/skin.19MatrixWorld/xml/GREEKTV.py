﻿import xbmc, xbmcgui
def GREEKTV():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    # xbmc.executebuiltin('Action(Back)')
    # xbmc.executebuiltin('Dialog.Close(all,true)')
    # xbmc.executebuiltin('ActivateWindow(10000)')
    xbmcgui.Dialog().notification("[B][COLOR orange]Ανακατεύθυνση...[/COLOR][/B]", "[COLOR white][B]--->[/B][/COLOR] [COLOR blue]GREEK TV [/COLOR]", sound=False, icon='special://home/addons/plugin.program.downloader19/resources/media/Pleasewait.png')
    xbmc.sleep(2000)
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.live.streamspro/?fanart=https%3a%2f%2fcdn.countryflags.com%2fthumbs%2fgreece%2fflag-800.png&mode=1&name=%5bB%5d%5bI%5d%5bCOLOR%20dodgerblue%5dGREEK%20TV%20(Android%20app%20list)%5b%2fB%5d%5b%2fCOLOR%5d%5b%2fI%5d&url=http%3a%2f%2fgknwizard.eu%2frepo%2fBuilds%2fGKoBu%2fxmls%2fandroid.m3u")')


    #xbmc.executebuiltin('Action(Back)')
    #xbmc.executebuiltin('Dialog.Close(all,true)')
    #xbmc.sleep(1000)

GREEKTV()