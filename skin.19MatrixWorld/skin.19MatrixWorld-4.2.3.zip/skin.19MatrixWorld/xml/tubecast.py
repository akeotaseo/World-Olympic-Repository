﻿import xbmc, xbmcgui
def tubecast():
    # xbmc.executebuiltin('ActivateWindow(10001,"plugin://script.module.debridmgr")')
    if xbmc.getCondVisibility('System.HasAddon({})'.format('script.tubecast')):
    # xbmc.executebuiltin('Dialog.Close(all,true)')
    # xbmc.executebuiltin('Action(Back)')
    # xbmc.executebuiltin('Dialog.Close(all,true)')
        xbmc.executebuiltin('RunScript("script.tubecast")')
    
    if not xbmc.getCondVisibility('System.HasAddon({})'.format('script.tubecast')):
        
        
        xbmc.executebuiltin('ActivateWindow(10025,"plugin://script.tubecast")')
        xbmc.sleep(12000)
        xbmc.executebuiltin('Dialog.Close(all,true)')
        xbmc.executebuiltin('Action(Back)')
        xbmc.executebuiltin('Dialog.Close(all,true)')
        xbmc.executebuiltin('ActivateWindow(10000)')
        xbmc.executebuiltin('RunScript("script.tubecast")')
        xbmc.executebuiltin('RunScript("script.tubecast")')
        xbmc.executebuiltin('RunScript("script.tubecast")')
tubecast()