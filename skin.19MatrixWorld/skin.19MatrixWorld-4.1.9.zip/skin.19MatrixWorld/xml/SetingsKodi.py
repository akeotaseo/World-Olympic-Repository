﻿import xbmc

def SetingsKodi():
    #xbmc.executebuiltin("ActivateWindow(Home)")
    #xbmc.sleep(1000)
    xbmc.executebuiltin("Action(Close)")
    xbmc.sleep(500)
    xbmc.executebuiltin("ActivateWindow(Settings)")

SetingsKodi()
