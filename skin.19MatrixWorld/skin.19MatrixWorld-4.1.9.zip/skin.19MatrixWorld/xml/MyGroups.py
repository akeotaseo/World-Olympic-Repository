﻿import xbmc
#from updatervar import *

def MyGroups():

    #dialog.notification('[B][COLOR orange]Ανακατεύθυνση...[/COLOR][/B]', '[COLOR white][B]--->[/B][/COLOR] [COLOR green]My Groups[/COLOR]', icon_Pleasewait, sound=False)
    #xbmcgui.Dialog().notification("[B][COLOR orange]Ανακατεύθυνση...[/COLOR][/B]", "[COLOR white][B]--->[/B][/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/Pleasewait.png, sound=False')
    #xbmc.sleep(100)
    #xbmc.executebuiltin("ActivateWindow(Home)")
    #xbmc.sleep(100)
    xbmc.executebuiltin("Action(Close)")
    xbmc.sleep(100)
    xbmc.executebuiltin("ActivateWindow(10025,plugin://plugin.program.autowidget/?mode=group&refresh&reload)")

MyGroups()
