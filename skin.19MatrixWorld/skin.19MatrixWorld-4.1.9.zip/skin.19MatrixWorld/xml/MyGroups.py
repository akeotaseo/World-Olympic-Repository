﻿import xbmc
#from updatervar import *

def MyGroups():

    #dialog.notification('[B][COLOR orange]Ανακατεύθυνση...[/COLOR][/B]', '[COLOR white][B]--->[/B][/COLOR] [COLOR green]My Groups[/COLOR]', icon_Pleasewait, sound=False)
    xbmc.executebuiltin("Action(Close)")
    #xbmc.sleep(200)
    #xbmc.executebuiltin("ActivateWindow(Home)")
    xbmc.sleep(200)
    xbmc.executebuiltin("ActivateWindow(10025,plugin://plugin.program.autowidget/?mode=group&refresh&reload,return)")
    xbmc.sleep(100)
    xbmc.executebuiltin("ActivateWindow(10025,plugin://plugin.program.autowidget/?mode=group&refresh&reload,return)")

MyGroups()
