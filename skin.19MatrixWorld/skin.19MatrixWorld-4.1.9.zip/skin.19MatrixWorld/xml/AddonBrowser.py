﻿import xbmc

def AddonBrowser():
    xbmc.executebuiltin("Action(Close)")
    #xbmc.sleep(200)
    #xbmc.executebuiltin("ActivateWindow(Home)")
    xbmc.sleep(100)
    xbmc.executebuiltin("ActivateWindow(AddonBrowser)")

AddonBrowser()
