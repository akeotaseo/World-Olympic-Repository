﻿import xbmc

def AddonBrowser():
    xbmc.executebuiltin("Action(Close)")
    xbmc.sleep(200)
    xbmc.executebuiltin("activatewindow(seekbar)")
    xbmc.sleep(200)
    xbmc.executebuiltin("ActivateWindow(AddonBrowser)")

AddonBrowser()
