﻿import xbmc

def AddonBrowser():
    #xbmc.executebuiltin("ActivateWindow(Home)")
    #xbmc.sleep(1000)
    xbmc.executebuiltin("Action(Close)")
    xbmc.sleep(500)
    xbmc.executebuiltin("ActivateWindow(AddonBrowser,return)")

AddonBrowser()
