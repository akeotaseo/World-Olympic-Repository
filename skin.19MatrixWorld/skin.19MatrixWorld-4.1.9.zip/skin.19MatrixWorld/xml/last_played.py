﻿import xbmc

def last_played():
    xbmc.executebuiltin("ActivateWindow(Home)")
    xbmc.sleep(1000)
    xbmc.executebuiltin("Action(Close)")
    xbmc.sleep(1000)
    xbmc.executebuiltin("RunAddon(plugin.video.last_played)")

last_played()
