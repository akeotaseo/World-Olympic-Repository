﻿import xbmc

def last_played():
    xbmc.executebuiltin("Action(Close)")
    xbmc.sleep(200)
    xbmc.executebuiltin("activatewindow(seekbar)")
    xbmc.sleep(200)
    xbmc.executebuiltin("RunAddon(plugin.video.last_played)")

last_played()
