root = None
menu = {
    'mplay': {
        'route': '/resources/lib/mkd/onfshare/qrplay:qrplay',
        'label': 'Mplay',
        'thumb': 'https://mi3s.top/thumb/fshare/qrcodeplay.png',
        'enabled': True,
        'order': 1
    },
    'pmp': {
        'route': '/resources/lib/mkd/phim:index_phim',
        'label': 'Free Film',
        'thumb': 'https://mi3s.top/thumb/phimmienphi.png',
        'enabled': True,
        'order': 2
    },
    'fshare': {
        'route': '/resources/lib/mkd/fshare:index_fshare',
        'label': 'Fshare',
        'thumb': 'https://mi3s.top/thumb/fshare.png',
        'enabled': True,
        'order': 3
    },
    'ytube': {
        'route': '/resources/lib/mkd/ytube:index_youtube',
        'label': 'Youtube',
        'thumb': 'https://mi3s.top/thumb/youtube.png',
        'enabled': True,
        'order': 4
    },
    'truyenhinh': {
        'route': '/resources/lib/mkd/truyenhinh:listiptv_root',
        'label': 'Truyền hình',
        'thumb': 'https://mi3s.top/thumb/truyenhinh.png',
        'enabled': True,
        'order': 5
    },
    'thethao': {
        'route': '/resources/lib/main:generic_menu',
        'label': 'Thể thao',
        'thumb': 'https://mi3s.top/thumb/thethao.png',
        'enabled': True,
        'order': 6
    },
    'tintuc': {
        'route': '/resources/lib/mkd/tintuc:index_tintuc',
        'label': 'Tin tức',
        'thumb': 'https://mi3s.top/thumb/tintuc.png',
        'enabled': True,
        'order': 7
    },
    'amnhac': {
        'route': '/resources/lib/mkd/nhac:index_amnhac',
        'label': 'Âm nhạc',
        'thumb': 'https://mi3s.top/thumb/amnhac.png',
        'enabled': True,
        'order': 8
    },
    'thieunhi': {
        'route': '/resources/lib/mkd/thieunhi:index_thieunhi',
        'label': 'Thiếu nhi',
        'thumb': 'https://mi3s.top/thumb/thieunhi.png',
        'enabled': True,
        'order': 9
    },
    'giaitri': {
        'route': '/resources/lib/mkd/giaitri:index_giaitri',
        'label': 'Giải trí',
        'thumb': 'https://mi3s.top/thumb/giaitri.png',
        'enabled': True,
        'order': 10
    },
    'gcs': {
        'route': '/resources/lib/mkd/onfshare/gcs:index_gcs',
        'label': 'Góc chia sẻ',
        'thumb': 'https://mi3s.top/thumb/fshare/gocchiase.png',
        'enabled': True,
        'order': 11
    },
    'tienich': {
        'route': '/resources/lib/mkd/tienich:index_tienich',
        'label': 'Tiện ích',
        'thumb': 'https://mi3s.top/thumb/tienich.png',
        'enabled': True,
        'order': 12
    }
}