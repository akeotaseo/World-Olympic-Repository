from codequick import Script, utils
from os import path
from functools import lru_cache
def get_item_label(item_id, item_infos={}):
    label = item_infos['label'] if 'label' in item_infos else item_id
    return label
@lru_cache(maxsize=None)
def get_item_media_path(item_media_path):
    full_path = ''
    if type(item_media_path) is list:
        full_path = path.join(Script.get_info("path"), "resources", "media", *(item_media_path))
    elif 'http' in item_media_path:
        full_path = item_media_path
    return utils.ensure_native_str(full_path)