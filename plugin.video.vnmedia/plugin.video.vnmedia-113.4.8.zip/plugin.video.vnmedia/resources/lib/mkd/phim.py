from codequick import Route, Listitem
@Route.register
def index_phim(plugin,**kwargs):
	yield Listitem.from_dict(**{'label': 'OPhim',
	'art': {'thumb': 'https://mi3s.top/thumb/phim/ophim.png',
	'fanart': 'https://mi3s.top/thumb/phim/ophim.png'},
	'callback': Route.ref('/resources/lib/mkd/onphim/ophim:index_ophim')})
	yield Listitem.from_dict(**{'label': 'TVHay',
	'art':{'thumb':'https://mi3s.top/thumb/phim/tvh.png',
	'fanart':'https://mi3s.top/thumb/phim/tvh.png'},
	'callback': Route.ref('/resources/lib/mkd/onphim/tvhay:index_tvh')})
	yield Listitem.from_dict(**{'label': 'PhimMoi',
	'art':{'thumb':'https://mi3s.top/thumb/phim/phimmoi.png',
	'fanart':'https://mi3s.top/thumb/phim/phimmoi.png'},
	'callback': Route.ref('/resources/lib/mkd/onphim/phimmoi:index_phimmoi')})
	yield Listitem.from_dict(**{'label': 'Phim1080',
	'art':{'thumb':'https://mi3s.top/thumb/phim/phim1080.png',
	'fanart':'https://mi3s.top/thumb/phim/phim1080.png'},
	'callback': Route.ref('/resources/lib/mkd/onphim/phim1080:index_1080')})
	yield Listitem.from_dict(**{'label': 'BiluTV',
	'art':{'thumb':'https://mi3s.top/thumb/phim/bilutv.png',
	'fanart':'https://mi3s.top/thumb/phim/bilutv.png'},
	'callback': Route.ref('/resources/lib/mkd/onphim/bilu:index_bilu')})
	yield Listitem.from_dict(**{'label': 'Xem8Z',
	'art':{'thumb':'https://mi3s.top/thumb/phim/x8z.png',
	'fanart':'https://mi3s.top/thumb/phim/x8z.png'},
	'callback': Route.ref('/resources/lib/mkd/onphim/xem8z:index_8z')})
	yield Listitem.from_dict(**{'label': 'TocAnime',
	'art':{'thumb':'https://mi3s.top/thumb/phim/tocanm.png',
	'fanart':'https://mi3s.top/thumb/phim/tocanm.png'},
	'callback': Route.ref('/resources/lib/mkd/onphim/tocanm:index_tocanm')})
	yield Listitem.from_dict(**{'label': 'Fmovies',
	'art':{'thumb':'https://mi3s.top/thumb/phim/fmovi.png',
	'fanart':'https://mi3s.top/thumb/phim/fmovi.png'},
	'callback': Route.ref('/resources/lib/mkd/onphim/fmovies:index_fm')})
	yield Listitem.from_dict(**{'label': 'FilmPlus',
	'art':{'thumb':'https://mi3s.top/thumb/phim/onstream.png',
	'fanart':'https://mi3s.top/thumb/phim/onstream.png'},
	'callback': Route.ref('/resources/lib/mkd/onphim/mdb:index_mdb')})