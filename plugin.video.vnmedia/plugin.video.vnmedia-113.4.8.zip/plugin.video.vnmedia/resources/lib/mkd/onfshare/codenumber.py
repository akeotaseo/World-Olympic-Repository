from codequick import Route, Listitem, Script, Resolver
from resources.lib.kedon import ADDON, search_history_get, search_history_clear, fu, get_info_fs, yttk, __addonnoti__, quangcao, search_history_save
from xbmcgui import Dialog, DialogProgressBG
from urllib.parse import quote_plus
from functools import lru_cache
import re
def get_user_input():
	shorturl = ADDON.getSetting('shorten_host')
	search_term = Dialog().input(f'{shorturl.upper()} - Mã CODE được chia sẻ bởi facebook Hội mê Phim')
	return search_term
@Route.register
def index_number(plugin, **kwargs):
	yield PlayNumberCode()
	yield Listitem.from_dict(**{'label': 'MÃ CODE gần đây',
	'art': {'thumb': 'https://mi3s.top/thumb/watched.png',
	'fanart': 'https://mi3s.top/thumb/kodivnm.jpg'},
	'callback': index_codeganday})
@Route.register
def index_codeganday(plugin, **kwargs):
	yield []
	if b:=search_history_get():
		for m in b:
			item = Listitem()
			item.label = m.split('/')[-1]
			item.art['thumb'] = 'https://mi3s.top/thumb/numbercode.png'
			item.art['fanart'] = 'https://mi3s.top/thumb/kodivnm.jpg'
			item.context.script(Script.ref('/resources/lib/kedon:remove_search_history'), 'Xoá khỏi lịch sử CODE', m)
			item.set_callback(dulieucode, m)
			yield item
		yield Listitem.from_dict(**{'label': 'Xoá lịch sử CODE',
		'art': {'thumb': 'https://mi3s.top/thumb/watched.png',
		'fanart': 'https://mi3s.top/thumb/kodivnm.jpg'},
		'callback': search_history_clear})
@Route.register
def dulieucode(plugin, m=None, **kwargs):
	yield []
	if m is None:
		pass
	else:
		x = fu(m)
		if 'fshare.vn/folder' in x:
			item = Listitem()
			ten = get_info_fs(x)[0]
			item.label = ten
			item.info['mediatype'] = 'episode'
			item.info['rating'] = 10.0
			item.info['trailer'] = yttk(ten)
			imgfs = 'https://mi3s.top/thumb/fshare.png'
			item.art['thumb'] = item.art['poster'] = imgfs
			item.art['fanart'] = 'https://mi3s.top/thumb/kodivnm.jpg'
			item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', x)
			item.set_callback(Route.ref('/resources/lib/mkd/onfshare/ifshare:index_fs'), x, 0, imgfs)
			yield item
		elif 'fshare.vn/file' in x:
			item = Listitem()
			ten = get_info_fs(x)[0]
			item.label = ten
			item.info['size'] = get_info_fs(x)[1]
			item.info['mediatype'] = 'episode'
			item.info['rating'] = 10.0
			item.info['trailer'] = yttk(ten)
			item.art['thumb'] = item.art['poster'] = 'https://mi3s.top/thumb/fshare.png'
			item.art['fanart'] = 'https://mi3s.top/thumb/kodivnm.jpg'
			if ADDON.getSetting('taifshare') == 'true':
				item.context.script(Script.ref('/resources/lib/download:downloadfs'), 'Tải về', x)
			item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', x)
			item.set_callback(Resolver.ref('/resources/lib/kedon:play_fs'), x, ten)
			yield item
		else:
			Script.notify(__addonnoti__, 'CODE không đúng')
			yield quangcao()
@Route.register
def searchnumber(plugin, search_query=None, **kwargs):
	yield []
	if search_query is None:
		pass
	else:
		shorturl = ADDON.getSetting('shorten_host')
		search_query = get_user_input()
		if search_query == '':
			Script.notify(f'{__addonnoti__} - {shorturl.upper()}', 'Bạn chưa nhập CODE')
			yield quangcao()
		else:
			dp = DialogProgressBG()
			dp.create(__addonnoti__, f'Đang lấy dữ liệu từ máy chủ {shorturl.upper()}...')
			search_query = quote_plus(search_query)
			z = f'http://{shorturl}/{search_query}'
			search_history_save(z)
			x = fu(z)
			dp.update(50)
			if 'fshare.vn/folder' in x:
				item = Listitem()
				ten = get_info_fs(x)[0]
				item.label = get_info_fs(x)[0]
				item.info['mediatype'] = 'episode'
				item.info['rating'] = 10.0
				item.info['trailer'] = yttk(ten)
				imgfs = 'https://mi3s.top/thumb/fshare.png'
				item.art['thumb'] = item.art['poster'] = imgfs
				item.art['fanart'] = 'https://mi3s.top/thumb/kodivnm.jpg'
				item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', x)
				item.set_callback(Route.ref('/resources/lib/mkd/onfshare/ifshare:index_fs'), x, 0, imgfs)
				yield item
			elif 'fshare.vn/file' in x:
				item = Listitem()
				ten = get_info_fs(x)[0]
				item.info['size'] = get_info_fs(x)[1]
				item.info['mediatype'] = 'episode'
				item.info['rating'] = 10.0
				item.info['trailer'] = yttk(ten)
				item.art['thumb'] = item.art['poster'] = 'https://mi3s.top/thumb/fshare.png'
				item.art['fanart'] = 'https://mi3s.top/thumb/kodivnm.jpg'
				if ADDON.getSetting('taifshare') == 'true':
					item.context.script(Script.ref('/resources/lib/download:downloadfs'), 'Tải về', x)
				item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', x)
				item.set_callback(Resolver.ref('/resources/lib/kedon:play_fs'), x, ten)
				yield item
			else:
				Script.notify(__addonnoti__, 'CODE không đúng')
				yield quangcao()
			dp.update(100)
			dp.close()
@lru_cache(maxsize=None)
def PlayNumberCode():
	shorturl = ADDON.getSetting('shorten_host')
	item = Listitem()
	item.label = 'MÃ CODE'
	item.info['plot'] = f'Mã CODE được chia sẻ bởi nhóm fb Hội mê phim - máy chủ {shorturl.upper()}'
	item.art['thumb'] = 'https://mi3s.top/thumb/numbercode.png'
	item.art['fanart'] = 'https://mi3s.top/thumb/kodivnm.jpg'
	item.set_callback(searchnumber, searchnumber)
	return item