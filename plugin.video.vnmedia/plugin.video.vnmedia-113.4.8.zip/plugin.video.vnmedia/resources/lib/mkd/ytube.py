from codequick import Route, Listitem
from resources.lib.kedon import replace_all, getlinkweb
from codecs import decode
import re
@Route.register
def index_youtube(plugin, **kwargs):
	thaythe = {'\\"':'','\\u0026':'&'}
	yield Listitem.search(Route.ref('/resources/lib/mkd/onyoutube/tim:search_youtube'))
	yield Listitem.from_dict(**{'label': 'TOP VIDEO THỊNH HÀNH',
	'art':{'thumb':'https://mi3s.top/thumb/fshare/hot.png',
	'fanart':'https://mi3s.top/thumb/fshare/hot.png'},
	'callback':Route.ref('/resources/lib/mkd/onyoutube/video:youtube_thinhhanh')})
	yield Listitem.from_dict(**{'label': 'TOP ÂM NHẠC THỊNH HÀNH',
	'art':{'thumb':'https://mi3s.top/thumb/nhacyt.png',
	'fanart':'https://mi3s.top/thumb/nhacyt.png'},
	'callback':Route.ref('/resources/lib/mkd/onyoutube/video:youtube_amnhacthinhhanh')})
	sre1 = re.compile(r'text":"(.*?)"}')
	sre2 = re.compile(r'videoId":"(.*?)"')
	url = 'https://www.youtube.com/?gl=VN&hl=vi'
	listplay = re.findall(r'videoRenderer(.*?)accessibility', replace_all(thaythe, getlinkweb(url, url, 20000).text))
	for k in listplay:
		item = Listitem()
		idvd = sre2.search(k)[1]
		item.label = sre1.search(k)[1]
		item.art['thumb'] = item.art['fanart'] = f'https://i.ytimg.com/vi/{idvd}/sddefault.jpg'
		item.set_path(f'plugin://plugin.video.youtube/play/?video_id={idvd}')
		yield item