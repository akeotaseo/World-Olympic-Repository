from codequick import Route, Listitem, Resolver
from resources.lib.kedon import getlinkvnm, getlink, quangcao
from time import strptime, strftime
from bs4 import BeautifulSoup
from functools import lru_cache
from json import loads
import re
@lru_cache(maxsize=None)
def getchannel(idk):
	r = getlinkvnm('https://ustream.click/channels.json', 'https://ustream.click/').json()
	for k in r:
		if k['id'] == idk:
			return k['url']
@Route.register
def index_ustream(plugin, **kwargs):
	yield []
	resp = getlink('https://ustream.click/', 'https://ustream.click/', 1000)
	if (resp is not None):
		soup = BeautifulSoup(resp.content, 'html.parser')
		soups = soup.select('div.w-full.flex.justify-between.flex-wrap.gap-4')
		for k in soups:
			item = Listitem()
			players = k.select_one('div.flex.flex-col.items-start p').get_text(strip=True)
			event_info = k.select_one('div.flex.flex-wrap.gap-2 p.text-text-secondary').get_text(strip=True)
			time_str = k.select_one('div.bg-black').get_text(strip=True)
			time_struct = strptime(time_str, '%I:%M:%S %p')
			hour = (time_struct.tm_hour + 7) % 24
			minute = time_struct.tm_min
			formatted_time_with_offset = f'{hour:02d}:{minute:02d}'
			tenm = f'{formatted_time_with_offset}: {players} ({event_info})'
			item.label = tenm
			item.art['thumb'] = item.art['fanart'] = 'https://mi3s.top/thumb/thethao/sports-channels.png'
			item.set_callback(list_ustream, k.select_one('astro-island')['uid'], tenm)
			yield item
	else:
		yield quangcao()
@Route.register
def list_ustream(plugin, uid=None, title=None, **kwargs):
	yield []
	if uid is None or title is None:
		pass
	else:
		resp = getlink('https://ustream.click/', 'https://ustream.click/', 1000)
		if resp is not None:
			soup = BeautifulSoup(resp.content, 'html.parser')
			props_value = soup.select_one(f"astro-island[uid='{uid}']")['props']
			props_dict = loads(props_value)
			channels_list = loads(props_dict["channels"][1])
			for k in channels_list:
				item = Listitem()
				tenm = f'{k[1]} - {title}'
				item.label = tenm
				item.art['thumb'] = item.art['fanart'] = 'https://mi3s.top/thumb/thethao/sports-channels.png'
				item.set_callback(Resolver.ref('/resources/lib/kedon:ifr_khomuc'), getchannel(k[1]), tenm)
				yield item
		else:
			yield quangcao()