from codequick import Route, Listitem, Resolver
from resources.lib.kedon import getlink, quangcao
from urllib.parse import urlparse
from bs4 import BeautifulSoup
@Route.register
def index_nba(plugin, **kwargs):
	yield []
	url = 'https://stream.tructiepnba.com/'
	resp = getlink(url, url, 1000)
	if (resp is not None):
		soup = BeautifulSoup(resp.content, 'html.parser')
		soups = soup.select('div.wp-block-group__inner-container')
		for block in soups:
			try:
				title = block.h2.get_text(strip=True)
				time = block.p.get_text(strip=True)
				buttons = block.select('a.wp-block-button__link')
				for button in buttons:
					item = Listitem()
					tenm = f'{button.text.strip()} - {time}: {title}'
					item.label = tenm
					item.art['thumb'] = item.art['fanart'] = 'https://mi3s.top/thumb/thethao/nba.png'
					item.set_callback(list_nba, button['href'], tenm)
					yield item
			except:
				pass
	else:
		yield quangcao()
@Route.register
def list_nba(plugin, url=None, title=None, **kwargs):
	yield []
	if url is None or title is None:
		pass
	else:
		resp = getlink(url, url, 400)
		if (resp is not None):
			item1 = Listitem()
			tenm = f'SV1 - {title}'
			item1.label = tenm
			item1.art['thumb'] = item1.art['fanart'] = 'https://mi3s.top/thumb/thethao/nba.png'
			item1.set_callback(Resolver.ref('/resources/lib/kedon:ifr_khomuc'), url, tenm)
			yield item1
			soup = BeautifulSoup(resp.content, 'html.parser')
			soups = soup.select('pagelinkselement#post-pagination a')
			for episode in soups:
				item = Listitem()
				tenk = f'{episode.get_text(strip=True)} - {title}'
				item.label = tenk
				item.art['thumb'] = item.art['fanart'] = 'https://mi3s.top/thumb/thethao/nba.png'
				item.set_callback(Resolver.ref('/resources/lib/kedon:ifr_khomuc'), episode['href'], tenk)
				yield item
		else:
			yield quangcao()