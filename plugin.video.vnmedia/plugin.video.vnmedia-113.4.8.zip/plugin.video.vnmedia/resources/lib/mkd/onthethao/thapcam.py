from codequick import Route, Listitem, Resolver
from resources.lib.kedon import u90, getlink, getlinkvnm, quangcao, stream, referer
from datetime import datetime
from bs4 import BeautifulSoup
from functools import lru_cache
from concurrent.futures import ThreadPoolExecutor
import re
@lru_cache(maxsize=None)
def get_full_url(url):
	utc = u90('thapcam')
	if url.startswith('/'):
		return f'{utc}{url}'
	else:
		return url
@lru_cache(maxsize=None)
def resptc():
	utc = u90('thapcam')
	tr1 = f'{utc}/tc/js/main.js'
	resp90 = getlinkvnm(tr1, tr1)
	if (resp90 is not None):
		html_content = re.sub(r"(\n\s*//.*)", "", resp90.content.decode())
		ref = re.search(r'base_embed_url\s*=\s*("|\')([^"\s]+)("|\')', html_content)[2]
	else:
		ref = tr1
	return ref
def get_list(idk):
	url = f'http://api.thapcam.xyz/api/match/{idk}/meta'
	resp = getlinkvnm(url, url)
	return resp
def xemlai(page):
	utc = u90('thapcam')
	url = f'{utc}/xem-lai' if page==1 else f'{utc}/xem-lai/trang-{page}'
	resp = getlink(url, url, 1000)
	return resp
@Route.register
def index_thapcam(plugin, **kwargs):
	yield []
	utc = 'https://api.thapcam.xyz/api/match/featured/mt'
	resp = getlinkvnm(utc, utc)
	if (resp is not None):
		rd = resp.json()['data']
		for k in rd:
			item = Listitem()
			time = datetime.fromtimestamp(int(k['timestamp'])/1000).strftime('%H:%M %d-%m')
			cm = k['commentators']
			blv = ' - '.join((h['name'] for h in cm or []))
			ten = f'{time}: {k["name"]} ({blv})' if cm else f'{time}: {k["name"]}'
			ten = f'[B]{ten}[/B]' if k['match_status'] == 'live' else ten
			tenm = f'[COLOR yellow]{ten}[/COLOR]' if (k['is_featured'] or k['tournament']['unique_tournament']['is_featured']) else ten
			item.label = tenm
			logotour = k['tournament']['logo']
			if logotour:
				item.art['thumb'] = item.art['fanart'] = logotour
			else:
				item.art['thumb'] = item.art['fanart'] = 'https://mi3s.top/thumb/thethao/thapcamtv.png'
			item.set_callback(list_thapcam, k['id'], tenm)
			yield item
	else:
		yield quangcao()
@Route.register
def list_thapcam(plugin, idk=None, title=None, **kwargs):
	yield []
	if idk is None or title is None:
		pass
	else:
		with ThreadPoolExecutor(2) as ex:
			f1 = ex.submit(resptc)
			f2 = ex.submit(get_list, idk)
			ref = f1.result()
			resp = f2.result()
		if (resp is not None) and ('.m3u8' in resp.text):
			kq = resp.json()
			kp = kq['data']['play_urls']
			for k in kp:
				item = Listitem()
				tenm = f'{k["name"]} - {title}'
				item.label = tenm
				linktrandau = f'{stream(k["url"])}{referer(ref)}'
				item.art['thumb'] = item.art['fanart'] = 'https://mi3s.top/thumb/thethao/thapcamtv.png'
				item.set_callback(Resolver.ref('/resources/lib/kedon:play_vnm'), linktrandau, tenm, '')
				yield item
		else:
			yield quangcao()
@Route.register
def xemlai_tc(plugin, page=None, **kwargs):
	yield []
	if page is None:
		pass
	else:
		with ThreadPoolExecutor(2) as ex:
			f1 = ex.submit(resptc)
			f2 = ex.submit(xemlai, page)
			ref = f1.result()
			resp = f2.result()
		if (resp is not None) and ('news-title' in resp.text):
			soup = BeautifulSoup(resp.content, 'html.parser')
			s1 = soup.select('div.box-content div.news-big')
			s2 = soup.select('div.box-content div.item.item-highlight')
			for k in s1:
				item = Listitem()
				tenm = k.select_one('h4.news-title a').get_text(strip=True)
				item.label = tenm
				item.art['thumb'] = item.art['fanart'] = k.select_one('a.news-thumb img')['data-src']
				item.set_callback(Resolver.ref('/resources/lib/kedon:list_re90'), get_full_url(k.select_one('h4.news-title a')['href']), ref, tenm)
				yield item
			for l in s2:
				item1 = Listitem()
				tenm1 = l.select_one('h4.news-title a').get_text(strip=True)
				item1.label = tenm1
				item1.art['thumb'] = item1.art['fanart'] = l.select_one('a.news-thumb img')['data-src']
				item1.set_callback(Resolver.ref('/resources/lib/kedon:list_re90'), get_full_url(l.select_one('h4.news-title a')['href']), ref, tenm1)
				yield item1
			if 'Trang tiếp' in resp.text:
				item2 = Listitem()
				item2.label = f'Trang {page + 1}'
				item2.art['thumb'] = item2.art['fanart'] = f'https://mi3s.top/thumb/next.png'
				item2.set_callback(xemlai_tc, page + 1)
				yield item2
		else:
			yield quangcao()