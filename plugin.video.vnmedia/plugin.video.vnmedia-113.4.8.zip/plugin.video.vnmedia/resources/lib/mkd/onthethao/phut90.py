from codequick import Route, Listitem, Resolver
from resources.lib.kedon import u90, getlinkvnm, quangcao, getlink, referer, stream
from datetime import datetime
from functools import lru_cache
from concurrent.futures import ThreadPoolExecutor
import re, sys
@lru_cache(maxsize=None)
def respphut90():
	tr = u90('90')
	resp90 = getlinkvnm(tr, tr)
	if (resp90 is not None):
		html_content = re.sub(r"(\n\s*//.*)", "", resp90.text)
		ref = re.search(r'base_embed_url\s*=\s*("|\')([^"\s]+)("|\')', html_content)[2]
	else:
		ref = tr
	return ref
def get_list(idk):
	url = f'http://api.vebo.xyz/api/match/{idk}/meta'
	resp = getlinkvnm(url, url)
	return resp
def xemlai(pl, page):
	url = f'https://api.vebo.xyz/api/news/mitom/list/{pl}/{page}'
	resp = getlink(url, url, 1000)
	return resp
@Route.register
def index_90p(plugin, **kwargs):
	yield []
	u9 = u90('90')
	resp = getlinkvnm('https://api.vebo.xyz/api/match/featured/mt', u9)
	if (resp is not None):
		rd = resp.json()['data']
		for k in rd:
			item = Listitem()
			time = datetime.fromtimestamp(int(k['timestamp'])/1000).strftime('%H:%M %d-%m')
			cm = k['commentators']
			blv = ' - '.join((h['name'] for h in cm or []))
			ten = f'{time}: {k["name"]} ({blv})' if cm else f'{time}: {k["name"]}'
			ten = f'[B]{ten}[/B]' if k['match_status'] == 'live' else ten
			tenm = f'[COLOR yellow]{ten}[/COLOR]' if (k['is_featured'] or k['tournament']['unique_tournament']['is_featured']) else ten
			item.label = tenm
			logotour = k['tournament']['logo']
			if logotour:
				item.art['thumb'] = item.art['fanart'] = logotour
			else:
				item.art['thumb'] = item.art['fanart'] = 'https://mi3s.top/thumb/thethao/vebo.png'
			item.set_callback(list_90p, k['id'], tenm)
			yield item
	else:
		yield quangcao()
@Route.register
def list_90p(plugin, idk=None, title=None, **kwargs):
	yield []
	if idk is None or title is None:
		pass
	else:
		with ThreadPoolExecutor(2) as ex:
			f1 = ex.submit(respphut90)
			f2 = ex.submit(get_list, idk)
			ref = f1.result()
			resp = f2.result()
		if (resp is not None) and ('.m3u8' in resp.text):
			rf = referer(ref)
			kq = resp.json()
			kp = kq['data']['play_urls']
			for k in kp:
				item = Listitem()
				tenm = f'{k["name"]} - {title}'
				item.label = tenm
				item.art['thumb'] = item.art['fanart'] = 'https://mi3s.top/thumb/thethao/90p.png'
				item.set_callback(Resolver.ref('/resources/lib/kedon:play_vnm'), f'{stream(k["url"])}{rf}', tenm, '')
				yield item
		else:
			yield quangcao()
@Route.register
def xemlai_90p(plugin, pl=None, page=None, **kwargs):
	yield []
	if pl is None or page is None:
		pass
	else:
		with ThreadPoolExecutor(2) as ex:
			f1 = ex.submit(respphut90)
			f2 = ex.submit(xemlai, pl, page)
			ref = f1.result()
			resp = f2.result()
		if (resp is not None):
			kq = resp.json()
			kl = kq['data']['list']
			if f:= kq['data']['highlight']:
				item = Listitem()
				item.label = f['name']
				item.art['thumb'] = item.art['fanart'] = f['feature_image']
				item.set_callback(Resolver.ref('/resources/lib/kedon:list_re90'), f"https://api.vebo.xyz/api/news/mitom/detail/{f['id']}", ref, f['name'])
				yield item
			for k in kl:
				item1 = Listitem()
				item1.label = k['name']
				item1.art['thumb'] = item1.art['fanart'] = k['feature_image']
				item1.set_callback(Resolver.ref('/resources/lib/kedon:list_re90'), f"https://api.vebo.xyz/api/news/mitom/detail/{k['id']}", ref, k["name"])
				yield item1
			item2 = Listitem()
			item2.label = f'Trang {page + 1}'
			item2.art['thumb'] = item2.art['fanart'] = f'https://mi3s.top/thumb/next.png'
			item2.set_callback(xemlai_90p, pl, page + 1)
			yield item2
		else:
			yield quangcao()
def create_list_item(k2, is_featured):
	item2 = Listitem()
	time = datetime.fromtimestamp(int(k2['timestamp'])/1000).strftime('%H:%M %d-%m')
	if k2['commentators']:
		tenm = f'{time}: {k2["name"]} ({k2["commentators"][0]["name"]})'
	else:
		tenm = f'{time}: {k2["name"]}'
	item2.label = tenm
	logotour2 = k2['tournament']['logo']
	if logotour2:
		item2.art['thumb'] = item2.art['fanart'] = logotour2
	else:
		item2.art['thumb'] = item2.art['fanart'] = 'https://mi3s.top/thumb/thethao/vebo.png'
	item2.set_callback(list_90p, k2['id'], tenm)
	return item2