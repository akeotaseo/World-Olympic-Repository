from codequick import Route, Listitem, Resolver, Script
from resources.lib.kedon import __addonnoti__, __addonname__, getlink, getlinkvnm, quangcao, fu
from concurrent.futures import ThreadPoolExecutor, as_completed
from xbmcgui import DialogProgress
from urllib.parse import quote_plus
from bs4 import BeautifulSoup
from functools import lru_cache
from urllib.parse import urlparse
import re, sys
@lru_cache(maxsize=None)
def tvhay():
	url = 'https://tvhay.blog'
	r = getlinkvnm(url, url)
	try:
		soup = BeautifulSoup(r.content, 'html.parser')
		hr = soup.select_one('ul.list-inline a')['href']
		if hr.startswith('/'):
			b= f'https:{hr}'
		elif hr.startswith('http'):
			b= hr
		else:
			b= f'https://{hr}'
		v = urlparse(fu(b))
		return f'{v.scheme}://{v.netloc}'
	except:
		sys.exit()
def get_episode(url):
	r = getlink(url, 'https://www.google.com.vn/', 1000)
	return r
@lru_cache(maxsize=None)
def get_info_tvhay(x):
	r = getlinkvnm(x,x)
	try:
		soup = BeautifulSoup(r.content, 'html.parser')
		soups = soup.select('div.blockbody')
		for k in soups:
			try:
				img = k.select_one('div.poster img')['data-src']
			except:
				img = 'https://mi3s.top/thumb/phim/tvh.png'
			try:
				title = k.select_one('div.title').get_text(strip=True)
				name2 = k.select_one('div.name2 h2').get_text(strip=True)
				ten = f'{title} - {name2}'
			except:
				ten = __addonname__
			try:
				mota = k.select_one('div.tabs-content div.text').get_text(strip=True)
			except:
				mota = ten
			return (ten, img, mota)
	except:
		return None
@lru_cache(maxsize=None)
def process_url(url):
	try:
		data = get_info_tvhay(url)
		return url, data
	except:
		return url, None
@Route.register
def search_tvh(plugin, search_query=None, **kwargs):
	yield []
	if search_query is None:
		pass
	else:
		tvh = tvhay()
		dialog = DialogProgress()
		dialog.create(__addonnoti__, 'Đang lấy dữ liệu...')
		next_page = 1
		sr = quote_plus(search_query)
		url = f'{tvh}/tag/{sr.replace(" ","+")}'
		trangtiep = f'{url}/trang-{next_page}'
		r = getlink(trangtiep, url, 1800)
		if (r is not None) and ('list-film' in r.text):
			soup = BeautifulSoup(r.content, 'html.parser')
			soups = soup.select('.status:not(:contains("Trailer"))')
			urls = [k.find_previous('a')['href'] for k in soups]
			length = len(urls)
			if length>0:
				count = 0
				with ThreadPoolExecutor(length) as ex:
					future_to_url = (ex.submit(process_url, url) for url in urls)
					ac = as_completed(future_to_url)
					for k in ac:
						l, data = k.result()
						if data is not None:
							if (dialog.iscanceled()):
								break
							count += 1
							done = int((count/length)*100)
							dialog.update(done, f'Đang giải mã {length} dữ liệu...\nLoading... [COLOR yellow]{done} %[/COLOR]')
							item = Listitem()
							item.label = data[0]
							item.info['plot'] = data[2]
							item.info['mediatype'] = 'movie'
							item.art['thumb'] = item.art['fanart'] = data[1]
							item.set_callback(episode_tvhay, l, data[0], data[2], data[1])
							yield item
				if f'/trang-{str(int(next_page) + 1)}' in r.text:
					item1 = Listitem()
					item1.label = f'Trang {str(int(next_page) + 1)}'
					item1.art['thumb'] = item1.art['fanart'] = 'https://mi3s.top/thumb/next.png'
					item1.set_callback(ds_tvhay, url, next_page + 1)
					yield item1
		else:
			Script.notify(__addonnoti__, 'Không tìm thấy kết quả')
			yield quangcao()
		dialog.close()
@Route.register
def index_tvh(plugin, **kwargs):
	tvh = tvhay()
	yield Listitem.search(search_tvh)
	dulieu = {
	'Phim mới': f'{tvh}/phim-moi',
	'Phim bộ': f'{tvh}/phim-bo',
	'Phim lẻ': f'{tvh}/phim-le',
	'Chiếu rạp': f'{tvh}/phim-chieu-rap',
	'Hoạt hình': f'{tvh}/phim-hoat-hinh',
	'Phim thuyết minh': f'{tvh}/phim-thuyet-minh',
	'Phim lồng tiếng': f'{tvh}/phim-long-tieng'
	}
	yield Listitem.from_dict(**{'label': 'Thể loại',
	'art': {'thumb': 'https://mi3s.top/thumb/phim/tvh.png',
	'fanart': 'https://mi3s.top/thumb/phim/tvh.png'},
	'callback': tvh_tl})
	yield Listitem.from_dict(**{'label': 'Quốc gia',
	'art':{'thumb':'https://mi3s.top/thumb/phim/tvh.png',
	'fanart':'https://mi3s.top/thumb/phim/tvh.png'},
	'callback': tvh_qg})
	for k in dulieu:
		item = Listitem()
		item.label = k
		item.art['thumb'] = item.art['fanart'] = 'https://mi3s.top/thumb/phim/tvh.png'
		item.set_callback(ds_tvhay, dulieu[k], 1)
		yield item
@Route.register
def tvh_tl(plugin, **kwargs):
	tvh = tvhay()
	dulieu = {
	'Hành động': f'{tvh}/the-loai/hanh-dong',
	'Võ thuật': f'{tvh}/the-loai/vo-thuat',
	'Tình cảm': f'{tvh}/the-loai/tinh-cam',
	'Tâm lý': f'{tvh}/the-loai/tam-ly',
	'Hài': f'{tvh}/the-loai/hai',
	'Hoạt hình': f'{tvh}/the-loai/hoat-hinh',
	'Phiêu lưu': f'{tvh}/the-loai/phieu-luu',
	'Kinh dị': f'{tvh}/the-loai/kinh-di',
	'Hình sự': f'{tvh}/the-loai/hinh-su',
	'Chiến tranh': f'{tvh}/the-loai/chien-tranh',
	'Thần thoại': f'{tvh}/the-loai/than-thoai',
	'Viễn tưởng': f'{tvh}/the-loai/vien-tuong',
	'Cổ trang': f'{tvh}/the-loai/co-trang',
	'Âm nhạc': f'{tvh}/the-loai/am-nhac',
	'TV Show': f'{tvh}/the-loai/tv-show',
	'Khoa học': f'{tvh}/the-loai/khoa-hoc'
	}
	for k in dulieu:
		item = Listitem()
		item.label = k
		item.art['thumb'] = item.art['fanart'] = 'https://mi3s.top/thumb/phim/tvh.png'
		item.set_callback(ds_tvhay, dulieu[k], 1)
		yield item
@Route.register
def tvh_qg(plugin, **kwargs):
	tvh = tvhay()
	dulieu = {
	'Mỹ': f'{tvh}/quoc-gia/my',
	'Hàn Quốc': f'{tvh}/quoc-gia/han-quoc',
	'Trung Quốc': f'{tvh}/quoc-gia/trung-quoc',
	'Hồng Kông': f'{tvh}/quoc-gia/hong-kong',
	'Đài Loan': f'{tvh}/quoc-gia/dai-loan',
	'Việt Nam': f'{tvh}/quoc-gia/viet-nam',
	'Nhật Bản': f'{tvh}/quoc-gia/nhat-ban',
	'Ấn Độ': f'{tvh}/quoc-gia/an-do',
	'Thái Lan': f'{tvh}/quoc-gia/thai-lan',
	'Pháp': f'{tvh}/quoc-gia/phap',
	'Anh': f'{tvh}/quoc-gia/anh',
	'Nước Khác': f'{tvh}/quoc-gia/khac'
	}
	for k in dulieu:
		item = Listitem()
		item.label = k
		item.art['thumb'] = item.art['fanart'] = 'https://mi3s.top/thumb/phim/tvh.png'
		item.set_callback(ds_tvhay, dulieu[k], 1)
		yield item
@Route.register
def ds_tvhay(plugin, url=None, next_page=None, **kwargs):
	yield []
	if url is None or next_page is None:
		pass
	else:
		dialog = DialogProgress()
		dialog.create(__addonnoti__, 'Đang lấy dữ liệu...')
		trangtiep = f'{url}/trang-{next_page}'
		r = getlink(trangtiep, trangtiep, 1000)
		if (r is not None) and ('list-film' in r.text):
			soup = BeautifulSoup(r.content, 'html.parser')
			soups = soup.select('.status:not(:contains("Trailer"))')
			urls = [k.find_previous('a')['href'] for k in soups]
			length = len(urls)
			if length>0:
				count = 0
				with ThreadPoolExecutor(length) as ex:
					future_to_url = (ex.submit(process_url, url) for url in urls)
					ac = as_completed(future_to_url)
					for k in ac:
						l, data = k.result()
						if data is not None:
							if (dialog.iscanceled()):
								break
							count += 1
							done = int((count/length)*100)
							dialog.update(done, f'Đang giải mã {length} dữ liệu...\nLoading... [COLOR yellow]{done} %[/COLOR]')
							item = Listitem()
							item.label = data[0]
							item.info['plot'] = data[2]
							item.info['mediatype'] = 'movie'
							item.art['thumb'] = item.art['fanart'] = data[1]
							item.set_callback(episode_tvhay, l, data[0], data[2], data[1])
							yield item
				if f'/trang-{str(int(next_page) + 1)}' in r.text:
					item1 = Listitem()
					item1.label = f'Trang {str(int(next_page) + 1)}'
					item1.art['thumb'] = item1.art['fanart'] = 'https://mi3s.top/thumb/next.png'
					item1.set_callback(ds_tvhay, url, str(int(next_page) + 1))
					yield item1
		else:
			yield quangcao()
		dialog.close()
@Route.register
def episode_tvhay(plugin, url=None, title=None, info=None, img=None, **kwargs):
	yield []
	if url is None or title is None or info is None or img is None:
		pass
	else:
		with ThreadPoolExecutor(2) as ex:
			f1 = ex.submit(tvhay)
			f2 = ex.submit(get_episode, url)
			tvh = f1.result()
			r = f2.result()
		if (r is not None) and 'btn-watch' in r.text:
			soupx = BeautifulSoup(r.content, 'html.parser')
			if 'youtube.com/embed/' in r.text:
				y = soupx.select_one('div.embed-responsive iframe')['src']
				idvd = re.search(r'/embed/([a-zA-Z0-9_-]+)', y)[1]
				item1 = Listitem()
				item1.label = f'TRAILER: [I]{title}[/I]'
				item1.art['thumb'] = item1.art['fanart'] = f'https://i.ytimg.com/vi/{idvd}/sddefault.jpg'
				item1.set_path(f'plugin://plugin.video.youtube/play/?video_id={idvd}')
				yield item1
			urlplay = soupx.select_one('a.btn-watch')['href']
			resp = getlink(urlplay, url, 1000)
			if (resp is not None):
				soup = BeautifulSoup(resp.content, 'html.parser')
				soups = soup.select('div.server')
				data = ((k.select_one('div.label').get_text(strip=True), l.a.get_text(strip=True), l.a['href']) for k in soups for l in k.select('ul.episodelist li'))
				for k in data:
					item = Listitem()
					tenm = f"[COLOR yellow]{k[0]}[/COLOR] Tập {k[1]} - {title}"
					item.label = tenm
					item.info['plot'] = info
					item.art['thumb'] = item.art['fanart'] = img
					item.set_callback(Resolver.ref('/resources/lib/kedon:play_tvhay'), k[2], tenm, tvh)
					yield item
			else:
				yield quangcao()
		else:
			yield quangcao()