from codequick import Script, Route, Listitem, Resolver
from resources.lib.kedon import getrow, getlinkphongblack, postlinktimfs, getlinkvnm, __addonnoti__, yttk, quangcao, get_last_play, clear_last_played, remove_last_played
from resources.lib.mkd.onfshare.gcs import set_item_callbacks
from concurrent.futures import ThreadPoolExecutor
from xbmcgui import DialogProgress
from urllib.parse import quote_plus, unquote
from xbmcaddon import Addon
from json import loads
from os.path import basename
from functools import lru_cache
import xbmc, random, requests, re
@lru_cache(maxsize=None)
def get_tkfs1(search_query):
    return getlinkphongblack(f'http://phongblack.me/search.php?author=phongblack&search={search_query}', 'http://www.google.com', -1)
@lru_cache(maxsize=None)
def get_tkfs2(search_query):
    return postlinktimfs(f'https://api.timfshare.com/v1/string-query-search?query={search_query}', 'https://timfshare.com/', -1)
@lru_cache(maxsize=None)
def get_tkfs3(search_query):
    return getlinkvnm(f'https://thuvienhd.com/?feed=fsharejson&search={search_query}', 'https://thuvienhd.com/')
@lru_cache(maxsize=None)
def get_tkfs4():
    return getlinkvnm(f'https://thuvienhd.com/?feed=fsharejson&search=', 'https://thuvienhd.com/')
@Route.register
def qrplay(plugin, **kwargs):
    yield Listitem.from_dict(**{'label': 'Nhấn để lấy mã liên kết với trang [COLOR yellow]mi3s.top[/COLOR]',
    'art': {'thumb': 'https://mi3s.top/thumb/MPlay.jpg',
    'fanart': 'https://mi3s.top/thumb/MPlay.jpg'},
    'callback': mplay})
    yield Listitem.from_dict(**{'label': 'Last MPlay Direct',
    'art': {'thumb': 'https://mi3s.top/thumb/MPlay.jpg',
    'fanart': 'https://mi3s.top/thumb/MPlay.jpg'},
    'callback': index_played})
@Route.register
def mplay(plugin, **kwargs):
    yield []
    my_number = random.randint(10000, 99999)
    url = 'https://docs.google.com/spreadsheets/d/11kmgd4cK8Kj7bJ8e8rGfYmgNxUvb1nQWN9S0y-4M3JQ/gviz/tq?gid=1028412373&headers=1'
    dialog = DialogProgress()
    dialog.create(f'[B][COLOR yellow]{my_number}[/COLOR][/B]', 'Đang lấy dữ liệu...')
    countdown = 1000
    timeout_expired = False
    while countdown > 0:
        if dialog.iscanceled():
            dialog.close()
            yield quangcao()
            break
        resp = requests.get(url)
        if f'"{my_number}"' in resp.text:
            dialog.close()
            noi = re.search(r'\{.*\}', resp.text)[0]
            m = loads(noi)
            rows = m['table']['rows']
            for row in rows:
                try:
                    dulieu = getrow(row['c'][1]).split('|')
                    tentrandau = unquote(dulieu[0]).replace('+', ' ')
                    kenh = unquote(dulieu[1])
                    ten = getrow(row['c'][2])
                    if ten == my_number:
                        if kenh.startswith('http'):
                            if 'fshare.vn/file' in kenh or 'fshare.vn/folder' in kenh:
                                item = Listitem()
                                item.label = tentrandau
                                item.art['thumb'] = item.art['fanart'] = 'https://mi3s.top/thumb/MPlay.jpg'
                                item.set_callback(Resolver.ref('/resources/lib/kedon:play_fs'), kenh, tentrandau)
                                yield item
                            else:
                                item = Listitem()
                                item.label = tentrandau
                                item.art['thumb'] = item.art['fanart'] = 'https://mi3s.top/thumb/MPlay.jpg'
                                item.set_callback(Resolver.ref('/resources/lib/kedon:play_vnm'), kenh, tentrandau, '')
                                yield item
                        else:
                            search_query = quote_plus(kenh)
                            dialog.create(__addonnoti__, 'Đang lấy dữ liệu...')
                            with ThreadPoolExecutor(4) as ex:
                                f1 = ex.submit(get_tkfs1, search_query)
                                f2 = ex.submit(get_tkfs2, search_query)
                                f3 = ex.submit(get_tkfs3, search_query)
                                f4 = ex.submit(get_tkfs4)
                                result_f1 = f1.result()
                                result_f2 = f2.result()
                                result_f3 = f3.result()
                                result_f4 = f4.result()
                            dialog.update(50)
                            try:
                                if result_f3 is not None and result_f4 is not None:
                                    if result_f3.content != result_f4.content:
                                        kqtvhd = result_f3.json()
                                        for t in kqtvhd:
                                            item = Listitem()
                                            item.label = t['title']
                                            item.info['plot'] = t['title']
                                            item.info['mediatype'] = 'episode'
                                            item.info['rating'] = 10.0
                                            item.info['trailer'] = yttk(t['title'])
                                            item.art['thumb'] = item.art['fanart'] = t['image']
                                            item.set_callback(Route.ref('/resources/lib/mkd/onfshare/thuvienhd:thuvienhd_link'), t['id'])
                                            yield item
                            except:
                                if result_f3 is not None and result_f4 is not None:
                                    if result_f3.content != result_f4.content:
                                        text = result_f3.text
                                        data = re.sub(r'<(.*?)\n','',text)
                                        jsm = loads(data)
                                        for t in jsm:
                                            item = Listitem()
                                            item.label = t['title']
                                            item.info['plot'] = t['title']
                                            item.info['mediatype'] = 'episode'
                                            item.info['rating'] = 10.0
                                            item.info['trailer'] = yttk(t['title'])
                                            item.art['thumb'] = item.art['fanart'] = t['image']
                                            item.set_callback(Route.ref('/resources/lib/mkd/onfshare/thuvienhd:thuvienhd_link'), t['id'])
                                            yield item
                            try:
                                x = result_f1.json()['items']
                                for m in x:
                                    path = m['path']
                                    if '/file/' in path:
                                        item = Listitem()
                                        item.label = m['label']
                                        link = path.split('&url=')[1]
                                        item.info['mediatype'] = 'episode'
                                        item.info['rating'] = 10.0
                                        item.info['trailer'] = yttk(m['label'])
                                        item.art['thumb'] = 'https://mi3s.top/thumb/fshare.png'
                                        item.art['fanart'] = 'https://mi3s.top/thumb/kodivnm.jpg'
                                        item.info['plot'] = m['info']['plot'] if 'info' in m else m['label']
                                        if Addon().getSetting('taifshare') == 'true':
                                            item.context.script(Script.ref('/resources/lib/download:downloadfs'), 'Tải về', link)
                                        item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', link)
                                        item.set_callback(Resolver.ref('/resources/lib/kedon:play_fs'), link, m['label'])
                                        yield item
                                    elif '/folder/' in path:
                                        item = Listitem()
                                        item.label = m['label']
                                        link = path.split("&url=")[1]
                                        item.info['mediatype'] = 'episode'
                                        item.info['rating'] = 10.0
                                        item.info['trailer'] = yttk(m['label'])
                                        imgfs = 'https://mi3s.top/thumb/fshare.png'
                                        item.art['thumb'] = item.art['poster'] = imgfs
                                        item.art['fanart'] = 'https://mi3s.top/thumb/kodivnm.jpg'
                                        item.info['plot'] = m['info']['plot'] if 'info' in m else m['label']
                                        item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', link)
                                        item.set_callback(Route.ref('/resources/lib/mkd/onfshare/ifshare:index_fs'), link, 0, imgfs)
                                        yield item
                            except:
                                try:
                                    kq = result_f2.json()
                                    m = (k for k in kq['data'] if 'data' in kq)
                                    for k in m:
                                        item = Listitem()
                                        item.label = k['name']
                                        item.info['mediatype'] = 'episode'
                                        item.info['rating'] = 10.0
                                        item.info['trailer'] = yttk(k['name'])
                                        imgfs = 'https://mi3s.top/thumb/fshare.png'
                                        item.art['thumb'] = item.art['poster'] = imgfs
                                        item.art['fanart'] = 'https://mi3s.top/thumb/kodivnm.jpg'
                                        item.context.script(Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo'), 'Thêm vào Fshare Favorite', k['url'])
                                        if 'folder' in k['url']:
                                            item.set_callback(Route.ref('/resources/lib/mkd/onfshare/ifshare:index_fs'), k['url'], 0, imgfs)
                                        else:
                                            item.info['size'] = k['size']
                                            if Addon().getSetting('taifshare') == 'true':
                                                item.context.script(Script.ref('/resources/lib/download:downloadfs'), 'Tải về', k['url'])
                                            item.set_callback(Resolver.ref('/resources/lib/kedon:play_fs'), k['url'], k['name'])
                                        yield item
                                except:
                                    pass
                            dialog.update(100)
                            dialog.close()
                except:
                    pass
            break
        else:
            countdown -= 1
            dialog.update(int(((1000-countdown)/1000)*100), f'Mã liên kết: [COLOR yellow][B]{my_number}[/B][/COLOR] - Đếm ngược: [COLOR orange][B]{countdown}[/B][/COLOR][CR]Vào trang [COLOR yellow][B]mi3s.top[/B][/COLOR] để lấy nội dung phát')
            xbmc.sleep(1000)
            if countdown == 0:
                timeout_expired = True
    if timeout_expired:
        yield quangcao()
    dialog.close()
@Route.register
def index_played(plugin, **kwargs):
    yield []
    if b:=get_last_play():
        for m in b:
            item = Listitem()
            item.label = m
            item.art['thumb'] = item.art['fanart'] = 'https://mi3s.top/thumb/MPlay.jpg'
            item.context.script(Script.ref('/resources/lib/kedon:remove_last_played'), 'Xoá khỏi lịch sử MPlay Direct', m)
            item.set_callback(Resolver.ref('/resources/lib/kedon:play_vnm'), b[m], m, '')
            yield item
        Playdel = {'label': 'Xoá lịch sử xem',
        'art': {'thumb': 'https://mi3s.top/thumb/MPlay.jpg',
        'fanart': 'https://mi3s.top/thumb/MPlay.jpg'},
        'callback': clear_last_played}
        yield Listitem.from_dict(**Playdel)