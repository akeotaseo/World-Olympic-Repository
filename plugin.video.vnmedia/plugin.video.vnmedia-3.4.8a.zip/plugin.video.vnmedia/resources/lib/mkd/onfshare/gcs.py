from codequick import Route, Listitem, Script, Resolver
from resources.lib.kedon import getlink, fu, yttk, getrow, quangcao, __addonnoti__, ADDON
from json import loads
from functools import lru_cache
from urllib.parse import unquote
import re
@Route.register
def index_gcs(plugin, **kwargs):
    yield []
    if u:= ADDON.getSetting('TextURL'):
        x = fu(u)
        if 'docs.google.com' in x:
            if 'gid' in x:
                timid = re.findall(r'/d/(.*?)/.*?gid=(\d+)', x)
                sid = timid[0][0]
                gid = timid[0][1]
            else:
                sid = re.findall(r'/d/(.*?)/', x)[0]
                gid = '0'
            url = f'https://docs.google.com/spreadsheets/d/{sid}/gviz/tq?gid={gid}&headers=1'
            resp = getlink(url, url, 1000)
            if (resp is not None):
                try:
                    noi = re.search(r'\{.*\}', resp.text)[0]
                    m = loads(noi)
                    cols = m['table']['cols']
                    rows = m['table']['rows']
                    if 'http' in cols[1]['label']:
                        item = Listitem()
                        kenh = cols[1]['label']
                        tenm = cols[0]['label']
                        item.label = tenm
                        item.info['mediatype'] = 'movie'
                        item.info['rating'] = 10.0
                        item.info['trailer'] = yttk(tenm)
                        imgfs = cols[2]['label'] if len(cols) > 2 else 'https://mi3s.top/thumb/fshare.png'
                        item.art['thumb'] = item.art['poster'] = imgfs
                        item.info['plot'] = cols[3]['label'] if len(cols) > 3 else tenm
                        item.art['fanart'] = cols[4]['label'] if len(cols) > 4 else (cols[2]['label'] if len(cols) > 2 else 'https://mi3s.top/thumb/fshare.png')
                        set_item_callbacks(item, kenh, tenm, imgfs)
                        yield item
                    for cow in cols:
                        p = cow['label']
                        if '|http' in p:
                            yield create_listitem_from_link(p, '[COLOR red]VN Media[/COLOR]')
                    for row in rows:
                        k = getrow(row['c'][0])
                        if '|http' in k:
                            yield create_listitem_from_link(k, '[COLOR red]VN Media[/COLOR]')
                        elif 'http' in getrow(row['c'][1]):
                            item = Listitem()
                            item.label = k
                            item.info['mediatype'] = 'movie'
                            item.info['rating'] = 10.0
                            item.info['trailer'] = yttk(k)
                            kenh = getrow(row['c'][1])
                            imgfs = getrow(row['c'][2]) if len(row['c']) > 2 else 'https://mi3s.top/thumb/fshare.png'
                            item.art['thumb'] = item.art['poster'] = imgfs
                            item.info['plot'] = getrow(row['c'][3]) if len(row['c']) > 3 else k
                            item.art['fanart'] = getrow(row['c'][4]) if len(row['c']) > 4 else (getrow(row['c'][2]) if len(row['c']) > 2 else 'https://mi3s.top/thumb/fshare.png')
                            set_item_callbacks(item, kenh, k, imgfs)
                            yield item
                except:
                    yield []
        else:
            respx = getlink(u, u, 1000)
            ri = respx.iter_lines(decode_unicode=True)
            tach = (ll.rstrip() for ll in ri if ll.strip())
            for k in tach:
                yield listitemvmf(k, '[COLOR red]VN Media[/COLOR]')
    else:
        Script.notify(__addonnoti__, 'Vui lòng nhập Link trong cài đặt của VN Media')
        yield quangcao()
@Route.register
def listgg_gcs(plugin, urltext=None, title=None):
    yield []
    if urltext is None or title is None:
        pass
    else:
        if 'gid' in urltext:
            timid = re.findall(r'/d/(.+?)/.+?gid=(\d+)', urltext)
            sid = timid[0][0]
            gid = timid[0][1]
        else:
            sid = re.findall(r'/d/(.*?)/', urltext)[0]
            gid = '0'
        url = f'https://docs.google.com/spreadsheets/d/{sid}/gviz/tq?gid={gid}&headers=1'
        resp = getlink(url, url, 1000)
        if (resp is not None):
            try:
                noi = re.search(r'\{.*\}', resp.text)[0]
                m = loads(noi)
                cols = m['table']['cols']
                rows = m['table']['rows']
                if 'http' in cols[1]['label']:
                    item = Listitem()
                    kenh = cols[1]['label']
                    tenm = cols[0]['label']
                    item.label = tenm
                    item.info['mediatype'] = 'movie'
                    item.info['rating'] = 10.0
                    item.info['trailer'] = yttk(tenm)
                    imgfs = cols[2]['label'] if len(cols) > 2 else 'https://mi3s.top/thumb/fshare.png'
                    item.art['thumb'] = item.art['poster'] = imgfs
                    item.info['plot'] = cols[3]['label'] if len(cols) > 3 else title
                    item.art['fanart'] = cols[4]['label'] if len(cols) > 4 else (cols[2]['label'] if len(cols) > 2 else 'https://mi3s.top/thumb/fshare.png')
                    set_item_callbacks(item, kenh, tenm, imgfs)
                    yield item
                for cow in cols:
                    p = cow['label']
                    if '|http' in p:
                        yield create_listitem_from_link(p, title)
                for row in rows:
                    k = getrow(row['c'][0])
                    if '|http' in k:
                        yield create_listitem_from_link(k, title)
                    elif 'http' in getrow(row['c'][1]):
                        item = Listitem()
                        item.label = k
                        item.info['mediatype'] = 'movie'
                        item.info['rating'] = 10.0
                        item.info['trailer'] = yttk(k)
                        kenh = getrow(row['c'][1])
                        imgfs = getrow(row['c'][2]) if len(row['c']) > 2 else 'https://mi3s.top/thumb/fshare.png'
                        item.art['thumb'] = item.art['poster'] = imgfs
                        item.info['plot'] = getrow(row['c'][3]) if len(row['c']) > 3 else title
                        item.art['fanart'] = getrow(row['c'][4]) if len(row['c']) > 4 else (getrow(row['c'][2]) if len(row['c']) > 2 else 'https://mi3s.top/thumb/fshare.png')
                        set_item_callbacks(item, kenh, k, imgfs)
                        yield item
            except:
                yield quangcao()
        else:
            yield quangcao()
@Route.register
def listvmf_gcs(plugin, url=None, title=None):
    yield []
    if url is None or title is None:
        pass
    else:
        resp = getlink(url, url, 600)
        if (resp is not None) and (resp.content):
            ri = resp.iter_lines(decode_unicode=True)
            tach = (ll.rstrip() for ll in ri if ll.strip())
            for k in tach:
                yield listitemvmf(k, '[COLOR red]VN Media[/COLOR]')
        else:
            yield quangcao()
@lru_cache(maxsize=None)
def set_item_callbacks(item, kenh, title, imgfs):
    script = Script.ref('/resources/lib/mkd/onfshare/ifshare:tfavo')
    taifshare = ADDON.getSetting('taifshare')
    if 'fshare.vn/folder' in kenh:
        item.context.script(script, 'Thêm vào Fshare Favorite', kenh)
        item.set_callback(Route.ref('/resources/lib/mkd/onfshare/ifshare:index_fs'), kenh, 0, imgfs)
    elif 'fshare.vn/file' in kenh:
        item.context.script(script, 'Thêm vào Fshare Favorite', kenh)
        if taifshare == 'true':
            item.context.script(Script.ref('/resources/lib/download:downloadfs'), 'Tải về', kenh)
        item.set_callback(Resolver.ref('/resources/lib/kedon:play_fs'), kenh, title)
    elif 'docs.google.com' in kenh:
        item.set_callback(listgg_gcs, kenh, title)
    elif 'VMF' in kenh:
        item.set_callback(listvmf_gcs, kenh.replace('VMF-', ''), title)
    else:
        item.set_callback(Resolver.ref('/resources/lib/kedon:play_vnm'), unquote(kenh), title, '')
@lru_cache(maxsize=None)
def create_listitem_from_link(link, title):
    tachhat = link.split('|')
    if tachhat[1] and len(tachhat) > 1:
        item = Listitem()
        kenh = tachhat[1]
        tenm = tachhat[0].translate(str.maketrans({'*': '', '@': ''}))
        item.label = tenm
        item.info['mediatype'] = 'movie'
        item.info['rating'] = 10.0
        item.info['trailer'] = yttk(tenm)
        imgfs = tachhat[3] if len(tachhat) > 3 else 'https://mi3s.top/thumb/fshare.png'
        item.art['thumb'] = item.art['poster'] = imgfs
        item.info['plot'] = tachhat[4] if len(tachhat) > 4 else title
        item.art['fanart'] = tachhat[5] if len(tachhat) > 5 else (tachhat[3] if len(tachhat) > 3 else 'https://mi3s.top/thumb/fshare.png')
        set_item_callbacks(item, kenh, tenm, imgfs)
        return item
@lru_cache(maxsize=None)
def listitemvmf(link, title):
    tachhat = link.split('|')
    if len(tachhat) > 1:
        item = Listitem()
        kenh = tachhat[1]
        tenm = tachhat[0].translate(str.maketrans({'*': '', '@': ''}))
        item.label = tenm
        item.info['mediatype'] = 'movie'
        item.info['rating'] = 10.0
        item.info['trailer'] = yttk(tenm)
        imgfs = tachhat[3] if len(tachhat) > 3 else 'https://mi3s.top/thumb/fshare.png'
        item.art['thumb'] = item.art['poster'] = imgfs
        item.info['plot'] = tachhat[4] if len(tachhat) > 4 else title
        item.art['fanart'] = tachhat[5] if len(tachhat) > 5 else (tachhat[3] if len(tachhat) > 3 else 'https://mi3s.top/thumb/fshare.png')
        set_item_callbacks(item, kenh, tenm, imgfs)
        return item