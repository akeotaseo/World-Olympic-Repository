from codequick import Route, Listitem, Resolver, Script
from resources.lib.kedon import __addonnoti__, __addonname__, getlink, getlinkvnm, quangcao
from concurrent.futures import ThreadPoolExecutor, as_completed
from xbmcgui import DialogProgress
from urllib.parse import quote_plus
from bs4 import BeautifulSoup
from functools import lru_cache
from urllib.parse import urlparse
import re, resolveurl
x = 'https://xem8z.com'
@lru_cache(maxsize=None)
def get_info_x8z(x):
	r = getlinkvnm(x,x)
	try:
		soup = BeautifulSoup(r.content, 'html.parser')
		soups = soup.select('div.clearfix.wrap-content')
		for k in soups:
			try:
				img = k.select_one('div.movie-poster img.movie-thumb')['src']
			except:
				img = 'https://mi3s.top/thumb/phim/x8z.png'
			try:
				title = k.select_one('div.movie-detail h1.entry-title').get_text(strip=True)
				name2 = k.select_one('p.org_title').get_text(strip=True)
				ten = f'{title} - {name2}'
			except:
				ten = __addonname__
			try:
				mota = k.select_one('article.item-content').get_text(strip=True)
			except:
				mota = ten
			return (ten, img, mota)
	except:
		return None
@lru_cache(maxsize=None)
def process_url(url):
	try:
		data = get_info_x8z(url)
		return url, data
	except:
		return url, None
@Route.register
def search_x8z(plugin, search_query=None, **kwargs):
	yield []
	if search_query is None:
		pass
	else:
		dialog = DialogProgress()
		dialog.create(__addonnoti__, 'Đang lấy dữ liệu...')
		next_page = 1
		sr = quote_plus(search_query)
		url = f'{x}/search/{sr.replace(" ","+")}'
		trangtiep = f'{url}/page/{next_page}'
		r = getlink(trangtiep, url, 1800)
		if (r is not None) and ('halim-thumb' in r.text):
			soup = BeautifulSoup(r.content, 'html.parser')
			soups = soup.select('.status:not(:contains("Trailer"))')
			urls = [k.find_previous('a')['href'] for k in soups]
			length = len(urls)
			if length>0:
				count = 0
				with ThreadPoolExecutor(length) as ex:
					future_to_url = (ex.submit(process_url, url) for url in urls)
					ac = as_completed(future_to_url)
					for k in ac:
						l, data = k.result()
						if data is not None:
							if (dialog.iscanceled()):
								break
							count += 1
							done = int((count/length)*100)
							dialog.update(done, f'Đang giải mã {length} dữ liệu...\nLoading... [COLOR yellow]{done} %[/COLOR]')
							item = Listitem()
							item.label = data[0]
							item.info['plot'] = data[2]
							item.info['mediatype'] = 'movie'
							item.art['thumb'] = item.art['fanart'] = data[1]
							item.set_callback(episode_x8z, l, data[0], data[2], data[1])
							yield item
				if f'/page/{str(int(next_page) + 1)}' in r.text:
					item1 = Listitem()
					item1.label = f'Trang {str(int(next_page) + 1)}'
					item1.art['thumb'] = item1.art['fanart'] = 'https://mi3s.top/thumb/next.png'
					item1.set_callback(ds_x8z, url, next_page + 1)
					yield item1
		else:
			Script.notify(__addonnoti__, 'Không tìm thấy kết quả')
			yield quangcao()
		dialog.close()
@Route.register
def index_8z(plugin, **kwargs):
	yield Listitem.search(search_x8z)
	dulieu = {
	'Phim bộ': f'{x}/phim-bo',
	'Phim lẻ': f'{x}/phim-le',
	'Chiếu rạp': f'{x}/phim-chieu-rap',
	}
	yield Listitem.from_dict(**{'label': 'Thể loại',
	'art': {'thumb': 'https://mi3s.top/thumb/phim/x8z.png',
	'fanart': 'https://mi3s.top/thumb/phim/x8z.png'},
	'callback': x8z_tl})
	yield Listitem.from_dict(**{'label': 'Quốc gia',
	'art':{'thumb':'https://mi3s.top/thumb/phim/x8z.png',
	'fanart':'https://mi3s.top/thumb/phim/x8z.png'},
	'callback': x8z_qg})
	for k in dulieu:
		item = Listitem()
		item.label = k
		item.art['thumb'] = item.art['fanart'] = 'https://mi3s.top/thumb/phim/x8z.png'
		item.set_callback(ds_x8z, dulieu[k], 1)
		yield item
@Route.register
def x8z_tl(plugin, **kwargs):
	dulieu = {
	'Hành động': f'{x}/hanh-dong',
	'Võ thuật': f'{x}/vo-thuat',
	'Tình cảm': f'{x}/tinh-cam',
	'Tâm lý': f'{x}/tam-ly',
	'Hài': f'{x}/hai-huoc',
	'Hoạt hình': f'{x}/hoat-hinh',
	'Phiêu lưu': f'{x}/phieu-luu',
	'Kinh dị': f'{x}/kinh-di',
	'Lịch sử': f'{x}/giat-gan',
	'Kiếm hiệp': f'{x}/kiem-hiep',
	'Hình sự': f'{x}/hinh-su',
	'Chiến tranh': f'{x}/chien-tranh',
	'Đua xe': f'{x}/dua-xe',
	'Viễn tưởng': f'{x}/vien-tuong',
	'Cổ trang': f'{x}/co-trang',
	'Tiên hiệp': f'{x}/tien-hiep',
	'Giật gân': f'{x}/giat-gan',
	'Chính kịch': f'{x}/chinh-kich',
	'Xã hội đen': f'{x}/xa-hoi-den'
	}
	for k in dulieu:
		item = Listitem()
		item.label = k
		item.art['thumb'] = item.art['fanart'] = 'https://mi3s.top/thumb/phim/x8z.png'
		item.set_callback(ds_x8z, dulieu[k], 1)
		yield item
@Route.register
def x8z_qg(plugin, **kwargs):
	dulieu = {
	'Âu Mỹ': f'{x}/country/au-my',
	'Hàn Quốc': f'{x}/country/han-quoc',
	'Trung Quốc': f'{x}/country/trung-quoc',
	'Việt Nam': f'{x}/country/viet-nam',
	'Nhật Bản': f'{x}/country/nhat-ban',
	'Ấn Độ': f'{x}/country/an-do',
	'Thái Lan': f'{x}/country/thai-lan',
	'Anh': f'{x}/country/anh-quoc'
	}
	for k in dulieu:
		item = Listitem()
		item.label = k
		item.art['thumb'] = item.art['fanart'] = 'https://mi3s.top/thumb/phim/x8z.png'
		item.set_callback(ds_x8z, dulieu[k], 1)
		yield item
@Route.register
def ds_x8z(plugin, url=None, next_page=None, **kwargs):
	yield []
	if url is None or next_page is None:
		pass
	else:
		dialog = DialogProgress()
		dialog.create(__addonnoti__, 'Đang lấy dữ liệu...')
		trangtiep = f'{url}/page/{next_page}'
		r = getlink(trangtiep, trangtiep, 1000)
		if (r is not None) and ('halim-thumb' in r.text):
			soup = BeautifulSoup(r.content, 'html.parser')
			soups = soup.select('.status:not(:contains("Trailer"))')
			urls = [k.find_previous('a')['href'] for k in soups]
			length = len(urls)
			if length>0:
				count = 0
				with ThreadPoolExecutor(length) as ex:
					future_to_url = (ex.submit(process_url, url) for url in urls)
					ac = as_completed(future_to_url)
					for k in ac:
						l, data = k.result()
						if data is not None:
							if (dialog.iscanceled()):
								break
							count += 1
							done = int((count/length)*100)
							dialog.update(done, f'Đang giải mã {length} dữ liệu...\nLoading... [COLOR yellow]{done} %[/COLOR]')
							item = Listitem()
							item.label = data[0]
							item.info['plot'] = data[2]
							item.info['mediatype'] = 'movie'
							item.art['thumb'] = item.art['fanart'] = data[1]
							item.set_callback(episode_x8z, l, data[0], data[2], data[1])
							yield item
				if f'/page/{str(int(next_page) + 1)}' in r.text:
					item1 = Listitem()
					item1.label = f'Trang {str(int(next_page) + 1)}'
					item1.art['thumb'] = item1.art['fanart'] = 'https://mi3s.top/thumb/next.png'
					item1.set_callback(ds_x8z, url, str(int(next_page) + 1))
					yield item1
		else:
			yield quangcao()
		dialog.close()
@Route.register
def episode_x8z(plugin, url=None, title=None, info=None, img=None, **kwargs):
	yield []
	if url is None or title is None or info is None or img is None:
		pass
	else:
		r = getlink(url, url, 1000)
		if (r is not None) and 'watch-movie' in r.text:
			try:
				soup = BeautifulSoup(r.content, 'html.parser')
				if 'youtube.com/embed/' in r.text:
					idvd = re.search(r'/embed/([a-zA-Z0-9_-]+)', r.text)[1]
					item1 = Listitem()
					item1.label = f'TRAILER: [I]{title}[/I]'
					item1.art['thumb'] = item1.art['fanart'] = f'https://i.ytimg.com/vi/{idvd}/sddefault.jpg'
					item1.set_path(f'plugin://plugin.video.youtube/play/?video_id={idvd}')
					yield item1
				soups = soup.select('div#halim-list-server.list-eps-ajax ul.halim-list-eps li span')
				for k in soups:
					item = Listitem()
					tenm = f"SV{k['data-server']}-{k.text} - {title}"
					episode_slug = k['data-episode-slug']
					post_id = k['data-post-id']
					server_id = k['data-server']
					item.label = tenm
					item.info['plot'] = info
					item.art['thumb'] = item.art['fanart'] = img
					item.set_callback(Resolver.ref('/resources/lib/kedon:play_x8z'), tenm, episode_slug, server_id, post_id, url, x)
					yield item
			except:
				yield quangcao()
		else:
			yield quangcao()
