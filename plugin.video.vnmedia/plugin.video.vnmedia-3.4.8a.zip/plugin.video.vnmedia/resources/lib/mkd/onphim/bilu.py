from codequick import Route, Listitem, Resolver, Script
from resources.lib.kedon import __addonnoti__, __addonname__, getlink, getlinkvnm, quangcao, fu
from concurrent.futures import ThreadPoolExecutor, as_completed
from xbmcgui import DialogProgress
from urllib.parse import quote_plus
from bs4 import BeautifulSoup
from requests import Session
from functools import lru_cache
from urllib.parse import urlparse
import re, sys
@lru_cache(maxsize=None)
def biluapp():
	url = 'https://bilutv.app'
	r = getlinkvnm(url, 'https://www.google.com.vn/')
	try:
		soup = BeautifulSoup(r.content, 'html.parser')
		hr = soup.select_one('ul.list-inline a')['href']
		if hr.startswith('/'):
			b= f'https:{hr}'
		elif hr.startswith('http'):
			b= hr
		else:
			b= f'https://{hr}'
		v = urlparse(fu(b))
		return f'{v.scheme}://{v.netloc}'
	except:
		sys.exit()
def get_episode(url):
	r = getlink(url, url, 1000)
	return r
@lru_cache(maxsize=None)
def get_info_bilu(x):
	r = getlinkvnm(x,x)
	try:
		soup = BeautifulSoup(r.content, 'html.parser')
		soups = soup.select('div.blockbody')
		for k in soups:
			try:
				img = k.select_one('div.poster img')['data-src']
			except:
				img = 'https://mi3s.top/thumb/phim/bilutv.png'
			try:
				title = k.select_one('div.title').get_text(strip=True)
				name2 = k.select_one('div.name2 h2').get_text(strip=True)
				ten = f'{title} - {name2}'
			except:
				ten = __addonname__
			try:
				mota = k.select_one('div.tabs-content div.text').get_text(strip=True)
			except:
				mota = ten
			return (ten, img, mota)
	except:
		return None
@lru_cache(maxsize=None)
def process_url(url):
	try:
		data = get_info_bilu(url)
		return url, data
	except:
		return url, None
@Route.register
def search_bilu(plugin, search_query=None, **kwargs):
	yield []
	if search_query is None:
		pass
	else:
		bilu = biluapp()
		dialog = DialogProgress()
		dialog.create(__addonnoti__, 'Đang lấy dữ liệu...')
		next_page = 1
		sr = quote_plus(search_query)
		url = f'{bilu}/tag/{sr.replace(" ","+")}'
		trangtiep = f'{url}/trang-{next_page}'
		r = getlink(trangtiep, url, 1800)
		if (r is not None) and ('list-film' in r.text):
			soup = BeautifulSoup(r.content, 'html.parser')
			soups = soup.select('.status:not(:contains("Trailer"))')
			urls = [k.find_previous('a')['href'] for k in soups]
			length = len(urls)
			if length>0:
				count = 0
				with ThreadPoolExecutor(length) as ex:
					future_to_url = (ex.submit(process_url, url) for url in urls)
					ac = as_completed(future_to_url)
					for k in ac:
						l, data = k.result()
						if data is not None:
							if (dialog.iscanceled()):
								break
							count += 1
							done = int((count/length)*100)
							dialog.update(done, f'Đang giải mã {length} dữ liệu...\nLoading... [COLOR yellow]{done} %[/COLOR]')
							item = Listitem()
							item.label = data[0]
							item.info['plot'] = data[2]
							item.info['mediatype'] = 'movie'
							item.art['thumb'] = item.art['fanart'] = data[1]
							item.set_callback(episode_bilu, l, data[0], data[2], data[1])
							yield item
				if f'/trang-{str(int(next_page) + 1)}' in r.text:
					item1 = Listitem()
					item1.label = f'Trang {str(int(next_page) + 1)}'
					item1.art['thumb'] = item1.art['fanart'] = 'https://mi3s.top/thumb/next.png'
					item1.set_callback(ds_bilu, url, next_page + 1)
					yield item1
		else:
			Script.notify(__addonnoti__, 'Không tìm thấy kết quả')
			yield quangcao()
		dialog.close()
@Route.register
def index_bilu(plugin, **kwargs):
	bilu = biluapp()
	yield Listitem.search(search_bilu)
	dulieu = {
	'Phim mới': f'{bilu}/phim-moi',
	'Phim bộ': f'{bilu}/phim-bo',
	'Phim lẻ': f'{bilu}/phim-le',
	'Chiếu rạp': f'{bilu}/phim-chieu-rap',
	'Hoạt hình': f'{bilu}/phim-hoat-hinh',
	'Phim thuyết minh': f'{bilu}/phim-thuyet-minh',
	'Phim lồng tiếng': f'{bilu}/phim-long-tieng'
	}
	yield Listitem.from_dict(**{'label': 'Thể loại',
	'art': {'thumb': 'https://mi3s.top/thumb/phim/bilutv.png',
	'fanart': 'https://mi3s.top/thumb/phim/bilutv.png'},
	'callback': bilu_tl})
	yield Listitem.from_dict(**{'label': 'Quốc gia',
	'art':{'thumb':'https://mi3s.top/thumb/phim/bilutv.png',
	'fanart':'https://mi3s.top/thumb/phim/bilutv.png'},
	'callback': bilu_qg})
	for k in dulieu:
		item = Listitem()
		item.label = k
		item.art['thumb'] = item.art['fanart'] = 'https://mi3s.top/thumb/phim/bilutv.png'
		item.set_callback(ds_bilu, dulieu[k], 1)
		yield item
@Route.register
def bilu_tl(plugin, **kwargs):
	bilu = biluapp()
	dulieu = {
	'Hành động': f'{bilu}/the-loai/hanh-dong',
	'Võ thuật': f'{bilu}/the-loai/vo-thuat',
	'Tình cảm': f'{bilu}/the-loai/tinh-cam',
	'Tâm lý': f'{bilu}/the-loai/tam-ly',
	'Hài': f'{bilu}/the-loai/hai',
	'Hoạt hình': f'{bilu}/the-loai/hoat-hinh',
	'Phiêu lưu': f'{bilu}/the-loai/phieu-luu',
	'Kinh dị': f'{bilu}/the-loai/kinh-di',
	'Hình sự': f'{bilu}/the-loai/hinh-su',
	'Chiến tranh': f'{bilu}/the-loai/chien-tranh',
	'Thần thoại': f'{bilu}/the-loai/than-thoai',
	'Viễn tưởng': f'{bilu}/the-loai/vien-tuong',
	'Cổ trang': f'{bilu}/the-loai/co-trang',
	'Âm nhạc': f'{bilu}/the-loai/am-nhac',
	'TV Show': f'{bilu}/the-loai/tv-show',
	'Khoa học': f'{bilu}/the-loai/khoa-hoc'
	}
	for k in dulieu:
		item = Listitem()
		item.label = k
		item.art['thumb'] = item.art['fanart'] = 'https://mi3s.top/thumb/phim/bilutv.png'
		item.set_callback(ds_bilu, dulieu[k], 1)
		yield item
@Route.register
def bilu_qg(plugin, **kwargs):
	bilu = biluapp()
	dulieu = {
	'Mỹ': f'{bilu}/quoc-gia/my',
	'Hàn Quốc': f'{bilu}/quoc-gia/han-quoc',
	'Trung Quốc': f'{bilu}/quoc-gia/trung-quoc',
	'Hồng Kông': f'{bilu}/quoc-gia/hong-kong',
	'Đài Loan': f'{bilu}/quoc-gia/dai-loan',
	'Việt Nam': f'{bilu}/quoc-gia/viet-nam',
	'Nhật Bản': f'{bilu}/quoc-gia/nhat-ban',
	'Ấn Độ': f'{bilu}/quoc-gia/an-do',
	'Thái Lan': f'{bilu}/quoc-gia/thai-lan',
	'Pháp': f'{bilu}/quoc-gia/phap',
	'Anh': f'{bilu}/quoc-gia/anh',
	'Nước Khác': f'{bilu}/quoc-gia/khac'
	}
	for k in dulieu:
		item = Listitem()
		item.label = k
		item.art['thumb'] = item.art['fanart'] = 'https://mi3s.top/thumb/phim/bilutv.png'
		item.set_callback(ds_bilu, dulieu[k], 1)
		yield item
@Route.register
def ds_bilu(plugin, url=None, next_page=None, **kwargs):
	yield []
	if url is None or next_page is None:
		pass
	else:
		dialog = DialogProgress()
		dialog.create(__addonnoti__, 'Đang lấy dữ liệu...')
		trangtiep = f'{url}/trang-{next_page}'
		r = getlink(trangtiep, trangtiep, 1000)
		if (r is not None) and ('list-film' in r.text):
			soup = BeautifulSoup(r.content, 'html.parser')
			soups = soup.select('.status:not(:contains("Trailer"))')
			urls = [k.find_previous('a')['href'] for k in soups]
			length = len(urls)
			if length>0:
				count = 0
				with ThreadPoolExecutor(length) as ex:
					future_to_url = (ex.submit(process_url, url) for url in urls)
					ac = as_completed(future_to_url)
					for k in ac:
						l, data = k.result()
						if data is not None:
							if (dialog.iscanceled()):
								break
							count += 1
							done = int((count/length)*100)
							dialog.update(done, f'Đang giải mã {length} dữ liệu...\nLoading... [COLOR yellow]{done} %[/COLOR]')
							item = Listitem()
							item.label = data[0]
							item.info['plot'] = data[2]
							item.info['mediatype'] = 'movie'
							item.art['thumb'] = item.art['fanart'] = data[1]
							item.set_callback(episode_bilu, l, data[0], data[2], data[1])
							yield item
				if f'/trang-{str(int(next_page) + 1)}' in r.text:
					item1 = Listitem()
					item1.label = f'Trang {str(int(next_page) + 1)}'
					item1.art['thumb'] = item1.art['fanart'] = 'https://mi3s.top/thumb/next.png'
					item1.set_callback(ds_bilu, url, str(int(next_page) + 1))
					yield item1
		else:
			yield quangcao()
		dialog.close()
@Route.register
def episode_bilu(plugin, url=None, title=None, info=None, img=None, **kwargs):
	yield []
	if url is None or title is None or info is None or img is None:
		pass
	else:
		with ThreadPoolExecutor(2) as ex:
			f1 = ex.submit(biluapp)
			f2 = ex.submit(get_episode, url)
			bilu = f1.result()
			r = f2.result()
		if (r is not None) and 'btn-watch' in r.text:
			soupx = BeautifulSoup(r.content, 'html.parser')
			if 'youtube.com/embed/' in r.text:
				y = soupx.select_one('div.embed-responsive iframe')['src']
				idvd = re.search(r"/embed/([a-zA-Z0-9_-]+)", y)[1]
				item1 = Listitem()
				item1.label = f'TRAILER: [I]{title}[/I]'
				item1.art['thumb'] = item1.art['fanart'] = f'https://i.ytimg.com/vi/{idvd}/sddefault.jpg'
				item1.set_path(f'plugin://plugin.video.youtube/play/?video_id={idvd}')
				yield item1
			urlplay = soupx.select_one('a.btn-watch')['href']
			resp = getlink(urlplay, url, 1000)
			if (resp is not None):
				soup = BeautifulSoup(resp.content, 'html.parser')
				soups = soup.select('div.server')
				data = ((k.select_one('div.label').get_text(strip=True), l.a.get_text(strip=True), l.a['href']) for k in soups for l in k.select('ul.episodelist li'))
				for k in data:
					item = Listitem()
					tenm = f'[COLOR yellow]{k[0]}[/COLOR] Tập {k[1]} - {title}'
					item.label = tenm
					item.info['plot'] = info
					item.art['thumb'] = item.art['fanart'] = img
					item.set_callback(Resolver.ref('/resources/lib/kedon:play_tvhay'), k[2], tenm, bilu)
					yield item
			else:
				yield quangcao()
		else:
			yield quangcao()