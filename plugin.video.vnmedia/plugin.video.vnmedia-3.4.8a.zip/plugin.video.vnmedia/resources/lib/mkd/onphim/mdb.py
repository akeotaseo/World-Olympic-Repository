from codequick import Route, Listitem, Resolver
from resources.lib.kedon import __addonnoti__, getlink, getlinkvnm, quangcao, yttk, listqc, news, qc, streamifr, referer
from concurrent.futures import ThreadPoolExecutor
from bs4 import BeautifulSoup
from xbmcgui import DialogProgressBG
from urllib.parse import quote_plus
from datetime import date
import re
tmdbAPI='https://api.themoviedb.org/3'
apimdb='b030404650f279792a8d3287232358e3'
apiKey = f'{apimdb}&language=vi-VN'
append = 'alternative_titles,credits,external_ids,keywords,videos,recommendations'
def playsmashy(idk):
	u4 = f'https://embed.smashystream.com/playere.php?tmdb={idk}'
	r4 = getlinkvnm(u4,u4)
	if (r4 is not None) and ('data-id="http' in r4.text):
		soup = BeautifulSoup(r4.content, 'html.parser')
		url = soup.select_one('a.server')['data-id']
		r = getlinkvnm(url, url)
		if (r is not None) and ('.m3u8' in r.text):
			a = r.text.replace('\\/', '/')
			match = re.search(r'(https?://[^\s"]+?\.m3u8[^\,]*)', a)
			playsmashy = f'{streamifr(match[1])}{referer(url)}'
		else:
			playsmashy = qc
	else:
		playsmashy = qc
	return playsmashy
def subvidto(idk):
	if '&' in str(idk):
		match = re.search(r'(\d+)&season=(\d+)&episode=(\d+)', idk)
		u2 = f'https://vidsrc.to/embed/tv/{match[1]}/{match[2]}/{match[3]}'
	else:
		u2 = f'https://vidsrc.to/embed/movie/{idk}'
	r2 = getlinkvnm(u2,u2)
	if (r2 is not None) and ('data-id' in r2.text):
		dataid = re.search('data-id="(.*?)"', r2.text)[1]
		u = f'https://vidsrc.to/ajax/embed/episode/{dataid}/subtitles'
		r = getlinkvnm(u,u)
		if (r is not None) and ('Vietnam' in r.text):
			vtt = ''.join((k['file'] for k in r.json() if 'Vietnam' in k['label']))
		else:
			vtt = news
	else:
		vtt = news
	return vtt
@Route.register
def search_mdb(plugin, search_query=None, **kwargs):
	yield []
	if search_query is None:
		pass
	else:
		dialog = DialogProgressBG()
		dialog.create(__addonnoti__, 'Đang lấy dữ liệu...')
		next_page = 1
		sr = quote_plus(search_query)
		match = f'{tmdbAPI}/search/multi?api_key={apiKey}&query={sr.replace(" ","+")}'
		u = f'{match}&page={next_page}'
		r = getlink(u, u, 1000)
		if (r is not None) and ('results' in r.text):
			rj = r.json()
			for k in rj['results']:
				if 'known_for' in k:
					s = k['known_for'][0]
					try:
						ten = s['name']
					except:
						ten = s['title']
					idp = s['id']
					mota = s['overview']
					diem = s['vote_average']
					anhposter = s['poster_path']
					anhback = s['backdrop_path']
					try:
						typep = s['media_type']
					except:
						typep = 'movie' if '/movie' in match else 'tv'
					try:
						try:
							phathanh = s['release_date']
						except:
							phathanh = s['first_air_date']
					except:
						phathanh = date.today()
				else:
					try:
						ten = k['name']
					except:
						ten = k['title']
					idp = k['id']
					mota = k['overview']
					diem = k['vote_average']
					anhposter = k['poster_path']
					anhback = k['backdrop_path']
					try:
						typep = k['media_type']
					except:
						typep = 'movie' if '/movie' in match else 'tv'
					try:
						try:
							phathanh = k['release_date']
						except:
							phathanh = k['first_air_date']
					except:
						phathanh = date.today()
				item = Listitem()
				item.label = ten
				item.info['plot'] = mota
				item.info['mediatype'] = 'movie'
				item.info['premiered'] = phathanh
				item.info['rating'] = float(diem)
				item.info['dbid'] = idp
				item.info['trailer'] = yttk(ten)
				item.art['thumb'] = item.art['poster'] = f"https://image.tmdb.org/t/p/w500{anhposter}"
				item.art['fanart'] = f"https://image.tmdb.org/t/p/w500{anhback}"
				item.set_callback(detail_mdb, idp, typep)
				yield item
			tong = rj['total_pages']
			if next_page < tong:
				item1 = Listitem()
				item1.label = f'Trang {str(int(next_page) + 1)}'
				item1.art['thumb'] = item1.art['fanart'] = 'https://mi3s.top/thumb/next.png'
				item1.set_callback(ds_mdb, match, next_page + 1)
				yield item1
		else:
			yield quangcao()
		dialog.close()
@Route.register
def index_mdb(plugin, **kwargs):
	yield Listitem.search(search_mdb)
	dulieu = {
	'Trending': f'{tmdbAPI}/trending/all/day?api_key={apiKey}&region=US',
	'Popular Movies': f'{tmdbAPI}/movie/popular?api_key={apiKey}&region=US',
	'Popular TV Shows': f'{tmdbAPI}/tv/popular?api_key={apiKey}&region=US&with_original_language=en',
	'Airing Today TV Shows': f'{tmdbAPI}/tv/airing_today?api_key={apiKey}&region=US&with_original_language=en',
	'Netflix': f'{tmdbAPI}/discover/tv?api_key={apiKey}&with_networks=213',
	'Amazon': f'{tmdbAPI}/discover/tv?api_key={apiKey}&with_networks=1024',
	'Disney+': f'{tmdbAPI}/discover/tv?api_key={apiKey}&with_networks=2739',
	'Hulu': f'{tmdbAPI}/discover/tv?api_key={apiKey}&with_networks=453',
	'Apple TV+': f'{tmdbAPI}/discover/tv?api_key={apiKey}&with_networks=2552',
	'HBO': f'{tmdbAPI}/discover/tv?api_key={apiKey}&with_networks=49',
	'Paramount+': f'{tmdbAPI}/discover/tv?api_key={apiKey}&with_networks=4330',
	'Top Rated Movies': f'{tmdbAPI}/movie/top_rated?api_key={apiKey}&region=US',
	'Top Rated TV Shows': f'{tmdbAPI}/tv/top_rated?api_key={apiKey}&region=US',
	'Upcoming Movies': f'{tmdbAPI}/movie/upcoming?api_key={apiKey}&region=US',
	'Korean Shows': f'{tmdbAPI}/discover/tv?api_key={apiKey}&with_original_language=ko',
	'Airing Today Anime': f'{tmdbAPI}/tv/airing_today?api_key={apiKey}&with_keywords=210024|222243&sort_by=primary_release_date.desc',
	'Ongoing Anime': f'{tmdbAPI}/tv/on_the_air?api_key={apiKey}&with_keywords=210024|222243&sort_by=primary_release_date.desc',
	'Anime': f'{tmdbAPI}/discover/tv?api_key={apiKey}&with_keywords=210024|222243',
	'Anime Movies': f'{tmdbAPI}/discover/movie?api_key={apiKey}&with_keywords=210024|222243'
	}
	for k in dulieu:
		item = Listitem()
		item.label = k
		item.art['thumb'] = item.art['fanart'] = 'https://mi3s.top/thumb/phim/onstream.png'
		item.set_callback(ds_mdb, dulieu[k], 1)
		yield item
@Route.register
def ds_mdb(plugin, match=None, next_page=None, **kwargs):
	yield []
	if match is None or next_page is None:
		pass
	else:
		u = f'{match}&page={next_page}'
		r = getlink(u,u,1000)
		if (r is not None) and ('results' in r.text):
			rj = r.json()
			for k in rj['results']:
				if 'known_for' in k:
					s = k['known_for'][0]
					try:
						ten = s['name']
					except:
						ten = s['title']
					idp = s['id']
					mota = s['overview']
					diem = s['vote_average']
					anhposter = s['poster_path']
					anhback = s['backdrop_path']
					try:
						typep = s['media_type']
					except:
						typep = 'movie' if '/movie' in match else 'tv'
					try:
						try:
							phathanh = s['release_date']
						except:
							phathanh = s['first_air_date']
					except:
						phathanh = date.today()
				else:
					try:
						ten = k['name']
					except:
						ten = k['title']
					idp = k['id']
					mota = k['overview']
					diem = k['vote_average']
					anhposter = k['poster_path']
					anhback = k['backdrop_path']
					try:
						typep = k['media_type']
					except:
						typep = 'movie' if '/movie' in match else 'tv'
					try:
						try:
							phathanh = k['release_date']
						except:
							phathanh = k['first_air_date']
					except:
						phathanh = date.today()
				item = Listitem()
				item.label = ten
				item.info['plot'] = mota
				item.info['mediatype'] = 'movie'
				item.info['premiered'] = phathanh
				item.info['rating'] = float(diem)
				item.info['dbid'] = idp
				item.info['trailer'] = yttk(ten)
				item.art['thumb'] = item.art['poster'] = f"https://image.tmdb.org/t/p/w500{anhposter}"
				item.art['fanart'] = f"https://image.tmdb.org/t/p/w500{anhback}"
				item.set_callback(detail_mdb, idp, typep)
				yield item
			tong = rj['total_pages']
			if next_page < tong:
				item1 = Listitem()
				item1.label = f'Trang {str(int(next_page) + 1)}'
				item1.art['thumb'] = item1.art['fanart'] = 'https://mi3s.top/thumb/next.png'
				item1.set_callback(ds_mdb, match, next_page + 1)
				yield item1
		else:
			yield quangcao()
@Route.register
def detail_mdb(plugin, idp=None, typep=None, **kwargs):
	yield []
	if idp is None or typep is None:
		pass
	else:
		if typep == 'tv':
			res_url = f'{tmdbAPI}/tv/{idp}?api_key={apiKey}&append_to_response={append}'
			res_response = getlink(res_url,res_url,1000)
			if res_response is not None:
				res_data = res_response.json()
				try:
					title = res_data['title']
				except:
					title = res_data['name']
				bg_poster = res_data['backdrop_path']
				try:
					trailer_results = res_data['videos']['results'][0]['key']
					ut = f'plugin://plugin.video.youtube/play/?video_id={trailer_results}'
					for season in res_data['seasons']:
						season_number = season['season_number']
						item = Listitem()
						item.label = f"{title} - {season['name']}"
						item.info['plot'] = season['overview']
						item.info['mediatype'] = 'movie'
						item.info['premiered'] = season['air_date']
						item.info['rating'] = float(season['vote_average'])
						item.info['dbid'] = idp
						item.info['trailer'] = ut
						item.art['thumb'] = item.art['poster'] = f"https://image.tmdb.org/t/p/w500{season['poster_path']}"
						item.art['fanart'] = f'https://image.tmdb.org/t/p/w500{bg_poster}'
						item.set_callback(tv_mdb, idp, season_number, title)
						yield item
				except:
					for season in res_data['seasons']:
						season_number = season['season_number']
						item = Listitem()
						item.label = f"{title} - {season['name']}"
						item.info['plot'] = season['overview']
						item.info['mediatype'] = 'movie'
						item.info['premiered'] = season['air_date']
						item.info['rating'] = float(season['vote_average'])
						item.info['dbid'] = idp
						item.info['trailer'] = yttk(title)
						item.art['thumb'] = item.art['poster'] = f"https://image.tmdb.org/t/p/w500{season['poster_path']}"
						item.art['fanart'] = f'https://image.tmdb.org/t/p/w500{bg_poster}'
						item.set_callback(tv_mdb, idp, season_number, title)
						yield item
			else:
				yield quangcao()
		else:
			res_url = f'{tmdbAPI}/movie/{idp}?api_key={apiKey}&append_to_response={append}'
			res_response = getlink(res_url,res_url,1000)
			if res_response is not None:
				res_data = res_response.json()
				try:
					title = res_data['title']
				except:
					title = res_data['name']
				poster = res_data['poster_path']
				bg_poster = res_data['backdrop_path']
				mota = res_data['overview']
				img = f"https://image.tmdb.org/t/p/w500{res_data['poster_path']}"
				try:
					try:
						release_date = res_data['release_date']
					except:
						release_date = res_data['first_air_date']
				except:
					release_date = date.today()
				try:
					trailer_results = res_data['videos']['results'][0]['key']
					ut = f'plugin://plugin.video.youtube/play/?video_id={trailer_results}'
					item2 = Listitem()
					item2.label = f'TRAILER: [I]{title}[/I]'
					item2.art['thumb'] = item2.art['fanart'] = f'https://i.ytimg.com/vi/{trailer_results}/sddefault.jpg'
					item2.set_path(ut)
					yield item2
					item = Listitem()
					item.label = title
					item.info['trailer'] = ut
					item.info['rating'] = float(res_data['vote_average'])
					item.info['mediatype'] = 'movie'
					item.info['premiered'] = release_date
					item.info['plot'] = mota
					item.art['thumb'] = item.art['poster'] = img
					item.set_callback(list_smashyflix, idp, idp, title)
					yield item
				except:
					item = Listitem()
					item.label = title
					item.info['trailer'] = yttk(title)
					item.info['rating'] = float(res_data['vote_average'])
					item.info['mediatype'] = 'movie'
					item.info['premiered'] = release_date
					item.info['plot'] = mota
					item.art['thumb'] = item.art['poster'] = img
					item.set_callback(list_smashyflix, idp, idp, title)
					yield item
			else:
				yield quangcao()
@Route.register
def tv_mdb(plugin, idp=None, season_number=None, title=None, **kwargs):
	yield []
	if idp is None or season_number is None or title is None:
		pass
	else:
		res_url = f'{tmdbAPI}/tv/{idp}/season/{season_number}?api_key={apiKey}'
		res_response = getlink(res_url,res_url,1000)
		if res_response is not None:
			season_data = res_response.json()
			season_episodes = season_data['episodes']
			bg_poster = f"https://image.tmdb.org/t/p/w500{season_data['poster_path']}"
			vote_average = season_data['vote_average']
			try:
				trailer_results = season_data['videos']['results'][0]['key']
				ut = f'plugin://plugin.video.youtube/play/?video_id={trailer_results}'
				for episode in season_episodes:
					eps_title = episode['name']
					episode_number = episode['episode_number']
					season_number = episode['season_number']
					mota = episode['overview']
					uep = f'{idp}&season={season_number}&episode={episode_number}'
					e = f'{title} S{season_number}E{episode_number}'
					item = Listitem()
					item.label = e
					item.info['mediatype'] = 'movie'
					item.info['rating'] = float(vote_average)
					item.info['premiered'] = episode['air_date']
					item.info['plot'] = mota
					item.info['trailer'] = ut
					item.art['thumb'] = item.art['poster'] = item.art['fanart'] = bg_poster
					item.set_callback(list_smashyflix, uep, idp, title)
					yield item
			except:
				for episode in season_episodes:
					episode_number = episode['episode_number']
					season_number = episode['season_number']
					mota = episode['overview']
					uep = f'{idp}&season={season_number}&episode={episode_number}'
					item = Listitem()
					e = f'{title} S{season_number}E{episode_number}'
					item.label = e
					item.info['mediatype'] = 'movie'
					item.info['rating'] = float(vote_average)
					item.info['premiered'] = episode['air_date']
					item.info['plot'] = episode['overview']
					item.info['trailer'] = yttk(e)
					item.art['thumb'] = item.art['poster'] = item.art['fanart'] = bg_poster
					item.set_callback(list_smashyflix, uep, idp, title)
					yield item
		else:
			yield quangcao()
@Resolver.register
def list_smashyflix(plugin, idk, idp, title, **kwargs):
	try:
		if '&' in str(idk):
			u = f'{tmdbAPI}/tv/{idp}?language=en-US&api_key={apimdb}'
		else:
			u = f'{tmdbAPI}/movie/{idp}?language=en-US&api_key={apimdb}'
		with ThreadPoolExecutor(2) as ex:
			f1 = ex.submit(playsmashy, idk)
			f2 = ex.submit(subvidto, idk)
			psm = f1.result()
			pd = f2.result()
		ru = getlinkvnm(u,u)
		if (ru is not None):
			rj = ru.json()
			try:
				name = rj['name']
			except:
				name = rj['title']
			return listqc(name, pd, psm)
		else:
			return listqc(title, news, qc)
	except:
		return listqc(title, news, qc)