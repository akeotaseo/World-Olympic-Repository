from codequick import Route, Listitem
from resources.lib.kedon import getlink, ace, quangcao
from datetime import datetime, timedelta, date
from bs4 import BeautifulSoup
@Route.register
def index_livetvxs(plugin, **kwargs):
	yield []
	url = 'http://livetv.sx/export/webmasters.php?lang=en'
	resp = getlink(url, url, 400)
	if (resp is not None) and ('acestream' in resp.text):
		soup = BeautifulSoup(resp.content, 'html.parser')
		soups = soup.select('tr td')
		for episode in soups:
			z = episode.select('td.time')
			for w in z:
				timex = w.get_text(strip=True)
				if len(timex)==4:
					y = f'{date.today()}T0{timex}'
				else:
					y = f'{date.today()}T{timex}'
				z = (datetime.fromisoformat(y) + timedelta(hours=6)).strftime('%H:%M')
			a = episode.select('td a.title')
			for b in a:
				tentran = b.get_text(strip=True)
			anh = episode.select('td img')
			for im in anh:
				img = f'https:{im["src"]}'
			x = episode.select('div a')
			for index, number in enumerate(x):
				lp = number['href']
				if 'acestream' in lp:
					item = Listitem()
					item.art['thumb'] = item.art['fanart'] = img
					tenm = f'Link {index+1}-{z} {tentran}'
					item.label = tenm
					item.path = ace(lp, tenm)
					item.set_callback(item.path)
					yield item
	else:
		yield quangcao()