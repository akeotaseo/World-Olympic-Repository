from codequick import Route, Listitem, Resolver
from resources.lib.kedon import __addonnoti__, fu, getlink, getlinkvnm, quangcao
from urllib.parse import urlparse
from bs4 import BeautifulSoup
from functools import lru_cache
from xbmcgui import DialogProgressBG
import re
@lru_cache(maxsize=None)
def mitom():
	url = 'http://bit.ly/m/xoilac'
	r = getlinkvnm(url, 'https://www.google.com.vn/')
	matches = re.findall(r'\{"target": "([^"]+)(.*?)\}', r.text)
	fil = (k[0] for k in matches if 'mitom' in k[1].lower())
	mitom_url = ''.join(fil)
	mu = mitom_url if 'http' in mitom_url else f'https://{mitom_url}'
	return mu
@Route.register
def index_91phut(plugin, **kwargs):
	yield []
	try:
		dialog = DialogProgressBG()
		dialog.create(__addonnoti__, 'Đang lấy dữ liệu...')
		v = urlparse(fu(mitom()))
		p91 = f'{v.scheme}://{v.netloc}/vb-ajax.php?action=filter_match&filter=blv&league='
		resp = getlink(p91, p91, 1000)
		if (resp is not None):
			soup = BeautifulSoup(resp.json()['data']['html'], 'html.parser')
			soups = soup.select('div.position-relative.match')
			length = len(soups)
			count = 0
			for episode in soups:
				count += 1
				done = int((count/length)*100)
				dialog.update(done, f'Đang giải mã {length} dữ liệu...')
				name = episode.select_one('a.link-match')['title']
				v = episode.select('ul.blv li a')
				for d in v:
					item = Listitem()
					link = d['href']
					blv = d.get_text(strip=True)
					tenm = f'{name} - {blv}'
					item.label = tenm
					item.art['thumb'] = item.art['fanart'] = 'https://mi3s.top/thumb/thethao/mitom.png'
					item.set_callback(Resolver.ref('/resources/lib/kedon:ifr_bongda'), link, tenm)
					yield item
		else:
			yield quangcao()
		dialog.close()
	except:
		pass