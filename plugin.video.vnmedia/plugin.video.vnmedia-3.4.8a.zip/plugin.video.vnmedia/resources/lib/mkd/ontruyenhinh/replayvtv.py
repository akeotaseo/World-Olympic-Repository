from codequick import Route, Listitem
from datetime import date, timedelta
@Route.register
def index_vtv(plugin, **kwargs):
	n1 = date.today()
	for i in range(3):
		n = n1-timedelta(i)
		h = n.strftime('%d/%m/%Y')
		item = Listitem()
		item.label = h
		item.art['thumb'] = item.art['fanart'] = 'https://img.websosanh.vn/v10/users/review/images/1yuxgbu89uqkb/lua-cho-tivi-cho-gia-dinh-1.jpg'
		item.set_callback(list_vtv, n, h)
		yield item
@Route.register
def list_vtv(plugin, tg=None, ngay=None, **kwargs):
	yield []
	if tg is None or ngay is None:
		pass
	else:
		kenhidvt = {
		'VTV1':'2',
		'VTV2':'3',
		'VTV3':'4',
		'VTV5':'110',
		'VTV5 TNB':'157',
		'VTV Cần Thơ':'98',
		'HTV1':'190',
		'HTV4':'9',
		'HTV9':'194',
		'HTV Thể thao':'195',
		'HTVC Gia đình':'11',
		'HTVC Phụ nữ':'12',
		'HTVC Thuần Việt':'13',
		'HTVC Ca nhạc':'14',
		'HTVC Plus':'132',
		'HTVC Du lịch':'133',
		'SCTV6':'232',
		'VTC1':'16',
		'VTC2':'196',
		'ANTV':'20',
		'Quốc hội':'290',
		'Quốc phòng':'19',
		'Vnews':'24',
		'Hà Nội 1':'33',
		'Sự kiện 1':'2554',
		'Sự kiện 2':'1',
		'Sự kiện 3':'148',
		'Sự kiện 4':'2458'}
		kenhidx = {
		'THVL1':'thvl1',
		'THVL2':'thvl2',
		'THVL3':'thvl3',
		'THVL4':'thvl4'}
		for m in kenhidvt:
			item = Listitem()
			item.label = f'{m} - {ngay}'
			item.art['thumb'] = item.art['fanart'] = 'https://img.websosanh.vn/v10/users/review/images/1yuxgbu89uqkb/lua-cho-tivi-cho-gia-dinh-1.jpg'
			item.set_callback(Route.ref('/resources/lib/mkd/ontruyenhinh/replaythvl:get_vtvvt'), kenhidvt[m], tg)
			yield item
		for l in kenhidx:
			item1 = Listitem()
			item1.label = f'{l} - {ngay}'
			item1.art['thumb'] = item1.art['fanart'] = 'https://img.websosanh.vn/v10/users/review/images/1yuxgbu89uqkb/lua-cho-tivi-cho-gia-dinh-1.jpg'
			item1.set_callback(Route.ref('/resources/lib/mkd/ontruyenhinh/replaythvl:get_thvl'), kenhidx[l], tg)
			yield item1