root = 'root'
menu = {'vnmsport': {
        'route': '/resources/lib/mkd/onthethao/vnm:index_vnm',
        'label': 'SỰ KIỆN TRỰC TIẾP',
        'thumb': 'https://mi3s.top/thumb/thethao/sukien.png',
        'enabled': True,
        'order': 1
        },
        'replaysport': {
        'route': '/resources/lib/mkd/onthethao/xemlaivk:index_xemlaivk',
        'label': 'XEM LẠI SỰ KIỆN',
        'thumb': 'https://mi3s.top/thumb/thethao/xemlai.png',
        'enabled': True,
        'order': 2
        },
        'tinthethao': {
        'route': '/resources/lib/mkd/onthethao/tinthethao:index_tinthethao',
        'label': 'Tin thể thao',
        'thumb': 'https://mi3s.top/thumb/thethao/tinthethao.png',
        'enabled': True,
        'order': 3
        },
        'acest': {
        'route': '/resources/lib/mkd/acest:index_acestream',
        'label': 'Nhóm ACESTREAM',
        'thumb': 'https://mi3s.top/thumb/thethao/acestream.png',
        'enabled': True,
        'order': 4
        },
        'daddylive': {
        'route': '/resources/lib/mkd/onthethao/daddylive:index_daddy',
        'label': 'DADDYLIVE',
        'thumb': 'https://mi3s.top/thumb/thethao/daddy-live-hd-channels-list.png',
        'enabled': True,
        'order': 5
        },
        'ustream': {
        'route': '/resources/lib/mkd/onthethao/ustream:index_ustream',
        'label': 'MECIURI TV',
        'thumb': 'https://mi3s.top/thumb/thethao/sports-channels.png',
        'enabled': True,
        'order': 6
        },
        'phut901': {
        'route': '/resources/lib/mkd/onthethao/phut90:index_90p',
        'label': '90PHUT - VEBO',
        'thumb': 'https://mi3s.top/thumb/thethao/90p.png',
        'enabled': True,
        'order': 7
        },
        'thapcam': {
        'route': '/resources/lib/mkd/onthethao/thapcam:index_thapcam',
        'label': 'THAPCAM.NET',
        'thumb': 'https://mi3s.top/thumb/thethao/thapcamtv.png',
        'enabled': True,
        'order': 8
        },
        'bongcam': {
        'route': '/resources/lib/mkd/onthethao/bongcam:index_bc',
        'label': 'BONGCAM.TV',
        'thumb': 'https://mi3s.top/thumb/thethao/nba.png',
        'enabled': True,
        'order': 9
        },
        'phut91': {
        'route': '/resources/lib/mkd/onthethao/phut91:index_91phut',
        'label': 'MITOM - XOILAC',
        'thumb': 'https://mi3s.top/thumb/thethao/mitom.png',
        'enabled': True,
        'order': 10
        },
        'cakhia': {
        'route': '/resources/lib/mkd/onthethao/cakhia:index_cakhia',
        'label': 'CAKHIA - CAHEO',
        'thumb': 'https://mi3s.top/thumb/thethao/cakhia.png',
        'enabled': True,
        'order': 11
        },
        'saoke': {
        'route': '/resources/lib/mkd/onthethao/saoke:index_saoke',
        'label': 'SAOKE - MANNHAN',
        'thumb': 'https://mi3s.top/thumb/thethao/saoke.png',
        'enabled': True,
        'order': 12
        },
        'socolive': {
        'route': '/resources/lib/mkd/onthethao/socolive:index_socolive',
        'label': 'SOCOLIVE.ORG',
        'thumb': 'https://mi3s.top/thumb/thethao/soco.png',
        'enabled': True,
        'order': 13
        },
        'nba': {
        'route': '/resources/lib/mkd/onthethao/nba:index_nba',
        'label': 'TRUCTIEPNBA',
        'thumb': 'https://mi3s.top/thumb/thethao/nba.png',
        'enabled': True,
        'order': 14
        }
            }