import os, xbmc, xbmcgui

def install_elementum ():
    if not xbmc.getCondVisibility('System.HasAddon({})'.format('plugin.video.elementum')):
        choice = xbmcgui.Dialog().yesno('[B][COLOR red]ΠΡΟΣΟΧΗ![/COLOR][/B]', '[B][COLOR orange]                                          Πρόσθετο Torrent! [CR]                    Το χρησιμοποιείτε με δική σας ευθύνη. [CR]                                   Προτείνεται χρήση VPN![/COLOR][/B]',
                                        yeslabel='[B][COLOR lime]Ok[/COLOR][/B]', nolabel='[B][COLOR orange]Άκυρο[/COLOR][/B]')
        if choice == 1: (xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.elementum/")'),
                         
                         )

    if xbmc.getCondVisibility('System.HasAddon({})'.format('plugin.video.elementum')):
        choice = xbmcgui.Dialog().yesno('[B][COLOR red]ΠΡΟΣΟΧΗ![/COLOR][/B]', '[B][COLOR orange]                                          Πρόσθετο Torrent! [CR]                    Το χρησιμοποιείτε με δική σας ευθύνη. [CR]                                   Προτείνεται χρήση VPN![/COLOR][/B]',
                                        yeslabel='[B][COLOR lime]Ok[/COLOR][/B]', nolabel='[B][COLOR orange]Άκυρο[/COLOR][/B]')
        if choice == 1: (xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.elementum/")'),
                         
                         )


install_elementum ()
