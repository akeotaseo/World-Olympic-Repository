import xbmc, xbmcgui


def WeatherWidget():
    funcs = (click_1, click_2)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]Weather[/COLOR][/B]', 
['ΚΑΙΡΟΣ ALPHA',

 'ΚΑΙΡΟΣ STAR'])


    if call:
        if call < 0:
            return
        func = funcs[call-2]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('ActivateWindow(Videos,"plugin://plugin.video.alphatv.gr/?action=news_episodes&title=%CE%9A%CE%B1%CE%B9%CF%81%CE%BF%CF%82&query=35")')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.star.gr/?action=youtube&image=https%3a%2f%2fi.ytimg.com%2fvi%2fFUsHO8A4A6M%2fhqdefault.jpg&title=%ce%94%ce%b5%ce%bb%cf%84%ce%af%ce%b1%20%ce%ba%ce%b1%ce%b9%cf%81%ce%bf%cf%8d&url=PLCg0cLoEdHTwGvb6UwJRsvtP4Ftm4e0YE")')


WeatherWidget()
