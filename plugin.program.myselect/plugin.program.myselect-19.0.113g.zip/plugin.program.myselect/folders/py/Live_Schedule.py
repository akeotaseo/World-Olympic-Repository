import xbmc, xbmcgui
def Live_Schedule():

    funcs = (click_1, click_2)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]~ Schedule ~[/COLOR][/B]', 
['[COLOR orange][B]Click Here For Todays Schedule[/B]  [COLOR lime](The Loop)[/COLOR]',
 '[B][COLORyellow]TODAYS SPORTING EVENTS[/B]  [COLORgold](Mad Titan Sports)[/COLOR]'])


    if call:
        if call < 0:
            return
        func = funcs[call-2]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmcgui.Dialog().notification("[B][COLOR lime]The Loop[/COLOR][/B]", "[COLOR orange][B]Today's Schedule[/B][/COLOR]", sound=False, icon='special://home/addons/plugin.image.World/resources/media/addonset foto/the-loop.png')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.the-loop/get_list/https://loopaddon.uk/files/k19/xmls/auto_fixtures.json")')

def click_2():
    xbmcgui.Dialog().notification("Mad Titan [COLORyellow]Sports[/COLOR]", "[B][COLORyellow]TODAYS SPORTING EVENTS3[/COLOR][/B]", sound=False, icon='special://home/addons/plugin.image.World/resources/media/addonset foto/madtitansports.png')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.madtitansports/get_list/https://magnetic.website/MAD_TITAN_SPORTS/SPORTS/search_leagues.json")')


Live_Schedule()