import os, xbmc, xbmcvfs, xbmcgui, xbmcaddon, shutil, glob
xbmcgui.Dialog().notification("[B][COLOR orange]They don't always work[/COLOR][/B]", "[COLOR green]Δεν λειτουργούν πάντα...[/COLOR]", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/doestworkalltime.png')
# xbmc.sleep(4000)
def vod():
    funcs = (click_1, click_2)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]~ VOD ~[/COLOR][/B]', 
[
 '[B][COLOR=blue]VOD[/COLOR][/B] xx35.live  (mac_player)',

 '[B][COLOR=orange]VOD[/COLOR][/B] monstertv.site  (my_iptv)'
])


    if call:
        if call < 0:
            return
        func = funcs[call-2]
        return func()
    else:
        func = funcs[call]
        return func()
    return 




def click_1():
    choice = xbmcgui.Dialog().yesno('[COLOR orange]xx35.live[/COLOR]', '1. Πατήστε [B][COLOR=blue]VOD[/COLOR][/B][CR]2. Επιλέξτε [B]MAC[/B][CR]3. Διαλέξτε [B]VOD Ταινίες[/B] ή [B]VOD Σειρές[/B][CR]--- Σε περίπτωση Αποτυχίας Απαραγωγής... δοκιμάζουμε άλλη [B]MAC[/B]',
        
                                        nolabel='[B][COLOR white]Άκυρο[/COLOR][/B]',yeslabel='[B][COLOR=blue]VOD[/COLOR][/B]')

    if choice == 1: xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.downloader/?_id&description&episode_number&fanart&foldername&icon=C%3a%5cPortableApps%5ckodi%5ckodi%20World%2021%5cKodi%5cportable_data%5caddons%5cplugin.program.downloader%5cresources%5cicons%5ciptv.png&mediatype=video&mode=mac_player_sel_mac&name=xx35.live&name2&page&season_number&url=%7b%22portal_server%22%3a%20%22http%3a%2f%2fxx35.live%3a8080%2fc%2f%22%2c%20%22server_macs%22%3a%20%22%5b%5c%2200%3a1A%3a79%3a13%3a51%3aEC%5c%22%2c%20%5c%2200%3a1A%3a79%3a13%3a51%3aED%5c%22%2c%20%5c%2200%3a1A%3a79%3a13%3a51%3aEE%5c%22%2c%20%5c%2200%3a1A%3a79%3a13%3a52%3aB0%5c%22%2c%20%5c%2200%3a1A%3a79%3a13%3a52%3aD5%5c%22%2c%20%5c%2200%3a1A%3a79%3a13%3a52%3aD8%5c%22%2c%20%5c%2200%3a1A%3a79%3a13%3a52%3aDC%5c%22%2c%20%5c%2200%3a1A%3a79%3a13%3a52%3aE0%5c%22%2c%20%5c%2200%3a1A%3a79%3a13%3a52%3aE1%5c%22%2c%20%5c%2200%3a1A%3a79%3a13%3a52%3aE4%5c%22%2c%20%5c%2200%3a1A%3a79%3a13%3a52%3aE6%5c%22%2c%20%5c%2200%3a1A%3a79%3a13%3a52%3aE7%5c%22%2c%20%5c%2200%3a1A%3a79%3a13%3a52%3aE8%5c%22%2c%20%5c%2200%3a1A%3a79%3a13%3a53%3a4D%5c%22%2c%20%5c%2200%3a1A%3a79%3a13%3a53%3a50%5c%22%2c%20%5c%2200%3a1A%3a79%3a13%3a53%3a51%5c%22%2c%20%5c%2200%3a1A%3a79%3a13%3a53%3a52%5c%22%2c%20%5c%2200%3a1A%3a79%3a13%3a53%3a53%5c%22%2c%20%5c%2200%3a1A%3a79%3a13%3a53%3a55%5c%22%2c%20%5c%2200%3a1A%3a79%3a13%3a53%3a56%5c%22%2c%20%5c%2200%3a1A%3a79%3a13%3a53%3a5D%5c%22%2c%20%5c%2200%3a1A%3a79%3a13%3a53%3a5E%5c%22%2c%20%5c%2200%3a1A%3a79%3a13%3a53%3a5F%5c%22%5d%22%7d")')



def click_2():
    choice = xbmcgui.Dialog().yesno('[COLOR orange]monstertv[/COLOR]', '1. Πατήστε [B][COLOR=blue]VOD[/COLOR][/B][CR]2. Επιλέξτε [B] URL[/B][CR]3. Διαλέξτε [B]VOD Ταινίες[/B] ή [B]VOD Σειρές[/B][CR]--- Σε περίπτωση Αποτυχίας Απαραγωγής... δοκιμάζουμε άλλο [B]URL[/B]',
        
                                        nolabel='[B][COLOR white]Άκυρο[/COLOR][/B]',yeslabel='[B][COLOR=blue]VOD[/COLOR][/B]')

    if choice == 1: xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.downloader/?_id&description&episode_number&fanart&foldername&icon=C%3a%5cPortableApps%5ckodi%5ckodi%20World%2021%5cKodi%5cportable_data%5caddons%5cplugin.program.downloader%5cresources%5cicons%5cxcodes.jpg&mediatype=video&mode=get_remote_xcodes&name=Remote%20x-treme%20codes%20%ce%bb%ce%af%cf%83%cf%84%ce%b5%cf%82&name2&page&season_number&url=%7b%22url%22%3a%20%22https%3a%2f%2fraw.githubusercontent.com%2fakeotaseo%2fworld_repo%2frefs%2fheads%2fmain%2fUpdater_Matrix%2fXML2%2fmonstertv.txt%22%7d")')


vod()
