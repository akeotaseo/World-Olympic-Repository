import xbmc, xbmcgui

xbmc.executebuiltin('Dialog.Close(all,true)')

xbmcgui.Dialog().notification("[COLOR white]Νέες Ταινίες / Επεισόδια[/COLOR]", "[COLOR=red]Blacklodge[/COLOR]...", sound=False, icon='special://home/addons/plugin.video.blacklodge/icon.png')
# xbmc.sleep(4000)

# xbmcgui.Dialog().notification("[COLOR white]Πρόσφατες προσθήκες[/COLOR]", "[COLORlime]Tenies-οnline[/COLOR]", sound=False, icon='special://home/addons/plugin.video.microjen/icon.png')
# xbmc.sleep(4000)




def tvone():
    funcs = (click_1, click_2, click_3, click_4)
    call = xbmcgui.Dialog().select('[B][COLOR=lime]Νέες Ταινίες / Επεισόδια[/COLOR][/B]', 
['[B][COLOR=white]Νέες Ταινίες[/B] [COLOR=red](Blacklodge)[/COLOR]',
 '[B][COLOR=white]Νέες Σειρές[/B] [COLOR=red](Blacklodge)[/COLOR]',
 '[COLOR=white]Πρόσφατες προσθήκες [COLORlime]Tenies-οnline [COLOR=orange](MicroJen)[/COLOR]',
 '[COLOR=white]New Movies[COLOR grey] GHOST [COLOR=blue](Shadow)[/COLOR]'])





    if call:
        if call < 0:
            return
        func = funcs[call-4]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmcgui.Dialog().ok('[B][COLOR white]Νέες Ταινίες[/COLOR][/B]', 'Για καλύτερα αποτελέσματα χρειάζεται λογαριασμός[CR][B][COLOR aquamarine]Real-Debrid[/COLOR][/B][CR](ή λογαριασμός απο άλλη υπηρεσία)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.blacklodge/?action=movieWidget")')

def click_2():
    xbmcgui.Dialog().ok('[B][COLOR white]Νέες Σειρές[/COLOR][/B]', 'Για καλύτερα αποτελέσματα χρειάζεται λογαριασμός[CR][B][COLOR aquamarine]Real-Debrid[/COLOR][/B][CR](ή λογαριασμός απο άλλη υπηρεσία)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.blacklodge/?action=tvshows&url=premiere")')

def click_3():
    xbmcgui.Dialog().notification("[COLOR white]Πρόσφατες προσθήκες[/COLOR]", "[COLORlime]Tenies-οnline[/COLOR]", sound=False, icon='special://home/addons/plugin.video.microjen/icon.png')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.myselect/?group=microjen-test-1747067374.1555417&mode=group&refresh&reload")')

def click_4():
    xbmcgui.Dialog().notification("[COLOR white]New Movies[/COLOR]", "[COLOR grey]GHOST[/COLOR]", sound=False, icon='https://thechains24.com/PornKing/ghost.png')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.ghost/?all_w=%7b%7d&data&dates=%20&description=%20&eng_name=%20&episode=%20&fanart=https%3a%2f%2fthechains24.com%2fPornKing%2fBuilds%2ffanart.jpg&fav_status=false&heb_name=%20&iconimage=https%3a%2f%2fthechains24.com%2fPornKing%2fghost.png&id&image_master&isr=0&last_id&mode=189&mypass&name=%5bCOLORwhite%5dNew%20Movies%5b%2fCOLOR%5d&original_title=%5bCOLORwhite%5dNew%20Movies%5b%2fCOLOR%5d&search_db&season=%20&show_original_year=%20&tmdbid=%20&url=http%3a%2f%2fthechains24.com%2fGREENHAT%2fnewm.NEW.xml&video_data=%7b%22title%22%3a%20%22%5bCOLORwhite%5dNew%20Movies%5b%2fCOLOR%5d%22%2c%20%22mediatype%22%3a%20%22movie%22%2c%20%22TVshowtitle%22%3a%20%22%22%2c%20%22season%22%3a%200%2c%20%22episode%22%3a%200%2c%20%22OriginalTitle%22%3a%20%22%5bCOLORwhite%5dNew%20Movies%5b%2fCOLOR%5d%22%2c%20%22year%22%3a%20%22%22%2c%20%22rating%22%3a%20%220%22%2c%20%22plot%22%3a%20%22%20%22%2c%20%22Tag%22%3a%20%22189%22%2c%20%22trailer%22%3a%20%22%22%2c%20%22id%22%3a%20%22%22%7d")')

tvone()
