import xbmc, xbmcgui

def dl():
    funcs = (click_1, click_2, click_3)
    call = xbmcgui.Dialog().select('[COLOR=red]~ Daddylive ~[/COLOR]', 
[
 '[COLORred][B]Daddylive[/COLOR][/B] (GKoBu)',
# '[B][COLOR=darkviolet]Daddylive[/COLOR][/B]  (THE CREW)',
 '[COLOR=yellow]DaddyLive[/COLOR]  (Arkane14)',
 '[B][COLOR=orange]Daddylive[/COLOR][/B]  (Browser)'

 # '[COLOR=yellow]DaddyLive V2[/COLOR]  (X)'
 # '[COLOR=slateblue]DaddyLiveHD[/COLOR]  (FubuZ)'
 ])


    if call:
        if call < 0:
            return
        func = funcs[call-3]
        return func()
    else:
        func = funcs[call]
        return func()
    return 





def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.microjen/daddylive")')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.daddylive/")')
    

def click_3():
    xbmc.executebuiltin('RunScript("special://home/addons/skin.19MatrixWorld/xml/DialogContextPair/Daddylive.py")')

# def click_2():
    # xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.daddylive/",return)')

# def click_3():
    # xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.dlv2/",return)')

# def click_4():
    # xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.daddylivehd/,return")')

dl()

