import xbmc, xbmcgui


def Search_music():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7, click_8, click_9)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]Αναζήτηση ... [/COLOR][/B]',
['[B][COLOR=lime]Mp3Streams [COLOR=white]Artists[/COLOR][/B]',
 '[B][COLOR=lime]Mp3Streams [COLOR=white]Albums[/COLOR][/B]',
 '[B][COLOR=lime]Mp3Streams [COLOR=white]Songs[/COLOR][/B]',
 '[B][COLOR=orange]Soundcloud[/COLOR][/B]',
 '[B][COLOR=white]You[B][COLOR=red]Toube[/COLOR][/B]',
 '[B][COLOR=red]Duff You[/COLOR][/B]',
 '[B][COLOR=cyan]E-Radio[/COLOR][/B]',
 '[B][COLOR=blue]Alive[COLOR=white]GR[/COLOR][/B]',
 '[B][COLOR red]<---                                                                      [COLOR grey]Back[/COLOR][/B]'])

    if call:
        if call < 0:
            return
        func = funcs[call-9]
        return func()
    else:
        func = funcs[call]
        return func()
    return 


def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.audio.mp3streams/?mode=24&name=Search%20Artists&type&url=url)')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.audio.mp3streams/?mode=24&name=Search%20Albums&type&url=url)')

def click_3():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.audio.mp3streams/?mode=24&name=Search%20Songs&type&url=url)')

def click_4():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.audio.soundcloud/search/?action=new)')

def click_5():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.youtube/kodion/search/input)')

def click_6():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.duffyou/?eydhY3Rpb24nOiAnb2lPTzAwT28nLCAnZmFuYXJ0JzogJ0M6XFxVc2Vyc1xcaHBsYXBcXEFwcERhdGFcXFJvYW1pbmdcXEtvZGlcXGFkZG9uc1xccGx1Z2luLnZpZGVvLmR1ZmZ5b3VcXGZhbmFydC5qcGcnLCAnaWNvbic6ICdDOlxcVXNlcnNcXGhwbGFwXFxBcHBEYXRhXFxSb2FtaW5nXFxLb2RpXFxhZGRvbnNcXHBsdWdpbi52aWRlby5kdWZmeW91XFxyZXNvdXJjZXNcXG1lZGlhXFxuZXdfc2VhcmNoLnBuZycsICdsYWJlbCc6ICdbQl1OZXcgU2VhcmNoWy9CXScsICdwYWdlJzogMSwgJ3Bsb3QnOiAnW0JdU2VhcmNoWy9CXVtDUl1bQ1JdU2VhcmNoIGZvciBhIHZpZGVvLCBhIGxpdmUsIGEgcGxheWxpc3Qgb3IgYSBjaGFubmVsLicsICdxdWVyeSc6IFRydWUsICd0aXBvJzogJ3ZpZGVvJ30%3d&amp;sf_options=fanart%3Dspecial%3A%2F%2Fhome%2Faddons%5Cplugin.video.duffyou%5Cfanart.jpg%26desc%3D%5BB%5DSearch%5B%2FB%5D%5BCR%5D%5BCR%5DSearch+for+a+video%2C+a+live%2C+a+playlist+or+a+channel.%26meta%3Dvotes%253D0%2526plot%253D%25255BB%25255DSearch%25255B%25252FB%25255D%25255BCR%25255D%25255BCR%25255DSearch%252Bfor%252Ba%252Bvideo%25252C%252Ba%252Blive%25252C%252Ba%252Bplaylist%252Bor%252Ba%252Bchannel.%2526title%253D%25255BB%25255DNew%252BSearch%25255B%25252FB%25255D%2526label%253D%25255BB%25255DNew%252BSearch%25255B%25252FB%25255D%26)')

def click_7():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.audio.eradio.gr/?action=search)')

def click_8():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.AliveGR/?action=search_index)')

def click_9():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.myselect/folders/py/SearchTk/SearchAll.py")')

Search_music()