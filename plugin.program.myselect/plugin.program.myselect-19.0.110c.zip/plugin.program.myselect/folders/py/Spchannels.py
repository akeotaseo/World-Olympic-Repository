import xbmc, xbmcgui


def spchannels():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7, click_8, click_9, click_10, click_11, click_12, click_13, click_14)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]  ~ Sports Channels ~[/COLOR][/B]', 
['[COLOR=white]TvOne[/COLOR]',
 '[COLOR=white]TvOne11[/COLOR]',
 '[COLOR=white]TvOne111[/COLOR]',
 '[COLOR=white]TvOne1112[/COLOR]',
 '[COLOR=white]TvOne112[/COLOR]',

 '[COLOR=white]CANAIS DE ESPORTES [/COLOR]([COLOR=yellow]BRAZIL[/COLOR])',
 '[COLOR=white][COLOR=white]DESPORTO/SPORTS [/COLOR][COLOR=green](Magellan)[/COLOR]',
 '[COLOR=white]**Sports** [/COLOR][COLOR=orange](LiveStreamsPro)[/COLOR]',

 '[COLOR=white]Ζωντανά Κανάλια [COLOR=red]daddylive[/COLOR]  ([COLOR orange]microjen[/COLOR])',

 '[B][COLOR white]Ζωντανά Κανάλια[/COLOR][/B]  [B][COLORorange]Sport[COLORwhite]HD+[/COLOR][/B]  ([COLOR orange]microjen[/COLOR])',

 '[B][COLOR white]tv adictos[/COLOR][/B]  (koditv)',

 '[COLOR=white]Streamonsport[/COLOR] France [COLOR=purple](vstream)[/COLOR]',

 '[COLOR=white]Sports[/COLOR] [COLOR=yellow](vnmedia)[/COLOR]',

 '[COLORwhite]SPORTS NETWORKS[/COLOR] - FIXED [COLOR red]madtitansports[/COLOR]',])



    if call:
        if call < 0:
            return
        func = funcs[call-14]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.tvone/list_channels/5")')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.tvone11/list_channels/8")')

def click_3():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.tvone111/list_channels/1")')

def click_4():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.tvone1111/list_channels/1")')
    
def click_5():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.tvone112/list_channels/38")')


def click_6():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.pluginstreaming/?fanart=https%3a%2f%2fia800509.us.archive.org%2f10%2fitems%2ffanart_20240729%2ffanart.jpeg&mode=1&name=%5bB%5d%5bCOLOR%20blue%5d%5b%2fCOLOR%5d%20%5bCOLOR%20yellow%5d%20CANAIS%20DE%20ESPORTES%20%5b%2fCOLOR%5d%5b%2fB%5d&url=https%3a%2f%2fraw.githubusercontent.com%2ftwoaddons%2fREPO-TWO-ADDON%2fmain%2fbraz-tv%2520esportes.XML")')



def click_7():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.Magellan_Matrix/?fanart=https%3a%2f%2fwallpapercave.com%2fwp%2fwp7245862.jpg&mode=1&name=%5bCOLOR%20lime%5d%20%3e%20%5bCOLOR%20yellow%5dDESPORTO%2fSPORTS%20%5b%2fCOLOR%5d&url=https%3a%2f%2fpastebin.com%2fraw%2fz9jHvduv")')

def click_8():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.live.streamspro/?fanart&mode=1&name=%2a%2aSports%2a%2a&url=https%3a%2f%2fiptv-org.github.io%2fiptv%2fcategories%2fsports.m3u",return)')

def click_9():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.microjen/daddylive?mode=menu&serv_type=live_tv")')

def click_10():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.microjen/sporthd?description=Live%20TV%20Channels&iconimage=https%3a%2f%2fraw.githubusercontent.com%2fbugatsinho%2fbugatsinho.github.io%2fmaster%2fplugin.video.sporthdme%2ficon.png&mode=get_livetv&name=%5bB%5d%5bCOLOR%20white%5d%ce%96%cf%89%ce%bd%cf%84%ce%b1%ce%bd%ce%ac%20%ce%9a%ce%b1%ce%bd%ce%ac%ce%bb%ce%b9%ce%b1%5b%2fCOLOR%5d%5b%2fB%5d&url=https%3a%2f%2fsporthd.live%2flivetv")')

def click_11():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.koditv/?extra=%5bB%5d%5bLOWERCASE%5d%5bCAPITALIZE%5d%5bCOLOR%20white%5dTV%20DEPORTES%5b%2fCAPITALIZE%5d%5b%2fLOWERCASE%5d%5b%2fCOLOR%5d%5b%2fB%5d&mode=tv_adictos2&thumbnail=https%3a%2f%2ffx-24.xyz%2fmychannel%2fpublic%2fsub_cat2_images%2f2083924114.png&url=54")')

def click_12():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.vstream/?function=showMovies&sFav=showMovies&site=streamonsport&siteUrl=31-foot-rugby-tennis-basket-f1-moto-hand-en-streaming-direct.html&title=Streamonsport")')

def click_13():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.vnmedia/resources/lib/mkd/ontruyenhinh/listiptv/info_iptv/?_pickle_=80049574000000000000007d94288c075f7469746c655f948c0653706f727473948c065f617267735f948c4c68747470733a2f2f7261772e67697468756275736572636f6e74656e742e636f6d2f6b676173617a2f346b7568642f6d61737465722f73706f7274732d6368616e6e656c732d346b2e6d33759468028694752e")')

def click_14():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.madtitansports/search_json/https://magnetic.website/jet/TVGUIDE/TVGUIDE_Sports Networks.json?dialog=false&query=sports%20networks")')


spchannels()
