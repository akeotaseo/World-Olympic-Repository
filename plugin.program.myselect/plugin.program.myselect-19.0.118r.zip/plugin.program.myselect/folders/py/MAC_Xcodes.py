import os, xbmc, xbmcvfs, xbmcgui, xbmcaddon, shutil, glob
xbmcgui.Dialog().notification("[B][COLOR orange]They don't always work[/COLOR][/B]", "[COLOR green]Δεν λειτουργούν πάντα...[/COLOR]", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/doestworkalltime.png')
# xbmc.sleep(4000)
def vod():
    funcs = (click_1, click_2)
    call = xbmcgui.Dialog().select('[B][COLOR=silver]GKoBu Tools[/COLOR][/B]', 
[
 '[B][COLOR=blue]Mac Player[/COLOR][/B]  (GKoBu Tools)',

 '[B][COLOR=orange]X-treme codes player[/COLOR][/B]  (GKoBu Tools)'
])


    if call:
        if call < 0:
            return
        func = funcs[call-2]
        return func()
    else:
        func = funcs[call]
        return func()
    return 




def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.downloader/?_id&description=Mac%20Player&episode_number&fanart&foldername&icon=C%3a%5cPortableApps%5ckodi%5ckodi%20World%2021%5cKodi%5cportable_data%5caddons%5cplugin.program.downloader%5cresources%5cicons%5ciptv.png&mediatype=video&mode=mac_player_main&name=%5bB%5dMac%20Player%5b%2fB%5d&name2&page&season_number&url")')



def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.downloader/?_id&description=X-treme%20codes%20player&episode_number&fanart&foldername&icon=C%3a%5cPortableApps%5ckodi%5ckodi%20World%2021%5cKodi%5cportable_data%5caddons%5cplugin.program.downloader%5cresources%5cicons%5cxcodes.jpg&mediatype=video&mode=xcodes_menu&name=%5bB%5dX-treme%20codes%20player%5b%2fB%5d&name2&page&season_number&url")')


vod()
