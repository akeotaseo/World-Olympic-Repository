import xbmc, xbmcgui


def live_now():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7, click_8, click_9, click_10, click_11, click_12, click_13, click_14, click_15)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]       Live Now...[/COLOR][/B]',
['[COLOR=orange]LIVE EVENTS[/COLOR] (SportHD)',

 '[COLOR=white]Ζωντανοί αγώνες - Πρόγραμμα Ημέρας[/COLOR] [COLORred][B]Daddylive[/COLOR][/B]-mj',
 '[COLOR=white]USA SPORTS [COLOR=lime](The Endzone 19)[/COLOR] (microjen)',
 '[B][COLOR=red]Rising Tides[/COLOR][/B]',
 #'[COLOR=white]Mr. Dupont [/COLOR] [COLOR=green](Thegroove360)[/COLOR]',
 #'[COLOR=grey]WEB STREAM SPORT AGENDA [/COLOR][COLOR=green](Thegroove360)[/COLOR]',
 '[COLOR=white][COLOR gold]TheANONYMOUS[/COLOR][COLOR cyan] EVENTOS DESPORTIVOS  [/COLOR]',
 '[COLOR=white]JOGOS [COLOR lime] [COLOR=yellow](Aguia_De_Ouro)[/COLOR]',
 '[COLOR=white]Live TV[/COLOR] [COLOR=purple](vstream)[/COLOR]',
 '[COLOR=white]Live TV[/COLOR] [COLOR green](Dracarys)[/COLOR]',
 '[COLOR=white]Rojadirecta[/COLOR] [COLOR green](Dracarys)[/COLOR]',
 '[COLOR=tomato]VIPStand[/COLOR]',
 '[COLOR=darkorange]SportStream365[/COLOR]',
 '[COLOR goldenrod]Live Football[/COLOR] (Asgard/shadow)',
 '[COLOR white]agendas live [/COLOR] (koditv)',
 '[COLOR=white]Daddylive [COLOR=olive](All)[/COLOR]',
 #'[COLOR=white]Ver Agenda [/COLOR] [COLOR=red](Winner 2)[/COLOR] ACE...',
 '[COLOR yellow]NemesisAIO Live Sports & Replays[/COLOR]'
 ])

 #'[COLOR=white]Scraper Section[/COLOR] [COLOR yellow](Τorque Lite)[/COLOR] microjen[B][COLOR=red]   OFF?...[/COLOR][/B]',


    if call:
        if call < 1:
            return
        func = funcs[call-15]
        return func()
    else:
        func = funcs[call]
        return func()
    return 






def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.sporthdme/?description&iconimage=C%3a%5cPortableApps%5ckodi%5ckodi%20World%2020%5cKodi%5cportable_data%5caddons%5cplugin.video.sporthdme%5cicon.png&mode=5&name=%5bB%5d%5bCOLOR%20white%5dLIVE%20EVENTS%5b%2fCOLOR%5d%5b%2fB%5d&url=https%3a%2f%2f1.ivesoccer.sx%2f")')
    #xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.myselect/folders/py/sporthdme.py")')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.microjen/daddylive?mode=menu&serv_type=sched")')

def click_3():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.microjen/get_list/https://l3grthu.com/ez/endzone.xml")')

def click_4():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.Rising.Tides)')

#def click_6():
#    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.thegroove360/thegroove/scripters/Mr_Dupont/path%3DSport_sport.xml")')

#def click_7():
    #xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.thegroove360/thegroove/scripters/Soter/path%3Dsport_rojadirecta_rojadirecta.php")')

def click_5():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.desporto.theanonymous/?fanart=http%3a%2f%2fmilhano.pt%2fftp-milhano%2faladotv%2fTheAnonymous.Desporto%2fdesp_fanart.jpg&mode=1&name=%5bCOLOR%20yellow%5d%5bB%5dEVENTOS%20DESPORTIVOS%5b%2fB%5d%5b%2fCOLOR%5d&url=http%3a%2f%2fmilhano.pt%2fftp-milhano%2faladotv%2fTheAnonymous.Desporto%2fsportsonline2%2f")')

def click_6():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.aguia_de_ouro/jogos/name%3D%255BB%255DJOGOS%255B%252FB%255D%26iconimage%3DC%253A%255CPortableApps%255Ckodi%255CMy%2BKODI%2B21%255CKodi%255Cportable_data%255Caddons%255Cplugin.video.aguia_de_ouro%255Cicon.png%26description%3DASSISTA%2BOS%2BMELHORES%2BJOGOS")')

def click_7():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.vstream/?function=load&sFav=load&site=livetv&siteUrl=True&title=Live%20TV")')

def click_8():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.dracarys/?category=live_sport&mode=open_site&site=livetv")')

def click_9():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.dracarys/?category=live_sport&mode=open_site&site=rojadirecta")')
    
def click_10():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.sportsdevil/?item=title%3dVIPStand%2b%26director%3dvipstand.pm%26icon%3dC%253A%255CPortableApps%255Ckodi%255CMy%2bKODI%2b21%255CKodi%255Cportable_data%255Caddons%255Cplugin.video.sd%255Cresources%255Cimages%255Cvipstand.png%26url%3dlivesports%252Fvipstand.cfg%26type%3drss%26genre%3dLive%2bSports%26definedIn%3dlivesports.cfg&mode=1")')

def click_11():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.sportsdevil/?item=title%3dSportStream365%26director%3dlivestream365%26icon%3dhttp%253A%252F%252Fcdns.livestreamapi.ru%252Fimg%252Flogo_ls365.png%26url%3dlivesports%252Fsportstream365_wss.cfg%26type%3drss%26genre%3dLive%2bSports%26definedIn%3dlivesports.cfg&mode=1")')

def click_12():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.shadow/?all_w=%7b%7d&data&dates=%20&description=Live%20Football&eng_name=%20&episode=%20&fanart=https%3a%2f%2fmylostsoulspace.co.uk%2fimages%2fSports-Icoms%2ffanart.jpg&fav_status=false&heb_name=%20&iconimage=https%3a%2f%2fmylostsoulspace.co.uk%2fimages%2fSports-Icoms%2flivefootball.png&id&image_master&isr=0&last_id&mode=189&mypass&name=%5bCOLOR%20goldenrod%5dLive%20Football%5b%2fCOLOR%5d&original_title=%5bCOLOR%20goldenrod%5dLive%20Football%5b%2fCOLOR%5d&search_db&season=%20&show_original_year=%20&tmdbid=%20&url=https%3a%2f%2fmylostsoulspace.co.uk%2fAddon-1%2fAddon%2ftext%2fAll-Sports-xmls%2flivefootball.xml&video_data=%7b%22title%22%3a%20%22%5bCOLOR%20goldenrod%5dLive%20Football%5b%2fCOLOR%5d%22%2c%20%22mediatype%22%3a%20%22movie%22%2c%20%22TVshowtitle%22%3a%20%22%22%2c%20%22season%22%3a%200%2c%20%22episode%22%3a%200%2c%20%22OriginalTitle%22%3a%20%22%5bCOLOR%20goldenrod%5dLive%20Football%5b%2fCOLOR%5d%22%2c%20%22year%22%3a%20%22%22%2c%20%22rating%22%3a%20%220%22%2c%20%22plot%22%3a%20%22Live%20Football%22%2c%20%22Tag%22%3a%20%22189%22%2c%20%22trailer%22%3a%20%22%22%2c%20%22id%22%3a%20%22%22%7d")')

def click_13():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.tvchopo/?action=agendas&extra&page&plot&thumbnail=https%3a%2f%2fwww.montero-aramburu.com%2fwp-content%2fuploads%2f2017%2f07%2fdeportes_varios.jpg&title=%5bB%5d%5bLOWERCASE%5d%5bCAPITALIZE%5d%5bCOLOR%20white%5dagendas%20live%5b%2fCOLOR%5d%5b%2fCAPITALIZE%5d%5b%2fLOWERCASE%5d%5b%2fB%5d&url")')

def click_14():
    xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.myselect/folders/py/Daddylive.py)')

#def click_10():
    #xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.winner/?xVak92ScxFMyASSE90SgkXTcxVak92acx1cwBXQlxmYhRncvBFXcpzQnAiOiQnch5WYmJCIscybP90bw8EMwk2bnAiOi42bpR3YhJye03Jml2ZuUmdpxGXcFWakVWbcx1clNmc192clJHXcJXZu5Wa35yblRWa25ibpdWdsBHXcNnbvRGZhxFXhRXYk9VZsJWY0J3bwxFXpR2bLxFXwIDIJR0TLBSeNxFXpR2brxFXzBHcBVGbiFGdy9GUcxlODdCI6IiclR3cvBnIgwyJdJ0LbFGZuV2ZBBiclZVXCt1JgojIsVmYhxmIgwyJnBnauQnch5WYmxFXhlGZl1GXcNXZjJXdvNXZyxFXyVmbul2du8WZklmdu4WanVHbwxFXz52bkRWYcxVY0FGZfVGbiFGdy9Gcc")')

def click_15():
    xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.downloader/resources/okpn.py, ActivateWindow(10025,"plugin://plugin.video.nemesisaio/?description=Sports%20Time%2c%20Come%20On%20You%20Reds%20%23YNWA&fanart=0&iconimage=special://home/addons%5cplugin.video.nemesisaio%5cresources%5cImages%5cSports.gif&mode=1&name=%5bCOLOR%20yellow%5d%5bB%5dLive%20Sports%20%26%20Replays%5b%2fB%5d%5b%2fCOLOR%5d&url=SPORTS"))')

#def click_2():
#    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.myselect/folders/py/torquelite.py")')

live_now()
