import xbmc, xbmcgui
def Live_Schedule():

    funcs = (click_1, click_2, click_3)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]~ Schedule ~[/COLOR][/B]', 
['[B][COLOR white]Πλήρες Πρόγραμμα Αγώνων[/B]  [COLOR orange](Sporthd+ microjen)[/COLOR]',
 '[COLOR orange][B]Click Here For Todays Schedule[/B]  [COLOR lime](The Loop)[/COLOR]',
 '[B][COLORyellow]TODAYS SPORTING EVENTS[/B]  [COLORgold](Mad Titan Sports)[/COLOR]'])


    if call:
        if call < 0:
            return
        func = funcs[call-3]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmcgui.Dialog().notification("[B][COLOR orange]Sporthd+ microjen[/COLOR][/B]", "[B][COLOR white]Πλήρες Πρόγραμμα Αγώνων[/COLOR][/B]", sound=False, icon='https://raw.githubusercontent.com/bugatsinho/bugatsinho.github.io/master/plugin.video.sporthdme/icon.png')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.microjen/sporthd?description=Daily%20events%20list&iconimage=https%3a%2f%2fraw.githubusercontent.com%2fbugatsinho%2fbugatsinho.github.io%2fmaster%2fplugin.video.sporthdme%2ficon.png&mode=events&name=%5bB%5d%5bCOLOR%20white%5d%ce%a0%ce%bb%ce%ae%cf%81%ce%b5%cf%82%20%ce%a0%cf%81%cf%8c%ce%b3%cf%81%ce%b1%ce%bc%ce%bc%ce%b1%20%ce%91%ce%b3%cf%8e%ce%bd%cf%89%ce%bd%5b%2fCOLOR%5d%5b%2fB%5d&url=https%3a%2f%2fsuper.league.do%2f",return)')


def click_2():
    xbmcgui.Dialog().notification("[B][COLOR lime]The Loop[/COLOR][/B]", "[COLOR orange][B]Today's Schedule[/B][/COLOR]", sound=False, icon='special://home/addons/plugin.image.World/resources/media/addonset foto/the-loop.png')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.the-loop/get_list/https://loopaddon.uk/files/k19/xmls/auto_fixtures.json")')

def click_3():
    xbmcgui.Dialog().notification("Mad Titan [COLORyellow]Sports[/COLOR]", "[B][COLORyellow]TODAYS SPORTING EVENTS3[/COLOR][/B]", sound=False, icon='special://home/addons/plugin.image.World/resources/media/addonset foto/madtitansports.png')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.madtitansports/get_list/https://magnetic.website/MAD_TITAN_SPORTS/SPORTS/search_leagues.json")')


Live_Schedule()