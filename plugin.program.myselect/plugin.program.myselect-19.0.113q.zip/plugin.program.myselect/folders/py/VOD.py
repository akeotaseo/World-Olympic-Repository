import os, xbmc, xbmcvfs, xbmcgui, xbmcaddon, shutil, glob
xbmcgui.Dialog().notification("[B][COLOR orange]They don't always work[/COLOR][/B]", "[COLOR green]Δεν λειτουργούν πάντα...[/COLOR]", sound=False, icon='special://home/addons/plugin.video.macvod/DialogPleaseWait/doestworkalltime.png')
# xbmc.sleep(4000)
def vod():
    funcs = (click_1, click_2)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]~ VOD ~[/COLOR][/B]', 
[
# '[B][COLOR=blue]VOD[/COLOR][/B] cmjl.online  (mac_player)',
 '[B][COLOR=blue]VOD[/COLOR][/B] line.iptveros  (mac_player)',
 '[B][COLOR=orange]VOD[/COLOR][/B] monstertv.site  (my_iptv)'
])


    if call:
        if call < 0:
            return
        func = funcs[call-2]
        return func()
    else:
        func = funcs[call]
        return func()
    return 




# def click_1():
    # choice = xbmcgui.Dialog().yesno('[COLOR orange]cmjl.online[/COLOR]', '1. Πατήστε [B][COLOR=blue]VOD[/COLOR][/B][CR]2. Επιλέξτε [B]MAC[/B][CR]3. Διαλέξτε [B]VOD Ταινίες[/B] ή [B]VOD Σειρές[/B][CR]--- Σε περίπτωση Αποτυχίας Απαραγωγής... δοκιμάζουμε άλλη [B]MAC[/B]',
        
                                        # nolabel='[B][COLOR white]Άκυρο[/COLOR][/B]',yeslabel='[B][COLOR=blue]VOD[/COLOR][/B]')

    # if choice == 1: xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.downloader/?_id&description&episode_number&fanart&foldername&icon=C%3a%5cPortableApps%5ckodi%5ckodi%20World%2021%5cKodi%5cportable_data%5caddons%5cplugin.program.downloader%5cresources%5cicons%5ciptv.png&mediatype=video&mode=mac_player_sel_mac&name=cmjl.online&name2&page&season_number&url=%7b%22portal_server%22%3a%20%22http%3a%2f%2fcmjl.online%3a8080%2fc%2f%22%2c%20%22server_macs%22%3a%20%22%5b%5c%2200%3a1A%3a79%3a60%3a00%3a2A%5c%22%2c%20%5c%2200%3a1A%3a79%3a60%3a00%3aF6%5c%22%2c%20%5c%2200%3a1A%3a79%3a60%3a0E%3a5A%5c%22%2c%20%5c%2200%3a1A%3a79%3a60%3a1E%3a8A%5c%22%2c%20%5c%2200%3a1A%3a79%3a60%3a28%3a64%5c%22%2c%20%5c%2200%3a1A%3a79%3a60%3a2F%3aCF%5c%22%2c%20%5c%2200%3a1A%3a79%3a60%3a35%3a21%5c%22%2c%20%5c%2200%3a1A%3a79%3a60%3a3C%3a00%5c%22%2c%20%5c%2200%3a1A%3a79%3a60%3a59%3aB7%5c%22%5d%22%7d")')


def click_1():
    choice = xbmcgui.Dialog().yesno('[COLOR orange]line.iptveros.com[/COLOR]', '1. Πατήστε [B][COLOR=blue]VOD[/COLOR][/B][CR]2. Επιλέξτε [B]MAC[/B][CR]3. Διαλέξτε [B]VOD Ταινίες[/B] ή [B]VOD Σειρές[/B][CR]--- Σε περίπτωση Αποτυχίας Απαραγωγής... δοκιμάζουμε άλλη [B]MAC[/B]',
        
                                        nolabel='[B][COLOR white]Άκυρο[/COLOR][/B]',yeslabel='[B][COLOR=blue]VOD[/COLOR][/B]')

    if choice == 1: xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.downloader/?_id&description&episode_number&fanart&foldername&icon=C%3a%5cPortableApps%5ckodi%5ckodi%20World%2021%5cKodi%5cportable_data%5caddons%5cplugin.program.downloader%5cresources%5cicons%5ciptv.png&mediatype=video&mode=mac_player_sel_mac&name=line.iptveros.com&name2&page&season_number&url=%7b%22portal_server%22%3a%20%22http%3a%2f%2fline.iptveros.com%2fc%2f%22%2c%20%22server_macs%22%3a%20%22%5b%5c%2200%3a1A%3a79%3a32%3aBD%3a7D%5c%22%2c%20%5c%2200%3a1A%3a79%3aB4%3aDC%3aF1%5c%22%2c%20%5c%2200%3a1A%3a79%3a52%3a5D%3aB4%5c%22%2c%20%5c%2200%3a1A%3a79%3a24%3a98%3aC2%5c%22%2c%20%5c%2200%3a1A%3a79%3a44%3a8B%3a33%5c%22%2c%20%5c%2200%3a1A%3a79%3aC3%3a1E%3aDD%5c%22%2c%20%5c%2200%3a1A%3a79%3a19%3a30%3a72%5c%22%2c%20%5c%2200%3a1A%3a79%3aE9%3aA5%3a1B%5c%22%2c%20%5c%2200%3a1A%3a79%3a1B%3a69%3a92%5c%22%2c%20%5c%2200%3a1A%3a79%3aC5%3a91%3aC9%5c%22%2c%20%5c%2200%3a1A%3a79%3aA3%3aA5%3a46%5c%22%5d%22%7d")')


def click_2():
    choice = xbmcgui.Dialog().yesno('[COLOR orange]monstertv[/COLOR]', '1. Πατήστε [B][COLOR=blue]VOD[/COLOR][/B][CR]2. Επιλέξτε [B] URL[/B][CR]3. Διαλέξτε [B]VOD Ταινίες[/B] ή [B]VOD Σειρές[/B][CR]--- Σε περίπτωση Αποτυχίας Απαραγωγής... δοκιμάζουμε άλλο [B]URL[/B]',
        
                                        nolabel='[B][COLOR white]Άκυρο[/COLOR][/B]',yeslabel='[B][COLOR=blue]VOD[/COLOR][/B]')

    if choice == 1: xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.downloader/?_id&description&episode_number&fanart&foldername&icon=C%3a%5cPortableApps%5ckodi%5ckodi%20World%2021%5cKodi%5cportable_data%5caddons%5cplugin.program.downloader%5cresources%5cicons%5cxcodes.jpg&mediatype=video&mode=get_remote_xcodes&name=Remote%20x-treme%20codes%20%ce%bb%ce%af%cf%83%cf%84%ce%b5%cf%82&name2&page&season_number&url=%7b%22url%22%3a%20%22https%3a%2f%2fraw.githubusercontent.com%2fakeotaseo%2fworld_repo%2frefs%2fheads%2fmain%2fUpdater_Matrix%2fXML2%2fmonstertv.txt%22%7d",return)')


vod()
