import xbmc, xbmcgui


def SearchTube():
    funcs = (click_1, click_2, click_3, click_4)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]Αναζήτηση ...[/COLOR][/B]',
['[B][COLOR=white]You[B][COLOR=red] Toube[/COLOR][/B]',
 '[B][COLOR=blue]Dailymotion[/COLOR][/B]',
 '[B][COLOR=green]Rumble[/COLOR][/B]',
 '[B][COLOR red]<---                                                                      [COLOR grey]Back[/COLOR][/B]'])



    if call:
        if call < 1:
            return
        func = funcs[call-4]
        return func()
    else:
        func = funcs[call]
        return func()
    return 





def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.youtube/kodion/search/input)')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.dailymotion_com/?mode=search&url=https%3a%2f%2fapi.dailymotion.com%2fvideos%3ffields%3ddescription%2cduration%2cid%2cowner.username%2ctaken_time%2cthumbnail_large_url%2ctitle%2cviews_total%26search%3d%26sort%3drelevance%26limit%3d50%26family_filter%3d1%26localization%3den_GB%26page%3d1",return)')

def click_3():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.rumble/?cat&description&fanart&iconimage=special%3a%2f%2fhome%2faddons%2fplugin.video.rumble%2fresources%2fmedia%2fsearch.png&mode=1&name=%ce%91%ce%bd%ce%b1%ce%b6%ce%ae%cf%84%ce%b7%cf%83%ce%b7&url",return)')

def click_4():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.myselect/folders/py/SearchTk/SearchAll.py")')

SearchTube()
