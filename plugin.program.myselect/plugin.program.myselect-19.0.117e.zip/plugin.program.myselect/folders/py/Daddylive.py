import xbmc, xbmcgui

def daddylive():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7, click_8, click_9, click_10)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]~ Daddylive ~[/COLOR][/B]', 
['[B][COLOR=white]Daddylive[/COLOR][/B]',

 '[COLORred][B]Daddylive[/COLOR][/B] (microjen)',

 '[COLORwhite]DaddyLive[/COLOR] [COLOR yellow](mayhem)[/COLOR]',


 '[COLOR white]Αγώνες [COLOR lime]Ζωντανά...[/COLOR] (Atlas)',
 
 '[COLOR=white]Daddylive[/COLOR] (the-loop)',
 '[COLOR=white]Daddylive[/COLOR] (Μadtitansports)',


 'DaddyLive V2',
 'DaddyLiveHD',


 '[COLOR=white]DADDYLIVE [COLOR=silver]Black Ghost [COLOR=orange](microjen)[/COLOR]',


 '[B][COLOR red]<---                                                                      [COLOR grey]Back[/COLOR][/B]'])


    if call:
        if call < 0:
            return
        func = funcs[call-10]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.daddylive/?mode=menu&serv_type=sched")')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.microjen/daddylive?mode=menu&serv_type=sched")')

def click_3():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.mayhem/get_list/https://mfirepo.github.io/db/daddylive.json")')

def click_4():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.atlas/?mode=menu&serv_type=sched")')

def click_5():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.the-loop/sportjetextractors/games/Daddylive")')

def click_6():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.madtitansports/sportjetextractors/games/Daddylive")')

def click_7():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.dlv2/")')

def click_8():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.daddylivehd/")')

def click_9():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.live.streamspro/?fanart=http%3a%2f%2fbgaddon.online%2fblack%2fimg%2ffanart.jpg&mode=1&name=%20%20%5bCOLOR%20lightcyan%5dAGENDA%20%5b%2fCOLOR%5d%5bCOLOR%20lightblue%5dDADDYLIVE%5b%2fCOLOR%5d%20%20%5bCOLOR%20lightslategray%5d%20%20%5b%2fCOLOR%5d%20%20&url=http%3a%2f%2fbgaddon.online%2fdaddy.php%3fdaddy")')

def click_10():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.myselect/folders/py/Live_Now.py")')

daddylive()

