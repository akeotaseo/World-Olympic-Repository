import xbmc, xbmcgui



def live_now():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7, click_8, click_9, click_10)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]       Live Now...[/COLOR][/B]',
['[COLOR=orange]LIVE EVENTS[/COLOR] (SportHD)',

 '[COLOR=firebrick]DADDYLIVE[/COLOR]',


 '[COLOR=white]Live TV[/COLOR] [COLOR=red]sx[/COLOR]',


 '[COLOR=white]Rojadirecta[/COLOR] [COLOR green](Dracarys)[/COLOR]',

 '[B][Live][/B]  (tvone1112)',


 '[COLORcornflowerblue]Live[/COLOR] Streamed/sportscentral [COLOR orange](microjen)[/COLOR]',
 '[COLORsteelblue]TopEmbed Live TV & Sports[/COLOR][COLOR orange] (microjen)[/COLOR]',
 '[COLOR lightcyan]AGENDA [/COLOR][COLOR lightblue]ARENASPORT[/COLOR]  [COLOR lightslategray] [/COLOR] -blackghost- [COLOR orange] (livestreamspro / microjen)[/COLOR]',


  '[COLORaqua]Agenda Deportiva[/COLOR] (Latin Sports)',





 # '[COLOR=white]USA SPORTS [COLOR=lime](The Endzone 19) [COLOR=orange](microjen)[/COLOR]  [COLOR red]OFF?...[/COLOR]',

 # '[COLOR yellow]NemesisAIO Live Sports & Replays[/COLOR]',
 
 '[COLOR=white]Daddylive [COLOR=olive](All)[/COLOR]'
 ])




    if call:
        if call < 1:
            return
        func = funcs[call-10]
        return func()
    else:
        func = funcs[call]
        return func()
    return 






def click_1():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.sporthdme/?description=C%3a%5cPortableApps%5ckodi%5ckodi%20World%2021%5cKodi%5cportable_data%5caddons%5cplugin.video.sporthdme%5cfanart.jpg&iconimage=C%3a%5cPortableApps%5ckodi%5ckodi%20World%2021%5cKodi%5cportable_data%5caddons%5cplugin.video.sporthdme%5cicon.png&mode=events&name=%5bB%5d%5bCOLOR%20white%5dLIVE%20EVENTS%5b%2fCOLOR%5d%5b%2fB%5d&url=https%3a%2f%2fsporthd.me%2f")')
    #xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.myselect/folders/py/sporthdme.py")')


def click_2():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.daddylive/?mode=menu&serv_type=sched",return)')


def click_3():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.myselect/folders/py/Livetvsx.py")')


def click_4():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.dracarys/?category=live_sport&mode=open_site&site=rojadirecta")')


def click_5():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.tvone1111/list_live")')


def click_6():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.microjen/streamed?content=video&fanart=https%3a%2f%2ffunstersplace.net%2f19repo%2fplugin.video.sportscentral%2ffanart.jpg&link=https%3a%2f%2fstreamed.su%2fapi%2fmatches%2flive&mode=streamed_get_list&page=1&thumbnail=https%3a%2f%2ffunstersplace.net%2f19repo%2fplugin.video.sportscentral%2ficon.png&title=Live&type=dir")')


def click_7():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.microjen/get_list/m3u|eNoNykEOAjEIBdAT2b9wY7zMhClomwHaFBrj7fWtX8uc8QQWfcq7Z9vnDll1eIpnqcPASX6x2AxBjil2Ct/svrHkFWhCHDDqDlI9aiN30cA1uB9T6as9svz74weGCSiK")')


def click_8():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.live.streamspro/?iconimage=http%3a%2f%2fblackghost.site%2fblack%2fimg%2fdeportes.png&mode=17&regexs=%7b%27makelist%27%3a%20%7b%27name%27%3a%20%27makelist%27%2c%20%27listrepeat%27%3a%20%27%5cn%3ctitle%3e%5bCOLOR%20lightblue%5d%5bmakelist.param1%5d%5b%2fCOLOR%5d%20(%5bmakelist.param4%5d)%3c%2ftitle%3e%5cn%3clink%3eNA%3c%2flink%3e%5cn%3cexternallink%3ehttp%3a%2f%2fblackghost.site%2farena.php%3fid4%3d%5bmakelist.param2%5d%26amp%3bname%3d%5bmakelist.param3%5d%3c%2fexternallink%3e%5cn%27%2c%20%27expres%27%3a%20%27%3d(.%2a%3f)%2c(.%2a%3f)%2c(.%2a%3f)%2c(.%2a%3f)%2c%27%2c%20%27page%27%3a%20%27http%3a%2f%2fblackghost.site%2farena.php%3farena%27%2c%20%27cookiejar%27%3a%20%27%27%7d%7d&url=%24doregex%5bmakelist%5d")')


def click_9():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.latinsports/resources/lib/chanels/tucanaldeportivo/agendadeportiva/?_pickle_=80049521000000000000007d948c075f7469746c655f948c104167656e6461204465706f727469766194732e")')


# def click_10():
    # xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.downloader/resources/okpn.py, ActivateWindow(10025,"plugin://plugin.video.nemesisaio/?description=Sports%20Time%2c%20Come%20On%20You%20Reds%20%23YNWA&fanart=0&iconimage=special://home/addons%5cplugin.video.nemesisaio%5cresources%5cImages%5cSports.gif&mode=1&name=%5bCOLOR%20yellow%5d%5bB%5dLive%20Sports%20%26%20Replays%5b%2fB%5d%5b%2fCOLOR%5d&url=SPORTS"))')


def click_10():
    xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.myselect/folders/py/Daddylive.py)')

live_now()
