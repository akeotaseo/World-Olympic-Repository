import os, xbmc, xbmcvfs, xbmcgui, xbmcaddon, shutil, glob

def InstallElementumSub():
        choice = xbmcgui.Dialog().yesno('[B][COLOR red]ΠΡΟΣΟΧΗ![/COLOR][/B]', '[B][COLOR orange]Πρόσθετα Torrent! [CR]Τα χρησιμοποιείτε με δική σας ευθύνη. [CR]Προτείνεται χρήση VPN![/COLOR][/B]',
                                        yeslabel='[B][COLOR lime]Ok[/COLOR][/B]', nolabel='[B][COLOR orange]Άκυρο[/COLOR][/B]')
        if choice == 1: torrent()


def torrent():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]Elementum[/COLOR][/B]', 
['[COLOR=orange]Elementum[/COLOR]',
 'Elementum [COLOR FFFF6B00]Burst[/COLOR]*',
 '[B][COLOR orange]Install Elementum[/COLOR][/B]'])
 # '[B][COLOR green]Torrest[/COLOR][/B]',
 # '[B][COLOR red]Delete[/COLOR][/B][CR]GitHub Add-on repository / Torrest'
 # '[COLOR violet]THUNDER[/COLOR]  [COLOR red]OFF?...[/COLOR]'])
 



    if call:
        if call < 0:
            return
        func = funcs[call-6]
        return func()
    else:
        func = funcs[call]
        return func()
    return 





def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.elementum/")')
    
def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.elementum/settings/script.elementum.burst")')
    
def click_3():
    xbmc.executebuiltin('ActivateWindow(10001,"plugin://plugin.program.installelementum/?description&fanart&iconimage&mode=3&name=%5bB%5dElementum%5b%2fB%5d&setaddon&skin&url")')

def click_4(): Torrest ()

def click_5(): delete_GitHubAddonrepository_Torres()

def click_6(): 
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.thethunder/")')



def Torrest ():
    if not xbmc.getCondVisibility('System.HasAddon({})'.format('repository.github')) or not xbmc.getCondVisibility('System.HasAddon({})'.format('plugin.video.torrest')):
        xbmcgui.Dialog().ok('[B][COLOR green]Torrest[/COLOR][/B]', 'Πρέπει να εγκαταστήσετε τα[CR][COLOR=green]Torrest[/COLOR] και [COLOR=silver]GitHub Add-on repository[/COLOR]')
        choice = xbmcgui.Dialog().yesno('[COLOR green]Torrest[/COLOR]', '[COLOR white]Μετά την εγκατάσταση του πρόσθετου [COLOR green]Torrest[/COLOR] μπορείτε να παρακολουθήσετε περιεχόμενο απο το Πρόσθετο [B][COLOR yellow]MatrixFlix[/B].[/COLOR]',
                                        nolabel='[B][COLOR red]Άκυρο...[/COLOR][/B]',yeslabel='[B][COLOR lime]Εγκατάσταση Torrest[/COLOR][/B]')

        if choice == 1: GitHubAddonrepository()
                        
                        
                        
                        
                        
                        
                        
                        
                        
                         # (xbmc.executebuiltin('InstallAddon(pvr.stalker)'),
                         # xbmc.sleep(1000),
                         # xbmc.executebuiltin('SendClick(11)'),
    # if xbmc.getCondVisibility('System.HasAddon({})'.format('plugin.video.torrest')): MatrixFlixTorrest() 
    else: MatrixFlixTorrest()
        
# def InstallTorrest():
        # xbmc.executebuiltin('InstallAddon(plugin.video.torrest)')
        # xbmc.sleep(10000)
        # MatrixFlixTorrest()
        

def GitHubAddonrepository():
        xbmc.executebuiltin('InstallAddon(repository.github)')
        xbmc.sleep(1000)
        xbmc.executebuiltin('SendClick(11)')
        xbmc.sleep(3000)
        xbmc.executebuiltin('InstallAddon(plugin.video.torrest)')
        
        
        
        xbmc.sleep(40000)
        MatrixFlixTorrest()



def MatrixFlixTorrest():
    
    funcs = (click__1, click__2)
    call = xbmcgui.Dialog().select('[B][COLOR green]Torrest[/COLOR][/B]', 
['[B][COLOR yellow]MatrixFlix[/COLOR][/B]',

 '[B][COLOR green]Torrest[/COLOR][/B]'])
 



    if call:
        if call < 0:
            return
        func = funcs[call-2]
        return func()
    else:
        func = funcs[call]
        return func()
    return 





def click__1():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.matrixflix/?function=load&sFav=load&site=torrent&siteUrl=http%3a%2f%2fvenom&title=Torrent")')
    
def click__2():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.torrest/")')
    





def delete_GitHubAddonrepository_Torres():
    
    
    if xbmc.getCondVisibility('System.HasAddon({})'.format('repository.github')) or xbmc.getCondVisibility('System.HasAddon({})'.format('plugin.video.torrest')):
        choice = xbmcgui.Dialog().yesno('[B][COLOR orange]GitHub Add-on repository - Torrest[/COLOR][/B]', 'Είστε σίγουροι οτι θέλετε να απεγκαταστήσετε τα πρόσθετα[CR][B]GitHub Add-on repository - Torrest?[/B]',
                                        nolabel='[B][COLOR red]Άκυρο...[/COLOR][/B]',yeslabel='[B][COLOR lime]Ναι[/COLOR][/B]')

        if choice == 1: 
            xbmcgui.Dialog().ok('[B][COLOR orange]GitHub Add-on repository - Torrest[/COLOR][/B]', 'Θα ακολουθήσει απεγκατάσταση των προσθέτων και επαναφόρτωση του προφίλ')
            delete()
        
        
        
    
    



    else:
    # if not xbmc.getCondVisibility('System.HasAddon({})'.format('repository.github')) or not xbmc.getCondVisibility('System.HasAddon({})'.format('plugin.video.torrest')): 
        xbmcgui.Dialog().ok('[B][COLOR orange]GitHub Add-on repository - Torrest[/COLOR][/B]', 'Τα πρόσθετα δεν είναι εγκατεστημένα!')
        
        
        
        
def delete():

    base_path = xbmcvfs.translatePath('special://home/addons')

    dir_list = glob.iglob(os.path.join(base_path, "repository.github"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)


    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.torrest"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    xbmc.sleep(1000)
    xbmcgui.Dialog().notification("[B][COLOR red]Delete[/COLOR] GitHub Add-on repository - Torrest[/B]", "[COLOR white]Τα πρόσθετα αφαιρέθηκαν με επιτυχία![/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/clean.png')
    xbmc.sleep(4000)
    xbmcgui.Dialog().notification("[B][COLOR red]Ok[/COLOR][/B]", "[COLOR white]Αναμονή για Reload Profile...[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/rp.png')
    xbmc.sleep(4000)
    xbmc.executebuiltin("LoadProfile(Master user)")
    xbmc.sleep(2000)
    xbmcgui.Dialog().notification("[B][COLOR orange]Reload Profile[/COLOR][/B]", "[COLOR white]Παρακαλώ περιμένετε...[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/reloadprofile.png')
    # xbmcgui.Dialog().ok('[B][COLOR orange]GitHub Add-on repository - Torres[/COLOR][/B]', 'Τα πρόσθετα αφερέθηκαν με επιτυχία!')
    # xbmc.executebuiltin('Dialog.Close(all,true)')
    # xbmc.executebuiltin('Action(Back)')
    # xbmc.executebuiltin('Dialog.Close(all,true)')
    # xbmc.executebuiltin('ActivateWindow(10000)')
    # xbmc.executebuiltin("LoadProfile(Master user)")

InstallElementumSub()



# xbmcgui.Dialog().notification("[COLOR=green]TORREST[/COLOR]", "[COLOR white]Περιμένετε... να ολοκληρωθεί η εγκατάσταση ...[/COLOR]", icon='special://home/addonsskin.19MatrixWorld/media/Torrest.png', sound=True), xbmc.sleep(5000), xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.matrixflix/?function=load&sFav=load&site=torrent&siteUrl=http%3a%2f%2fvenom&title=Torrent")'), xbmc.sleep(5000), xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.matrixflix/?function=load&sFav=load&site=torrent&siteUrl=http%3a%2f%2fvenom&title=Torrent")')


