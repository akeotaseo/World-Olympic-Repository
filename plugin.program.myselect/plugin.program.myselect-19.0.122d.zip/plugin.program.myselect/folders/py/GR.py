import xbmc, xbmcgui
xbmcgui.Dialog().notification("[B][COLOR green]Loading lists[/COLOR][/B]", "[COLOR orange]They don't always work[/COLOR]", sound=False, icon='special://home/addons/plugin.video.myiptvpro/thumbnail/doestworkalltime.png')
xbmc.executebuiltin('Dialog.Close(all,true)')
xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.mypreferences/?content_type=video&fanart=https%3a%2f%2fupload.wikimedia.org%2fwikipedia%2fcommons%2fthumb%2f5%2f5c%2fFlag_of_Greece.svg%2f2560px-Flag_of_Greece.svg.png&image=https%3a%2f%2fupload.wikimedia.org%2fwikipedia%2fcommons%2fthumb%2f5%2f5c%2fFlag_of_Greece.svg%2f2560px-Flag_of_Greece.svg.png&label=GR&mode=400&path=special%3a%2f%2fprofile%2faddon_data%2fplugin.program.mypreferences%5cSuper%20Favourites%5cGR",return)')

