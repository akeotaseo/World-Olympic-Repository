import xbmc, xbmcgui


def NemesisAIO():
    funcs = (click_1, click_2, click_3, click_4)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]~ NemesisAIO / UK Turk Movies ~[/COLOR][/B]', 
['[B][COLOR=white][COLOR red]E[COLOR yellow]nterTain Me[/COLOR][/COLOR][/B]',
 '[B][COLOR=white][COLOR yellow]NemesisAIO Movies[/COLOR][/COLOR][/B]',
 '[B][COLOR=white][COLOR yellow]NemesisAIO Tv Shows[/COLOR][/COLOR][/B]',
 '[B][COLOR=white]UK Turk Movies[/COLOR][/B]'])


    if call:
        if call < 0:
            return
        func = funcs[call-4]
        return func()
    else:
        func = funcs[call]
        return func()
    return 


def click_1():
    xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.downloader/resources/okpn.py, ActivateWindow(10025,"plugin://plugin.video.EntertainMe/"))')

def click_2():
    xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.downloader/resources/okpn.py, ActivateWindow(10025,"plugin://plugin.video.nemesisaio/?description=Grab%20The%20Popcorn%20And%20Watch%20A%20Film&fanart=0&iconimage=G%3a%5cKodi.19%5cportable_data%5caddons%5cplugin.video.nemesisaio%5cresources%5cImages%5cMovies.gif&mode=1&name=%5bCOLOR%20yellow%5d%5bB%5dMovies%5b%2fB%5d%5b%2fCOLOR%5d&url=MOVIES"))')

def click_3():
    xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.downloader/resources/okpn.py, ActivateWindow(10025,"plugin://plugin.video.nemesisaio/?description=Lets%20Watch%20Our%20Fav%20Tv%20Show&fanart=0&iconimage=G%3a%5cKodi.19%5cportable_data%5caddons%5cplugin.video.nemesisaio%5cresources%5cImages%5cTv-Shows.gif&mode=1&name=%5bCOLOR%20yellow%5d%5bB%5dTv%20Shows%5b%2fB%5d%5b%2fCOLOR%5d&url=TVSHOWS"))')

def click_4():
    xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.downloader/resources/okpn.py, ActivateWindow(10025,"plugin://plugin.video.ukturk19/?description=Movies&fanart=%2fstorage%2femulated%2f0%2fAndroid%2fdata%2forg.xbmc.kodi%2ffiles%2f.kodi%2faddons%2fplugin.video.ukturk19%2ffanart.jpg&icon=https%3a%2f%2fukturks.app%2fapi%2fAddon%2fthumbs%2fnew%2fUk%2520turk%2520thumbnails%2520movies1.jpg&mode=1&name=Movies&url=https%3a%2f%2fukturks.app%2fapi%2fAddon%2fAddon%2fmovies%2fIndexx.txt"))')


NemesisAIO()
