
import time
import xbmc
import os
import xbmcgui
import webbrowser


def Livetvsx():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7, click_8)
    call = xbmcgui.Dialog().select('[B][COLOR=blue]      Livetv[/COLOR][/B] [B][COLOR=red]sx[/COLOR][/B]',
['[COLOR=white]Live TV[/COLOR] [COLOR=orange](microjen)[/COLOR]',


 '[COLOR=white]Live TV[/COLOR] [COLOR=purple](vstream)[/COLOR]',

 '[COLOR=white]Live TV[/COLOR] [COLOR green](Dracarys)[/COLOR]',

 '[COLOR=white]Live TV[/COLOR] [COLOR silver](apex_sports)[/COLOR]',

 '[COLOR=white]Live TV[/COLOR] [COLOR yellow](MatrixFlix Media)[/COLOR] [COLOR red](OFF?...)[/COLOR]',

 '[B][COLOR=white]Browser Links[/COLOR][/B]',

 '[COLOR blue]Live TV[/COLOR]  [COLOR=aqua](mandrakodi)[/COLOR]',


 # '[COLOR=white]Live TV[/COLOR] [COLOR=grey](sd)[/COLOR]',

 '[B][COLOR red]<---                                                                      [COLOR grey]Back[/COLOR][/B]'
 ])







    if call:
        if call < 1:
            return
        func = funcs[call-8]
        return func()
    else:
        func = funcs[call]
        return func()
    return 






def click_1():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.microjen/sporthd?description=LiveTV.ru%20Main%20menu&iconimage=C%3a%5cPortableApps%5ckodi%5cKODI%20TEST%5cKodi%5cportable_data%5caddons%5cplugin.video.microjen%5cresources%5clib%5cexternal%5csporthd%5cmedia%5clivetv.png&mode=livetvSX_main&name=%5bB%5d-%20%5bCOLOR%20red%5dLive%5bCOLOR%20white%5dTV.ru%5b%2fCOLOR%5d%5b%2fB%5d&url")')


def click_2():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.vstream/?function=load&sFav=load&site=livetv&siteUrl=True&title=Live%20TV")')
def click_3():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.dracarys/?category=live_sport&mode=open_site&site=livetv")')


def click_4():

    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.apex_sports/?category=live_sport&mode=open_site&site=livetv")')

def click_5():

    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.matrixflix/?function=showLive&sFav=showLive&site=livetv&siteUrl=https%3a%2f%2flivetv852.me%2fenx%2f&title=Live%20TV")')

# def click_6():
    # xbmc.executebuiltin('Dialog.Close(all,true)')
    # xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.sportsdevil/?item=title%3dLiveTV.ru%26director%3dLiveTV.ru%26icon%3dC%253A%255CPortableApps%255Ckodi%255Ckodi%2bWorld%2b21%255CKodi%255Cportable_data%255Caddons%255Cplugin.video.sportsdevil%255Cresources%255Cimages%255Clivetv_ru.png%26url%3dlivesports%252Flivetv.ru.cfg%26type%3drss%26genre%3dLive%2bSports%26definedIn%3dlivesports.cfg&mode=1")')

def click_6(): sxYesNo()


def click_7():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.mandrakodi/?action=getExtData&url=https%3a%2f%2ftest34344.herokuapp.com%2ffilter.php%3fnumTest%3dA1A170%26writeKodi%3d1%26mode%3d0")')

def click_8():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.myselect/folders/py/Live_Now.py")')





def sxYesNo():
        choice = xbmcgui.Dialog().yesno('[COLOR=red]LiveTv.sx[/COLOR]', '[COLOR white]Πατήστε [COLOR=red]LiveTv.sx[/COLOR] για να μεταφερθείτε στο site[CR]https://livetv.sx/enx/',
                                        nolabel='[COLOR white]Όχι τώρα[/COLOR]',yeslabel='[COLOR=red]LiveTv.sx[/COLOR]')
        if choice == 1: sx()


def sx():
    dialog = xbmcgui.Dialog()
    funcs = (
        function1, function1
    )
        
    call = dialog.select('Ανακατεύθυνση σε [B][COLOR=blue]Browser[/COLOR][/B]',
    [
    
    '[COLOR=red]LiveTv.sx[/COLOR]',])

    # dialog.selectreturns
    #   0 -> escape pressed
    #   1 -> first item
    #   2 -> second item
    if call:
        # esc is not pressed
        if call < 0:
            return
        func = funcs[call-2]
        return func()
    else:
        func = funcs[call]
        return func()
    return 

def platform():
    if xbmc.getCondVisibility('system.platform.android'):
        return 'android'
    elif xbmc.getCondVisibility('system.platform.linux'):
        return 'linux'
    elif xbmc.getCondVisibility('system.platform.windows'):
        return 'windows'
    elif xbmc.getCondVisibility('system.platform.osx'):
        return 'osx'
    elif xbmc.getCondVisibility('system.platform.atv2'):
        return 'atv2'
    elif xbmc.getCondVisibility('system.platform.ios'):
        return 'ios'

myplatform = platform()




def function1():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://livetv.sx/enx/' ) )
    else:
        opensite = webbrowser . open('https://livetv.sx/enx/')
Livetvsx()