import xbmc, xbmcgui, xbmcaddon



def live_now():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7, click_8, click_9)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]       Live Now...[/COLOR][/B]',
['[B][COLOR white]Sport[COLOR gold]HD[COLOR white] - Πλήρες Πρόγραμμα Αγώνων[/COLOR][/B] [COLOR orange] (microjen)[/COLOR]',

 '[B][COLOR red]Live[/COLOR][COLOR white]TV.ru[/COLOR] - Πλήρες Πρόγραμμα Αγώνων[/B] [COLOR orange] (microjen)[/COLOR]',

 '[COLOR=firebrick]DADDYLIVE[/COLOR]',


 # '[COLOR lime]====================[/COLOR]',

 # '[COLOR=white]Rojadirecta[/COLOR] [COLOR green](Dracarys)[/COLOR]',
 '[B][Live][/B]  (tvone1112)',
 '[COLOR gold]LISTA 3[/COLOR] [COLOR blue](Sportzonline)[/COLOR]  [COLOR=aqua](mandrakodi)[/COLOR]',
 # '[B][COLOR white]ALL YOU CAN SPORT[/B]  [COLOR green](thegroove360)[/COLOR]'
 '[I]10Cam [COLOR green](TheThao)[/COLOR][/I]',
 # '[I]Tâm điểm thapcam  [COLOR orange](thapcam)[/COLOR][/I]',
 # '[COLOR lime]====================[/COLOR]'
 '[B][COLOR red]Live Now[/COLOR][/B]  (streamedez)',
 '[COLOR lightcyan]AGENDA [/COLOR][COLOR lightblue]ROJA[/COLOR]  [COLOR lightslategray][I][/I][/COLOR] [B]B L A C K[/B] G H O S T [COLOR orange] (microjen)[/COLOR]',
 '[B][COLOR gold]Live_Stream[/COLOR][/B]  (Tk)',

 # '[COLOR=blue]=[COLOR=white]Live TV[COLOR=blue]=[CR][COLOR=red]sx[/COLOR]'
 ])




    if call:
        if call < 1:
            return
        func = funcs[call-9]
        return func()
    else:
        func = funcs[call]
        return func()
    return 






def click_1():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.microjen/sporthd?description=Daily%20events%20list&iconimage=https%3a%2f%2fraw.githubusercontent.com%2fbugatsinho%2fbugatsinho.github.io%2fmaster%2fplugin.video.sporthdme%2ficon.png&mode=events&name=%5bB%5d-%20%5bCOLOR%20white%5dSport%5bCOLOR%20gold%5dHD%5bCOLOR%20white%5d%20-%20%ce%a0%ce%bb%ce%ae%cf%81%ce%b5%cf%82%20%ce%a0%cf%81%cf%8c%ce%b3%cf%81%ce%b1%ce%bc%ce%bc%ce%b1%20%ce%91%ce%b3%cf%8e%ce%bd%cf%89%ce%bd%5b%2fCOLOR%5d%5b%2fB%5d&url=https%3a%2f%2fsuper.league.do%2f")')


def click_2():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    Livetv_setMj_off()
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.microjen/sporthd?description=LiveTV.ru%20Daily%20events%20list&iconimage=C%3a%5cPortableApps%5ckodi%5cKODI%20TEST%5cKodi%5cportable_data%5caddons%5cplugin.video.microjen%5cresources%5clib%5cexternal%5csporthd%5cmedia%5clivetv.png&mode=livetvSX_events&name=%5bB%5d-%20%5bCOLOR%20red%5dLive%5b%2fCOLOR%5d%5bCOLOR%20white%5dTV.ru%5b%2fCOLOR%5d%20-%20%ce%a0%ce%bb%ce%ae%cf%81%ce%b5%cf%82%20%ce%a0%cf%81%cf%8c%ce%b3%cf%81%ce%b1%ce%bc%ce%bc%ce%b1%20%ce%91%ce%b3%cf%8e%ce%bd%cf%89%ce%bd%5b%2fB%5d&url=eJzLKCkpKLbS109OydPLySxLLSmzMDXWy03VLyou1i8tSM7PzcxLj0%2fN06vIzQEAZbMQMg%3d%3d")')


def click_3():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.daddylive/?mode=menu&serv_type=sched")')


# def click_4():
    # xbmc.executebuiltin('Dialog.Close(all,true)')
    # xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.myselect/folders/py/Live_Now.py")')


# def click_5():
    # xbmc.executebuiltin('Dialog.Close(all,true)')
    # xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.dracarys/?category=live_sport&mode=open_site&site=rojadirecta")')


def click_4():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.tvone1111/list_live")')


def click_5():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.mandrakodi/?action=myresolve&parIn=zonline&url=sportMenu")')


# def click_6():
    # xbmc.executebuiltin('Dialog.Close(all,true)')
    # xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.thegroove360/regex/eyJfX2NsYXNzX18iOiAiVGhlZ3Jvb3ZlSXRlbSIsICJfX21vZHVsZV9fIjogInJlc291cmNlcy5tb2R1bGVzLnRoZWdyb292ZS50aGVncm9vdmVfaXRlbSIsICJfcmF3IjogIjxpdGVtPlxuPHRpdGxlPltDT0xPUiBsaW1lXSAtIFtCXVtDT0xPUiBpdm9yeV1BTEwgWU9VIENBTiBTUE9SVFsvQ09MT1JdWy9CXTwvdGl0bGU+XG48bGluaz4kZG9yZWdleFttYWtlbGlzdF08L2xpbms+XG48dGh1bWJuYWlsPmh0dHBzOi8vd3d3LmRyb3Bib3guY29tL3MvYzR2eHU4bW8weHQ5Nmx2L3Nwb3J0LnBuZz9kbD0xPC90aHVtYm5haWw+XG48ZmFuYXJ0Pmh0dHBzOi8vd3d3LmRyb3Bib3guY29tL3MvYzR2eHU4bW8weHQ5Nmx2L3Nwb3J0LnBuZz9kbD0xPC9mYW5hcnQ+XG48cmVnZXg+XG48bmFtZT5tYWtlbGlzdDwvbmFtZT5cbjxsaXN0cmVwZWF0PjwhW0NEQVRBW1xuPHRpdGxlPltDT0xPUiB3aGl0ZV0gW21ha2VsaXN0LnBhcmFtMV1bL0NPTE9SXTwvdGl0bGU+XG48dGh1bWJuYWlsPjwvdGh1bWJuYWlsPlxuPGZhbmFydD48L2ZhbmFydD5cbjxsaW5rPiRkb3JlZ2V4W21ha2VsaXN0Ml08L2xpbms+XG48cmVmZXJlcj48L3JlZmVyZXI+XG5dXT48L2xpc3RyZXBlYXQ+XG48ZXhwcmVzPjwhW0NEQVRBWyMkcHlGdW5jdGlvblxuZGVmIGdldF90aGVncm9vdmVfeG1sX2ZuKHBhZ2U9XCJcIiwgcGFnZV9zcmM9XCJcIik6XG4gICAgdHJ5OlxuICAgICAgICBpbXBvcnQgcmVxdWVzdHMsIHJlXG4gICAgICAgIGZyb20gZGF0ZXRpbWUgaW1wb3J0IGRhdGV0aW1lLCB0aW1lZGVsdGFcbiAgICAgICAgaW1wb3J0IHRpbWVcbiAgICAgICAgdXJsID0gcGFnZVxuXG4gICAgICAgIGV4cHJlc3MxID0gcicoXFxkKzpcXGQrKVxccyguKj8pXFxzXFx8XFxzKC4qPylcXG4nXG4gICAgICAgIFxuXG4gICAgICAgIGhlYWRlcnMgPSB7XG4gICAgICAgICAgICAndXNlci1hZ2VudCc6IFwiTW96aWxsYS81LjAgKFgxMTsgTGludXggeDg2XzY0KSBBcHBsZVdlYktpdC81MzcuMzYgKEtIVE1MLCBsaWtlIEdlY2tvKSBDaHJvbWUvNzQuMC4zNzI5LjEzMSBTYWZhcmkvNTM3LjM2XCJcbiAgICAgICAgfVxuXG4gICAgICAgIHMgPSByZXF1ZXN0cy5TZXNzaW9uKClcbiAgICAgICAgciA9IHMuZ2V0KHVybCwgaGVhZGVycz1oZWFkZXJzKVxuICAgICAgICBwcmludChyLnRleHQpXG4gICAgICAgIHJlcyA9IHJlLmNvbXBpbGUoZXhwcmVzczEsIHJlLk1VTFRJTElORSB8IHJlLkRPVEFMTCkuZmluZGFsbChyLnRleHQpXG5cbiAgICAgICAgcmV0ID0gW11cblxuICAgICAgICBzdWJsaW5rcyA9IFtdXG4gICAgICAgIGZvciByIGluIHJlczpcbiAgICAgICAgICAgIG9yYXJpb19vcmlnID0gZGF0ZXRpbWUoKih0aW1lLnN0cnB0aW1lKHJbMF0sIFwiJUg6JU1cIilbMDo2XSkpXG4gICAgICAgICAgICBvcmFyaW9fbnVvdm8gPSBvcmFyaW9fb3JpZyArIHRpbWVkZWx0YShob3Vycz0rMSlcbiAgICAgICAgICAgIGRhdGEgPSBvcmFyaW9fbnVvdm8uc3RyZnRpbWUoXCIlSDolTVwiKVxuXG4gICAgICAgICAgICB0aXRvbG8gPSBcIltDT0xPUiBsaW1lXVwiICsgZGF0YSArIFwiWy9DT0xPUl1cIiArIFwiW0NPTE9SIGl2b3J5XSBcIiArIHJbMV0gKyBcIlsvQ09MT1JdXCJcbiBcbiAgICAgICAgICAgIHJldC5hcHBlbmQoKHRpdG9sbyxyWzJdKSlcbiAgICAgICAgICAgIFxuICAgICAgICByZXR1cm4gcmV0XG4gICAgZXhjZXB0IEV4Y2VwdGlvbiBhcyBlOlxuICAgICAgICBpbXBvcnQgdHJhY2ViYWNrXG4gICAgICAgIHRyYWNlYmFjay5wcmludF9leGMoKVxuICAgICAgICBwcmludChlKVxuXV0+PC9leHByZXM+XG48cGFnZT5odHRwczovL3Nwb3J0c29ubGluZS5nbC9wcm9nLnR4dDwvcGFnZT5cbjwvcmVnZXg+XG5cblxuPHJlZ2V4PlxuICAgIDxuYW1lPm1ha2VsaXN0MjwvbmFtZT5cbiAgICA8ZXhwcmVzPjwhW0NEQVRBWyMkcHlGdW5jdGlvblxuZGVmIGdldF90aGVncm9vdmVfeG1sX2ZuKHBhZ2U9XCJcIik6XG4gICBcbiAgICB0cnk6XG4gICAgICAgXG5cbiAgICAgICAgcmV0dXJuICAgJ1ttYWtlbGlzdC5wYXJhbTJdJ1xuICAgICAgICBcbiAgICBleGNlcHQgRXhjZXB0aW9uIGFzIGU6XG4gICAgICAgIGltcG9ydCB0cmFjZWJhY2tcbiAgICAgICAgdHJhY2ViYWNrLnByaW50X2V4YygpXG4gICAgICAgIHByaW50KGUpXG5dXT48L2V4cHJlcz5cbiAgICA8cGFnZT48L3BhZ2U+XG48L3JlZ2V4PlxuPC9pdGVtPiIsICJhcnRzIjogeyJ0aHVtYm5haWwiOiAiIiwgImZhbmFydCI6ICJodHRwczovL3d3dy5kcm9wYm94LmNvbS9zL2M0dnh1OG1vMHh0OTZsdi9zcG9ydC5wbmc/ZGw9MSIsICJ0aHVtYiI6ICJodHRwczovL3d3dy5kcm9wYm94LmNvbS9zL2M0dnh1OG1vMHh0OTZsdi9zcG9ydC5wbmc/ZGw9MSJ9LCAiaW5mbyI6IHsiZ2VucmUiOiAiIiwgImNvdW50cnkiOiAiIiwgInllYXIiOiAiIiwgImVwaXNvZGUiOiAiIiwgInNlYXNvbiI6ICIiLCAic29ydGVwaXNvZGUiOiAiIiwgInNvcnRzZWFzb24iOiAiIiwgImVwaXNvZGVndWlkZSI6ICIiLCAic2hvd2xpbmsiOiAiIiwgInRvcDI1MCI6ICIiLCAic2V0aWQiOiAiIiwgInRyYWNrbnVtYmVyIjogIiIsICJyYXRpbmciOiAiIiwgInVzZXJyYXRpbmciOiAiIiwgIndhdGNoZWQiOiAiIiwgInBsYXljb3VudCI6ICIiLCAib3ZlcmxheSI6ICIiLCAiY2FzdCI6IFtdLCAiY2FzdGFuZHJvbGUiOiBbXSwgImRpcmVjdG9yIjogIiIsICJtcGFhIjogIiIsICJwbG90IjogIiIsICJwbG90b3V0bGluZSI6ICIiLCAidGl0bGUiOiAiIiwgIm9yaWdpbmFsdGl0bGUiOiAiIiwgInNvcnR0aXRsZSI6ICIiLCAiZHVyYXRpb24iOiAiIiwgInN0dWRpbyI6ICIiLCAidGFnbGluZSI6ICIiLCAid3JpdGVyIjogIiIsICJ0dnNob3d0aXRsZSI6ICIiLCAicHJlbWllcmVkIjogIiIsICJzdGF0dXMiOiAiIiwgInNldCI6ICIiLCAic2V0b3ZlcnZpZXciOiAiIiwgInRhZyI6ICIiLCAiaW1kYm51bWJlciI6ICIiLCAiY29kZSI6ICIiLCAiYWlyZWQiOiAiIiwgImNyZWRpdHMiOiAiIiwgImxhc3RwbGF5ZWQiOiAiIiwgImFsYnVtIjogIiIsICJhcnRpc3QiOiBbXSwgInZvdGVzIjogIiIsICJwYXRoIjogIiIsICJ0cmFpbGVyIjogIiIsICJkYXRlYWRkZWQiOiAiIiwgIm1lZGlhdHlwZSI6ICJ2aWRlbyIsICJkYmlkIjogIiJ9LCAicmVnZXhlcyI6IFtdLCAiaXNfZm9sZGVyIjogdHJ1ZSwgInVybCI6ICIkZG9yZWdleFttYWtlbGlzdF0iLCAibGFiZWwiOiAiW0NPTE9SIGxpbWVdIC0gW0JdW0NPTE9SIGl2b3J5XUFMTCBZT1UgQ0FOIFNQT1JUWy9DT0xPUl1bL0JdIiwgInBhcmVudF94bWwiOiAiIiwgInN1YmxpbmtzIjogW10sICJpc19wbGF5YWJsZSI6IGZhbHNlLCAidGdfcmVzb2x2ZXIiOiAiIiwgImlzX3BsdWdpbiI6IGZhbHNlLCAicG9zIjogMH0=")')


# def click_8():
    # xbmc.executebuiltin('Dialog.Close(all,true)')
    # xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.myselect/folders/py/Daddylive.py)')


# def click_9():
    # xbmc.executebuiltin('Dialog.Close(all,true)')
    # xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.myselect/folders/py/Daddylive.py)')


def click_6():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.thethao/?mode=group&nhom=10Cam")')


# def click_6():
    # xbmc.executebuiltin('Dialog.Close(all,true)')
    # xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.thapcam/?mode=index_thapcam")')


def click_7():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.streamedez/?mode=live_now")')


def click_8():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.live.streamspro/?iconimage=http%3a%2f%2fbgaddon.online%2fblack%2fimg%2fdeportes.png&mode=17&regexs=%7b%27makelist%27%3a%20%7b%27name%27%3a%20%27makelist%27%2c%20%27listrepeat%27%3a%20%27%5cn%3ctitle%3e%5bCOLOR%20lightblue%5d%5bmakelist.param1%5d%5b%2fCOLOR%5d%5bCOLOR%20orange%5d%20%20(%5bmakelist.param3%5d)%5b%2fCOLOR%5d%5bCOLOR%20gray%5d%20%5bmakelist.param2%5d%5b%2fCOLOR%5d%3c%2ftitle%3e%5cn%3clink%3e%24doregex%5bmakelist2%5d%3c%2flink%3e%5cn%3cthumbnail%3ehttp%3a%2f%2fbgaddon.online%2fblack%2fimg%2fdeportes.png%3c%2fthumbnail%3e%5cn%20%20%27%2c%20%27expres%27%3a%20%27%3d(.%2a%3f)%2c(.%2a%3f)%2c(.%2a%3f)%5c%5cn%27%2c%20%27page%27%3a%20%27http%3a%2f%2fbgaddon.online%2fredcard.php%27%2c%20%27cookiejar%27%3a%20%27%27%7d%2c%20%27makelist2%27%3a%20%7b%27name%27%3a%20%27makelist2%27%2c%20%27listrepeat%27%3a%20%27%5cn%3ctitle%3e%5bCOLOR%20lightblue%5d%5bmakelist.param1%5d%5b%2fCOLOR%5d%5bCOLOR%20orange%5dopcion%20%5bmakelist2.param1%5d%5b%2fCOLOR%5d%20%3c%2ftitle%3e%5cn%3clink%3e%24%5bmakelist2.param2%5d%3c%2flink%3e%5cn%3cthumbnail%3ehttp%3a%2f%2fbgaddon.online%2fblack%2fimg%2fdeportes.png%3c%2fthumbnail%3e%5cn%20%20%27%2c%20%27expres%27%3a%20%27%3d%22(.%2a%3f)%22%2c%22(.%2a%3f)%22%27%2c%20%27page%27%3a%20%27%5cn%20%20%3d%22ws%20(player4)%22%2c%22doregex%5bgeturl2%5d%7cReferer%3dhttps%3a%2f%2fplanetfastidious.net%26Origin%3dhttps%3a%2f%2fplanetfastidious.net%26User-Agent%3dMozilla%2f5.0%20(Windows%20NT%2010.0%3b%20Win64%3b%20x64)%20AppleWebKit%2f537.36%20(KHTML%2c%20like%20Gecko)%20Chrome%2f117.0.0.0%20Safari%2f537.36%22%5cn%20%20%3d%22ws%20%20(player3)%22%2c%22doregex%5bgeturl3%5d%7cReferer%3dhttps%3a%2f%2fplanetfastidious.net%26Origin%3dhttps%3a%2f%2fplanetfastidious.net%26User-Agent%3dMozilla%2f5.0%20(Windows%20NT%2010.0%3b%20Win64%3b%20x64)%20AppleWebKit%2f537.36%20(KHTML%2c%20like%20Gecko)%20Chrome%2f117.0.0.0%20Safari%2f537.36%22%5cn%20%20%3d%22Footy%20(player2)%22%2c%22doregex%5bgeturl4%5d%7cUser-Agent%3dMozilla%2f5.0%20(Windows%20NT%2010.0%3b%20Win64%3b%20x64)%20AppleWebKit%2f537.36%20(KHTML%2c%20like%20Gecko)%20Chrome%2f127.0.0.0%20Safari%2f537.36%26Origin%3dhttps%3a%2f%2fhoca6.com%26Referer%3dhttps%3a%2f%2fhoca6.com%2f%22%27%2c%20%27cookiejar%27%3a%20%27%27%7d%2c%20%27geturl1%27%3a%20%7b%27name%27%3a%20%27geturl1%27%2c%20%27expres%27%3a%20%27%22player%22%2c%22(.%2a%3f)%22%27%2c%20%27page%27%3a%20%27https%3a%2f%2feyespeeled.click%2fplayer%2f%24doregex%5bgeturl11%5d%27%2c%20%27referer%27%3a%20%27https%3a%2f%2ftarjetarojaenvivo.lat%2f%27%2c%20%27setcookie%27%3a%20%27a%3dPgaUyDMXitTncaWeBOKXrLCdRydZdCm4%3b%27%2c%20%27cookiejar%27%3a%20%27%27%7d%2c%20%27geturl11%27%3a%20%7b%27name%27%3a%20%27geturl11%27%2c%20%27expres%27%3a%20%22ThePlayerJS.%2a%3f%2c%27(.%2a%3f)%27%22%2c%20%27page%27%3a%20%27https%3a%2f%2ftarjetarojaenvivo.lat%2fplayer%2f1%2f%5bmakelist.param2%5d%27%2c%20%27cookiejar%27%3a%20%27%27%7d%2c%20%27geturl4%27%3a%20%7b%27name%27%3a%20%27geturl4%27%2c%20%27expres%27%3a%20%27%24pyFunction%3a%5c%27%24doregex%5bgeturl44%5d%5c%27.replace(%5c%27%22%5c%27%2c%5c%27%5c%27).replace(%5c%27%2c%5c%27%2c%5c%27%5c%27).replace(%5c%27%5c%5c%2f%5c%5c%2f%5c%5c%2f%5c%5c%2f%5c%27%2c%5c%27%2f%2f%5c%27)%27%2c%20%27page%27%3a%20%27NA%27%2c%20%27cookiejar%27%3a%20%27%27%7d%2c%20%27geturl44%27%3a%20%7b%27name%27%3a%20%27geturl44%27%2c%20%27expres%27%3a%20%27return%5c%5c(%5c%5c%5b%22(.%2a%3f)%22%5c%5c%5d%27%2c%20%27page%27%3a%20%27https%3a%2f%2fhoca6.com%2ffooty.php%3fplayer%3ddesktop%26live%3dufeed%5bmakelist.param2%5d%27%2c%20%27referer%27%3a%20%27https%3a%2f%2ftarjetarojaenvivo.lat%2f%27%2c%20%27cookiejar%27%3a%20%27%27%7d%2c%20%27geturl3%27%3a%20%7b%27name%27%3a%20%27geturl3%27%2c%20%27expres%27%3a%20%27src%3d%22(.%2a%3f)%22%27%2c%20%27page%27%3a%20%27%24doregex%5bgetunpacked3%5d%27%2c%20%27referer%27%3a%20%27https%3a%2f%2frereyano.ru%2fplayer%2f3%2f%5bmakelist.param2%5d%27%2c%20%27cookiejar%27%3a%20%27%27%7d%2c%20%27getunpacked3%27%3a%20%7b%27name%27%3a%20%27getunpacked3%27%2c%20%27expres%27%3a%20%22%24pyFunction%3aget_unpacked(page_data%2c%27(%5c%5cn%3cscript%3eeval%5c%5c(function%5c%5c(p%2ca%2cc%2ck%2ce%2cd.%2a)%27%20)%22%2c%20%27page%27%3a%20%27%24doregex%5bgeturl33%5d%27%2c%20%27referer%27%3a%20%27https%3a%2f%2frereyano.ru%2f%27%2c%20%27connection%27%3a%20%27keep-alive%27%2c%20%27cookiejar%27%3a%20%27%27%7d%2c%20%27geturl33%27%3a%20%7b%27name%27%3a%20%27geturl33%27%2c%20%27expres%27%3a%20%27iframe%20src%3d%22(.%2b%3f)%22%27%2c%20%27page%27%3a%20%27http%3a%2f%2frereyano.ru%2fplayer%2f3%2f%5bmakelist.param2%5d%27%2c%20%27cookiejar%27%3a%20%27%27%7d%2c%20%27geturl2%27%3a%20%7b%27name%27%3a%20%27geturl2%27%2c%20%27expres%27%3a%20%27src%3d%22(.%2a%3f)%22%27%2c%20%27page%27%3a%20%27%24doregex%5bgetunpacked%5d%27%2c%20%27referer%27%3a%20%27https%3a%2f%2frereyano.ru%2fplayer%2f4%2f%5bmakelist.param2%5d%27%2c%20%27cookiejar%27%3a%20%27%27%7d%2c%20%27getunpacked%27%3a%20%7b%27name%27%3a%20%27getunpacked%27%2c%20%27expres%27%3a%20%22%24pyFunction%3aget_unpacked(page_data%2c%27(%5c%5cn%3cscript%3eeval%5c%5c(function%5c%5c(p%2ca%2cc%2ck%2ce%2cd.%2a)%27%20)%22%2c%20%27page%27%3a%20%27%24doregex%5bgeturl%5d%27%2c%20%27referer%27%3a%20%27https%3a%2f%2frereyano.ru%2f%27%2c%20%27connection%27%3a%20%27keep-alive%27%2c%20%27cookiejar%27%3a%20%27%27%7d%2c%20%27geturl%27%3a%20%7b%27name%27%3a%20%27geturl%27%2c%20%27expres%27%3a%20%27iframe%20src%3d%22(.%2b%3f)%22%27%2c%20%27page%27%3a%20%27http%3a%2f%2frereyano.ru%2fplayer%2f4%2f%5bmakelist.param2%5d%27%2c%20%27cookiejar%27%3a%20%27%27%7d%2c%20%27geturl5%27%3a%20%7b%27name%27%3a%20%27geturl5%27%2c%20%27expres%27%3a%20%27src%3d%22(.%2a%3f)%22%27%2c%20%27page%27%3a%20%27%24doregex%5bgetunpacked5%5d%27%2c%20%27referer%27%3a%20%27https%3a%2f%2ftarjetarojaenvivo.lat%2f%27%2c%20%27cookiejar%27%3a%20%27%27%7d%2c%20%27getunpacked5%27%3a%20%7b%27name%27%3a%20%27getunpacked5%27%2c%20%27expres%27%3a%20%22%24pyFunction%3aget_unpacked(page_data%2c%27(eval%5c%5c(function%5c%5c(p%2ca%2cc%2ck%2ce%2cd.%2a)%27%20)%22%2c%20%27page%27%3a%20%27%24doregex%5bgeturl55%5d%27%2c%20%27referer%27%3a%20%27https%3a%2f%2ftarjetarojaenvivo.lat%2f%27%2c%20%27connection%27%3a%20%27keep-alive%27%2c%20%27cookiejar%27%3a%20%27%27%7d%2c%20%27geturl55%27%3a%20%7b%27name%27%3a%20%27geturl55%27%2c%20%27expres%27%3a%20%27iframe%20src%3d%22(.%2b%3f)%22%27%2c%20%27page%27%3a%20%27https%3a%2f%2ftarjetarojaenvivo.lat%2fplayer%2f5%2f%5bmakelist.param2%5d%27%2c%20%27cookiejar%27%3a%20%27%27%7d%7d&url=%24doregex%5bmakelist%5d")')

# def click_7():
    # xbmc.executebuiltin('Dialog.Close(all,true)')
    # xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.myselect/folders/py/Livetvsx.py")')

def click_9():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('RunScript("special://home/addons/skin.19MatrixWorld/xml/Live_Stream.py")')


def Livetv_setMj_off():
    addon_microjen       = xbmcaddon.Addon('plugin.video.microjen')
    setting_microjen     = addon_microjen.getSetting
    setting_set_microjen = addon_microjen.setSetting
    if not setting_microjen('enable_ace_links')=='false':
        xbmc.sleep(1000)
        setting_set_microjen('enable_ace_links', 'false')

live_now()


