﻿import os, xbmc, xbmcvfs, xbmcgui, xbmcaddon, shutil, glob

def DialogEnableDisabledownloaderstartup():        
        choice = xbmcgui.Dialog().yesno('[COLOR orange]Pach API -Codes[/COLOR]', '[CR]Με την εκτέλεση του [COLOR yellow][B]Pach API -Codes[/B][/COLOR], θα ανοίξει παράθυρο διαλόγου... και το kodi θα κλείσει άμεσα.[CR][CR]Για να συνεχίσετε πατήστε [B][COLOR yellow]Pach API -Codes[/COLOR][/B]',
                                        nolabel='[B][COLOR white]Όχι τώρα...[/COLOR][/B]',yeslabel='[B][COLOR yellow]Pach API -Codes[/COLOR][/B]')
                                        
        if choice == 1: [xbmc.executebuiltin('ActivateWindow(10001,"plugin://script.x-codes.api/",return)'),
                        ]
                         
DialogEnableDisabledownloaderstartup()
