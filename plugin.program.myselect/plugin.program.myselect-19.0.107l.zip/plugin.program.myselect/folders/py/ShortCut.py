import xbmc, xbmcgui


def ShortCut():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7, click_8, click_9, click_10, click_11, click_12)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]~ Mix~[/COLOR][/B]', 
['[B][COLOR=orange]ΑΝΑΖΗΤΗΣΗ[/COLOR][/B]',
 '[COLOR=white]New Movies - One Click[/COLOR] [COLOR=green](mj-Halcyon)[/COLOR]',
 '[COLOR=white]Ταινιες - Προβολές[/COLOR] [COLOR=maroon](blacklodge)[/COLOR]',
 '[COLOR=white]Σειρές -  Με πολλούς ψήφους[/COLOR] [COLOR=maroon](blacklodge)[/COLOR]',
 '[COLOR white]LIVE EVENTS[/COLOR] [COLOR=yellow](sporthdme)[/COLOR]',
 '[COLOR=white]Live Sports[/COLOR] [COLOR=red](mj-daddylive)[/COLOR]',
 '[COLOR=white]SPORTS TV[/COLOR] [COLOR=silver](tvone112)[/COLOR]',
 '[COLOR=white]LIVE TV[/COLOR] [COLOR=red](mj-daddylive)[/COLOR]',
 '[COLOR=white]Xrysoi - Παιδικά Μεταγλωτισμένα[/COLOR] [COLOR=gold](mj-cartoonsgr)[/COLOR]',
 '[COLOR=white]Xrysoi - Παιδικά Υπότιτλοι[/COLOR] [COLOR=gold](mj-cartoonsgr)[/COLOR]',
 '[COLOR=white]Ζωντανή Τηλεόραση[/COLOR] [COLOR=blue](AliveGR)[/COLOR]',
 '[COLOR=white]Sophisticated[/COLOR] [COLOR=cornflowerblue](eradio)[/COLOR]'])


    if call:
        if call < 0:
            return
        func = funcs[call-12]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.myselect/folders/py/SearchTk/SearchAll.py")')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.microjen/get_list/https://mfirepo.github.io/hal/newrels.json",return)') 


def click_3():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.blacklodge/?action=movies&url=trending")') 

def click_4():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.blacklodge/?action=tvshows&url=views")')

def click_5():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.sporthdme/?description&iconimage=C%3a%5cPortableApps%5ckodi%5cMy%20KODI%2020%5cKodi%5cportable_data%5caddons%5cplugin.video.sporthdme%5cicon.png&mode=5&name=%5bB%5d%5bCOLOR%20white%5dLIVE%20EVENTS%5b%2fCOLOR%5d%5b%2fB%5d&url=https%3a%2f%2fmy.livesoccer.sx%2f",return)')

def click_6():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.microjen/daddylive?mode=menu&serv_type=sched",return)')

def click_7():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.tvone112/list_channels/38",return)')

def click_8():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.microjen/daddylive?mode=menu&serv_type=live_tv",return)')

def click_9():
    xbmc.executebuiltin('PlayMedia("plugin://plugin.video.microjen/run_plug/plugin.video.cartoonsgr%2F%3Fdescription%26amp%3Biconimage%3Dnone%26amp%3Bmode%3Dxrysoiposts%26amp%3Bname%3D%2520%26amp%3Burl%3Dhttps%3A%2F%2Fxrysoi.pro%2Fcategory%2F%25ce%25ba%25ce%25b9%25ce%25bd-%25cf%2583%25cf%2587%25ce%25ad%25ce%25b4%25ce%25b9%25ce%25b1%2F")')

def click_10():
    xbmc.executebuiltin('PlayMedia("plugin://plugin.video.microjen/run_plug/plugin.video.cartoonsgr%2F%3Fdescription%26amp%3Biconimage%3Dnone%26amp%3Bmode%3Dxrysoiposts%26amp%3Bname%3D%2520%26amp%3Burl%3Dhttps%3A%2F%2Fxrysoi.pro%2Fcategory%2F%25ce%25ba%25ce%25b9%25ce%25bd-%25cf%2583%25cf%2587%25ce%25ad%25ce%25b4%25ce%25b9%25ce%25b1-subs%2F")')

def click_11():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.AliveGR/?action=live_tv&title=%ce%96%cf%89%ce%bd%cf%84%ce%b1%ce%bd%ce%ae%20%ce%a4%ce%b7%ce%bb%ce%b5%cf%8c%cf%81%ce%b1%cf%83%ce%b7")')

def click_12():
    xbmc.executebuiltin('ActivateWindow(10502,"plugin://plugin.audio.eradio.gr/?action=radios&title=Sophisticated&url=http%3a%2f%2feradio.mobi%2fcache%2f1%2f1%2fmedialist_categoryID11.json")')


ShortCut()
