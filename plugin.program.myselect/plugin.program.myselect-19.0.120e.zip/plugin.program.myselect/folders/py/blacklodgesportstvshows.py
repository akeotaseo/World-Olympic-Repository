import xbmc, xbmcgui

xbmcgui.Dialog().notification("[COLOR white]Sports Tvshows[/COLOR]", "Για καλύτερα αποτελέσματα χρειάζεται λογαριασμός [B][COLOR aquamarine]Real-Debrid[/COLOR][/B] (ή απο άλλη υπηρεσία)...", sound=False, icon='special://home/addons/plugin.video.blacklodge/icon.png')

xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.blacklodge/?action=tvshows&url=https%3a%2f%2fwww.imdb.com%2fsearch%2ftitle%2f%3ftitle_type%3dtv_series%2ctv_miniseries%26genres%3dsport%2c!documentary%26release_date%3d%2cdate%5b0%5d%26sort%3dmoviemeter%2casc%26count%3d40")')



