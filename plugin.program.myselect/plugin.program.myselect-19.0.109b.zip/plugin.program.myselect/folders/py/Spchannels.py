import xbmc, xbmcgui


def spchannels():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7, click_8, click_9, click_10, click_11, click_12, click_13)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]  ~ Sports Channels ~[/COLOR][/B]', 
['[COLOR=white]TvOne[/COLOR]',
 '[COLOR=white]TvOne11[/COLOR]',
 '[COLOR=white]TvOne111[/COLOR]',
 '[COLOR=white]TvOne1112[/COLOR]',
 '[COLOR=white]TvOne112[/COLOR]',

 '[COLOR=white]Ζωντανά Κανάλια [COLOR=red](daddylive)[/COLOR] microjen',

 '[COLOR=white]ESPORTES [/COLOR][COLOR=yellow](BRAZIL)[/COLOR] [COLOR=paleturquoise](OnePlay)[/COLOR]',
 '[COLOR=white][COLOR=white]DESPORTO/SPORTS [/COLOR][COLOR=green](Magellan)[/COLOR]',
 '[COLOR=white]**Sports** [/COLOR][COLOR=orange](LiveStreamsPro)[/COLOR]',
 '[COLOR lightcyan][B]CANALES [/COLOR][COLOR lightblue]VIPGOAL[/COLOR][/B][COLOR lightslategray][/COLOR] [COLOR grey](Black Ghost)[/COLOR] microjen',

 '[B][COLOR white]tv adictos[/COLOR][/B]',

 '[COLOR=white]Streamonsport[/COLOR] France [COLOR=purple](vstream)[/COLOR]',


 '[COLORwhite]SPORTS NETWORKS[/COLOR] - FIXED [COLOR red]madtitansports[/COLOR]',])



    if call:
        if call < 0:
            return
        func = funcs[call-13]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.tvone/list_channels/5")')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.tvone11/list_channels/8")')

def click_3():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.tvone111/list_channels/1")')

def click_4():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.tvone1111/list_channels/1")')
    
def click_5():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.tvone112/list_channels/38")')

def click_6():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.microjen/daddylive?mode=menu&serv_type=live_tv")')

def click_7():
    xbmc.executebuiltin('ActivateWindow(10001,"plugin://plugin.program.simple.favourites/index_of/special%3A%2F%2Fhome%2Faddons%2Fplugin.program.simple.favourites%2Ffolders%2Fesportes%2F")')

def click_8():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.Magellan_Matrix/?fanart=https%3a%2f%2fwallpapercave.com%2fwp%2fwp7245862.jpg&mode=1&name=%5bCOLOR%20lime%5d%20%3e%20%5bCOLOR%20yellow%5dDESPORTO%2fSPORTS%20%5b%2fCOLOR%5d&url=https%3a%2f%2fpastebin.com%2fraw%2fz9jHvduv")')

def click_9():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.live.streamspro/?fanart&mode=1&name=%2a%2aSports%2a%2a&url=https%3a%2f%2fiptv-org.github.io%2fiptv%2fcategories%2fsports.m3u",return)')

def click_10():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.live.streamspro/?iconimage=http%3a%2f%2fbgtv.site%2fblack%2fimg%2fdeportes.png&mode=17&regexs=%7b%27makelist%27%3a%20%7b%27name%27%3a%20%27makelist%27%2c%20%27listrepeat%27%3a%20%27%5cn%3ctitle%3e%5bCOLOR%20skyblue%5d%5b%23BG%5d%5b%2fCOLOR%5d%20%5bCOLOR%20white%5d%5bB%5d%5bmakelist.param1%5d%5b%2fB%5d%5b%2fCOLOR%5d%3c%2ftitle%3e%5cn%3clink%3e%5bmakelist.param2%5d%3c%2flink%3e%5cn%3cthumbnail%3ehttp%3a%2f%2fbgtv.site%2fblack%2fimg%2fdeportes.png%3c%2fthumbnail%3e%5cn%27%2c%20%27expres%27%3a%20%27name%5c%5cs%5c%5c%3d(.%2a%3f)%3c.%2a%3fenlace%5c%5cs%5c%5c%3d%5c%5cs(.%2a%3f)%5c%5c%3c%27%2c%20%27page%27%3a%20%27http%3a%2f%2fbgtv.site%2fplay%2fvipgoal.php%27%2c%20%27cookiejar%27%3a%20%27%27%7d%7d&url=%24doregex%5bmakelist%5d")')

def click_11():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.koditv/?action=tv_adictos&extra&page&plot&thumbnail=https%3a%2f%2fpbs.twimg.com%2fprofile_images%2f790955417841139712%2fjM8OSNJq_400x400.jpg&title=%5bB%5d%5bCOLOR%20white%5dtv%20adictos%5b%2fCOLOR%5d%5b%2fB%5d&url")')

def click_12():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.vstream/?function=showMovies&sFav=showMovies&site=streamonsport&siteUrl=31-foot-rugby-tennis-basket-f1-moto-hand-en-streaming-direct.html&title=Streamonsport")')

def click_13():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.madtitansports/search_json/https://magnetic.website/jet/TVGUIDE/TVGUIDE_Sports Networks.json?dialog=false&query=sports%20networks")')


 # '[COLORwhite]Sports[/COLOR] [COLOR gold](FHD)[/COLOR] VN Media',


# def click_13():
    # xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.vnmedia/resources/lib/mkd/ontruyenhinh/listiptv/info_iptv/?_pickle_=80049574000000000000007d94288c075f7469746c655f948c0653706f727473948c065f617267735f948c4c68747470733a2f2f7261772e67697468756275736572636f6e74656e742e636f6d2f6b676173617a2f346b7568642f6d61737465722f73706f7274732d6368616e6e656c732d346b2e6d33759468028694752e")')
spchannels()
