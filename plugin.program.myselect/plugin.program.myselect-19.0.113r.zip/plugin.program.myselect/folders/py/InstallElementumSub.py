import os, xbmc, xbmcgui

def InstallElementumSub ():
        choice = xbmcgui.Dialog().yesno('[B][COLOR red]ΠΡΟΣΟΧΗ![/COLOR][/B]', '                                          [B][COLOR orange]Πρόσθετα Torrent! [CR]                    Τα χρησιμοποιείτε με δική σας ευθύνη. [CR]                                   Προτείνεται χρήση VPN![/COLOR][/B]',
                                        yeslabel='[B][COLOR lime]Ok[/COLOR][/B]', nolabel='[B][COLOR orange]Άκυρο[/COLOR][/B]')
        if choice == 1: torrent()


def torrent():
    funcs = (click_1, click_2, click_3, click_4)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]Elementum[/COLOR][/B]', 
['[COLOR=orange]Elementum[/COLOR]',
 'Elementum [COLOR FFFF6B00]Burst[/COLOR]*',
 '[B][COLOR orange]Install Elementum[/COLOR][/B]',
 '[COLOR violet]THUNDER[/COLOR]  [COLOR red]OFF?...[/COLOR]'])
 



    if call:
        if call < 0:
            return
        func = funcs[call-4]
        return func()
    else:
        func = funcs[call]
        return func()
    return 





def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.elementum/")')
    
def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.elementum/settings/script.elementum.burst")')
    
def click_3():
    xbmc.executebuiltin('ActivateWindow(10001,"plugin://plugin.program.installelementum/?description&fanart&iconimage&mode=3&name=%5bB%5dElementum%5b%2fB%5d&setaddon&skin&url")')

def click_4():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.thethunder/")')



def TheThunder ():
        choice = xbmcgui.Dialog().yesno('[B][COLOR violet]THUNDER[/COLOR][/B]', '                Το πρόσθετο έχει και συνδέσμους Torrent. [CR]                    Το χρησιμοποιείτε με δική σας ευθύνη. [CR]                                   ',
                                        yeslabel='[B][COLOR lime]Ok[/COLOR][/B]', nolabel='[B][COLOR orange]Άκυρο[/COLOR][/B]')
        if choice == 1: (xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.thethunder/")'),
                         )




InstallElementumSub ()
