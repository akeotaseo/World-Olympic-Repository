import xbmc, xbmcgui

xbmcgui.Dialog().notification("[COLOR white]Blacklodge Tvshows[/COLOR]", "Για καλύτερα αποτελέσματα χρειάζεται λογαριασμός [B][COLOR aquamarine]Real-Debrid[/COLOR][/B] (ή απο άλλη υπηρεσία)...", sound=False, icon='special://home/addons/plugin.video.blacklodge/icon.png')

xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.blacklodge/?action=tvNavigator")')



