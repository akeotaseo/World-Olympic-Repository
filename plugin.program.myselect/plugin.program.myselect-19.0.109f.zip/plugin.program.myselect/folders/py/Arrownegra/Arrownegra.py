import xbmc, xbmcgui


def Arrownegra():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7, click_8, click_9, click_10, click_11, click_12, click_13, click_14, click_15, click_16, click_17, click_18, click_19, click_20, click_21, click_22, click_23, click_24, click_25, click_26, click_27, click_28, click_29, click_30, click_31, click_32, click_33, click_34, click_35)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]  ~ ArrowNegra ~[/COLOR][/B]', 
['[B][COLOR=white]X-codes[/COLOR][/B]',
 '[COLOR maroon]ÁGUIA[/COLOR] [COLOR gold]BRANCA[/COLOR] (PORTAL)',
 '[COLOR red]Águia[/COLOR] [COLOR yellow]Negra[/COLOR] (MULTI)',
 '[COLOR red]Flecha[/COLOR] [COLOR grey]Negra[/COLOR] (MULTI)',
 '[COLORred] Dwight_[COLORgold]Farrokh_Lista[/COLOR]',
 '[COLOR grey]Black [COLORorange]Truck[/COLOR] (CANAIS)',
 '[COLORlime]steel[/COLOR] [COLORmaroon]eagle[/COLOR] (CANAIS)',
 '[COLORlime]Vultur[/COLOR] [COLORmaroon]foc[/COLOR] (CANAIS)',
 '[COLORgrey]Águia [COLORbrown]Real[/COLOR] (CANAIS)',
 '[COLORred]Águia [COLORwhite]Vavoo[/COLOR]',
 '[COLOR grey]fenix [COLORorange]portal[/COLOR] (CANAIS-VOD)',
 '[COLORcyan]Fenix [COLORgrey]Mac[/COLOR]...',
 '[COLORgrey]ArrowNegra[/COLOR] [COLORred]Play[/COLOR] [COLORcyan]Tv[/COLOR]',
 'ArrowLSP (LiveStreamsPro)',
 '[COLORgrey]ArrowNegra[/COLOR] [COLORred]Play[/COLOR] [COLORcyan]Tv[/COLOR] (iptv-org)',
 '[COLOR orange]K-PT[/COLOR] (CANAIS)',
 '[COLORorange]Infinity[/COLOR] (CANAIS)',
 '[COLORlime]Aguia[/COLOR] [COLORyellow]Lobo[/COLOR] (CANAIS)',
 '[COLOR green]KodiLoucos [/COLOR][COLORgold] Brasil[/COLOR] (MULTI)',
 '[COLOR orange]Flash[/COLOR][COLORlime]Brasil[/COLOR] ...',
 '[COLORcyan]Aqua[/COLOR] [COLORgold]Man[/COLOR] [COLORgrey]Portugal[/COLOR] (PORTAL)',
 '[COLORred]Flecha[COLORgrey]Negra [COLORgold]Vip[/COLOR] (PORTAL)',
 '[COLORred]Aguia[COLORgold]Gold[/COLOR] [COLOR grey](PORTAL)[/COLOR]',
 '[COLOR red]predator [COLORorange]portal [COLOR grey](PORTAL)[/COLOR]',
 '[COLOR lime]Port[COLORgrey]ugal[/COLOR] [COLOR grey](PORTAL)[/COLOR]',
 '[COLOR grey]Adler[COLORblack]Deu[COLORred]tsch[COLORyellow]land[/COLOR] [COLOR grey](PORTAL)[/COLOR]',
 '[COLOR orange]kodi[/COLOR] [COLOR orange]azor[/COLOR] (PORTAL)',
 '[COLOR red]Aguillas Douradas[/COLOR] [COLORorange]Portal TV[/COLOR] (PORTAL)',
 '[COLORlime]Vultur[/COLOR] [COLORmaroon]foc.portal[/COLOR] (PORTAL)',
 '[COLOR lime]IncoGnit[/COLOR] (CANAIS)',
 '[COLORred] Eagle.[/COLOR][COLORgold]Africa[/COLOR] (FREE)',
 '[COLORred] Eagle.[/COLOR][COLORgold]Franca[/COLOR] (FREE)',
 '[COLORred] Eagle.[/COLOR][COLORgold]Latinos[/COLOR] (FREE)',
 '[COLORred] Eagle.[/COLOR][COLORgold]Usa[/COLOR] (FREE)',
 '[COLORlime]black[/COLOR] [COLORmaroon]arrow18[/COLOR]'
 ])
 #'[B][COLOR orchid]¤[/COLOR] [B][COLOR white]LIVE CHANNELS[/COLOR] [COLOR orchid] (DL)[/COLOR] [COLOR orchid]¤[/COLOR][/B] (THE CREW)',


    if call:
        if call < 0:
            return
        func = funcs[call-35]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.myselect/folders/py/Arrownegra/x-codes.py")')

def click_2():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.myselect/folders/py/Arrownegra/aguia-branca.py")')

def click_3():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.aguianegra/",return)')

def click_4():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.flechanegra/",return)')
    
def click_5():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.Dwight_Farrokh_Lista/",return)')

def click_6():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.blacktruck/",return)')
    
def click_7():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.steel_eagle/",return)')

def click_8():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.vultur.de.foc.portal/",return)')

def click_9():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.aguia_real/",return)')
    
def click_10():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.aguiavavoo/",return)')

def click_11():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.fenix.portal/",return)')

def click_12():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.fenix-mac/",return)')

def click_13():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.arrownegra.play.tv/",return)')
    
def click_14():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.arrow.lsp/",return)')
    
def click_15():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.arrownegra.play.tv/",return)')
    
def click_16():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.K-PT/",return)')

def click_17():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.infinity/",return)')
    
def click_18():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.aguia.lobo/",return)')
    
def click_19():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.kodiloucos_brasil/",return)')

def click_20():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.flash.brasil/",return)')

def click_21():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.aquaman.portugal/",return)')

def click_22():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.flechanegra.vip/",return)')

def click_23():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.aguiagold/",return)')

def click_24():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.predator.portal/",return)')

def click_25():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.portugal/",return)')

def click_26():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.adler.deutschland/",return)')

def click_27():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.kodiazor/",return)')

def click_28():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.aguillas.douradas.portal/",return)')

def click_29():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.vultur.de.foc.portal/",return)')

def click_30():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.IncoGnit/",return)')

def click_31():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.eagle.africa/",return)')

def click_32():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.eagle.franca/",return)')

def click_33():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.eagle.latinos/",return)')

def click_34():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.eagle.usa/",return)')

def click_35():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.blackarrow18/",return)')

Arrownegra()
