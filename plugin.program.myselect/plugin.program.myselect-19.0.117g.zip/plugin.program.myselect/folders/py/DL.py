import xbmc, xbmcgui

def dl():
    funcs = (click_1, click_2, click_3, click_4)
    call = xbmcgui.Dialog().select('[COLOR=red]~ Daddylive ~[/COLOR]', 
['[B][COLOR=darkviolet]Daddylive[/COLOR][/B]  (THE CREW)',

 '[COLORred][B]Daddylive[/COLOR][/B] (GKoBu)',

 '[COLOR=yellow]DaddyLive V2[/COLOR]  (X)',
 '[COLOR=slateblue]DaddyLiveHD[/COLOR]  (FubuZ)'])


    if call:
        if call < 0:
            return
        func = funcs[call-4]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.daddylive/",return)')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.microjen/daddylive",return)')

def click_3():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.dlv2/",return)')

def click_4():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.daddylivehd/,return")')

dl()

