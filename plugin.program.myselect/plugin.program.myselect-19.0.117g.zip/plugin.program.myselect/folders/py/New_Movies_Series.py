import xbmc, xbmcgui

xbmc.executebuiltin('Dialog.Close(all,true)')

xbmcgui.Dialog().notification("[COLOR white]Νέες Ταινίες / Επεισόδια[/COLOR]", "[COLOR=red]Blacklodge[/COLOR]", sound=False, icon='special://home/addons/plugin.video.blacklodge/icon.png')
# xbmc.sleep(4000)

# xbmcgui.Dialog().notification("[COLOR white]Πρόσφατες προσθήκες[/COLOR]", "[COLORlime]Tenies-οnline[/COLOR]", sound=False, icon='special://home/addons/plugin.video.microjen/icon.png')
# xbmc.sleep(4000)




def tvone():
    funcs = (click_1, click_2, click_3)
    call = xbmcgui.Dialog().select('[B][COLOR=lime]Νέες Ταινίες / Επεισόδια[/COLOR][/B]', 
['[B][COLOR=white]Νέες Ταινίες[/B] [COLOR=red](Blacklodge)[/COLOR]',
 '[B][COLOR=white]Νέα Επεισόδια[/B] [COLOR=red](Blacklodge)[/COLOR]',
 '[COLOR=white]Πρόσφατες προσθήκες [COLORlime]Tenies-οnline [COLOR=orange](MicroJen)[/COLOR]'])





    if call:
        if call < 0:
            return
        func = funcs[call-3]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.blacklodge/?action=movieWidget")')

def click_2():
    xbmcgui.Dialog().ok('[B][COLOR white]Νέα Επεισόδια[/COLOR][/B]', 'Για καλύτερα αποτελέσματα χρειάζεται λογαριασμός[CR][B][COLOR aquamarine]Real-Debrid[/COLOR][/B][CR](ή λογαριασμός απο άλλη υπηρεσία)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.blacklodge/?action=tvWidget")')

def click_3():
    xbmcgui.Dialog().notification("[COLOR white]Πρόσφατες προσθήκες[/COLOR]", "[COLORlime]Tenies-οnline[/COLOR]", sound=False, icon='special://home/addons/plugin.video.microjen/icon.png')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.myselect/?group=microjen-test-1747067374.1555417&mode=group&refresh&reload")')

tvone()
