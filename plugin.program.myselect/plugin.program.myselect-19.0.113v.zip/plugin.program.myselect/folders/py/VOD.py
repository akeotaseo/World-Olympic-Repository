import os, xbmc, xbmcvfs, xbmcgui, xbmcaddon, shutil, glob
xbmcgui.Dialog().notification("[B][COLOR orange]They don't always work[/COLOR][/B]", "[COLOR green]Δεν λειτουργούν πάντα...[/COLOR]", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/doestworkalltime.png')
# xbmc.sleep(4000)
def vod():
    funcs = (click_1, click_2)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]~ VOD ~[/COLOR][/B]', 
[
 '[B][COLOR=blue]VOD[/COLOR][/B] tv.premiumplus.tv  (mac_player)',

 '[B][COLOR=orange]VOD[/COLOR][/B] monstertv.site  (my_iptv)'
])


    if call:
        if call < 0:
            return
        func = funcs[call-2]
        return func()
    else:
        func = funcs[call]
        return func()
    return 




def click_1():
    choice = xbmcgui.Dialog().yesno('[COLOR orange]tv.premiumplus.tv[/COLOR]', '1. Πατήστε [B][COLOR=blue]VOD[/COLOR][/B][CR]2. Επιλέξτε [B]MAC[/B][CR]3. Διαλέξτε [B]VOD Ταινίες[/B] ή [B]VOD Σειρές[/B][CR]--- Σε περίπτωση Αποτυχίας Απαραγωγής... δοκιμάζουμε άλλη [B]MAC[/B]',
        
                                        nolabel='[B][COLOR white]Άκυρο[/COLOR][/B]',yeslabel='[B][COLOR=blue]VOD[/COLOR][/B]')

    if choice == 1: xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.downloader/?_id&description&episode_number&fanart&foldername&icon=C%3a%5cPortableApps%5ckodi%5ckodi%20World%2021%5cKodi%5cportable_data%5caddons%5cplugin.program.downloader%5cresources%5cicons%5ciptv.png&mediatype=video&mode=mac_player_sel_mac&name=tv.premiumplus.tv&name2&page&season_number&url=%7b%22portal_server%22%3a%20%22http%3a%2f%2ftv.premiumplus.tv%2fc%2f%22%2c%20%22server_macs%22%3a%20%22%5b%5c%2200%3a1A%3a79%3a02%3a63%3a92%5c%22%2c%20%5c%2200%3a1A%3a79%3a05%3aC9%3a75%5c%22%2c%20%5c%2200%3a1A%3a79%3a0A%3aAC%3a74%5c%22%2c%20%5c%2200%3a1A%3a79%3a13%3a04%3a84%5c%22%2c%20%5c%2200%3a1A%3a79%3a13%3a28%3a49%5c%22%2c%20%5c%2200%3a1A%3a79%3a13%3aC5%3aE0%5c%22%2c%20%5c%2200%3a1A%3a79%3a18%3a0A%3a18%5c%22%2c%20%5c%2200%3a1A%3a79%3a18%3a0C%3a46%5c%22%2c%20%5c%2200%3a1A%3a79%3a21%3aBD%3a9C%5c%22%2c%20%5c%2200%3a1A%3a79%3a22%3a40%3aBF%5c%22%2c%20%5c%2200%3a1A%3a79%3a24%3a98%3aC2%5c%22%2c%20%5c%2200%3a1A%3a79%3a25%3a91%3aD6%5c%22%2c%20%5c%2200%3a1A%3a79%3a2E%3a7F%3a25%5c%22%2c%20%5c%2200%3a1A%3a79%3a32%3aC8%3aEF%5c%22%2c%20%5c%2200%3a1A%3a79%3a3B%3a6F%3aEC%5c%22%2c%20%5c%2200%3a1A%3a79%3a40%3a6F%3a5B%5c%22%2c%20%5c%2200%3a1A%3a79%3a45%3a30%3aAF%5c%22%2c%20%5c%2200%3a1A%3a79%3a46%3a37%3a2D%5c%22%2c%20%5c%2200%3a1A%3a79%3a4A%3aF9%3a48%5c%22%2c%20%5c%2200%3a1A%3a79%3a4F%3a61%3a0D%5c%22%2c%20%5c%2200%3a1A%3a79%3a52%3a5D%3aB4%5c%22%2c%20%5c%2200%3a1A%3a79%3a54%3aCA%3a4A%5c%22%2c%20%5c%2200%3a1A%3a79%3a5F%3a76%3a00%5c%22%2c%20%5c%2200%3a1A%3a79%3a60%3aD3%3a59%5c%22%2c%20%5c%2200%3a1A%3a79%3a6C%3a21%3a0A%5c%22%2c%20%5c%2200%3a1A%3a79%3a73%3aC2%3a42%5c%22%2c%20%5c%2200%3a1A%3a79%3a73%3aC8%3a40%5c%22%2c%20%5c%2200%3a1A%3a79%3a74%3a1F%3aF3%5c%22%2c%20%5c%2200%3a1A%3a79%3a75%3a63%3a44%5c%22%2c%20%5c%2200%3a1A%3a79%3a77%3a82%3aB7%5c%22%2c%20%5c%2200%3a1A%3a79%3a77%3a84%3a03%5c%22%2c%20%5c%2200%3a1A%3a79%3a78%3a8A%3a02%5c%22%2c%20%5c%2200%3a1A%3a79%3a79%3a9B%3aCE%5c%22%2c%20%5c%2200%3a1A%3a79%3a7A%3a44%3a3C%5c%22%2c%20%5c%2200%3a1A%3a79%3a7B%3a51%3a8B%5c%22%2c%20%5c%2200%3a1A%3a79%3a7B%3aCB%3a50%5c%22%2c%20%5c%2200%3a1A%3a79%3a7C%3aFE%3aEE%5c%22%2c%20%5c%2200%3a1A%3a79%3a7D%3aDA%3a07%5c%22%2c%20%5c%2200%3a1A%3a79%3a7F%3a71%3a45%5c%22%2c%20%5c%2200%3a1A%3a79%3a92%3a8E%3a94%5c%22%2c%20%5c%2200%3a1A%3a79%3aA2%3aC4%3a57%5c%22%2c%20%5c%2200%3a1A%3a79%3aA3%3aA5%3a46%5c%22%2c%20%5c%2200%3a1A%3a79%3aA6%3a73%3a14%5c%22%2c%20%5c%2200%3a1A%3a79%3aAA%3a4B%3aB9%5c%22%2c%20%5c%2200%3a1A%3a79%3aAD%3aD0%3a59%5c%22%2c%20%5c%2200%3a1A%3a79%3aAF%3a12%3aC9%5c%22%2c%20%5c%2200%3a1A%3a79%3aAF%3a6D%3a4E%5c%22%2c%20%5c%2200%3a1A%3a79%3aAF%3aA5%3aAD%5c%22%2c%20%5c%2200%3a1A%3a79%3aB2%3a71%3a75%5c%22%2c%20%5c%2200%3a1A%3a79%3aB3%3aE2%3a22%5c%22%2c%20%5c%2200%3a1A%3a79%3aB4%3aDC%3aF1%5c%22%2c%20%5c%2200%3a1A%3a79%3aB4%3aF0%3a6E%5c%22%2c%20%5c%2200%3a1A%3a79%3aB5%3a0D%3aFF%5c%22%2c%20%5c%2200%3a1A%3a79%3aB5%3a10%3aD1%5c%22%2c%20%5c%2200%3a1A%3a79%3aB5%3a19%3a8D%5c%22%2c%20%5c%2200%3a1A%3a79%3aB5%3aD7%3a0B%5c%22%2c%20%5c%2200%3a1A%3a79%3aBE%3a09%3aD6%5c%22%2c%20%5c%2200%3a1A%3a79%3aBE%3aB9%3aA0%5c%22%2c%20%5c%2200%3a1A%3a79%3aBF%3aA5%3aD0%5c%22%2c%20%5c%2200%3a1A%3a79%3aC1%3a2C%3aFF%5c%22%2c%20%5c%2200%3a1A%3a79%3aC2%3a40%3a91%5c%22%2c%20%5c%2200%3a1A%3a79%3aC3%3a8E%3a7E%5c%22%2c%20%5c%2200%3a1A%3a79%3aC4%3a31%3a8B%5c%22%2c%20%5c%2200%3a1A%3a79%3aC4%3aA8%3aDF%5c%22%2c%20%5c%2200%3a1A%3a79%3aCB%3a86%3a95%5c%22%2c%20%5c%2200%3a1A%3a79%3aCC%3a1F%3a05%5c%22%2c%20%5c%2200%3a1A%3a79%3aCF%3a50%3aF7%5c%22%2c%20%5c%2200%3a1A%3a79%3aD3%3aB1%3aCA%5c%22%2c%20%5c%2200%3a1A%3a79%3aD4%3aDC%3a6B%5c%22%2c%20%5c%2200%3a1A%3a79%3aD5%3a4C%3aA4%5c%22%2c%20%5c%2200%3a1A%3a79%3aD5%3a5F%3a4C%5c%22%2c%20%5c%2200%3a1A%3a79%3aDE%3aFB%3aE2%5c%22%2c%20%5c%2200%3a1A%3a79%3aE5%3aA8%3a42%5c%22%2c%20%5c%2200%3a1A%3a79%3aE6%3a1E%3a54%5c%22%2c%20%5c%2200%3a1A%3a79%3aE9%3aA5%3a1B%5c%22%2c%20%5c%2200%3a1A%3a79%3aEE%3a6A%3a50%5c%22%2c%20%5c%2200%3a1A%3a79%3aF0%3aC9%3a32%5c%22%2c%20%5c%2200%3a1A%3a79%3aF2%3a98%3a3A%5c%22%2c%20%5c%2200%3a1A%3a79%3aF5%3a38%3a5F%5c%22%2c%20%5c%2200%3a1A%3a79%3aF9%3a71%3a37%5c%22%2c%20%5c%2200%3a1A%3a79%3aFB%3a14%3a26%5c%22%2c%20%5c%2200%3a1A%3a79%3aFB%3a3A%3a61%5c%22%2c%20%5c%2200%3a1A%3a79%3aFF%3a04%3aE0%5c%22%2c%20%5c%2200%3a1A%3a79%3aFF%3aD8%3aB4%5c%22%5d%22%7d",return)')



def click_2():
    choice = xbmcgui.Dialog().yesno('[COLOR orange]monstertv[/COLOR]', '1. Πατήστε [B][COLOR=blue]VOD[/COLOR][/B][CR]2. Επιλέξτε [B] URL[/B][CR]3. Διαλέξτε [B]VOD Ταινίες[/B] ή [B]VOD Σειρές[/B][CR]--- Σε περίπτωση Αποτυχίας Απαραγωγής... δοκιμάζουμε άλλο [B]URL[/B]',
        
                                        nolabel='[B][COLOR white]Άκυρο[/COLOR][/B]',yeslabel='[B][COLOR=blue]VOD[/COLOR][/B]')

    if choice == 1: xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.downloader/?_id&description&episode_number&fanart&foldername&icon=C%3a%5cPortableApps%5ckodi%5ckodi%20World%2021%5cKodi%5cportable_data%5caddons%5cplugin.program.downloader%5cresources%5cicons%5cxcodes.jpg&mediatype=video&mode=get_remote_xcodes&name=Remote%20x-treme%20codes%20%ce%bb%ce%af%cf%83%cf%84%ce%b5%cf%82&name2&page&season_number&url=%7b%22url%22%3a%20%22https%3a%2f%2fraw.githubusercontent.com%2fakeotaseo%2fworld_repo%2frefs%2fheads%2fmain%2fUpdater_Matrix%2fXML2%2fmonstertv.txt%22%7d")')


vod()
