import os, xbmc, xbmcvfs, xbmcgui, xbmcaddon, shutil, glob
xbmcgui.Dialog().notification("[B][COLOR orange]They don't always work[/COLOR][/B]", "[COLOR green]Δεν λειτουργούν πάντα...[/COLOR]", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/doestworkalltime.png')
# xbmc.sleep(4000)
def vod():
    funcs = (click_1, click_2)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]~ VOD ~[/COLOR][/B]', 
[
 '[B][COLOR=blue]VOD[/COLOR][/B] mag.realvip.co  (mac_player)',

 '[B][COLOR=orange]VOD[/COLOR][/B] monstertv.site  (my_iptv)'
])


    if call:
        if call < 0:
            return
        func = funcs[call-2]
        return func()
    else:
        func = funcs[call]
        return func()
    return 




def click_1():
    choice = xbmcgui.Dialog().yesno('[COLOR orange]mag.realvip.co[/COLOR]', '1. Πατήστε [B][COLOR=blue]VOD[/COLOR][/B][CR]2. Επιλέξτε [B]MAC[/B][CR]3. Διαλέξτε [B]VOD Ταινίες[/B] ή [B]VOD Σειρές[/B][CR]--- Σε περίπτωση Αποτυχίας Απαραγωγής... δοκιμάζουμε άλλη [B]MAC[/B]',
        
                                        nolabel='[B][COLOR white]Άκυρο[/COLOR][/B]',yeslabel='[B][COLOR=blue]VOD[/COLOR][/B]')

    if choice == 1: xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.downloader/?_id&description&episode_number&fanart&foldername&icon=C%3a%5cPortableApps%5ckodi%5ckodi%20World%2021%20ALL%5cKodi%5cportable_data%5caddons%5cplugin.program.downloader%5cresources%5cicons%5ciptv.png&mediatype=video&mode=mac_player_sel_mac&name=mag.realvip.co&name2&page&season_number&url=%7b%22portal_server%22%3a%20%22http%3a%2f%2fmag.realvip.co%2fc%2f%22%2c%20%22server_macs%22%3a%20%22%5b%5c%2200%3a1A%3a79%3a08%3a34%3aB6%5c%22%2c%20%5c%2200%3a1A%3a79%3a0A%3a6C%3aCF%5c%22%2c%20%5c%2200%3a1A%3a79%3a0E%3a65%3a2A%5c%22%2c%20%5c%2200%3a1A%3a79%3a11%3a8B%3a0D%5c%22%2c%20%5c%2200%3a1A%3a79%3a17%3a54%3a0F%5c%22%2c%20%5c%2200%3a1A%3a79%3a19%3a30%3a72%5c%22%2c%20%5c%2200%3a1A%3a79%3a1B%3a69%3a92%5c%22%2c%20%5c%2200%3a1A%3a79%3a21%3a0E%3aA8%5c%22%2c%20%5c%2200%3a1A%3a79%3a24%3a98%3aC2%5c%22%2c%20%5c%2200%3a1A%3a79%3a26%3a8B%3aE9%5c%22%2c%20%5c%2200%3a1A%3a79%3a29%3a2C%3aC5%5c%22%2c%20%5c%2200%3a1A%3a79%3a2C%3a97%3a3E%5c%22%2c%20%5c%2200%3a1A%3a79%3a3B%3a04%3a0B%5c%22%2c%20%5c%2200%3a1A%3a79%3a40%3aA7%3aB7%5c%22%2c%20%5c%2200%3a1A%3a79%3a4B%3aA3%3a44%5c%22%2c%20%5c%2200%3a1A%3a79%3a4D%3a3A%3a42%5c%22%2c%20%5c%2200%3a1A%3a79%3a52%3a5D%3aB4%5c%22%2c%20%5c%2200%3a1A%3a79%3a59%3a6F%3a37%5c%22%2c%20%5c%2200%3a1A%3a79%3a73%3a98%3a4B%5c%22%2c%20%5c%2200%3a1A%3a79%3a7C%3a5F%3a22%5c%22%2c%20%5c%2200%3a1A%3a79%3a81%3a5C%3a15%5c%22%2c%20%5c%2200%3a1A%3a79%3a81%3aD4%3a51%5c%22%2c%20%5c%2200%3a1A%3a79%3a83%3a67%3a97%5c%22%2c%20%5c%2200%3a1A%3a79%3a8C%3a07%3aA0%5c%22%2c%20%5c%2200%3a1A%3a79%3a97%3a0C%3a5B%5c%22%2c%20%5c%2200%3a1A%3a79%3aA3%3aA5%3a46%5c%22%2c%20%5c%2200%3a1A%3a79%3aAD%3a93%3a4F%5c%22%2c%20%5c%2200%3a1A%3a79%3aAE%3a69%3a11%5c%22%2c%20%5c%2200%3a1A%3a79%3aB0%3a0E%3aE8%5c%22%2c%20%5c%2200%3a1A%3a79%3aB1%3a01%3a7A%5c%22%2c%20%5c%2200%3a1A%3a79%3aB4%3a39%3a19%5c%22%2c%20%5c%2200%3a1A%3a79%3aB4%3aDC%3aF1%5c%22%2c%20%5c%2200%3a1A%3a79%3aB5%3a2A%3a2F%5c%22%2c%20%5c%2200%3a1A%3a79%3aB5%3a9A%3a0F%5c%22%2c%20%5c%2200%3a1A%3a79%3aB5%3aF7%3a9C%5c%22%2c%20%5c%2200%3a1A%3a79%3aB6%3a01%3aE8%5c%22%2c%20%5c%2200%3a1A%3a79%3aB6%3a42%3a06%5c%22%2c%20%5c%2200%3a1A%3a79%3aB6%3aAF%3aA9%5c%22%2c%20%5c%2200%3a1A%3a79%3aB6%3aB9%3a89%5c%22%2c%20%5c%2200%3a1A%3a79%3aB6%3aD6%3aC5%5c%22%2c%20%5c%2200%3a1A%3a79%3aB8%3a4A%3a02%5c%22%2c%20%5c%2200%3a1A%3a79%3aBF%3a91%3aA0%5c%22%2c%20%5c%2200%3a1A%3a79%3aBF%3aB5%3a9F%5c%22%2c%20%5c%2200%3a1A%3a79%3aC3%3a1E%3aDD%5c%22%2c%20%5c%2200%3a1A%3a79%3aC3%3aE0%3a8D%5c%22%2c%20%5c%2200%3a1A%3a79%3aC5%3a2C%3aBC%5c%22%2c%20%5c%2200%3a1A%3a79%3aC5%3a91%3aC9%5c%22%2c%20%5c%2200%3a1A%3a79%3aCC%3a0A%3a68%5c%22%2c%20%5c%2200%3a1A%3a79%3aD3%3a0A%3a5F%5c%22%2c%20%5c%2200%3a1A%3a79%3aE6%3aD7%3aF5%5c%22%2c%20%5c%2200%3a1A%3a79%3aE9%3aA5%3a1B%5c%22%2c%20%5c%2200%3a1A%3a79%3aF2%3aCD%3a86%5c%22%2c%20%5c%2200%3a1A%3a79%3aF8%3a8C%3a50%5c%22%2c%20%5c%2200%3a1A%3a79%3aFB%3a1E%3aB7%5c%22%2c%20%5c%2200%3a1A%3a79%3aFF%3a09%3a5B%5c%22%5d%22%7d")')



def click_2():
    choice = xbmcgui.Dialog().yesno('[COLOR orange]monstertv[/COLOR]', '1. Πατήστε [B][COLOR=blue]VOD[/COLOR][/B][CR]2. Επιλέξτε [B] URL[/B][CR]3. Διαλέξτε [B]VOD Ταινίες[/B] ή [B]VOD Σειρές[/B][CR]--- Σε περίπτωση Αποτυχίας Απαραγωγής... δοκιμάζουμε άλλο [B]URL[/B]',
        
                                        nolabel='[B][COLOR white]Άκυρο[/COLOR][/B]',yeslabel='[B][COLOR=blue]VOD[/COLOR][/B]')

    if choice == 1: xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.downloader/?_id&description&episode_number&fanart&foldername&icon=C%3a%5cPortableApps%5ckodi%5ckodi%20World%2021%5cKodi%5cportable_data%5caddons%5cplugin.program.downloader%5cresources%5cicons%5cxcodes.jpg&mediatype=video&mode=get_remote_xcodes&name=Remote%20x-treme%20codes%20%ce%bb%ce%af%cf%83%cf%84%ce%b5%cf%82&name2&page&season_number&url=%7b%22url%22%3a%20%22https%3a%2f%2fraw.githubusercontent.com%2fakeotaseo%2fworld_repo%2frefs%2fheads%2fmain%2fUpdater_Matrix%2fXML2%2fmonstertv.txt%22%7d")')


vod()
