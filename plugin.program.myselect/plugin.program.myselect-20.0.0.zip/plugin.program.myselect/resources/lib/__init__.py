"""All Python scripts for MySelect go here."""
