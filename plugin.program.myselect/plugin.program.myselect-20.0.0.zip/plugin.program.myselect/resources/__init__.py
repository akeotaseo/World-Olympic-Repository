"""The base resources folder for MySelect."""
