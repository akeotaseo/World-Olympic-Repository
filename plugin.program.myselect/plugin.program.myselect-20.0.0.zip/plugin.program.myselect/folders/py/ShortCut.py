# -*- coding: utf-8 -*-
import xbmc
import xbmcgui


def ShortCut():
    # 1. Ορίζουμε τις επιλογές του μενού (Όνομα, Υπότιτλος, Εικονίδιο, Περιγραφή, Builtin / Script)
    menu_items = [
        {
            "label": "[COLOR orange]ΠΡΟΤΙΜΗΣΕΙΣ[/COLOR]",
            "subtitle": "Αγαπημένα & Συντομεύσεις",
            "icon": "special://home/addons/plugin.program.mypreferences/icon.png",
            "plot": "(My Preferences)",
            "builtin": 'ActivateWindow(10025,"plugin://plugin.program.mypreferences/?content_type=video&fanart=special%3a%2f%2fhome%2faddons%5cplugin.program.mypreferences%5cfanart.jpg&image=special%3a%2f%2fhome%2faddons%5cplugin.program.mypreferences%5cicon.png&label=My%20Preferences&mode=400&path=special%3a%2f%2fprofile%2faddon_data%2fplugin.program.mypreferences%5cSuper%20Favourites%5cMy%20Preferences")'
        },
        {
            "label": "[COLOR gold]ΑΝΑΖΗΤΗΣΗ[/COLOR]",
            "subtitle": "Καθολική Αναζήτηση Περιεχομένου",
            "icon": "icon_search.png",
            "plot": "(SearchAll)",
            "script": "special://home/addons/plugin.program.myselect/folders/py/SearchTk/SearchAll.py"
        },
        {
            "label": "[COLOR orange]Ταινιες - Προβολές[/COLOR]",
            "subtitle": "Δημοφιλείς Ταινίες",
            "icon": "special://home/addons/plugin.video.blacklodge/icon.png",
            "plot": "(Blacklodge)",
            "builtin": 'ActivateWindow(10025,"plugin://plugin.video.blacklodge/?action=movies&url=trending")'
        },
        {
            "label": "[COLOR orange]Σειρές - Με πολλούς ψήφους[/COLOR]",
            "subtitle": "Κορυφαίες Σειρές",
            "icon": "special://home/addons/plugin.video.blacklodge/icon.png",
            "plot": "(Blacklodge)",
            "builtin": 'ActivateWindow(10025,"plugin://plugin.video.blacklodge/?action=tvshows&url=tmdb_voted")'
        },
        {
            "label": "[COLOR green]Πλήρες Πρόγραμμα Αγώνων[/COLOR]",
            "subtitle": "SportHD Events",
            "icon": "https://raw.githubusercontent.com/bugatsinho/bugatsinho.github.io/master/plugin.video.sporthdme/icon.png",
            "plot": "(MicroJen - SportHD)",
            "builtin": 'ActivateWindow(10025,"plugin://plugin.video.microjen/sporthd?description=Daily%20events%20list&iconimage=https%3a%2f%2fraw.githubusercontent.com%2fbugatsinho%2fbugatsinho.github.io%2fmaster%2fplugin.video.sporthdme%2ficon.png&mode=events&name=%5bB%5d-%20%5bCOLOR%20white%5dSport%5bCOLOR%20gold%5dHD%5bCOLOR%20white%5d%20-%20%ce%a0%ce%bb%ce%ae%cf%81%ce%b5%cf%82%20%ce%a0%cf%81%cf%8c%ce%b3%cf%81%ce%b1%ce%bc%ce%bc%ce%b1%20%ce%91%ce%b3%cf%8e%ce%bd%cf%89%ce%bd%5b%2fCOLOR%5d%5b%2fB%5d&url=https%3a%2f%2fleague.st%2f")'
        },
        {
            "label": "[COLOR green]Live Sports[/COLOR]",
            "subtitle": "Ζωντανοί Αγώνες",
            "icon": "special://home/addons/skin.19MatrixWorld/media/DaddyLive.jpg",
            "plot": "(MicroJen - Daddylive)",
            "builtin": 'ActivateWindow(10025,"plugin://plugin.video.microjen/daddylive?mode=menu&serv_type=sched")'
        },
        # {
            # "label": "[COLOR cornflowerblue]SPORTS TV[/COLOR] ([COLOR red]OFF?...[/COLOR])",
            # "subtitle": "Αθλητικά Κανάλια",
            # "icon": "special://home/addons/plugin.video.tvone112/icon.png",
            # "plot": "(Tvone112)",
            # "builtin": 'ActivateWindow(10025,"plugin://plugin.video.tvone112/list_channels/38")'
        # },
        {
            "label": "[COLOR cornflowerblue]LIVE TV[/COLOR]",
            "subtitle": "Ζωντανά Τηλεοπτικά Κανάλια",
            "icon": "special://home/addons/skin.19MatrixWorld/media/DaddyLive.jpg",
            "plot": "(MicroJen - Daddylive)",
            "builtin": 'ActivateWindow(10025,"plugin://plugin.video.microjen/daddylive?mode=menu&serv_type=live_tv")'
        },
        {
            "label": "[COLOR hotpink]Tainiomania - Παιδικά[/COLOR]",
            "subtitle": "Παιδικές Ταινίες & Σειρές",
            "icon": "special://home/addons/plugin.video.cartoonsgr/icon.png",
            "plot": "(MicroJen - cartoonsgr)",
            "builtin": 'ActivateWindow(10025,"plugin://plugin.program.myselect/?group=color_hotpinktainiomania_-_color-1795256707.9704783&mode=group&refresh&reload")'

        },
        {
            "label": "[B][COLORdodgerblue]Greek Android IPTV (Full list)[/COLOR][/B]",
            "subtitle": "Ελληνικές Λίστες M3U",
            "icon": "special://home/addons/plugin.video.microjen/icon.png",
            "plot": "(MicroJen - Ελληνικές M3U)",
            "builtin": 'ActivateWindow(10025,"plugin://plugin.video.microjen/get_list/m3ucat|eJzLKCkpsNLXT8/OK8+sSixK0Ust1S9KLcjXdyrNzEkp1nf3zncq1a/IzSnWT8xLKcrPTNHLNS4FACTOE9Y=|all_categories")'
        },
        {
            "label": "[COLOR blue]Sophisticated[/COLOR]",
            "subtitle": "Ελληνικό Ραδιόφωνο",
            "icon": "special://home/addons/plugin.audio.eradio.gr/icon.png",
            "plot": "(Eradio)",
            "builtin": 'ActivateWindow(10502,"plugin://plugin.audio.eradio.gr/?action=radios&title=Sophisticated&url=http%3a%2f%2feradio.mobi%2fcache%2f1%2f1%2fmedialist_categoryID11.json")'
        }
    ]

    # 2. Φτιάχνουμε τη λίστα με τα αντικείμενα (ListItems)
    movie_page = []
    for item in menu_items:
        selected_title = f"[B]{item['label']}[/B]  [COLOR grey]{item['subtitle']}[/COLOR]"
        liz = xbmcgui.ListItem(selected_title)
        liz.setInfo(type="Video", infoLabels={"Title": item["label"], "Plot": item["plot"]})
        liz.setArt({'thumb': item["icon"], 'icon': item["icon"]})
        movie_page.append(liz)

    # 3. Καλούμε το select
    ret = xbmcgui.Dialog().select('[B][COLOR=orange]~ Mix ~[/COLOR][/B]', movie_page, useDetails=False)

    # 4. Έξυπνη εκτέλεση ανάλογα με τον τύπο της επιλογής
    if ret >= 0:
        chosen = menu_items[ret]
        xbmc.sleep(300)

        if "notification" in chosen:
            notif = chosen["notification"]
            xbmcgui.Dialog().notification(notif["title"], notif["msg"], sound=False, icon=notif["icon"])

        if "function" in chosen:
            chosen["function"]()
        elif "builtin" in chosen:
            xbmc.executebuiltin(chosen["builtin"])
        elif "script" in chosen:
            xbmc.executebuiltin(f'RunScript("{chosen["script"]}")')


if __name__ == '__main__':
    ShortCut()
