import xbmc, xbmcgui



def live_now():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7, click_8, click_9, click_10, click_11, click_12, click_13, click_14, click_15, click_16)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]       Live Now...[/COLOR][/B]',
['[COLOR=orange]LIVE EVENTS[/COLOR] (SportHD)',

 '[COLOR=red]DADDYLIVE[/COLOR]',


 '[COLOR=white]Streamonsport[/COLOR] [COLOR=purple](vstream)[/COLOR]',
 '[COLOR=white]Live TV[/COLOR] [COLOR=purple](vstream)[/COLOR]',


 '[COLOR=white]Live TV[/COLOR] [COLOR green](Dracarys)[/COLOR]',
 '[COLOR=white]Rojadirecta[/COLOR] [COLOR green](Dracarys)[/COLOR]',
 
 '[COLOR lightcyan][B]AGENDA [/COLOR][COLOR lightblue]ARENASPORT[/COLOR][/B]  [COLOR lightslategray] [/COLOR]',
 '[COLOR lightcyan][B]AGENDA [/COLOR][COLOR lightblue]SPORTZONLINE[/COLOR][/B]  [COLOR lightslategray] [/COLOR]',

 '[COLOR=white]JOGOS [COLOR lime] [COLOR=yellow](Aguia_De_Ouro)[/COLOR]',
 '[COLOR=white][COLOR gold]TheANONYMOUS[/COLOR][COLOR cyan] EVENTOS DESPORTIVOS  [/COLOR]',

 '[COLOR=white]USA SPORTS [COLOR=lime](The Endzone 19) [COLOR=orange](microjen)[/COLOR]',
 '[COLOR=white]Strikeout [COLOR=orange](microjen)[/COLOR] ',
 '[COLOR=white]SportsBox(non-PC) [COLOR=orange](microjen)[/COLOR]',

 '[COLOR=white]Live events(The Thao) [COLOR=crimson](vnmedia)[/COLOR]',

 '[COLOR yellow]NemesisAIO Live Sports & Replays[/COLOR]',
 
 '[COLOR=white]Daddylive [COLOR=olive](All)[/COLOR]'
 ])




    if call:
        if call < 1:
            return
        func = funcs[call-16]
        return func()
    else:
        func = funcs[call]
        return func()
    return 






def click_1():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.sporthdme/?description&iconimage=C%3a%5cPortableApps%5ckodi%5ckodi%20World%2020%5cKodi%5cportable_data%5caddons%5cplugin.video.sporthdme%5cicon.png&mode=5&name=%5bB%5d%5bCOLOR%20white%5dLIVE%20EVENTS%5b%2fCOLOR%5d%5b%2fB%5d&url=https%3a%2f%2f1.ivesoccer.sx%2f")')
    #xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.myselect/folders/py/sporthdme.py")')

def click_2():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.daddylive/?mode=menu&serv_type=sched",return)')

def click_3():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.vstream/?function=showMovies&sFav=showMovies&site=streamonsport&siteUrl=%2f&title=Streamonsport")')

def click_4():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.vstream/?function=showMovies&sFav=showMovies&site=livetv&siteUrl=https%3a%2f%2flivetv767.me%2f%2ffrx%2fallupcoming%2f&title=Les%20sports%20")')

def click_5():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.dracarys/?category=live_sport&mode=open_site&site=livetv")')

def click_6():
    
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.dracarys/?category=live_sport&mode=open_site&site=rojadirecta")')

def click_7():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.live.streamspro/?fanart=http%3a%2f%2fbgtv.xyz%2fblack%2fimg%2ffanart.jpg&mode=1&name=%20%20%5bCOLOR%20lightcyan%5d%5bB%5dAGENDA%20%5b%2fCOLOR%5d%5bCOLOR%20lightblue%5dARENASPORT%5b%2fCOLOR%5d%5b%2fB%5d%20%20%5bCOLOR%20lightslategray%5d%20%5b%2fCOLOR%5d%20&url=https%3a%2f%2fbgtv.xyz%2floves.php%3farena")')

def click_8():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.live.streamspro/?iconimage=http%3a%2f%2fbgtv.xyz%2fblack%2fimg%2fdeportes.png&mode=17&regexs=%7b%27makelist%27%3a%20%7b%27name%27%3a%20%27makelist%27%2c%20%27listrepeat%27%3a%20%27%5cn%20%20%3ctitle%3e%5bCOLOR%20deepskyblue%5d%5b%2fCOLOR%5d%20%5bCOLOR%20lightgreen%5d%5bmakelist.param1%5d%5b%2fCOLOR%5d%20%5bCOLOR%20skyblue%5d%5bB%5d%5bmakelist.param2%5d%5b%2fB%5d%5b%2fCOLOR%5d%20%20%20%5bCOLOR%20lightslategray%5d%5bI%5d%5bmakelist.param4%5d%20%5b%2fI%5d%5b%2fCOLOR%5d%3c%2ftitle%3e%20%3clink%3e%24doregex%5bgeturl2%5d%7cReferer%3dhttps%3a%2f%2fplanetfastidious.net%26amp%3bOrigin%3dhttps%3a%2f%2fplanetfastidious.net%26amp%3bUser-Agent%3dMozilla%2f5.0%20(Windows%20NT%2010.0%3b%20Win64%3b%20x64)%20AppleWebKit%2f537.36%20(KHTML%2c%20like%20Gecko)%20Chrome%2f117.0.0.0%20Safari%2f537.36%3c%2flink%3e%20%3creferer%3ehttps%3a%2f%2fplanetfastidious.net%2f%3c%2freferer%3e%20%3cthumbnail%3ehttp%3a%2f%2fbgtv.xyz%2fblack%2fimg%2fdeportes.png%3c%2fthumbnail%3e%5cn%27%2c%20%27expres%27%3a%20%27%3d(.%2a%3f)%2c(.%2a%3f)%2c(.%2a%3f)%2c(.%2a%3f)%5c%5cn%27%2c%20%27page%27%3a%20%27https%3a%2f%2fbgtv.xyz%2floves.php%3fszone%27%2c%20%27cookiejar%27%3a%20%27%27%7d%2c%20%27geturl2%27%3a%20%7b%27name%27%3a%20%27geturl2%27%2c%20%27expres%27%3a%20%27src%3d%22(.%2a%3f)%22%27%2c%20%27page%27%3a%20%27%24doregex%5bgetunpacked%5d%27%2c%20%27referer%27%3a%20%27https%3a%2f%2fsportsonline.so%2f%27%2c%20%27cookiejar%27%3a%20%27%27%7d%2c%20%27getunpacked%27%3a%20%7b%27name%27%3a%20%27getunpacked%27%2c%20%27expres%27%3a%20%22%24pyFunction%3aget_unpacked(page_data%2c%27(eval%5c%5c(function%5c%5c(p%2ca%2cc%2ck%2ce%2cd.%2a)%27%20)%22%2c%20%27page%27%3a%20%27%24doregex%5bgeturl%5d%27%2c%20%27referer%27%3a%20%27https%3a%2f%2fsportsonline.so%2fchannels%2fhd%2fhd6.php%27%2c%20%27connection%27%3a%20%27keep-alive%27%2c%20%27cookiejar%27%3a%20%27%27%7d%2c%20%27geturl%27%3a%20%7b%27name%27%3a%20%27geturl%27%2c%20%27expres%27%3a%20%27iframe%20src%3d%22(.%2b%3f)%22%27%2c%20%27page%27%3a%20%27%5bmakelist.param3%5d%27%2c%20%27cookiejar%27%3a%20%27%27%7d%7d&url=%24doregex%5bmakelist%5d")')

def click_9():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.aguia_de_ouro/jogos/name%3D%255BB%255DJOGOS%255B%252FB%255D%26iconimage%3DC%253A%255CPortableApps%255Ckodi%255CMy%2BKODI%2B21%255CKodi%255Cportable_data%255Caddons%255Cplugin.video.aguia_de_ouro%255Cicon.png%26description%3DASSISTA%2BOS%2BMELHORES%2BJOGOS")')

def click_10():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.desporto.theanonymous/?fanart=http%3a%2f%2fmilhano.pt%2fftp-milhano%2faladotv%2fTheAnonymous.Desporto%2fdesp_fanart.jpg&mode=1&name=%5bCOLOR%20yellow%5d%5bB%5dEVENTOS%20DESPORTIVOS%5b%2fB%5d%5b%2fCOLOR%5d&url=http%3a%2f%2fmilhano.pt%2fftp-milhano%2faladotv%2fTheAnonymous.Desporto%2fsportsonline2%2f")')

def click_11():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.microjen/get_list/https://l3grthu.com/ez/endzone.xml")')

def click_12():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.microjen/SportSites/get_games/Strikeout")')

def click_13():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.microjen/SportSites/get_games/SportsBox(non-PC)")')

def click_14():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.vnmedia/resources/lib/mkd/onfshare/gcs/listvmf_gcs/?_pickle_=80049553000000000000007d94288c075f7469746c655f948c1953e1bbb0204b49e1bb864e205452e1bbb043205449e1babe50948c065f617267735f948c1868747470733a2f2f6d6933732e746f702f766e6d656469619468028694752e")')

def click_15():
    xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.downloader/resources/okpn.py, ActivateWindow(10025,"plugin://plugin.video.nemesisaio/?description=Sports%20Time%2c%20Come%20On%20You%20Reds%20%23YNWA&fanart=0&iconimage=special://home/addons%5cplugin.video.nemesisaio%5cresources%5cImages%5cSports.gif&mode=1&name=%5bCOLOR%20yellow%5d%5bB%5dLive%20Sports%20%26%20Replays%5b%2fB%5d%5b%2fCOLOR%5d&url=SPORTS"))')

def click_16():
    xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.myselect/folders/py/Daddylive.py)')

live_now()
