import os, xbmc, xbmcvfs, xbmcgui, xbmcaddon, shutil, glob
xbmcgui.Dialog().notification("[B][COLOR orange]They don't always work[/COLOR][/B]", "[COLOR green]Δεν λειτουργούν πάντα...[/COLOR]", sound=False, icon='special://home/addons/plugin.video.macvod/DialogPleaseWait/doestworkalltime.png')
# xbmc.sleep(4000)
def vod():
    funcs = (click_1,click_2,click_3)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]~ VOD ~[/COLOR][/B]', 
['[B][COLOR=blue]VOD[/COLOR][/B] islacam.live  (mac_player)',
 '[B][COLOR=blue]VOD[/COLOR][/B] cmjl.online  (mac_player)',
 '[B][COLOR=blue]VOD[/COLOR][/B] darknetiptv1.ddns.net  (mac_player)'
])


    if call:
        if call < 0:
            return
        func = funcs[call-3]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    choice = xbmcgui.Dialog().yesno('[COLOR orange]mag.diamondma.club[/COLOR]', '1. Πατήστε [B][COLOR=blue]VOD[/COLOR][/B][CR]2. Επιλέξτε [B]MAC[/B][CR]3. Διαλέξτε [B]VOD Ταινίες[/B] ή [B]VOD Σειρές[/B][CR]--- Σε περίπτωση Αποτυχίας Απαραγωγής... δοκιμάζουμε άλλη [B]MAC[/B]',
        
                                        nolabel='[B][COLOR white]Άκυρο[/COLOR][/B]',yeslabel='[B][COLOR=blue]VOD[/COLOR][/B]')
    
    if choice == 1: xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.downloader/?_id&description&episode_number&fanart&foldername&icon=C%3a%5cPortableApps%5ckodi%5ckodi%20World%2021%5cKodi%5cportable_data%5caddons%5cplugin.program.downloader%5cresources%5cicons%5ciptv.png&mediatype=video&mode=mac_player_sel_mac&name=islacam.live&name2&page&season_number&url=%7b%22portal_server%22%3a%20%22http%3a%2f%2fislacam.live%3a8080%2fc%2f%22%2c%20%22server_macs%22%3a%20%22%5b%5c%2200%3a1a%3a79%3a31%3a73%3a53%5c%22%2c%20%5c%2200%3a1A%3a79%3a5D%3a9F%3a05%5c%22%2c%20%5c%2200%3a1A%3a79%3a09%3a77%3a8F%5c%22%2c%20%5c%2200%3a1a%3a79%3ab9%3afe%3a43%5c%22%2c%20%5c%2200%3a1A%3a79%3a34%3a67%3aED%5c%22%2c%20%5c%2200%3a1A%3a79%3a5D%3a3A%3aFD%5c%22%2c%20%5c%2200%3a1A%3a79%3a63%3a52%3a0F%5c%22%2c%20%5c%2200%3a1A%3a79%3a05%3a7D%3a78%5c%22%2c%20%5c%2200%3a1A%3a79%3aB6%3a0A%3a22%5c%22%5d%22%7d",)')


def click_1():
    choice = xbmcgui.Dialog().yesno('[COLOR orange]mag.diamondma.club[/COLOR]', '1. Πατήστε [B][COLOR=blue]VOD[/COLOR][/B][CR]2. Επιλέξτε [B]MAC[/B][CR]3. Διαλέξτε [B]VOD Ταινίες[/B] ή [B]VOD Σειρές[/B][CR]--- Σε περίπτωση Αποτυχίας Απαραγωγής... δοκιμάζουμε άλλη [B]MAC[/B]',
        
                                        nolabel='[B][COLOR white]Άκυρο[/COLOR][/B]',yeslabel='[B][COLOR=blue]VOD[/COLOR][/B]')

    if choice == 1: xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.downloader/?_id&description&episode_number&fanart&foldername&icon=C%3a%5cPortableApps%5ckodi%5ckodi%20World%2021%5cKodi%5cportable_data%5caddons%5cplugin.program.downloader%5cresources%5cicons%5ciptv.png&mediatype=video&mode=mac_player_sel_mac&name=islacam.live&name2&page&season_number&url=%7b%22portal_server%22%3a%20%22http%3a%2f%2fislacam.live%3a8080%2fc%2f%22%2c%20%22server_macs%22%3a%20%22%5b%5c%2200%3a1a%3a79%3a31%3a73%3a53%5c%22%2c%20%5c%2200%3a1A%3a79%3a5D%3a9F%3a05%5c%22%2c%20%5c%2200%3a1A%3a79%3a09%3a77%3a8F%5c%22%2c%20%5c%2200%3a1a%3a79%3ab9%3afe%3a43%5c%22%2c%20%5c%2200%3a1A%3a79%3a34%3a67%3aED%5c%22%2c%20%5c%2200%3a1A%3a79%3a5D%3a3A%3aFD%5c%22%2c%20%5c%2200%3a1A%3a79%3a63%3a52%3a0F%5c%22%2c%20%5c%2200%3a1A%3a79%3a05%3a7D%3a78%5c%22%2c%20%5c%2200%3a1A%3a79%3aB6%3a0A%3a22%5c%22%5d%22%7d")')


def click_2():
    choice = xbmcgui.Dialog().yesno('[COLOR orange]mag.diamondma.club[/COLOR]', '1. Πατήστε [B][COLOR=blue]VOD[/COLOR][/B][CR]2. Επιλέξτε [B]MAC[/B][CR]3. Διαλέξτε [B]VOD Ταινίες[/B] ή [B]VOD Σειρές[/B][CR]--- Σε περίπτωση Αποτυχίας Απαραγωγής... δοκιμάζουμε άλλη [B]MAC[/B]',
        
                                        nolabel='[B][COLOR white]Άκυρο[/COLOR][/B]',yeslabel='[B][COLOR=blue]VOD[/COLOR][/B]')

    if choice == 1: xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.downloader/?_id&description&episode_number&fanart&foldername&icon=C%3a%5cPortableApps%5ckodi%5ckodi%20World%2021%5cKodi%5cportable_data%5caddons%5cplugin.program.downloader%5cresources%5cicons%5ciptv.png&mediatype=video&mode=mac_player_sel_mac&name=islacam.live&name2&page&season_number&url=%7b%22portal_server%22%3a%20%22http%3a%2f%2fislacam.live%3a8080%2fc%2f%22%2c%20%22server_macs%22%3a%20%22%5b%5c%2200%3a1a%3a79%3a31%3a73%3a53%5c%22%2c%20%5c%2200%3a1A%3a79%3a5D%3a9F%3a05%5c%22%2c%20%5c%2200%3a1A%3a79%3a09%3a77%3a8F%5c%22%2c%20%5c%2200%3a1a%3a79%3ab9%3afe%3a43%5c%22%2c%20%5c%2200%3a1A%3a79%3a34%3a67%3aED%5c%22%2c%20%5c%2200%3a1A%3a79%3a5D%3a3A%3aFD%5c%22%2c%20%5c%2200%3a1A%3a79%3a63%3a52%3a0F%5c%22%2c%20%5c%2200%3a1A%3a79%3a05%3a7D%3a78%5c%22%2c%20%5c%2200%3a1A%3a79%3aB6%3a0A%3a22%5c%22%5d%22%7d",)')


def click_3():
    choice = xbmcgui.Dialog().yesno('[COLOR orange]mag.diamondma.club[/COLOR]', '1. Πατήστε [B][COLOR=blue]VOD[/COLOR][/B][CR]2. Επιλέξτε [B]MAC[/B][CR]3. Διαλέξτε [B]VOD Ταινίες[/B] ή [B]VOD Σειρές[/B][CR]--- Σε περίπτωση Αποτυχίας Απαραγωγής... δοκιμάζουμε άλλη [B]MAC[/B]',
        
                                        nolabel='[B][COLOR white]Άκυρο[/COLOR][/B]',yeslabel='[B][COLOR=blue]VOD[/COLOR][/B]')

    if choice == 1: xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.downloader/?_id&description&episode_number&fanart&foldername&icon=C%3a%5cPortableApps%5ckodi%5ckodi%20World%2021%5cKodi%5cportable_data%5caddons%5cplugin.program.downloader%5cresources%5cicons%5ciptv.png&mediatype=video&mode=mac_player_sel_mac&name=darknetiptv1.ddns.net&name2&page&season_number&url=%7b%22portal_server%22%3a%20%22http%3a%2f%2fdarknetiptv1.ddns.net%3a25461%2fc%2f%22%2c%20%22server_macs%22%3a%20%22%5b%5c%2200%3a1A%3a79%3a54%3aD7%3aC8%5c%22%2c%20%5c%2200%3a1A%3a79%3a3E%3a67%3aC5%5c%22%2c%20%5c%2200%3a1A%3a79%3a48%3aB0%3a08%5c%22%2c%20%5c%2200%3a1A%3a79%3aB6%3aC9%3aF6%5c%22%2c%20%5c%2200%3a1A%3a79%3aCF%3a41%3a06%5c%22%2c%20%5c%2200%3a1A%3a79%3a27%3aE9%3a5E%5c%22%2c%20%5c%2200%3a1A%3a79%3a72%3a7E%3a75%5c%22%2c%20%5c%2200%3a1A%3a79%3aC2%3a42%3a3F%5c%22%2c%20%5c%2200%3a1A%3a79%3a82%3a80%3a38%5c%22%2c%20%5c%2200%3a1A%3a79%3aB8%3a45%3a66%5c%22%2c%20%5c%2200%3a1A%3a79%3aF4%3aBA%3a1B%5c%22%2c%20%5c%2200%3a1A%3a79%3a61%3aA1%3a23%5c%22%2c%20%5c%2200%3a1A%3a79%3aB8%3a49%3aAD%5c%22%2c%20%5c%2200%3a1A%3a79%3aBA%3aA9%3a39%5c%22%2c%20%5c%2200%3a1A%3a79%3aFE%3aE5%3a2D%5c%22%2c%20%5c%2200%3a1A%3a79%3a5B%3a8D%3a4C%5c%22%2c%20%5c%2200%3a1A%3a79%3a42%3a2B%3a31%5c%22%2c%20%5c%2200%3a1A%3a79%3aB8%3a45%3aD6%5c%22%2c%20%5c%2200%3a1A%3a79%3a77%3aEA%3aB9%5c%22%5d%22%7d")')


vod()
