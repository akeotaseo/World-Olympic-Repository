import xbmc, xbmcgui

def dl():
    funcs = (click_1, click_2, click_3, click_4, click_5)
    call = xbmcgui.Dialog().select('[COLOR=red]~ Daddylive ~[/COLOR]', 
[
 '[COLORred][B]Daddylive[/COLOR][/B] (GKoBu)',
# '[B][COLOR=darkviolet]Daddylive[/COLOR][/B]  (THE CREW)',
 '[COLOR=yellow]DaddyLive[/COLOR]  (Arkane14)',
 '[COLOR=slategrey]DLTV[/COLOR]  (Arkane14)',
 '[B][COLOR=orange]Daddylive[/COLOR][/B]  (Browser)',
 '[COLOR lightcyan]AGENDA [/COLOR][COLOR lightblue]DADDYLIVE[/COLOR][COLOR lightslategray][/COLOR]  (BlackGhost)'

 # '[COLOR=yellow]DaddyLive V2[/COLOR]  (X)'
 # '[COLOR=slateblue]DaddyLiveHD[/COLOR]  (FubuZ)'
 ])


    if call:
        if call < 0:
            return
        func = funcs[call-5]
        return func()
    else:
        func = funcs[call]
        return func()
    return 





def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.microjen/daddylive")')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.daddylive/")')

def click_3():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.dltv/")')

def click_4():
    xbmc.executebuiltin('RunScript("special://home/addons/skin.19MatrixWorld/xml/DialogContextPair/Daddylive.py")')


def click_5():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.live.streamspro/?fanart=http%3a%2f%2faddonbg.co%2fblack%2fimg%2ffanart.jpg&mode=1&name=%20%20%5bCOLOR%20lightcyan%5dAGENDA%20%5b%2fCOLOR%5d%5bCOLOR%20lightblue%5dDADDYLIVE%5b%2fCOLOR%5d%20%20%5bCOLOR%20lightslategray%5d%20%20%5b%2fCOLOR%5d%20%20&url=http%3a%2f%2faddonbg.co%2fdaddy.php%3fdaddy%26a44")')

# def click_3():
    # xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.dlv2/",return)')

# def click_4():
    # xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.daddylivehd/,return")')

dl()

