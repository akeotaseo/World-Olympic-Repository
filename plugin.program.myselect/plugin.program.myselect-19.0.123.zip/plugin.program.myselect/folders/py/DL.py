import xbmc, xbmcgui
xbmcgui.Dialog().notification("[B][COLOR orange]They don't always work[/COLOR][/B]", "[COLOR green]Δεν λειτουργούν πάντα...[/COLOR]", sound=True, icon='special://home/addons/plugin.video.playlistloaderworld/resources/images/doestworkalltime.png')
def dl():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6)
    call = xbmcgui.Dialog().select('[COLOR=red]~ Daddylive ~[/COLOR]', 
[
 '[COLORred][B]Daddylive[/COLOR][/B] (GKoBu)',
# '[B][COLOR=darkviolet]Daddylive[/COLOR][/B]  (THE CREW)',
 '[COLOR=yellow]DaddyLive[/COLOR]  (THE CREW)',
 '[COLOR=slategrey]DLTV[/COLOR]  (Arkane14)',
 '[B][COLOR=orange]Daddylive[/COLOR][/B]  (Browser)',
 '[COLOR lightcyan]AGENDA [/COLOR][COLOR lightblue]DADDYLIVE[/COLOR][COLOR lightslategray][/COLOR]  (BlackGhost)',
 '[COLOR gold]LISTA 1[/COLOR] [COLOR blue](Daddy)[/COLOR][CR][COLOR lime](Online)[/COLOR]'


 # '[COLOR=yellow]DaddyLive V2[/COLOR]  (X)'
 # '[COLOR=slateblue]DaddyLiveHD[/COLOR]  (FubuZ)'
 ])


    if call:
        if call < 0:
            return
        func = funcs[call-6]
        return func()
    else:
        func = funcs[call]
        return func()
    return 





def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.microjen/daddylive")')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.daddylive/")')

def click_3():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.dltv/")')

def click_4():
    xbmc.executebuiltin('RunScript("special://home/addons/skin.19MatrixWorld/xml/DialogContextPair/Daddylive.py")')


def click_5():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.live.streamspro/?fanart=http%3a%2f%2faddonbg.co%2fblack%2fimg%2ffanart.jpg&mode=1&name=%20%20%5bCOLOR%20lightcyan%5dAGENDA%20%5b%2fCOLOR%5d%5bCOLOR%20lightblue%5dDADDYLIVE%5b%2fCOLOR%5d%20%20%5bCOLOR%20lightslategray%5d%20%20%5b%2fCOLOR%5d%20%20&url=http%3a%2f%2faddonbg.co%2fdaddy.php%3fdaddy%26a44")')

# def click_3():
    # xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.dlv2/",return)')

# def click_4():
    # xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.daddylivehd/,return")')

def click_6():
    xbmcgui.Dialog().notification("[B][COLOR orange]Ανακατεύθυνση...[/COLOR][/B]", "[B][COLOR aqua]mandrakodi[/COLOR][/B]--->[COLOR lime]LISTE EVENTI[/COLOR][CR][COLOR blue](Daddy)[/COLOR]", sound=False, icon='https://www.dropbox.com/s/35xf78ndxhu3xnt/event_list.png?dl=1')
    # xbmc.sleep(1000)
    # xbmc.executebuiltin('Dialog.Close(all,true)')
    # xbmc.executebuiltin('Action(Back)')
    # xbmc.executebuiltin('Dialog.Close(all,true)')
    # xbmc.executebuiltin('ActivateWindow(Home)')
    xbmc.executebuiltin('SendClick(11)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.mandrakodi/")')
    xbmc.sleep(2000)
    xbmc.executebuiltin('SendClick(11)')
    xbmcgui.Dialog().notification("[B][COLOR orange]Ανακατεύθυνση...[/COLOR][/B]", "[B][COLOR aqua]mandrakodi[/COLOR][/B]--->[COLOR lime]LISTE EVENTI[/COLOR][CR][COLOR blue](Daddy)[/COLOR]", sound=False, icon='https://www.dropbox.com/s/35xf78ndxhu3xnt/event_list.png?dl=1')
    xbmc.sleep(2000)
    xbmc.executebuiltin('SendClick(11)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.mandrakodi/?action=getExtData&url=https%3a%2f%2ftest34344.herokuapp.com%2ffilter.php")')

    xbmc.sleep(2000)
    xbmc.executebuiltin('SendClick(11)')
    xbmcgui.Dialog().notification("[B][COLOR orange]Ανακατεύθυνση...[/COLOR][/B]", "[B][COLOR aqua]mandrakodi[/COLOR][/B]--->[COLOR lime]LISTE EVENTI[/COLOR][CR][COLOR blue](Daddy)[/COLOR]", sound=False, icon='https://www.dropbox.com/s/35xf78ndxhu3xnt/event_list.png?dl=1')
    xbmc.sleep(2000)
    xbmc.executebuiltin('SendClick(11)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.mandrakodi/?action=getExtData&url=https%3a%2f%2ftest34344.herokuapp.com%2ffilter.php%3fnumTest%3dA1A110")')
    xbmc.executebuiltin('SendClick(11)')
    xbmc.sleep(2000)
    xbmc.executebuiltin('SendClick(11)')
    xbmcgui.Dialog().notification("[B][COLOR orange]Ανακατεύθυνση...[/COLOR][/B]", "[B][COLOR aqua]mandrakodi[/COLOR][/B]--->[COLOR lime]LISTE EVENTI[/COLOR][CR][COLOR blue](Daddy)[/COLOR]", sound=False, icon='https://www.dropbox.com/s/35xf78ndxhu3xnt/event_list.png?dl=1')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.mandrakodi/?action=getExtData&url=https%3a%2f%2ftest34344.herokuapp.com%2ffilter.php%3fnumTest%3dA1A114",return)')
    xbmc.executebuiltin('SendClick(11)')








dl()

