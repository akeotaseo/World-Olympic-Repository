import xbmc, xbmcgui


def TubeMovies():
    funcs = (click_1, click_2, click_3, click_4)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]~ TubeMovies ~[/COLOR][/B]', 
['[B][COLOR=white]Λίστες αναπαραγωγής[/COLOR][/B]',
 '[B][COLOR=white]OLD CLASSIC MOVIES[/COLOR][/B]',
 '[B][COLOR=white]Youtube Movies[/COLOR][/B] (MicroJen)',
 '[B][COLOR=white]Butter Fingers Movies[/COLOR][/B] (Addon)'])


    if call:
        if call < 0:
            return
        func = funcs[call-4]
        return func()
    else:
        func = funcs[call]
        return func()
    return 




def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.youtube/kodion/search/query/?q=%ce%9e%ce%ad%ce%bd%ce%b5%cf%82%20%ce%b1%cf%83%cf%80%cf%81%cf%8c%ce%bc%ce%b1%cf%85%cf%81%ce%b5%cf%82%20%cf%84%ce%b1%ce%b9%ce%bd%ce%af%ce%b5%cf%82%20%ce%bc%ce%b5%20%ce%b5%ce%bb%ce%bb%ce%b7%ce%bd%ce%b9%ce%ba%ce%bf%cf%8d%cf%82%20%cf%85%cf%80%cf%8c%cf%84%ce%b9%cf%84%ce%bb%ce%bf%cf%85%cf%82&search_type=playlist",return)')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.youtube/kodion/search/query/?category_label=Old%20Classic%20Movies&q=Old%20Classic%20Movies",return)')

def click_3():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.microjen/get_list/https://fuse99.com/xml19/youtube19/youtubemoviestwiglet.json",return)')

def click_4():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.bfingers/",return)')


TubeMovies()
