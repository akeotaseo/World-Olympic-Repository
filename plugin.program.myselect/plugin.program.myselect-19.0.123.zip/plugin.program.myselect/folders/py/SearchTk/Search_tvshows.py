import xbmc, xbmcgui


def Search_tvshows():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7, click_8, click_9, click_10, click_11, click_12, click_13, click_14,
             click_15, click_16, click_17, click_18, click_19, click_20, click_21, click_22)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]Αναζήτηση Ταινίας ...[/COLOR][/B]', 
['[B][COLOR=white]Extended Info[/COLOR][/B]',
 '[B][COLOR=blue]TheMovieDb[/COLOR][/B]',
 '[B][COLOR=orange]Atlas[/COLOR][/B]',
 '[B][COLOR=maroon]Blacklodge[/COLOR][/B]',
 '[B][COLOR=purple]Scrubs v2[/COLOR][/B]',

 '[B][COLOR=orange]MicroJen[/COLOR][/B]',

 '[B][COLOR=orchid]The Crew[/COLOR][/B]',
 # '[B][COLOR=gray]Gratis[/COLOR][/B]',
 # '[B][COLOR=fuchsia]Thunder[/COLOR][/B]',
 # '[B][COLOR=orange]TVSeries[COLOR=white].video[/COLOR][/B]',
 '[B][COLOR=gray]Seren[/COLOR][/B]',
 '[B][COLOR=silver]FEN[/COLOR][/B]',
 '[B][COLOR=lavenderblush]POV[/COLOR][/B]',
 '[B][COLOR=white]Shadow[/COLOR][/B]',
 '[B][COLOR=white]Release[COLOR=orange]BB[/COLOR][/B]',
 # '[B][COLOR=yellow]Magic Dragon[/COLOR][/B]',
 '[B][COLOR=blue]Alive[COLOR=white]GR[/COLOR][/B]',
 '[B][COLOR=white]You[B][COLOR=red]Toube[/COLOR][/B]',
 # '[B][COLOR=red]duffyou[/COLOR][/B]',
 '[B][COLOR=blue]Nightwing[/COLOR][/B]',
 '[B][COLOR=firebrick]Umbrella[/COLOR][/B]',


 # '[B][COLOR=red]Homelander[/COLOR][/B]',

 # '[B][COLOR dodgerblue]Sealteam[/COLOR][COLOR red]6[/COLOR][/B]',
 # '[B][COLORsilver]Quicksilver[/COLOR][/B]',
 # '[B][COLOR=darkorange]Shazam[/COLOR][/B]',
 # '[B][COLOR teal]Absolution[/COLOR][/B]',
 # '[B][COLORff8cc63f]9 [COLORffd9f8b2]LIVES[/COLOR][/B]',
 # '[B][COLORred]THX 1138[/COLOR][/B]',
 # '[B][COLOR aqua]Alvin[/COLOR][/B]',
 '[B][COLOR=orange]Free99[/COLOR][/B]',
 # '[B][COLORff58c1e0]MORIA[/COLOR][/B]',
 '[B][COLOR gold]LookMovie[/COLOR][/B]',
 '[B][COLOR=ghostwhite]Scrapee[/COLOR][/B]',
 '[B][COLOR lightblue]TV Free[/COLOR][/B]',
 '[B][COLOR silver]Elementum[/COLOR][/B]',
 '[B][COLOR red]<---                                                                      [COLOR grey]Back[/COLOR][/B]'])
    if call:
        if call < 0:
            return
        func = funcs[call-22]
        return func()
    else:
        func = funcs[call]
        return func()
    return 


def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://script.extendedinfo/?info=search_menu)')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.themoviedb.helper/?info=search&tmdb_id=None&tmdb_type=tv&widget=True)')

def click_3():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&mode=4&url=new)')

def click_4():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.blacklodge/?action=tvSearch")')
    
def click_5():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.scrubsv2/?action=tvshows_searchterm&select=tvshow)')

def click_6():
    xbmc.executebuiltin('ActivateWindow(10001,"plugin://plugin.program.mypreferences/?content_type=executable&fanart=special://home/addons%5cplugin.program.mypreferences%5cfanart.jpg&image=https%3a%2f%2frebrand.ly%2fsearch_mov&label=GrSitesMj&mode=400&path=special%3a%2f%2fprofile%2faddon_data%2fplugin.program.mypreferences%5cSuper%20Favourites%5cEX%20-Simple%20Favourites%5cGrSitesMj")')

def click_7():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.thecrew/?action=tvSearchnew")')

# def click_8():
    # xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.gratis/?mode=bst_search)')

# def click_9():
    # xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.thethunder/?action=search_tv_shows)')

# def click_10():
    # xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.tvseriesvideo/?mode=search&page=1&url)')

def click_8():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.seren/?action=showsSearch&from_widget=false)')

def click_9():
    xbmc.executebuiltin('PlayMedia("plugin://plugin.video.fen/?mode=get_search_term&media_type=tv_show")')

def click_10():
    xbmc.executebuiltin('PlayMedia("plugin://plugin.video.pov/?mode=get_search_term&media_type=tv_show")')

def click_11():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.shadow/?all_w=%7b%7d&data=%20&dates=%20&description=TMDB&eng_name=%20&episode=%20&fanart=https%3a%2f%2fsearchengineland.com%2ffigz%2fwp-content%2fseloads%2f2017%2f12%2fcompare-seo-ss-1920-800x450.jpg&fav_status=false&heb_name=%20&iconimage=C%3a%5cUsers%5chplap%5cAppData%5cRoaming%5cKodi%5caddons%5cplugin.video.shadow%5cresources%5cartwork%2fsearch.png&id=%20&image_master&isr=0&last_id&mode=14&name=Search&original_title=%20&search_db&season=%20&show_original_year=%20&tmdbid=%20&url=http%3a%2f%2fapi.themoviedb.org%2f3%2fsearch%2ftv%3fapi_key%3d34142515d9d23817496eeb4ff1d223d0%26query%3d%25s%26language%3del%26page%3d1&video_data=%7b%22title%22%3a%20%22Search%22%2c%20%22mediatype%22%3a%20%22movie%22%2c%20%22TVshowtitle%22%3a%20%22%22%2c%20%22season%22%3a%200%2c%20%22episode%22%3a%200%2c%20%22OriginalTitle%22%3a%20%22%20%22%2c%20%22rating%22%3a%20%220%22%2c%20%22plot%22%3a%20%22TMDB%22%2c%20%22Tag%22%3a%20%223%22%2c%20%22id%22%3a%20%22%20%22%7d)')

def click_12():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.releaseBB/?mode=search_bb&url=new)')

# def click_13():
    # xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.magicdragon/?all_w=%7b%7d&data=%20&dates=%20&description=Search&eng_name=%20&episode=%20&fanart=https%3a%2f%2fsearchengineland.com%2ffigz%2fwp-content%2fseloads%2f2017%2f12%2fcompare-seo-ss-1920-800x450.jpg&fav_status=false&heb_name=%20&iconimage=C%3a%5cUsers%5chplap%5cAppData%5cRoaming%5cKodi%5caddons%5cplugin.video.magicdragon%5cresources%5cartwork%2fsearch.png&id=%20&image_master&isr=0&last_id&mode=5&mypass&name=Search&original_title=%20&search_db&season=%20&show_original_year=%20&tmdbid=%20&url=www&video_data=%7b%22title%22%3a%20%22Search%22%2c%20%22mediatype%22%3a%20%22movie%22%2c%20%22TVshowtitle%22%3a%20%22%22%2c%20%22season%22%3a%200%2c%20%22episode%22%3a%200%2c%20%22OriginalTitle%22%3a%20%22%20%22%2c%20%22rating%22%3a%20%220%22%2c%20%22plot%22%3a%20%22Search%22%2c%20%22Tag%22%3a%20%22None%22%2c%20%22id%22%3a%20%22%20%22%7d)')

def click_13():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.AliveGR/?action=search_index)')

def click_14():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.youtube/kodion/search/input)')

# def click_18():
    # xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.duffyou/?eydhY3Rpb24nOiAnb2lPTzAwT28nLCAnZmFuYXJ0JzogJ0M6XFxQb3J0YWJsZUFwcHNcXGtvZGlcXGtvZGkgV29ybGQgMjBcXEtvZGlcXHBvcnRhYmxlX2RhdGFcXGFkZG9uc1xccGx1Z2luLnZpZGVvLmR1ZmZ5b3VcXGZhbmFydC5qcGcnLCAnaWNvbic6ICdDOlxcUG9ydGFibGVBcHBzXFxrb2RpXFxrb2RpIFdvcmxkIDIwXFxLb2RpXFxwb3J0YWJsZV9kYXRhXFxhZGRvbnNcXHBsdWdpbi52aWRlby5kdWZmeW91XFxyZXNvdXJjZXNcXG1lZGlhXFxuZXdfc2VhcmNoLnBuZycsICdsYWJlbCc6ICfOnc6tzrEgzrHOvc6xzrbOrs%2bEzrfPg863JywgJ3BhZ2UnOiAxLCAncGxvdCc6ICdbQl3Okc69zrHOts6uz4TOt8%2bDzrdbL0JdW0NSXVtDUl3Okc69zrHOts63z4TOrs%2bDz4TOtSDOrc69zrEgzrLOr869z4TOtc6%2fLCDOvM6vzrEgzrbPic69z4TOsc69zq4gz4HOv86uLCDOvM65zrEgzrvOr8%2bDz4TOsSDOsc69zrHPgM6xz4HOsc6zz4nOs86uz4Igzq4gzq3Ovc6xIM66zrHOvc6szrvOuS4nLCAncXVlcnknOiBUcnVlLCAndGlwbyc6ICd2aWRlbyd9")')

def click_15():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.nightwing/?action=tvSearchnew")')

def click_16():
    xbmc.executebuiltin('PlayMedia("plugin://plugin.video.umbrella/?action=tvSearchnew")')



# def click_21():
    # xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.homelander/?action=tvSearchnew")')

# def click_22():
    # xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.sealteam6/?action=tvSearchnew")')

# def click_23():
    # xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.quicksilver/?action=tvSearchnew")')

# def click_24():
    # xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.shazam/?action=tvSearchnew")')

# def click_25():
    # xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.absolution/?action=tvSearchnew")')

# def click_26():
    # xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.nine/?action=tvSearchnew")')

# def click_27():
    # xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.thx/?action=tvSearchnew")')

# def click_28():
    # xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.alvin/?action=tvSearchnew")')

def click_17():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.free99/?action=search_tvshows_menu")')

# def click_30():
    # xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.moria/?action=tvSearchnew")')

def click_18():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.lookmovietomb/?image=C%3a%5cPortableApps%5ckodi%5cKODI%20TEST%5cKodi%5cportable_data%5caddons%5cplugin.video.lookmovietomb%5c%2fresources%2f..%2ficon.png&infoLabels=%257B%2527title%2527%253A%2b%2527%255BCOLOR%2bkhaki%255D%255BB%255DTV%2bShows%255B%252FCOLOR%255D%255B%252FB%255D%2527%257D&mode=listmenus&page=1&title=%5bCOLOR%20khaki%5d%5bB%5dTV%20Shows%5b%2fCOLOR%5d%5b%2fB%5d&url=series")')
    xbmc.sleep(10000)
    xbmc.executebuiltin('PlayMedia("plugin://plugin.video.lookmovietomb/?mode=search&url=https%3A%2F%2Flookmovie.foundation%2Fshows%2Fsearch%2Fpage%2F1%3Fq%3D&page=1&title=Search&image=C%3A%5CPortableApps%5Ckodi%5CKODI+TEST%5CKodi%5Cportable_data%5Caddons%5Cplugin.video.lookmovietomb%5C%2Fresources%2F..%2Ficon.png&infoLabels=%257B%2527plot%2527%253A%2B%2527TV%2Bshows%2B-%2Bsearch%2527%257D")')

def click_19():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.scrapee/?action=tvshow&iconImage=https%3a%2f%2fi.imgur.com%2fxYTdX3O.png&mode=history.search&name=TV%20Shows")')

def click_20():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.tvfree/get_list/https://srstop.link/search")')

def click_21():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.elementum/shows/search?keyboard=1")')

def click_22():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.myselect/folders/py/SearchTk/SearchAll.py")')

Search_tvshows()