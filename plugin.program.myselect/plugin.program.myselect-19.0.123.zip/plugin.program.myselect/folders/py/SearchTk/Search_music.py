import xbmc, xbmcgui


def Search_music():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7, click_8)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]Αναζήτηση ... [/COLOR][/B]',
['[B][COLOR=lime]Mp3Streams [COLOR=white]Artists[/COLOR][/B]',
 '[B][COLOR=lime]Mp3Streams [COLOR=white]Albums[/COLOR][/B]',
 '[B][COLOR=lime]Mp3Streams [COLOR=white]Songs[/COLOR][/B]',
 '[B][COLOR=orange]Soundcloud[/COLOR][/B]',
 '[B][COLOR=white]You[B][COLOR=red]Toube[/COLOR][/B]',
 '[B][COLOR=cyan]E-Radio[/COLOR][/B]',
 '[B][COLOR=blue]Alive[COLOR=white]GR[/COLOR][/B]',
 '[B][COLOR red]<---                                                                      [COLOR grey]Back[/COLOR][/B]'])

    if call:
        if call < 0:
            return
        func = funcs[call-8]
        return func()
    else:
        func = funcs[call]
        return func()
    return 


def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.audio.mp3streams/?mode=24&name=Search%20Artists&type&url=url)')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.audio.mp3streams/?mode=24&name=Search%20Albums&type&url=url)')

def click_3():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.audio.mp3streams/?mode=24&name=Search%20Songs&type&url=url)')

def click_4():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.audio.soundcloud/search/?action=new)')

def click_5():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.youtube/kodion/search/input)')

def click_6():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.audio.eradio.gr/?action=search)')

def click_7():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.AliveGR/?action=search_index)')

def click_8():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.myselect/folders/py/SearchTk/SearchAll.py")')

Search_music()