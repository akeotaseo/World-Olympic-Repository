import xbmc, xbmcgui


def tvone():
    funcs = (click_1, click_2, click_3, click_4, click_6, click_7)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]~ TvOne All ~[/COLOR][/B]', 
['[COLOR=white]TvOne[/COLOR]    [COLOR=red](OFF...)[/COLOR]',
 '[COLOR=white]TvOne[/COLOR]  (F Sports)    [COLOR=red](OFF...)[/COLOR]',
 '[COLOR=white]TvOne11[/COLOR]    [COLOR=red](OFF...)[/COLOR]',
 '[COLOR=white]TvOne111[/COLOR]    [COLOR=red](OFF...)[/COLOR]',
 '[COLOR=white]TvOne1112[/COLOR]    [COLOR=red](OFF...)[/COLOR]',
 '[COLOR=white]TvOne112[/COLOR]    [COLOR=red](OFF...)[/COLOR]',
 '[COLOR=blue]Sports Channels[/COLOR]'])


    if call:
        if call < 0:
            return
        func = funcs[call-7]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.tvone/list_channels/5")')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.tvone/list_sp_channels/5")')

def click_3():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.tvone11/list_channels/8")')

def click_4():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.tvone111/list_channels/1")')

def click_5():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.tvone1111/list_channels/1")')
    
def click_6():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.tvone112/list_channels/38")')


def click_7():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.myselect/folders/py/Spchannels.py")')

tvone()
