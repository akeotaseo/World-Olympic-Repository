import os, xbmc, xbmcvfs, xbmcgui, xbmcaddon, shutil, glob
# xbmcgui.Dialog().notification("[B][COLOR orange]They don't always work[/COLOR][/B]", "[COLOR green]Δεν λειτουργούν πάντα...[/COLOR]", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/doestworkalltime.png')
# xbmc.sleep(4000)
def vod():
    funcs = (click_1, click_2, click_3)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]~ VOD ~[/COLOR][/B]', 
[
 '[B][COLOR=blue]VOD[/COLOR][/B] weaseltv.live  (mac_player)',

 '[B][COLOR=blue]VOD[/COLOR][/B] vpn.louis-premium.com  (mac_player)',

 '[B][COLOR=orange]VOD[/COLOR][/B] nocable.cc / xxip9.top (my_iptv)'

])


    if call:
        if call < 0:
            return
        func = funcs[call-3]
        return func()
    else:
        func = funcs[call]
        return func()
    return 




def click_1():
    choice = xbmcgui.Dialog().yesno('[COLOR orange]weaseltv.live[/COLOR]', '1. Πατήστε [B][COLOR=blue]VOD[/COLOR][/B][CR]2. Επιλέξτε [B]MAC[/B][CR]3. Διαλέξτε [B]VOD Ταινίες[/B] ή [B]VOD Σειρές[/B][CR]--- Σε περίπτωση Αποτυχίας Απαραγωγής... δοκιμάζουμε άλλη [B]MAC[/B]',
        
                                        nolabel='[B][COLOR white]Άκυρο[/COLOR][/B]',yeslabel='[B][COLOR=blue]VOD[/COLOR][/B]')

    if choice == 1: xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.downloader/?_id&description&episode_number&fanart&foldername&icon=C%3a%5cPortableApps%5ckodi%5cKODI%20TEST%5cKodi%5cportable_data%5caddons%5cplugin.program.downloader%5cresources%5cicons%5ciptv.png&mediatype=video&mode=mac_player_sel_mac&name=weaseltv.live&name2&page&season_number&url=%7b%22portal_server%22%3a%20%22http%3a%2f%2fweaseltv.live%2fc%2f%22%2c%20%22server_macs%22%3a%20%22%5b%5c%2200%3a1A%3a79%3a00%3a2B%3aF5%5c%22%2c%20%5c%2200%3a1A%3a79%3a21%3a09%3a54%5c%22%2c%20%5c%2200%3a1A%3a79%3a22%3a02%3a0D%5c%22%2c%20%5c%2200%3a1A%3a79%3a22%3a02%3a5F%5c%22%2c%20%5c%2200%3a1A%3a79%3a22%3a03%3a6E%5c%22%2c%20%5c%2200%3a1A%3a79%3a32%3aC2%3a04%5c%22%2c%20%5c%2200%3a1A%3a79%3a32%3aC2%3a0E%5c%22%2c%20%5c%2200%3a1A%3a79%3a32%3aC2%3a18%5c%22%2c%20%5c%2200%3a1A%3a79%3a32%3aC2%3a61%5c%22%2c%20%5c%2200%3a1A%3a79%3a32%3aC8%3a01%5c%22%2c%20%5c%2200%3a1A%3a79%3a32%3aC8%3a6F%5c%22%2c%20%5c%2200%3a1A%3a79%3a32%3aC8%3aEE%5c%22%2c%20%5c%2200%3a1A%3a79%3a39%3a1E%3a48%5c%22%2c%20%5c%2200%3a1A%3a79%3a5E%3aC5%3aE7%5c%22%2c%20%5c%2200%3a1A%3a79%3a6B%3a69%3a48%5c%22%2c%20%5c%2200%3a1A%3a79%3a8C%3a00%3a25%5c%22%2c%20%5c%2200%3a1A%3a79%3aA1%3aBA%3a92%5c%22%2c%20%5c%2200%3a1A%3a79%3aA9%3a06%3aCA%5c%22%2c%20%5c%2200%3a1A%3a79%3aB5%3a9C%3a1E%5c%22%2c%20%5c%2200%3a1A%3a79%3aB6%3a21%3a66%5c%22%2c%20%5c%2200%3a1A%3a79%3aB6%3a55%3aAF%5c%22%2c%20%5c%2200%3a1A%3a79%3aB6%3a5E%3aF7%5c%22%2c%20%5c%2200%3a1A%3a79%3aBF%3a6F%3a08%5c%22%2c%20%5c%2200%3a1A%3a79%3aBF%3aE6%3aB2%5c%22%2c%20%5c%2200%3a1A%3a79%3aBF%3aE6%3aD0%5c%22%2c%20%5c%2200%3a1A%3a79%3aC1%3a01%3a96%5c%22%2c%20%5c%2200%3a1A%3a79%3aC1%3a55%3a63%5c%22%2c%20%5c%2200%3a1A%3a79%3aC1%3a55%3aB9%5c%22%2c%20%5c%2200%3a1A%3a79%3aC1%3a55%3aBD%5c%22%2c%20%5c%2200%3a1A%3a79%3aD5%3a19%3a39%5c%22%2c%20%5c%2200%3a1A%3a79%3aD5%3a55%3aED%5c%22%2c%20%5c%2200%3a1A%3a79%3aE7%3a8F%3a3F%5c%22%2c%20%5c%2200%3a1A%3a79%3aFB%3a17%3a42%5c%22%2c%20%5c%2200%3a1A%3a79%3aFB%3a17%3a4A%5c%22%2c%20%5c%2200%3a1A%3a79%3aFB%3a17%3aE4%5c%22%2c%20%5c%2200%3a1A%3a79%3aFB%3a17%3aE7%5c%22%2c%20%5c%2200%3a1A%3a79%3aFB%3a5F%3a79%5c%22%5d%22%7d")'), xbmcgui.Dialog().notification("[B][COLOR orange]They don't always work[/COLOR][/B]", "[COLOR green]Δεν λειτουργούν πάντα...[/COLOR]", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/doestworkalltime.png'), xbmc.sleep(4000)

    if choice == 0: xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.myselect/folders/py/VOD.py")')



def click_2():
    choice = xbmcgui.Dialog().yesno('[COLOR orange]vpn.louis-premium.com[/COLOR]', '1. Πατήστε [B][COLOR=blue]VOD[/COLOR][/B][CR]2. Επιλέξτε [B]MAC[/B][CR]3. Διαλέξτε [B]VOD Ταινίες[/B] ή [B]VOD Σειρές[/B][CR]--- Σε περίπτωση Αποτυχίας Απαραγωγής... δοκιμάζουμε άλλη [B]MAC[/B]',
        
                                        nolabel='[B][COLOR white]Άκυρο[/COLOR][/B]',yeslabel='[B][COLOR=blue]VOD[/COLOR][/B]')

    if choice == 1: xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.downloader/?_id&description&episode_number&fanart&foldername&icon=C%3a%5cPortableApps%5ckodi%5cKODI%20TEST%5cKodi%5cportable_data%5caddons%5cplugin.program.downloader%5cresources%5cicons%5ciptv.png&mediatype=video&mode=mac_player_sel_mac&name=vpn.louis-premium.com&name2&page&season_number&url=%7b%22portal_server%22%3a%20%22http%3a%2f%2fvpn.louis-premium.com%2fc%2f%22%2c%20%22server_macs%22%3a%20%22%5b%5c%2200%3a1A%3a79%3a00%3a00%3a95%5c%22%2c%20%5c%2200%3a1A%3a79%3a00%3a25%3a97%5c%22%2c%20%5c%2200%3a1A%3a79%3a04%3aD6%3aAD%5c%22%2c%20%5c%2200%3a1A%3a79%3a0E%3a0F%3aEC%5c%22%2c%20%5c%2200%3a1A%3a79%3a1D%3a7C%3aC4%5c%22%2c%20%5c%2200%3a1A%3a79%3a31%3a95%3aBB%5c%22%2c%20%5c%2200%3a1A%3a79%3a43%3a1B%3a37%5c%22%2c%20%5c%2200%3a1A%3a79%3a48%3a54%3a28%5c%22%2c%20%5c%2200%3a1A%3a79%3a4A%3aB4%3aF7%5c%22%2c%20%5c%2200%3a1A%3a79%3a5C%3a47%3a41%5c%22%2c%20%5c%2200%3a1A%3a79%3a64%3a37%3a37%5c%22%2c%20%5c%2200%3a1A%3a79%3a64%3a7B%3aCE%5c%22%2c%20%5c%2200%3a1A%3a79%3a66%3aE9%3a45%5c%22%2c%20%5c%2200%3a1A%3a79%3a6b%3aeb%3afc%5c%22%2c%20%5c%2200%3a1A%3a79%3a79%3a24%3a83%5c%22%2c%20%5c%2200%3a1A%3a79%3a7D%3a95%3aFC%5c%22%2c%20%5c%2200%3a1A%3a79%3a7E%3aE2%3aAF%5c%22%2c%20%5c%2200%3a1A%3a79%3a7F%3a26%3a2F%5c%22%2c%20%5c%2200%3a1A%3a79%3a80%3a78%3a5E%5c%22%2c%20%5c%2200%3a1A%3a79%3a82%3a30%3aDE%5c%22%2c%20%5c%2200%3a1A%3a79%3a92%3a5A%3a49%5c%22%2c%20%5c%2200%3a1A%3a79%3aA3%3aB7%3a56%5c%22%2c%20%5c%2200%3a1A%3a79%3aB1%3a9E%3a41%5c%22%2c%20%5c%2200%3a1A%3a79%3aB5%3a45%3a71%5c%22%2c%20%5c%2200%3a1A%3a79%3aB5%3a9D%3aC9%5c%22%2c%20%5c%2200%3a1A%3a79%3aB6%3a2C%3aCE%5c%22%2c%20%5c%2200%3a1A%3a79%3aB8%3a22%3a89%5c%22%2c%20%5c%2200%3a1A%3a79%3aBD%3aC7%3a08%5c%22%2c%20%5c%2200%3a1A%3a79%3aC1%3a5F%3a3C%5c%22%2c%20%5c%2200%3a1A%3a79%3aC3%3a8E%3aAC%5c%22%2c%20%5c%2200%3a1A%3a79%3aC3%3aB2%3a42%5c%22%2c%20%5c%2200%3a1A%3a79%3aC3%3aC9%3aC9%5c%22%2c%20%5c%2200%3a1A%3a79%3aC4%3a2C%3aA9%5c%22%2c%20%5c%2200%3a1A%3a79%3aCE%3a87%3a38%5c%22%2c%20%5c%2200%3a1A%3a79%3aCF%3a2B%3a4C%5c%22%2c%20%5c%2200%3a1A%3a79%3aD3%3a14%3a1D%5c%22%2c%20%5c%2200%3a1A%3a79%3aE1%3a01%3a2B%5c%22%2c%20%5c%2200%3a1A%3a79%3aE7%3aBA%3a7A%5c%22%2c%20%5c%2200%3a1A%3a79%3aE8%3a97%3aFD%5c%22%2c%20%5c%2200%3a1A%3a79%3aEA%3a0E%3a75%5c%22%5d%22%7d",return)'), xbmcgui.Dialog().notification("[B][COLOR orange]They don't always work[/COLOR][/B]", "[COLOR green]Δεν λειτουργούν πάντα...[/COLOR]", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/doestworkalltime.png'), xbmc.sleep(4000)

    if choice == 0: xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.myselect/folders/py/VOD.py")')



def click_3():
    choice = xbmcgui.Dialog().yesno('[COLOR orange]nocable / xxip9[/COLOR]', '1. Πατήστε [B][COLOR=blue]VOD[/COLOR][/B][CR]2. Επιλέξτε [B] URL[/B][CR]3. Διαλέξτε [B]VOD Ταινίες[/B] ή [B]VOD Σειρές[/B][CR]--- Σε περίπτωση Αποτυχίας Απαραγωγής... δοκιμάζουμε άλλο [B]URL[/B]',
        
                                        nolabel='[B][COLOR white]Άκυρο[/COLOR][/B]',yeslabel='[B][COLOR=blue]VOD[/COLOR][/B]')

    if choice == 1: xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.downloader/?_id&description&episode_number&fanart&foldername&icon=C%3a%5cPortableApps%5ckodi%5cKODI%20TEST%5cKodi%5cportable_data%5caddons%5cplugin.program.downloader%5cresources%5cicons%5cxcodes.jpg&mediatype=video&mode=get_remote_xcodes&name=Remote%20x-treme%20codes%20%ce%bb%ce%af%cf%83%cf%84%ce%b5%cf%82&name2&page&season_number&url=%7b%22url%22%3a%20%22https%3a%2f%2fraw.githubusercontent.com%2fakeotaseo%2fworld_repo%2frefs%2fheads%2fmain%2fUpdater_Matrix%2fXML2%2fDOV.txt%22%7d")'), xbmc.sleep(4000)

    if choice == 0: xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.myselect/folders/py/VOD.py")')





vod()
