import xbmc, xbmcgui


def WeatherWidget():
    funcs = (click_1, click_2, click_3, click_4)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]Weather[/COLOR][/B]', 
['Alphatv Ειδήσεις (Ελλάδα)',
 'ΚΑΙΡΟΣ STAR',
 'ANT1 Δελτίο Καιρού',
 'NEWS'])


    if call:
        if call < 0:
            return
        func = funcs[call-4]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.alphatv.gr/?action=gr_episodes&title=%ce%95%ce%b9%ce%b4%ce%ae%cf%83%ce%b5%ce%b9%cf%82%20(%ce%95%ce%bb%ce%bb%ce%ac%ce%b4%ce%b1)&url=https%3a%2f%2fwww.alphatv.gr%2fnewscast%2falpha-news%2fbroadcasts%2f")')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.star.gr/?action=youtube&image=https%3a%2f%2fi.ytimg.com%2fvi%2fFUsHO8A4A6M%2fhqdefault.jpg&title=%ce%94%ce%b5%ce%bb%cf%84%ce%af%ce%b1%20%ce%ba%ce%b1%ce%b9%cf%81%ce%bf%cf%8d&url=PLCg0cLoEdHTwGvb6UwJRsvtP4Ftm4e0YE")')

def click_3():
    xbmc.executebuiltin('PlayMedia("plugin://plugin.video.antenna.gr/?action=weather")')


def click_4():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.manalab/?action=parse_m3u&category=ALL_CHANNELS_FLAG&m3u_url=https%3a%2f%2ftest.manalab.net%2fwizard%2f111.m3u")')


WeatherWidget()
