import xbmc, xbmcgui



def live_now():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7, click_8, click_9, click_10, click_11, click_12)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]       Live Now...[/COLOR][/B]',
['[COLOR=orange]LIVE EVENTS[/COLOR] (SportHD)',

 '[COLOR=red]DADDYLIVE[/COLOR]',


 '[COLOR=white]Streamonsport[/COLOR] [COLOR=purple](vstream)[/COLOR]',
 '[COLOR=white]Live TV[/COLOR] [COLOR=purple](vstream)[/COLOR]',


 '[COLOR=white]Live TV[/COLOR] [COLOR green](Dracarys)[/COLOR]',
 '[COLOR=white]Rojadirecta[/COLOR] [COLOR green](Dracarys)[/COLOR]',

 '[COLOR=white]JOGOS [COLOR lime] [COLOR=yellow](Aguia_De_Ouro)[/COLOR]',
 '[COLOR=white][COLOR gold]TheANONYMOUS[/COLOR][COLOR cyan] EVENTOS DESPORTIVOS  [/COLOR]',

 '[COLOR=white]USA SPORTS [COLOR=lime](The Endzone 19) [COLOR=orange](microjen)[/COLOR]',


 '[COLOR=white]Live events(The Thao) [COLOR=crimson](vnmedia)[/COLOR]',

 '[COLOR yellow]NemesisAIO Live Sports & Replays[/COLOR]',
 
 '[COLOR=white]Daddylive [COLOR=olive](All)[/COLOR]'
 ])




    if call:
        if call < 1:
            return
        func = funcs[call-12]
        return func()
    else:
        func = funcs[call]
        return func()
    return 






def click_1():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.sporthdme/?description&iconimage=C%3a%5cPortableApps%5ckodi%5ckodi%20World%2020%5cKodi%5cportable_data%5caddons%5cplugin.video.sporthdme%5cicon.png&mode=5&name=%5bB%5d%5bCOLOR%20white%5dLIVE%20EVENTS%5b%2fCOLOR%5d%5b%2fB%5d&url=https%3a%2f%2f1.ivesoccer.sx%2f")')
    #xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.myselect/folders/py/sporthdme.py")')

def click_2():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.daddylive/?mode=menu&serv_type=sched",return)')

def click_3():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.vstream/?function=showMovies&sFav=showMovies&site=streamonsport&siteUrl=%2f&title=Streamonsport")')

def click_4():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.vstream/?function=showMovies&sFav=showMovies&site=livetv&siteUrl=https%3a%2f%2flivetv767.me%2f%2ffrx%2fallupcoming%2f&title=Les%20sports%20")')

def click_5():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.dracarys/?category=live_sport&mode=open_site&site=livetv")')

def click_6():
    
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.dracarys/?category=live_sport&mode=open_site&site=rojadirecta")')

def click_7():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.aguia_de_ouro/jogos/name%3D%255BB%255DJOGOS%255B%252FB%255D%26iconimage%3DC%253A%255CPortableApps%255Ckodi%255CMy%2BKODI%2B21%255CKodi%255Cportable_data%255Caddons%255Cplugin.video.aguia_de_ouro%255Cicon.png%26description%3DASSISTA%2BOS%2BMELHORES%2BJOGOS")')

def click_8():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.desporto.theanonymous/?fanart=http%3a%2f%2fmilhano.pt%2fftp-milhano%2faladotv%2fTheAnonymous.Desporto%2fdesp_fanart.jpg&mode=1&name=%5bCOLOR%20yellow%5d%5bB%5dEVENTOS%20DESPORTIVOS%5b%2fB%5d%5b%2fCOLOR%5d&url=http%3a%2f%2fmilhano.pt%2fftp-milhano%2faladotv%2fTheAnonymous.Desporto%2fsportsonline2%2f")')

def click_9():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.microjen/get_list/https://l3grthu.com/ez/endzone.xmll",return)')

def click_10():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.vnmedia/resources/lib/mkd/onfshare/gcs/listvmf_gcs/?_pickle_=80049553000000000000007d94288c075f7469746c655f948c1953e1bbb0204b49e1bb864e205452e1bbb043205449e1babe50948c065f617267735f948c1868747470733a2f2f6d6933732e746f702f766e6d656469619468028694752e")')

def click_11():
    xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.downloader/resources/okpn.py, ActivateWindow(10025,"plugin://plugin.video.nemesisaio/?description=Sports%20Time%2c%20Come%20On%20You%20Reds%20%23YNWA&fanart=0&iconimage=special://home/addons%5cplugin.video.nemesisaio%5cresources%5cImages%5cSports.gif&mode=1&name=%5bCOLOR%20yellow%5d%5bB%5dLive%20Sports%20%26%20Replays%5b%2fB%5d%5b%2fCOLOR%5d&url=SPORTS"))')

def click_12():
    xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.myselect/folders/py/Daddylive.py)')

live_now()
