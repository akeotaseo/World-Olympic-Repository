import xbmc, xbmcgui



def live_now():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]       Live Now...[/COLOR][/B]',
['[B][COLOR white]Sport[COLOR gold]HD[COLOR white] - Πλήρες Πρόγραμμα Αγώνων[/COLOR][/B] [COLOR orange] (microjen)[/COLOR]',

 '[B][COLOR red]Live[/COLOR][COLOR white]TV.ru[/COLOR] - Πλήρες Πρόγραμμα Αγώνων[/B] [COLOR orange] (microjen)[/COLOR]',

 '[COLOR=firebrick]DADDYLIVE[/COLOR]',


 # '[COLOR lime]====================[/COLOR]',

 # '[COLOR=white]Rojadirecta[/COLOR] [COLOR green](Dracarys)[/COLOR]',
 '[B][Live][/B]  (tvone1112)',
 '[COLOR gold]LISTA 3[/COLOR] [COLOR blue](Sportzonline)[/COLOR]  [COLOR=aqua](mandrakodi)[/COLOR]',
 # '[B][COLOR white]ALL YOU CAN SPORT[/B]  [COLOR green](thegroove360)[/COLOR]'
 '[I]Tâm điểm thapcam  [COLOR orange](thapcam)[/COLOR][/I]'
 # '[COLOR lime]====================[/COLOR]'

 # '[COLOR=blue]=[COLOR=olive]Daddylive[COLOR=blue]=[/COLOR]',

 # '[COLOR=blue]=[COLOR=white]Live TV[COLOR=blue]=[CR][COLOR=red]sx[/COLOR]'
 ])




    if call:
        if call < 1:
            return
        func = funcs[call-6]
        return func()
    else:
        func = funcs[call]
        return func()
    return 






def click_1():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.microjen/sporthd?description=Daily%20events%20list&iconimage=https%3a%2f%2fraw.githubusercontent.com%2fbugatsinho%2fbugatsinho.github.io%2fmaster%2fplugin.video.sporthdme%2ficon.png&mode=events&name=%5bB%5d-%20%5bCOLOR%20white%5dSport%5bCOLOR%20gold%5dHD%5bCOLOR%20white%5d%20-%20%ce%a0%ce%bb%ce%ae%cf%81%ce%b5%cf%82%20%ce%a0%cf%81%cf%8c%ce%b3%cf%81%ce%b1%ce%bc%ce%bc%ce%b1%20%ce%91%ce%b3%cf%8e%ce%bd%cf%89%ce%bd%5b%2fCOLOR%5d%5b%2fB%5d&url=https%3a%2f%2fsuper.league.do%2f")')


def click_2():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloader19/set_setting_LivetvsxACE_off.py")')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.microjen/sporthd?description=LiveTV.ru%20Daily%20events%20list&iconimage=C%3a%5cPortableApps%5ckodi%5cKODI%20TEST%5cKodi%5cportable_data%5caddons%5cplugin.video.microjen%5cresources%5clib%5cexternal%5csporthd%5cmedia%5clivetv.png&mode=livetvSX_events&name=%5bB%5d-%20%5bCOLOR%20red%5dLive%5b%2fCOLOR%5d%5bCOLOR%20white%5dTV.ru%5b%2fCOLOR%5d%20-%20%ce%a0%ce%bb%ce%ae%cf%81%ce%b5%cf%82%20%ce%a0%cf%81%cf%8c%ce%b3%cf%81%ce%b1%ce%bc%ce%bc%ce%b1%20%ce%91%ce%b3%cf%8e%ce%bd%cf%89%ce%bd%5b%2fB%5d&url=eJzLKCkpKLbS109OydPLySxLLSmzMDXWy03VLyou1i8tSM7PzcxLj0%2fN06vIzQEAZbMQMg%3d%3d")')
    


def click_3():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.daddylive/?mode=menu&serv_type=sched")')


# def click_4():
    # xbmc.executebuiltin('Dialog.Close(all,true)')
    # xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.myselect/folders/py/Live_Now.py")')


# def click_5():
    # xbmc.executebuiltin('Dialog.Close(all,true)')
    # xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.dracarys/?category=live_sport&mode=open_site&site=rojadirecta")')


def click_4():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.tvone1111/list_live")')


def click_5():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.mandrakodi/?action=myresolve&parIn=zonline&url=sportMenu")')


# def click_6():
    # xbmc.executebuiltin('Dialog.Close(all,true)')
    # xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.thegroove360/regex/eyJfX2NsYXNzX18iOiAiVGhlZ3Jvb3ZlSXRlbSIsICJfX21vZHVsZV9fIjogInJlc291cmNlcy5tb2R1bGVzLnRoZWdyb292ZS50aGVncm9vdmVfaXRlbSIsICJfcmF3IjogIjxpdGVtPlxuPHRpdGxlPltDT0xPUiBsaW1lXSAtIFtCXVtDT0xPUiBpdm9yeV1BTEwgWU9VIENBTiBTUE9SVFsvQ09MT1JdWy9CXTwvdGl0bGU+XG48bGluaz4kZG9yZWdleFttYWtlbGlzdF08L2xpbms+XG48dGh1bWJuYWlsPmh0dHBzOi8vd3d3LmRyb3Bib3guY29tL3MvYzR2eHU4bW8weHQ5Nmx2L3Nwb3J0LnBuZz9kbD0xPC90aHVtYm5haWw+XG48ZmFuYXJ0Pmh0dHBzOi8vd3d3LmRyb3Bib3guY29tL3MvYzR2eHU4bW8weHQ5Nmx2L3Nwb3J0LnBuZz9kbD0xPC9mYW5hcnQ+XG48cmVnZXg+XG48bmFtZT5tYWtlbGlzdDwvbmFtZT5cbjxsaXN0cmVwZWF0PjwhW0NEQVRBW1xuPHRpdGxlPltDT0xPUiB3aGl0ZV0gW21ha2VsaXN0LnBhcmFtMV1bL0NPTE9SXTwvdGl0bGU+XG48dGh1bWJuYWlsPjwvdGh1bWJuYWlsPlxuPGZhbmFydD48L2ZhbmFydD5cbjxsaW5rPiRkb3JlZ2V4W21ha2VsaXN0Ml08L2xpbms+XG48cmVmZXJlcj48L3JlZmVyZXI+XG5dXT48L2xpc3RyZXBlYXQ+XG48ZXhwcmVzPjwhW0NEQVRBWyMkcHlGdW5jdGlvblxuZGVmIGdldF90aGVncm9vdmVfeG1sX2ZuKHBhZ2U9XCJcIiwgcGFnZV9zcmM9XCJcIik6XG4gICAgdHJ5OlxuICAgICAgICBpbXBvcnQgcmVxdWVzdHMsIHJlXG4gICAgICAgIGZyb20gZGF0ZXRpbWUgaW1wb3J0IGRhdGV0aW1lLCB0aW1lZGVsdGFcbiAgICAgICAgaW1wb3J0IHRpbWVcbiAgICAgICAgdXJsID0gcGFnZVxuXG4gICAgICAgIGV4cHJlc3MxID0gcicoXFxkKzpcXGQrKVxccyguKj8pXFxzXFx8XFxzKC4qPylcXG4nXG4gICAgICAgIFxuXG4gICAgICAgIGhlYWRlcnMgPSB7XG4gICAgICAgICAgICAndXNlci1hZ2VudCc6IFwiTW96aWxsYS81LjAgKFgxMTsgTGludXggeDg2XzY0KSBBcHBsZVdlYktpdC81MzcuMzYgKEtIVE1MLCBsaWtlIEdlY2tvKSBDaHJvbWUvNzQuMC4zNzI5LjEzMSBTYWZhcmkvNTM3LjM2XCJcbiAgICAgICAgfVxuXG4gICAgICAgIHMgPSByZXF1ZXN0cy5TZXNzaW9uKClcbiAgICAgICAgciA9IHMuZ2V0KHVybCwgaGVhZGVycz1oZWFkZXJzKVxuICAgICAgICBwcmludChyLnRleHQpXG4gICAgICAgIHJlcyA9IHJlLmNvbXBpbGUoZXhwcmVzczEsIHJlLk1VTFRJTElORSB8IHJlLkRPVEFMTCkuZmluZGFsbChyLnRleHQpXG5cbiAgICAgICAgcmV0ID0gW11cblxuICAgICAgICBzdWJsaW5rcyA9IFtdXG4gICAgICAgIGZvciByIGluIHJlczpcbiAgICAgICAgICAgIG9yYXJpb19vcmlnID0gZGF0ZXRpbWUoKih0aW1lLnN0cnB0aW1lKHJbMF0sIFwiJUg6JU1cIilbMDo2XSkpXG4gICAgICAgICAgICBvcmFyaW9fbnVvdm8gPSBvcmFyaW9fb3JpZyArIHRpbWVkZWx0YShob3Vycz0rMSlcbiAgICAgICAgICAgIGRhdGEgPSBvcmFyaW9fbnVvdm8uc3RyZnRpbWUoXCIlSDolTVwiKVxuXG4gICAgICAgICAgICB0aXRvbG8gPSBcIltDT0xPUiBsaW1lXVwiICsgZGF0YSArIFwiWy9DT0xPUl1cIiArIFwiW0NPTE9SIGl2b3J5XSBcIiArIHJbMV0gKyBcIlsvQ09MT1JdXCJcbiBcbiAgICAgICAgICAgIHJldC5hcHBlbmQoKHRpdG9sbyxyWzJdKSlcbiAgICAgICAgICAgIFxuICAgICAgICByZXR1cm4gcmV0XG4gICAgZXhjZXB0IEV4Y2VwdGlvbiBhcyBlOlxuICAgICAgICBpbXBvcnQgdHJhY2ViYWNrXG4gICAgICAgIHRyYWNlYmFjay5wcmludF9leGMoKVxuICAgICAgICBwcmludChlKVxuXV0+PC9leHByZXM+XG48cGFnZT5odHRwczovL3Nwb3J0c29ubGluZS5nbC9wcm9nLnR4dDwvcGFnZT5cbjwvcmVnZXg+XG5cblxuPHJlZ2V4PlxuICAgIDxuYW1lPm1ha2VsaXN0MjwvbmFtZT5cbiAgICA8ZXhwcmVzPjwhW0NEQVRBWyMkcHlGdW5jdGlvblxuZGVmIGdldF90aGVncm9vdmVfeG1sX2ZuKHBhZ2U9XCJcIik6XG4gICBcbiAgICB0cnk6XG4gICAgICAgXG5cbiAgICAgICAgcmV0dXJuICAgJ1ttYWtlbGlzdC5wYXJhbTJdJ1xuICAgICAgICBcbiAgICBleGNlcHQgRXhjZXB0aW9uIGFzIGU6XG4gICAgICAgIGltcG9ydCB0cmFjZWJhY2tcbiAgICAgICAgdHJhY2ViYWNrLnByaW50X2V4YygpXG4gICAgICAgIHByaW50KGUpXG5dXT48L2V4cHJlcz5cbiAgICA8cGFnZT48L3BhZ2U+XG48L3JlZ2V4PlxuPC9pdGVtPiIsICJhcnRzIjogeyJ0aHVtYm5haWwiOiAiIiwgImZhbmFydCI6ICJodHRwczovL3d3dy5kcm9wYm94LmNvbS9zL2M0dnh1OG1vMHh0OTZsdi9zcG9ydC5wbmc/ZGw9MSIsICJ0aHVtYiI6ICJodHRwczovL3d3dy5kcm9wYm94LmNvbS9zL2M0dnh1OG1vMHh0OTZsdi9zcG9ydC5wbmc/ZGw9MSJ9LCAiaW5mbyI6IHsiZ2VucmUiOiAiIiwgImNvdW50cnkiOiAiIiwgInllYXIiOiAiIiwgImVwaXNvZGUiOiAiIiwgInNlYXNvbiI6ICIiLCAic29ydGVwaXNvZGUiOiAiIiwgInNvcnRzZWFzb24iOiAiIiwgImVwaXNvZGVndWlkZSI6ICIiLCAic2hvd2xpbmsiOiAiIiwgInRvcDI1MCI6ICIiLCAic2V0aWQiOiAiIiwgInRyYWNrbnVtYmVyIjogIiIsICJyYXRpbmciOiAiIiwgInVzZXJyYXRpbmciOiAiIiwgIndhdGNoZWQiOiAiIiwgInBsYXljb3VudCI6ICIiLCAib3ZlcmxheSI6ICIiLCAiY2FzdCI6IFtdLCAiY2FzdGFuZHJvbGUiOiBbXSwgImRpcmVjdG9yIjogIiIsICJtcGFhIjogIiIsICJwbG90IjogIiIsICJwbG90b3V0bGluZSI6ICIiLCAidGl0bGUiOiAiIiwgIm9yaWdpbmFsdGl0bGUiOiAiIiwgInNvcnR0aXRsZSI6ICIiLCAiZHVyYXRpb24iOiAiIiwgInN0dWRpbyI6ICIiLCAidGFnbGluZSI6ICIiLCAid3JpdGVyIjogIiIsICJ0dnNob3d0aXRsZSI6ICIiLCAicHJlbWllcmVkIjogIiIsICJzdGF0dXMiOiAiIiwgInNldCI6ICIiLCAic2V0b3ZlcnZpZXciOiAiIiwgInRhZyI6ICIiLCAiaW1kYm51bWJlciI6ICIiLCAiY29kZSI6ICIiLCAiYWlyZWQiOiAiIiwgImNyZWRpdHMiOiAiIiwgImxhc3RwbGF5ZWQiOiAiIiwgImFsYnVtIjogIiIsICJhcnRpc3QiOiBbXSwgInZvdGVzIjogIiIsICJwYXRoIjogIiIsICJ0cmFpbGVyIjogIiIsICJkYXRlYWRkZWQiOiAiIiwgIm1lZGlhdHlwZSI6ICJ2aWRlbyIsICJkYmlkIjogIiJ9LCAicmVnZXhlcyI6IFtdLCAiaXNfZm9sZGVyIjogdHJ1ZSwgInVybCI6ICIkZG9yZWdleFttYWtlbGlzdF0iLCAibGFiZWwiOiAiW0NPTE9SIGxpbWVdIC0gW0JdW0NPTE9SIGl2b3J5XUFMTCBZT1UgQ0FOIFNQT1JUWy9DT0xPUl1bL0JdIiwgInBhcmVudF94bWwiOiAiIiwgInN1YmxpbmtzIjogW10sICJpc19wbGF5YWJsZSI6IGZhbHNlLCAidGdfcmVzb2x2ZXIiOiAiIiwgImlzX3BsdWdpbiI6IGZhbHNlLCAicG9zIjogMH0=")')


# def click_8():
    # xbmc.executebuiltin('Dialog.Close(all,true)')
    # xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.myselect/folders/py/Daddylive.py)')


# def click_9():
    # xbmc.executebuiltin('Dialog.Close(all,true)')
    # xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.myselect/folders/py/Daddylive.py)')


def click_6():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.thapcam/?mode=index_thapcam")')

# def click_7():
    # xbmc.executebuiltin('Dialog.Close(all,true)')
    # xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.myselect/folders/py/Livetvsx.py")')

live_now()
