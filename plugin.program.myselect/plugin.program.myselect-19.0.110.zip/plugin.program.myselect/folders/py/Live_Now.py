import xbmc, xbmcgui



def live_now():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7, click_8, click_9, click_10, click_11, click_12)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]       Live Now...[/COLOR][/B]',
['[COLOR=orange]LIVE EVENTS[/COLOR] (SportHD)',

 '[COLOR=red]DADDYLIVE[/COLOR]',


 '[COLOR=white]Streamonsport[/COLOR] [COLOR=purple](vstream)[/COLOR]',
 '[COLOR=white]Live TV[/COLOR] [COLOR=red]sx[/COLOR]',


 '[COLOR=white]Rojadirecta[/COLOR] [COLOR green](Dracarys)[/COLOR]',

 '[COLOR lightcyan][B]AGENDA [/COLOR][COLOR lightblue]SPORTZONLINE[/COLOR][/B] *',
 '[COLOR lime] - [B][COLOR ivory]ALL YOU CAN SPORT[/COLOR][/B] (thegroove360)[/COLOR] * *',

 '[B][I][COLORyellow]TODAYS SPORTING EVENTS3[/COLOR][/B][/I]  (madtitansports)',


 '[COLOR=white]USA SPORTS [COLOR=lime](The Endzone 19) [COLOR=orange](microjen)[/COLOR]  [COLOR red]OFF?...[/COLOR]',

 '[COLOR yellow]NemesisAIO Live Sports & Replays[/COLOR]',
 
 '[COLOR=white]Daddylive [COLOR=olive](All)[/COLOR]'
 ])




    if call:
        if call < 1:
            return
        func = funcs[call-12]
        return func()
    else:
        func = funcs[call]
        return func()
    return 






def click_1():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.sporthdme/?description=C%3a%5cPortableApps%5ckodi%5ckodi%20World%2021%5cKodi%5cportable_data%5caddons%5cplugin.video.sporthdme%5cfanart.jpg&iconimage=C%3a%5cPortableApps%5ckodi%5ckodi%20World%2021%5cKodi%5cportable_data%5caddons%5cplugin.video.sporthdme%5cicon.png&mode=events&name=%5bB%5d%5bCOLOR%20white%5dLIVE%20EVENTS%5b%2fCOLOR%5d%5b%2fB%5d&url=https%3a%2f%2fsporthd.me%2f")')
    #xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.myselect/folders/py/sporthdme.py")')

def click_2():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.daddylive/?mode=menu&serv_type=sched",return)')

def click_3():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.vstream/?function=load&sFav=load&site=streamonsport&siteUrl=%2f&title=Streamonsport")')

def click_4():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.myselect/folders/py/Livetvsx.py")')

def click_5():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.dracarys/?category=live_sport&mode=open_site&site=livetv")')

def click_6():
    
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.dracarys/?category=live_sport&mode=open_site&site=rojadirecta")')

def click_7():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.live.streamspro/?iconimage=http%3a%2f%2fbgtv.xyz%2fblack%2fimg%2fdeportes.png&mode=17&regexs=%7b%27makelist%27%3a%20%7b%27name%27%3a%20%27makelist%27%2c%20%27listrepeat%27%3a%20%27%5cn%20%20%3ctitle%3e%5bCOLOR%20deepskyblue%5d%5b%2fCOLOR%5d%20%5bCOLOR%20lightgreen%5d%5bmakelist.param1%5d%5b%2fCOLOR%5d%20%5bCOLOR%20skyblue%5d%5bB%5d%5bmakelist.param2%5d%5b%2fB%5d%5b%2fCOLOR%5d%20%20%20%5bCOLOR%20lightslategray%5d%5bI%5d%5bmakelist.param4%5d%20%5b%2fI%5d%5b%2fCOLOR%5d%3c%2ftitle%3e%20%3clink%3e%24doregex%5bgeturl2%5d%7cReferer%3dhttps%3a%2f%2fplanetfastidious.net%26amp%3bOrigin%3dhttps%3a%2f%2fplanetfastidious.net%26amp%3bUser-Agent%3dMozilla%2f5.0%20(Windows%20NT%2010.0%3b%20Win64%3b%20x64)%20AppleWebKit%2f537.36%20(KHTML%2c%20like%20Gecko)%20Chrome%2f117.0.0.0%20Safari%2f537.36%3c%2flink%3e%20%3creferer%3ehttps%3a%2f%2fplanetfastidious.net%2f%3c%2freferer%3e%20%3cthumbnail%3ehttp%3a%2f%2fbgtv.xyz%2fblack%2fimg%2fdeportes.png%3c%2fthumbnail%3e%5cn%27%2c%20%27expres%27%3a%20%27%3d(.%2a%3f)%2c(.%2a%3f)%2c(.%2a%3f)%2c(.%2a%3f)%5c%5cn%27%2c%20%27page%27%3a%20%27http%3a%2f%2fbgtv.xyz%2floves.php%3fszone%27%2c%20%27cookiejar%27%3a%20%27%27%7d%2c%20%27geturl2%27%3a%20%7b%27name%27%3a%20%27geturl2%27%2c%20%27expres%27%3a%20%27src%3d%22(.%2a%3f)%22%27%2c%20%27page%27%3a%20%27%24doregex%5bgetunpacked%5d%27%2c%20%27referer%27%3a%20%27https%3a%2f%2fv2.sportsonline.si%2f%27%2c%20%27cookiejar%27%3a%20%27%27%7d%2c%20%27getunpacked%27%3a%20%7b%27name%27%3a%20%27getunpacked%27%2c%20%27expres%27%3a%20%22%24pyFunction%3aget_unpacked(page_data%2c%27(eval%5c%5c(function%5c%5c(p%2ca%2cc%2ck%2ce%2cd.%2a)%27%20)%22%2c%20%27page%27%3a%20%27https%3a%24doregex%5bgeturl%5d%27%2c%20%27referer%27%3a%20%27https%3a%2f%2fv2.sportsonline.si%2fchannels%2fhd%2fhd6.php%27%2c%20%27connection%27%3a%20%27keep-alive%27%2c%20%27cookiejar%27%3a%20%27%27%7d%2c%20%27geturl%27%3a%20%7b%27name%27%3a%20%27geturl%27%2c%20%27expres%27%3a%20%27iframe%20src%3d%22(.%2b%3f)%22%27%2c%20%27page%27%3a%20%27%5bmakelist.param3%5d%27%2c%20%27cookiejar%27%3a%20%27%27%7d%7d&url=%24doregex%5bmakelist%5d")')

def click_8():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.thegroove360/regex/eyJfX2NsYXNzX18iOiAiVGhlZ3Jvb3ZlSXRlbSIsICJfX21vZHVsZV9fIjogInJlc291cmNlcy5tb2R1bGVzLnRoZWdyb292ZS50aGVncm9vdmVfaXRlbSIsICJfcmF3IjogIjxpdGVtPlxuPHRpdGxlPltDT0xPUiBsaW1lXSAtIFtCXVtDT0xPUiBpdm9yeV1BTEwgWU9VIENBTiBTUE9SVFsvQ09MT1JdWy9CXTwvdGl0bGU+XG48bGluaz4kZG9yZWdleFttYWtlbGlzdF08L2xpbms+XG48dGh1bWJuYWlsPmh0dHBzOi8vd3d3LmRyb3Bib3guY29tL3MvYzR2eHU4bW8weHQ5Nmx2L3Nwb3J0LnBuZz9kbD0xPC90aHVtYm5haWw+XG48ZmFuYXJ0Pmh0dHBzOi8vd3d3LmRyb3Bib3guY29tL3MvYzR2eHU4bW8weHQ5Nmx2L3Nwb3J0LnBuZz9kbD0xPC9mYW5hcnQ+XG48cmVnZXg+XG48bmFtZT5tYWtlbGlzdDwvbmFtZT5cbjxsaXN0cmVwZWF0PjwhW0NEQVRBW1xuPHRpdGxlPltDT0xPUiB3aGl0ZV0gW21ha2VsaXN0LnBhcmFtMV1bL0NPTE9SXTwvdGl0bGU+XG48dGh1bWJuYWlsPjwvdGh1bWJuYWlsPlxuPGZhbmFydD48L2ZhbmFydD5cbjxsaW5rPiRkb3JlZ2V4W21ha2VsaXN0Ml08L2xpbms+XG48cmVmZXJlcj48L3JlZmVyZXI+XG5dXT48L2xpc3RyZXBlYXQ+XG48ZXhwcmVzPjwhW0NEQVRBWyMkcHlGdW5jdGlvblxuZGVmIGdldF90aGVncm9vdmVfeG1sX2ZuKHBhZ2U9XCJcIiwgcGFnZV9zcmM9XCJcIik6XG4gICAgdHJ5OlxuICAgICAgICBpbXBvcnQgcmVxdWVzdHMsIHJlXG4gICAgICAgIGZyb20gZGF0ZXRpbWUgaW1wb3J0IGRhdGV0aW1lLCB0aW1lZGVsdGFcbiAgICAgICAgaW1wb3J0IHRpbWVcbiAgICAgICAgdXJsID0gcGFnZVxuXG4gICAgICAgIGV4cHJlc3MxID0gcicoXFxkKzpcXGQrKVxccyguKj8pXFxzXFx8XFxzKC4qPylcXG4nXG4gICAgICAgIFxuXG4gICAgICAgIGhlYWRlcnMgPSB7XG4gICAgICAgICAgICAndXNlci1hZ2VudCc6IFwiTW96aWxsYS81LjAgKFgxMTsgTGludXggeDg2XzY0KSBBcHBsZVdlYktpdC81MzcuMzYgKEtIVE1MLCBsaWtlIEdlY2tvKSBDaHJvbWUvNzQuMC4zNzI5LjEzMSBTYWZhcmkvNTM3LjM2XCJcbiAgICAgICAgfVxuXG4gICAgICAgIHMgPSByZXF1ZXN0cy5TZXNzaW9uKClcbiAgICAgICAgciA9IHMuZ2V0KHVybCwgaGVhZGVycz1oZWFkZXJzKVxuICAgICAgICBwcmludChyLnRleHQpXG4gICAgICAgIHJlcyA9IHJlLmNvbXBpbGUoZXhwcmVzczEsIHJlLk1VTFRJTElORSB8IHJlLkRPVEFMTCkuZmluZGFsbChyLnRleHQpXG5cbiAgICAgICAgcmV0ID0gW11cblxuICAgICAgICBzdWJsaW5rcyA9IFtdXG4gICAgICAgIGZvciByIGluIHJlczpcbiAgICAgICAgICAgIG9yYXJpb19vcmlnID0gZGF0ZXRpbWUoKih0aW1lLnN0cnB0aW1lKHJbMF0sIFwiJUg6JU1cIilbMDo2XSkpXG4gICAgICAgICAgICBvcmFyaW9fbnVvdm8gPSBvcmFyaW9fb3JpZyArIHRpbWVkZWx0YShob3Vycz0rMSlcbiAgICAgICAgICAgIGRhdGEgPSBvcmFyaW9fbnVvdm8uc3RyZnRpbWUoXCIlSDolTVwiKVxuXG4gICAgICAgICAgICB0aXRvbG8gPSBcIltDT0xPUiBsaW1lXVwiICsgZGF0YSArIFwiWy9DT0xPUl1cIiArIFwiW0NPTE9SIGl2b3J5XSBcIiArIHJbMV0gKyBcIlsvQ09MT1JdXCJcbiBcbiAgICAgICAgICAgIHJldC5hcHBlbmQoKHRpdG9sbyxyWzJdKSlcbiAgICAgICAgICAgIFxuICAgICAgICByZXR1cm4gcmV0XG4gICAgZXhjZXB0IEV4Y2VwdGlvbiBhcyBlOlxuICAgICAgICBpbXBvcnQgdHJhY2ViYWNrXG4gICAgICAgIHRyYWNlYmFjay5wcmludF9leGMoKVxuICAgICAgICBwcmludChlKVxuXV0+PC9leHByZXM+XG48cGFnZT5odHRwczovL3Nwb3J0c29ubGluZS5nbC9wcm9nLnR4dDwvcGFnZT5cbjwvcmVnZXg+XG5cblxuPHJlZ2V4PlxuICAgIDxuYW1lPm1ha2VsaXN0MjwvbmFtZT5cbiAgICA8ZXhwcmVzPjwhW0NEQVRBWyMkcHlGdW5jdGlvblxuZGVmIGdldF90aGVncm9vdmVfeG1sX2ZuKHBhZ2U9XCJcIik6XG4gICBcbiAgICB0cnk6XG4gICAgICAgXG5cbiAgICAgICAgcmV0dXJuICAgJ1ttYWtlbGlzdC5wYXJhbTJdJ1xuICAgICAgICBcbiAgICBleGNlcHQgRXhjZXB0aW9uIGFzIGU6XG4gICAgICAgIGltcG9ydCB0cmFjZWJhY2tcbiAgICAgICAgdHJhY2ViYWNrLnByaW50X2V4YygpXG4gICAgICAgIHByaW50KGUpXG5dXT48L2V4cHJlcz5cbiAgICA8cGFnZT48L3BhZ2U+XG48L3JlZ2V4PlxuPC9pdGVtPiIsICJhcnRzIjogeyJ0aHVtYm5haWwiOiAiIiwgImZhbmFydCI6ICJodHRwczovL3d3dy5kcm9wYm94LmNvbS9zL2M0dnh1OG1vMHh0OTZsdi9zcG9ydC5wbmc/ZGw9MSIsICJ0aHVtYiI6ICJodHRwczovL3d3dy5kcm9wYm94LmNvbS9zL2M0dnh1OG1vMHh0OTZsdi9zcG9ydC5wbmc/ZGw9MSJ9LCAiaW5mbyI6IHsiZ2VucmUiOiAiIiwgImNvdW50cnkiOiAiIiwgInllYXIiOiAiIiwgImVwaXNvZGUiOiAiIiwgInNlYXNvbiI6ICIiLCAic29ydGVwaXNvZGUiOiAiIiwgInNvcnRzZWFzb24iOiAiIiwgImVwaXNvZGVndWlkZSI6ICIiLCAic2hvd2xpbmsiOiAiIiwgInRvcDI1MCI6ICIiLCAic2V0aWQiOiAiIiwgInRyYWNrbnVtYmVyIjogIiIsICJyYXRpbmciOiAiIiwgInVzZXJyYXRpbmciOiAiIiwgIndhdGNoZWQiOiAiIiwgInBsYXljb3VudCI6ICIiLCAib3ZlcmxheSI6ICIiLCAiY2FzdCI6IFtdLCAiY2FzdGFuZHJvbGUiOiBbXSwgImRpcmVjdG9yIjogIiIsICJtcGFhIjogIiIsICJwbG90IjogIiIsICJwbG90b3V0bGluZSI6ICIiLCAidGl0bGUiOiAiIiwgIm9yaWdpbmFsdGl0bGUiOiAiIiwgInNvcnR0aXRsZSI6ICIiLCAiZHVyYXRpb24iOiAiIiwgInN0dWRpbyI6ICIiLCAidGFnbGluZSI6ICIiLCAid3JpdGVyIjogIiIsICJ0dnNob3d0aXRsZSI6ICIiLCAicHJlbWllcmVkIjogIiIsICJzdGF0dXMiOiAiIiwgInNldCI6ICIiLCAic2V0b3ZlcnZpZXciOiAiIiwgInRhZyI6ICIiLCAiaW1kYm51bWJlciI6ICIiLCAiY29kZSI6ICIiLCAiYWlyZWQiOiAiIiwgImNyZWRpdHMiOiAiIiwgImxhc3RwbGF5ZWQiOiAiIiwgImFsYnVtIjogIiIsICJhcnRpc3QiOiBbXSwgInZvdGVzIjogIiIsICJwYXRoIjogIiIsICJ0cmFpbGVyIjogIiIsICJkYXRlYWRkZWQiOiAiIiwgIm1lZGlhdHlwZSI6ICJ2aWRlbyIsICJkYmlkIjogIiJ9LCAicmVnZXhlcyI6IFtdLCAiaXNfZm9sZGVyIjogdHJ1ZSwgInVybCI6ICIkZG9yZWdleFttYWtlbGlzdF0iLCAibGFiZWwiOiAiW0NPTE9SIGxpbWVdIC0gW0JdW0NPTE9SIGl2b3J5XUFMTCBZT1UgQ0FOIFNQT1JUWy9DT0xPUl1bL0JdIiwgInBhcmVudF94bWwiOiAiIiwgInN1YmxpbmtzIjogW10sICJpc19wbGF5YWJsZSI6IGZhbHNlLCAidGdfcmVzb2x2ZXIiOiAiIiwgImlzX3BsdWdpbiI6IGZhbHNlLCAicG9zIjogMH0=")')


def click_9():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.madtitansports/get_list/https://magnetic.website/MAD_TITAN_SPORTS/SPORTS/search_leagues.json")')




def click_10():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.shadow/?all_w=%7b%7d&data=%20&dates=%20&description=%20&eng_name=%20&episode=%20&fanart=https%3a%2f%2f&fav_status=false&heb_name=%20&iconimage=https%3a%2f%2fwww.midian.appboxes.co%2fwolfyB%2ffiles%2fplugin.video.ez19%2ficon.png&id&image_master&isr=0&last_id&mode=189&mypass&name=%5bCOLORnavajowhite%5dThe%20Endzone%2019%5b%2fCOLOR%5d&original_title=%20&search_db&season=%20&show_original_year=%20&tmdbid=%20&url=https%3a%2f%2fl3grthu.com%2fez%2fendzone.xml&video_data=%7b%22title%22%3a%20%22%5bCOLORnavajowhite%5dThe%20Endzone%2019%5b%2fCOLOR%5d%22%2c%20%22mediatype%22%3a%20%22movie%22%2c%20%22TVshowtitle%22%3a%20%22%22%2c%20%22season%22%3a%200%2c%20%22episode%22%3a%200%2c%20%22OriginalTitle%22%3a%20%22%20%22%2c%20%22rating%22%3a%20%220%22%2c%20%22plot%22%3a%20%22%20%22%2c%20%22Tag%22%3a%20%22189%22%2c%20%22trailer%22%3a%20%22%22%2c%20%22id%22%3a%20%22%22%7d")')

def click_11():
    xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.downloader/resources/okpn.py, ActivateWindow(10025,"plugin://plugin.video.nemesisaio/?description=Sports%20Time%2c%20Come%20On%20You%20Reds%20%23YNWA&fanart=0&iconimage=special://home/addons%5cplugin.video.nemesisaio%5cresources%5cImages%5cSports.gif&mode=1&name=%5bCOLOR%20yellow%5d%5bB%5dLive%20Sports%20%26%20Replays%5b%2fB%5d%5b%2fCOLOR%5d&url=SPORTS"))')

def click_12():
    xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.myselect/folders/py/Daddylive.py)')

live_now()
