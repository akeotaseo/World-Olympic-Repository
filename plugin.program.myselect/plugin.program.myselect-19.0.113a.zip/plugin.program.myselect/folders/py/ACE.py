import xbmc, xbmcgui, webbrowser


# xbmcgui.Dialog().ok('[B][COLOR blue]ACE[/COLOR][/B]', '[COLOR green]Πρώτα ανοίξτε [/COLOR] [COLOR chocolate]το Ace Stream Media[/COLOR] (σε Windows)[CR][CR]Αν αποτύχει η αναπαραγωγή, δοκιμάστε ξανά.')


def ACE():
    funcs = (click_1, click_2)
    call = xbmcgui.Dialog().select('[B][COLOR=blue]~ ACE ~[/COLOR][/B]', 
['[B][COLOR=lime]ΑceStream[/COLOR][/B]',

'[B][COLOR=]https://www.acestream.org[/COLOR][/B]'
 ])


    if call:
        if call < 0:
            return
        func = funcs[call-2]
        return func()
    else:
        func = funcs[call]
        return func()
    return 

def click_1():
    xbmcgui.Dialog().ok('[B][COLOR blue]ACE[/COLOR][/B]', '[COLOR green]Πρώτα ανοίξτε [/COLOR] [COLOR chocolate]το Ace Stream Media[/COLOR] (σε Windows)[CR][CR]Αν αποτύχει η αναπαραγωγή, δοκιμάστε ξανά.')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.myselect/?group=14ace-14&mode=group&refresh&reload")')



def click_2():
    choice = xbmcgui.Dialog().yesno('[COLOR orange]www.acestream.org[/COLOR]', 'Εγκαταστήστε το [B][COLOR=blue]ACE STREAM[/COLOR][/B] για το λειτουργικό σας σύστημα...',
        
                                        nolabel='[B][COLOR white]Άκυρο[/COLOR][/B]',yeslabel='[B][COLOR=blue]ACE STREAM[/COLOR][/B]')
    
    if choice == 1: menuoptions()
    if choice == 0: xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.myselect/folders/py/ACE.py")')
    
    

def menuoptions():
    dialog = xbmcgui.Dialog()
    funcs = (
        function1, function2
    )
        
    call = dialog.select('[B][COLOR=blur]ACE STREAM[/COLOR][/B]',
    [
    'Ανακατεύθυνση σε https://www.acestream.org',])

    # dialog.selectreturns
    #   0 -> escape pressed
    #   1 -> first item
    #   2 -> second item
    if call:
        # esc is not pressed
        if call < 0:
            return
        func = funcs[call-2]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def platform():
    if xbmc.getCondVisibility('system.platform.android'):
        return 'android'
    elif xbmc.getCondVisibility('system.platform.linux'):
        return 'linux'
    elif xbmc.getCondVisibility('system.platform.windows'):
        return 'windows'
    elif xbmc.getCondVisibility('system.platform.osx'):
        return 'osx'
    elif xbmc.getCondVisibility('system.platform.atv2'):
        return 'atv2'
    elif xbmc.getCondVisibility('system.platform.ios'):
        return 'ios'

myplatform = platform()

def function1():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.acestream.org/' ) )
    else:
        opensite = webbrowser . open('https://www.acestream.org/')


def function2():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.acestream.org/' ) )
    else:
        opensite = webbrowser . open('https://www.acestream.org/')




ACE()
