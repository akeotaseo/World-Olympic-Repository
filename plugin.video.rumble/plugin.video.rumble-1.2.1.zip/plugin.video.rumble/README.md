Ilikenwf forked this from https://github.com/OnePlayHD/OneRepo as they had the GPL in their repo, but for whatever reason had the code for this addon obfuscated.

The code has been unobfuscated and cleaned up.
Also has been updated for the new rumble site layout and is now both python 2 & 3 compatible.

Users can now login to see their subscription feed. This is classed as "in test" functionality.
Since it is now working it can now be improved upon.
To login go to "Settings" -> "Debug"
Then enter your username & password.
Save the settings.

A subscription entry will now appear in the menu which will try to log you in to see your subscription feed.
