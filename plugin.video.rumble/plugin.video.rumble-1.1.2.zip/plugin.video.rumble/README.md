Ilikenwf forked this from https://github.com/OnePlayHD/OneRepo as they had the GPL in their repo, but for whatever reason had the code for this addon obfuscated.

The code has been unobfuscated and cleaned up.
Also has been updated for the new rumble site layout and now made python 2 compatible,
