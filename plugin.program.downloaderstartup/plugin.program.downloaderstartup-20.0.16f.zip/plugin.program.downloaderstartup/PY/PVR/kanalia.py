import os, xbmc, xbmcgui

def kanalia():
    if not xbmc.getCondVisibility('System.HasAddon({})'.format('pvr.stalker')):
        choice = xbmcgui.Dialog().yesno('[COLOR orange]PVR Stalker[/COLOR]', '[COLOR white]Μετά την εγκατάσταση του πρόσθετου ανοίξτε το PVR Stalker απο τα [B]ΚΑΝΑΛΙΑ[/B]. Χρησιμοποιήστε την [COLOR lime]Αυτοματοποιημένη αντικατάσταση πύλης[/COLOR] ή περάστε δικές πύλες με την βοήθεια των Ιστότοπων Stalker Portal.[/COLOR]',
                                        nolabel='[B][COLOR orange]Άκυρο[/COLOR][/B]',yeslabel='[B][COLOR lime]Εγκατάσταση[/COLOR][/B]')

        if choice == 1: install()
                        # (xbmc.executebuiltin('InstallAddon(pvr.stalker)'),
                         # xbmc.sleep(1000),
                         # xbmc.executebuiltin('SendClick(11)'))
    if xbmc.getCondVisibility('System.HasAddon({})'.format('pvr.stalker')):
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.stalker","enabled":true}}')
        # xbmcgui.Dialog().notification("[COLOR orange]Υπομονή...[/COLOR]", "[COLOR white]μέχρι να φορτώσουν τα κανάλια...[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/Pleasewait.png', sound=True)
        # xbmc.sleep(4000)
        
        
        # xbmc.sleep(1000)
        
        # xbmc.executebuiltin('SendClick(11)')
        # xbmc.sleep(500)
        xbmc.executebuiltin('ActivateWindow(TVChannels)')
        xbmcgui.Dialog().notification("[COLOR orange]Υπομονή...[/COLOR]", "[COLOR white]μέχρι να φορτώσουν τα κανάλια...[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/Pleasewait.png', sound=True)
        xbmc.sleep(4000)
def install():
        xbmc.executebuiltin('InstallAddon(pvr.stalker)')




kanalia()
