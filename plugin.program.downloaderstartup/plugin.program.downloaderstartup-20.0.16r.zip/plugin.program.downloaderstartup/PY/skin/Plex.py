import xbmc, xbmcgui


def Plex():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6)
    call = xbmcgui.Dialog().select('[B]PLEX[/B]', 
['[COLOR orange]Plex[/COLOR]',
 '[COLOR White]PlexKodiConnect[/COLOR]',
 '[COLOR blue]Composite[/COLOR]',
 '[COLOR White]Plex Live[/COLOR]'])
 



    if call:
        if call < 0:
            return
        func = funcs[call-6]
        return func()
    else:
        func = funcs[call]
        return func()
    return 




#def click_1():
#    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.apex_sports/?category=live_sport&amp;mode=search)')
#    xbmcgui.Dialog().notification("[B][COLOR orange]TechNEWSology[/COLOR][/B]",'[COLOR white]Για την αναζήτηση αγώνων, πληκτρολογήστε την Ομάδα ή την Χώρα με λατινικούς χαρακτήρες ...[/COLOR]' , icon ='special://home/addons/skin.TechNEWSology/icon.png')

def click_1():
    xbmc.executebuiltin('ActivateWindow(programs,plugin://script.plex/)')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.plexkodiconnect/?content_type=video",return)')

def click_3():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.composite_for_plex/?content_type=video",return)')

def click_4():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://slyguy.plex.live/",return)')

def click_5():
    xbmc.executebuiltin("ReloadSkin()")

def click_6():
    xbmc.executebuiltin('PlayMedia("plugin://script.skinswitcher/?url=url&mode=1&name=Click+here+to+change+skins+&iconimage=C%3A%5CPortableApps%5Ckodi%5Ckodi+World+20%5CKodi%5Cportable_data%5Caddons%5Cscript.skinswitcher%5Cicon.png&fanart=C%3A%5CPortableApps%5Ckodi%5Ckodi+World+20%5CKodi%5Cportable_data%5Caddons%5Cscript.skinswitcher%5Cfanart.jpg")')

def click_7():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.romanianpack/?action=openCinemagia&meniu=tari&url=https%3a%2f%2fwww.cinemagia.ro%2ffilme%2f%3fpn%3d1",return)')

def click_8():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.romanianpack/?action=openCinemagia&meniu=all&url=https%3a%2f%2fwww.cinemagia.ro%2fseriale-tv%2f%3fpn%3d1",return)')

def click_9():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.romanianpack/?action=openCinemagia&meniu=ani&url=https%3a%2f%2fwww.cinemagia.ro%2fseriale-tv%2f%3fpn%3d1",return)')

def click_10():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.romanianpack/?action=openCinemagia&meniu=gen&url=https%3a%2f%2fwww.cinemagia.ro%2fseriale-tv%2f%3fpn%3d1",return)')

def click_11():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.romanianpack/?action=openCinemagia&meniu=tari&url=https%3a%2f%2fwww.cinemagia.ro%2ffilme%2f%3fpn%3d1",return)')

Plex()
