﻿import xbmc, xbmcgui
xbmcgui.Dialog().notification("[COLOR orange]Skin Switcher[/COLOR]", "Ανακατεύθυνση...", sound=False, icon='special://home/addons/script.skinswitcher/icon.png')

xbmc.executebuiltin('ActivateWindow(10000)')
xbmc.sleep(4000)
xbmc.executebuiltin('ActivateWindow(10001,"plugin://script.skinswitcher",return)')




