﻿import os, xbmc, xbmcvfs, xbmcgui, xbmcaddon, shutil, glob

def DeleteFoldersAutowidget():

#                            autowidge


    base_path = xbmcvfs.translatePath('special://home/addons/plugin.program.autowidget')

    dir_list = glob.iglob(os.path.join(base_path, "folders"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)


DeleteFoldersAutowidget()
