import os, xbmc, xbmcgui, xbmcvfs, xbmcaddon



def gen_pvr_W_M():
    funcs = (click_1, click_2)
    call = xbmcgui.Dialog().select(('[COLOR=lime] Αυτ/μένη αντικατάσταση πύλης [/COLOR]1-5'),
['[COLOR=blue]ZTEU [COLOR=lime]Generator [COLOR=white][1-5][/COLOR]',
 '[B][COLOR=deepskyblue]ZTEU [COLOR=lime]Generator [COLOR=white][1-5][/COLOR][/B]'])



    if call:
        if call < 0:
            return
        func = funcs[call-2]
        return func()
    else:
        func = funcs[call]
        return func()
    return 


def click_1():
#    xbmcgui.Dialog().notification("[B][COLOR lime]Pvr Stalker[/COLOR][/B] - [B][COLOR orange]Πύλη [COLOR lime]1[/COLOR][/B]",'[B][COLOR white]Αν η λίστα είναι κενή, ξαναπατάμε [COLOR=orange]ZTEU Generator![/COLOR][/B]' , icon)
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.sleep(100)
    xbmc.executebuiltin('Action(Back)')
    xbmc.sleep(100)
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.sleep(100)
    xbmc.executebuiltin('ActivateWindow(Home)')
    xbmc.sleep(100)
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/PVR/pvr-gen.py")')

def click_2():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.sleep(100)
    xbmc.executebuiltin('Action(Back)')
    xbmc.sleep(100)
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.sleep(100)
    xbmc.executebuiltin('ActivateWindow(Home)')
    xbmc.sleep(100)
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/PVR/gen_pvr.py")')


gen_pvr_W_M()
