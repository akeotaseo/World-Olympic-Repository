﻿import os, xbmc, xbmcvfs, xbmcgui, xbmcaddon, shutil, glob

def DialogRestartPvrStalker():
        choice = xbmcgui.Dialog().yesno('[B][COLOR orange]Restart Pvr Stalker[/COLOR][/B]', 'Μετά την επανεκκίνηση ίσως χρειαστεί (απο το [COLOR darkorchid]Επιλογή Γκρουπ[/COLOR]) να κάνετε μια αλλαγή...',
                                        nolabel='[B][COLOR white]Πίσω[/COLOR][/B]',yeslabel='[B][COLOR orange]Restart Pvr Stalker[/COLOR][/B]')

        if choice == 1: [xbmc.executebuiltin('RunPlugin(plugin://plugin.program.downloader/restartstalker/)'),]
        if choice == 0: [xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/PVR/Pvr.py")'),]
DialogRestartPvrStalker()
