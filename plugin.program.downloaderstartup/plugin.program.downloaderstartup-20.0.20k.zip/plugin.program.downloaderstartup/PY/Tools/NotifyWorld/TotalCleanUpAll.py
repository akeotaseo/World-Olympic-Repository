import os, xbmc, xbmcvfs, xbmcgui, shutil, glob
from updatervar import *

BG.create('Περιμένετε  χωρίς να πατήσετε κάτι...')
xbmc.sleep(5000)
BG.close()

dialog.notification('[B][COLOR orange]Γίνεται έλεγχος![/COLOR][/B]', '[COLOR white]Παρακαλώ περιμένετε...[/COLOR]', icon_ok2, sound=False)


#xbmcgui.Dialog().notification("[B][COLOR orange]Παρακαλώ περιμένετε...[/COLOR][/B]", "[COLOR white]Πραγματοποιείται Γενικός καθαρισμός[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/clean.png')
xbmc.sleep(3000)
xbmc.executebuiltin('PlayMedia("plugin://plugin.program.downloader19/?url=&mode=23&name=%5BB%5D%5BCOLOR+white%5D%CE%9A%CE%B1%CE%B8%CE%B1%CF%81%CE%B9%CF%83%CE%BC%CF%8C%CF%82+%CE%A0%CE%B1%CF%81%CF%8C%CF%87%CF%89%CE%BD%5B%2FCOLOR%5D%5B%2FB%5D&icon=special%3A%2F%2Fhome%2Faddons%2Fplugin.program.downloader19%2Fresources%2Fmedia%2FWorld.png&fanart=C%3A%5CPortableApps%5Ckodi%5Ckodi+World+20%5CKodi%5Cportable_data%5Caddons%5Cplugin.program.downloader19%5Cfanart.jpg&description=&name2=&version=")')
xbmc.sleep(5000)
dialog.notification('[B][COLOR orange]Πραγματοποιείται Γενικός καθαρισμός...[/COLOR][/B]', '[COLOR white]Περιμένετε...[/COLOR]', icon_clean, sound=False)


xbmc.sleep(15000)

xbmc.executebuiltin("Action(Close)")

xbmc.sleep(1000)


xbmcvfs.delete('special://home/userdata/addon_data/plugin.program.downloader/settings.xml')
xbmc.sleep(500)
xbmcvfs.delete('special://home/userdata/addon_data/plugin.video.themoviedb.helper/database_v5/ItemBuilder.db')
xbmc.sleep(500)
xbmcvfs.delete('special://home/userdata/addon_data/plugin.video.themoviedb.helper/database_v5/FanartTV.db')
xbmc.sleep(500)
xbmcvfs.delete('special://home/userdata/addon_data/plugin.video.themoviedb.helper/database_v6/ItemBuilder.db')
xbmc.sleep(500)
xbmcvfs.delete('special://home/userdata/addon_data/plugin.video.themoviedb.helper/database_v6/FanartTV.db')

xbmc.sleep(500)
xbmcvfs.delete('special://home/userdata/Database/MyVideos121.db')


xbmc.sleep(1000)

base_path = xbmcvfs.translatePath('special://home/addons')

dir_list = glob.iglob(os.path.join(base_path, "temp"))
for path in dir_list:
    if os.path.isdir(path):
        shutil.rmtree(path)



base_path = xbmcvfs.translatePath('special://home/')

dir_list = glob.iglob(os.path.join(base_path, "temp"))
for path in dir_list:
    if os.path.isdir(path):
        shutil.rmtree(path)


                                            # Folders Autowidget
xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/DeleteFoldersAutowidget.py")')


#                         Διαγραφή dead addons


base_path = xbmcvfs.translatePath('special://home/addons')

dir_list = glob.iglob(os.path.join(base_path, "plugin.video.neo.tv"))
for path in dir_list:
    if os.path.isdir(path):
        shutil.rmtree(path)




                              #plugin.video.stalker
base_path = xbmcvfs.translatePath('special://home/userdata/addon_data')

dir_list = glob.iglob(os.path.join(base_path, "plugin.video.stalker"))
for path in dir_list:
    if os.path.isdir(path):
        shutil.rmtree(path)


                       #script.artistslideshow
base_path = xbmcvfs.translatePath('special://home/userdata/addon_data/script.artistslideshow')

dir_list = glob.iglob(os.path.join(base_path, "ArtistInformation"))
for path in dir_list:
    if os.path.isdir(path):
        shutil.rmtree(path)


base_path = xbmcvfs.translatePath('special://home/userdata/addon_data/script.artistslideshow')

dir_list = glob.iglob(os.path.join(base_path, "ArtistSlideshow"))
for path in dir_list:
    if os.path.isdir(path):
        shutil.rmtree(path)




xbmc.sleep(5000)
dialog.notification('[B][COLOR orange]Αναμονή λίγο ακόμη...[/COLOR][/B]', '[COLOR white]...[/COLOR]', icon_Pleasewait, sound=False)
#xbmcgui.Dialog().notification("[B][COLOR orange]Παρακαλώ περιμένετε...[/COLOR][/B]", "[COLOR white]Λίγο έμεινε[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/Pleasewait.png')
xbmc.sleep(5000)
xbmc.executebuiltin('PlayMedia("plugin://plugin.program.G.K.N.Wizard/?mode=fullcleanNotAsk")')

xbmc.sleep(15000)
dialog.notification('[B][COLOR orange]Αυτο ήταν...![/COLOR][/B]', '[COLOR white]ok[/COLOR]', icon_ok2, sound=True)
#xbmcgui.Dialog().notification("[B][COLOR orange]Αυτο ήταν...[/COLOR][/B]", "[COLOR white]ok[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/ok2.png')

xbmc.sleep(5000)
dialog.notification('[B][COLOR orange]Για να συνεχίσετε πατήστε[/COLOR][/B]', '[COLOR white]CLOSE[/COLOR]', icon_Notify, sound=True)
#xbmcgui.Dialog().notification("[B][COLOR orange]Για να συνεχίσετε πατήστε[/COLOR][/B]", "[COLOR white]CLOSE[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/Notify.png')



#dialog = xbmcgui.Dialog()
#dialog.ok("[COLOR orange]World build[/COLOR]", "[COLOR white]Delete[/COLOR]")
#xbmc.executebuiltin('RunPlugin(plugin://plugin.program.G.K.N.Wizard/?mode=forceprofile)')
