import os, xbmc, xbmcgui, xbmcvfs, glob, shutil
def kanalia():
        if not xbmc.getCondVisibility('System.HasAddon({})'.format('pvr.stalker')): xbmcgui.Dialog().notification("[B][COLOR blue]Το PVR Stalker[/COLOR][/B]", "[COLOR white]δεν είναι εγκατεστημένο![/COLOR]", icon='special://home/addons/plugin.program.downloaderstartup/resources/media/not.png')
        else:
            addon_disable()

def addon_disable():
        choice = xbmcgui.Dialog().yesno('[B][COLOR blue]PVR Stalker[/COLOR][/B]', '[COLOR white]Επιθυμείτε την διαγραφή του PVR Stalker ?[/COLOR][CR](Η διαγραφή γίνεται μετά την έξοδο απο το kodi.[CR]Για εγκατάσταση εκ νέου, επανεκκινήστε το kodi)',
                                        nolabel='[COLOR orange]Άκυρο[/COLOR]',yeslabel='[COLOR lime]Διαγραφή[/COLOR]')

        if choice == 1: (xbmc.executebuiltin("Action(Close)"), xbmc.sleep(1000), xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.stalker","enabled":false}}'),
                         xbmc.sleep(5000), xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.stalker","enabled":false}}'), xbmc.sleep(1000), stalker_del())

def stalker_del():
        base_path = xbmcvfs.translatePath('special://home/addons')
        dir_list = glob.iglob(os.path.join(base_path, "pvr.stalker"))
        for path in dir_list:
            if os.path.isdir(path):
                shutil.rmtree(path)
            if os.path.exists(base_path): xbmcgui.Dialog().notification("[B][COLOR blue]PVR Stalker[/COLOR][/B]", "[COLOR white]Το PVR Stalker αφαιρέθηκε με επιτυχία![/COLOR]", icon='special://home/addons/plugin.program.downloaderstartup/resources/media/clean.png')



#        base_path = xbmcvfs.translatePath('special://home/userdata/addon_data')
#        dir_list = glob.iglob(os.path.join(base_path, "pvr.stalker"))
#        for path in dir_list:
#            if os.path.isdir(path):
#                shutil.rmtree(path)

kanalia()
