import xbmc, xbmcgui, xbmcvfs


def DeleteFavouritesSouper():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6)
    call = xbmcgui.Dialog().select('[B]Delete Favourites[/B]', 
['[COLOR White]Delete Favourites[/COLOR]',
 '[COLOR blue]Delete Souper Favourites[/COLOR]',
 '[COLOR orange]Delete MyPreferences[/COLOR]',
 '[COLOR white]Delete Lite Favourites[/COLOR]',
 '[COLOR gold]Delete Auto Widget[/COLOR]',
 '[COLOR coral]Delete Shortlist[/COLOR]'])
 



    if call:
        if call < 0:
            return
        func = funcs[call-6]
        return func()
    else:
        func = funcs[call]
        return func()
    return 





def click_1():
    favourites_delete()
    # xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/skin/Favourites_Delete.py")')

def click_2():
    xbmcgui.Dialog().notification("[B][COLOR red]Προσοχή!!![/COLOR][/B]", "[COLOR orange]Με αυτή την επιλογή θα γίνει διαγραφεί όλων των Συντομεύσεων και των Ρυθμίσεων του Πρόσθετου! [/COLOR]", sound=True, icon='special://home/addons/skin.19MatrixWorld/media/top/doestworkalltime1.png')
    xbmc.executebuiltin('PlayMedia("plugin://plugin.program.G.K.N.Wizard/?mode=removedata&name=plugin.program.super.favourites")')

def click_3():
    DialogMyPreferences()
    # xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/skin/DialogMyPreferences.py")')

def click_4():
    xbmcgui.Dialog().notification("[B][COLOR red]Προσοχή!!![/COLOR][/B]", "[COLOR orange]Με αυτή την επιλογή θα γίνει διαγραφεί όλων των Συντομεύσεων και των Ρυθμίσεων του Πρόσθετου! [/COLOR]", sound=True, icon='special://home/addons/skin.19MatrixWorld/media/top/doestworkalltime1.png')
    xbmc.executebuiltin('PlayMedia("plugin://plugin.program.G.K.N.Wizard/?mode=removedata&name=plugin.program.lite.favourites")')

def click_5():
    xbmcgui.Dialog().notification("[B][COLOR red]Προσοχή!!![/COLOR][/B]", "[COLOR orange]Με αυτή την επιλογή θα γίνει διαγραφεί όλων των Συντομεύσεων και των Ρυθμίσεων του Πρόσθετου! [/COLOR]", sound=True, icon='special://home/addons/skin.19MatrixWorld/media/top/doestworkalltime1.png')
    xbmc.executebuiltin('PlayMedia("plugin://plugin.program.G.K.N.Wizard/?mode=removedata&name=plugin.program.autowidget")')

def click_6():
    xbmcgui.Dialog().notification("[B][COLOR red]Προσοχή!!![/COLOR][/B]", "[COLOR orange]Με αυτή την επιλογή θα γίνει διαγραφεί όλων των Συντομεύσεων και των Ρυθμίσεων του Πρόσθετου! [/COLOR]", sound=True, icon='special://home/addons/skin.19MatrixWorld/media/top/doestworkalltime1.png')
    xbmc.executebuiltin('PlayMedia("plugin://plugin.program.G.K.N.Wizard/?mode=removedata&name=plugin.program.shortlist")')

def DialogMyPreferences():
        choice = xbmcgui.Dialog().yesno('[B][COLOR orange]MyPreferences[/COLOR][/B]', '[COLOR red] Προσοχή![/COLOR]  [COLOR white]Με αυτή την επιλογή θα γίνει διαγραφή των συντομεύσεων σε όλες τις κατηγορίες στις [/COLOR] [COLOR orange]Προτιμήσεις[/COLOR]',
                                        nolabel='[COLOR white]OXI[/COLOR]',yeslabel='[COLOR red]ΔΙΑΓΡΑΦΗ[/COLOR]')

        if choice == 1: xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/UpdaterMatrix_9.py")'),


def favourites_delete():
        choice = xbmcgui.Dialog().yesno('[COLOR orange]Διαγραφή αγαπημένων[/COLOR]', '[COLOR white]Με αυτή την επιλογή θα διαγραφούν[COLOR red] ΟΛΕΣ[/COLOR] οι συντομεύσεις των αγαπημένων και θα πραγματοποιηθεί επαναφόρτωση του προφίλ, με αποτέλεσμα να παγώσει για λίγα δευτερόλεπτα η εικόνα. Θέλετε να συνεχίσετε ?[/COLOR]',
                                        nolabel='[B][COLOR white]Όχι[/COLOR][/B]',yeslabel='[B][COLOR white]Ναι[/COLOR][/B]')

        if choice == 1: [xbmcvfs.delete('special://home/userdata/favourites.xml'), xbmcgui.Dialog().notification("[B][COLOR orange]Διαγραφή αγαπημένων με επιτυχία ![/COLOR][/B]",
                         "[COLOR white]Αναμονή για Reload Profile...[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/clean.png'), xbmc.sleep(6000),
                           xbmc.executebuiltin('RunPlugin(plugin://plugin.program.G.K.N.Wizard/?mode=forceprofile)')]

DeleteFavouritesSouper()
