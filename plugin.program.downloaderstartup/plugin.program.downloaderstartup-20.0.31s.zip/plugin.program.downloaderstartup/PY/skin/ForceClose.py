# -*- coding: utf-8 -*-
import os, sys, json, xbmc, xbmcgui, xbmcvfs

def prepare_clean_exit():
    """ 🛡️ Προετοιμασία για αστραπιαία επόμενη εκκίνηση πριν το Force Close """
    try:
        dl_path = xbmcvfs.translatePath('special://home/addons/plugin.program.downloader19')
        p_dir = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.program.downloader19')
        if os.path.exists(dl_path) and dl_path not in sys.path:
            sys.path.insert(0, dl_path)

        # 1. Αν είχαν μείνει κλειστά τα Widgets λόγω ημιτελούς ενημέρωσης, τα επαναφέρουμε
        b_widgets = os.path.join(p_dir, 'widgets_backup.json')
        if os.path.exists(b_widgets):
            try:
                import World_widget_OnOff as w_mgr
                w_mgr.restore_widgets(do_reload=False)
            except:
                pass


        # 2. Προ-παγώνουμε τις βαριές ρυθμίσεις (YouTube, thegroove360, TMDb Helper, PVR)
        #    ώστε η επόμενη εκκίνηση του Kodi να ξεκινήσει ακαριαία!
        import addon_optimizer as a_opt
        a_opt.pause_heavy_settings()
    except Exception as e:
        xbmc.log(f"[ForceClose] Σφάλμα προετοιμασίας εξόδου: {str(e)}", xbmc.LOGERROR)

def ForceClose():
    if xbmc.getCondVisibility('System.HasAddon(service.coreelec.settings)') or xbmc.getCondVisibility('System.HasAddon(service.libreelec.settings)'):
        CoreLibre()
    else:
        killkodi()

def killkodi():
    choice = xbmcgui.Dialog().yesno(
        '[B][COLOR orange]World Build[/COLOR][/B]',
        '[COLOR white]Το Kodi θα κλείσει...[CR]Θέλετε να συνεχίσετε;[/COLOR]',
        nolabel='[COLOR white]Όχι[/COLOR]',
        yeslabel='[COLOR white]Ναι[/COLOR]'
    )
    if choice == 1:
        xbmcgui.Dialog().notification("[B][COLOR orange]Bye bye![/COLOR][/B]", "[COLOR green]Να είστε καλά![/COLOR]", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/Bye.png')
        prepare_clean_exit()
        xbmc.sleep(1500)
        os._exit(1)
    elif choice == 0:
        xbmcgui.Dialog().notification("[B][COLOR orange]Ακόμα εδω;[/COLOR][/B]", "Να φύγετε![CR]Να πάτε αλλού!", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/angry.png')

def CoreLibre():
    choice = xbmcgui.Dialog().yesno(
        '[B][COLOR orange]World Build[/COLOR][/B]',
        '[COLOR white]Επανεκκίνηση Συστήματος...[CR]Θέλετε να συνεχίσετε;[/COLOR]',
        nolabel='[COLOR white]Όχι[/COLOR]',
        yeslabel='[COLOR white]Ναι[/COLOR]'
    )
    if choice == 1:
        xbmcgui.Dialog().notification("[B][COLOR orange]Επανεκκίνηση[/COLOR][/B]", "   ", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/restart.png')
        prepare_clean_exit()
        xbmc.sleep(1500)
        os._exit(1)
    elif choice == 0:
        xbmcgui.Dialog().notification("[B][COLOR orange]Ακόμα εδω;[/COLOR][/B]", "Να φύγετε![CR]Να πάτε αλλού!", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/angry.png')

if __name__ == '__main__':
    ForceClose()
