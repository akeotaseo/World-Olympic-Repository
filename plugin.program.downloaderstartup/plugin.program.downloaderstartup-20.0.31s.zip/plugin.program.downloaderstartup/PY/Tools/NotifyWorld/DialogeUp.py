﻿# -*- coding: utf-8 -*-
import xbmc
import xbmcgui

def main():
    xbuiltin = xbmc.executebuiltin

    # 1. 📢 ΠΡΩΤΟΣ ΔΙΑΛΟΓΟΣ: Ενημερώσεις Πρόσθετων
    choice_up = xbmcgui.Dialog().yesno(
        '[B][COLOR green]Ενημερώσεις Πρόσθετων[/COLOR][/B]', 
        'Θέλετε να δείτε τις ενημερώσεις των πρόσθετων ;',
        nolabel='[COLOR red]Οχι ReloadSkin[/COLOR]', 
        yeslabel='[COLOR green]Ναι[/COLOR]'
    )

    if choice_up:  # [ΝΑΙ]
        # 🔥 ΤΟ ΝΕΟ ΚΟΛΠΟ: Πετάμε ακαριαία το notification για να "γλυκάνουμε" την αναμονή
        # xbmcgui.Dialog().notification(
            # '[COLOR green]KODI UPDATE[/COLOR]', 
            # '[B]Ανάγνωση πρόσθετων[/B]', 
            # sound=False, 
            # icon='special://home/addons/skin.19MatrixWorld/media/update.png')
        
        # Κλείνουμε το yesno dialog και αφήνουμε το Kodi να φορτώσει το παράθυρο
        xbuiltin('Dialog.Close(yesnodialog)')
        xbmc.sleep(150) 
        xbuiltin('ActivateWindow(addonbrowser,addons://recently_updated/)')
        
    else:  # [ΟΧΙ RELOADSKIN]
        xbuiltin('Dialog.Close(all,true)')
        xbmc.sleep(200)
        
        # 📢 ΔΕΥΤΕΡΟΣ ΔΙΑΛΟΓΟΣ: Επιβεβαίωση για ReloadSkin
        choice_reload = xbmcgui.Dialog().yesno(
            '[B][COLOR red]ReloadSkin[/COLOR][/B]', 
            'Πατήστε [COLOR red]ReloadSkin...[/COLOR]',
            nolabel='Οχι', 
            yeslabel='[COLOR red]ReloadSkin[/COLOR]'
        )
        
        if choice_reload: # [RELOADSKIN]
            xbuiltin('ReloadSkin()')

if __name__ == '__main__':
    main()
