﻿# -*- coding: utf-8 -*-
import os, xbmc, xbmcvfs, xbmcgui
from updatervar import *
from resources.lib.modules import addonsEnable



from xbmc import executebuiltin
from xbmcaddon import Addon
from os.path import exists,join
from os import makedirs
from xbmcvfs import translatePath

xbmcvfs.delete('special://home/addons/plugin.video.vnmedia/service.py')
xbmc.sleep(2000)

pack = translatePath('special://home/addons/packages')

if not exists(pack):
	makedirs(pack)
packfolders = 'packages'


#if __name__ == '__main__':

dialog.notification('...', '   ', icon_tools, sound=False)
xbmc.sleep(4000)
xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/Tools/ArtistslideshowCleanUp.py")')

#G.create('Γίνεται έλεγχος', 'Παρακαλώ περιμένετε...')
#xbmc.sleep(5000)
#BG.update(100, 'Γίνεται έλεγχος', 'Παρακαλώ περιμένετε...')
#BG.close()
xbmc.sleep(1000)
xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/DeleteFilesDatabase.py")')
