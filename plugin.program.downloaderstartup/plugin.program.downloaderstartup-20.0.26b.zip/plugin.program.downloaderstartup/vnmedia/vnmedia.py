import os, xbmc, xbmcvfs, xbmcgui, shutil, glob


def vnmedia():
    funcs = (click_1, click_2, click_3)
    call = xbmcgui.Dialog().select('[B]Vnmedia[/B]', 
['[COLOR=lime]Install[/COLOR] Vnmedia',
 '[B][COLOR=gold]Πρόσθετα βίντεο[/COLOR][/B]',
 '[COLOR=red]Delete[/COLOR] Vnmedia'])
 



    if call:
        if call < 0:
            return
        func = funcs[call-3]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/UpdaterMatrix_29.py")')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,"library://video/addons.xml/")')

def click_3():
    DelleteVnmedia()
    DialogDelleteVnmedia()
    

def DelleteVnmedia():

    base_path = xbmcvfs.translatePath('special://home/addons')
    
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.90phuttv"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.avdb"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.caheo"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.daxem"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.bongdainfo"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.socolive"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.thapcam"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.thethao"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.truyenhinh"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.vnmedia"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.xemplay"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    
    dir_list = glob.iglob(os.path.join(base_path, "script.module.cloudscraperkd"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    
    dir_list = glob.iglob(os.path.join(base_path, "script.module.codequick"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    
    dir_list = glob.iglob(os.path.join(base_path, "script.module.requests-toolbelt"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)




    #############################################################################
    
    # base_path = xbmcvfs.translatePath('special://home/userdata/addon_data')
    
    



def DialogDelleteVnmedia():


    xbmc.sleep(2000)
    xbmcgui.Dialog().notification("[B][COLOR red]Delete[/COLOR] Vnmedia[/B]", "[COLOR white]Τα πρόσθετα [COLOR yellow]Vnmedia[/COLOR] αφαιρέθηκαν με επιτυχία![/COLOR]", icon='special://home/addons/plugin.program.downloaderstartup/resources/media/clean.png')
    xbmc.sleep(5000)
    xbmcgui.Dialog().notification("[B][COLOR red]Ok[/COLOR][/B]", "[COLOR white]Αναμονή για Reload Profile...[/COLOR]", icon='special://home/addons/plugin.program.downloaderstartup/resources/media/rp.png')
    xbmc.sleep(5000)
    xbmc.executebuiltin('RunPlugin(plugin://plugin.program.G.K.N.Wizard/?mode=forceprofile)')
    xbmc.sleep(1000)
    xbmcgui.Dialog().notification("[B][COLOR orange]Reload Profile[/COLOR][/B]", "[COLOR white]Παρακαλώ περιμένετε...[/COLOR]", icon='special://home/addons/plugin.program.downloaderstartup/resources/media/reloadprofile.png')
    
vnmedia()
    