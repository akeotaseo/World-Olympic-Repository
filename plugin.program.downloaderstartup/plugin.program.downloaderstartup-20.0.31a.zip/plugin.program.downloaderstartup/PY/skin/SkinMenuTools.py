import os, sys, glob, base64, xbmc, xbmcvfs, xbmcaddon, xbmcgui, shutil, subprocess

def SkinMenuTools():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6)
    call = xbmcgui.Dialog().select('[B]SkinMenuTools[/B]', 
['[COLOR red]Skin [/COLOR] Επαναφόρτωση',
'[COLOR red]Skin [/COLOR] Ρυθμίσεις',
 '[COLOR=red]Skin [/COLOR] Αλλαγή',
 '[COLOR red]Skin [/COLOR] Menu Settings',
 '[COLOR red]Skin [COLOR orange] Choose / Save Your Settings [/COLOR]',
 # '[B]Turn Skin Debuging On/Off[/B]',
 # '[COLOR red]TEST[/COLOR]',
 '[B][COLOR red]<---                                                                      [COLOR grey]Back[/COLOR][/B]'
 ])
 


    if call:
        if call < 0:
            return
        func = funcs[call-6]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin("ReloadSkin()")
    # Επαναφόρτωση

def click_2():
    xmlskinversion2047()
    # Ρυθμίσεις

def click_3():
    xbmc.executebuiltin('PlayMedia("plugin://script.skinswitcher/?url=url&mode=1&name=Click+here+to+change+skins+&iconimage=C%3A%5CPortableApps%5Ckodi%5Ckodi+World+20%5CKodi%5Cportable_data%5Caddons%5Cscript.skinswitcher%5Cicon.png&fanart=C%3A%5CPortableApps%5Ckodi%5Ckodi+World+20%5CKodi%5Cportable_data%5Caddons%5Cscript.skinswitcher%5Cfanart.jpg")')
    # Αλλαγή

def click_4():
    xmlskinversion2046()
    # Menu Settings

def click_5():
    World_home_switch()
    # Choose / Save Your Settings



def click_6():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/Tools/SkinTools.py")')
    # Back




def World_home_switch():
        dialog = xbmcgui.Dialog()
        settings_path = xbmcvfs.translatePath('special://userdata/addon_data/skin.19MatrixWorld/')
        flavor_list = ['Save Your Skin Settings', 'Choose Your Skin Settings']
        select = dialog.select('Save / Choose Skin Settings', flavor_list)
        if select == None:
            return          



        if select == 0:
                Save_Dialog()



        if select == 1:
                dialog = xbmcgui.Dialog()
                settings_path = xbmcvfs.translatePath('special://userdata/addon_data/skin.19MatrixWorld/')
                #απο εδω Choose Your Settings
                src_settings = xbmcvfs.translatePath('special://home/backup/Save_Your_Settings/settings.xml')
                #παει εδω
                dst_settings = xbmcvfs.translatePath('special://userdata/addon_data/skin.19MatrixWorld/settings.xml')
                
                if os.path.exists(os.path.join(settings_path)):
                        try:
                                shutil.copyfile(src_settings, dst_settings)
                                Choose()
                                # xbmcgui.Dialog().ok('Choose Your Settings', 'To save skin changes, please close Kodi, Press OK to force close Kodi')
                                # os._exit(1)
                        except:
                                xbmcgui.Dialog().ok('Choose Your Settings', 'Error...')
                else:
                        xbmcgui.Dialog().ok('Choose Your Settings', 'Error...')


def Save_Dialog():
        choice = xbmcgui.Dialog().yesno('[B][COLOR orange]Save Skin Settings[/COLOR][/B]', '[COLOR red]Προσοχή![/COLOR][CR]Αν έχετε ξανασώσει τα settings του Skin..[CR]θα αντικατασταθούν με αυτά![CR]Θέλετε να συνεχίσετε;',
                                        nolabel='Οχι',yeslabel='Ναι')
        if choice == 1: [Save_Ok(),]


def Save_Ok():
                dialog = xbmcgui.Dialog()
                settings_path = xbmcvfs.translatePath('special://userdata/addon_data/skin.19MatrixWorld/')
                #απο εδω Save Your Settings
                src_settings = xbmcvfs.translatePath('special://userdata/addon_data/skin.19MatrixWorld/settings.xml')
                #παει εδω
                dst_settings = xbmcvfs.translatePath('special://home/backup/Save_Your_Settings/settings.xml')
                
                
                if os.path.exists(os.path.join(settings_path)):
                        try:
                                shutil.copyfile(src_settings, dst_settings)
                                xbmcgui.Dialog().notification("[COLOR line]Save Skin Settings[/COLOR]", "Τα Settings αποθυκεύτηκαν με επιτυχία!", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/Profile.png')
                                
                                
                        except:
                            xbmcgui.Dialog().ok('Save Your Settings', 'Error...')
                                
                else:
                        xbmcgui.Dialog().ok('Save Your Settings', 'Error...')
                        


def Choose():
        choice = xbmcgui.Dialog().yesno('[B][COLOR orange]Choose Skin Settings[/COLOR][/B]', 'Για να εφαρμοστούν οι αλλαγές[CR]Πατήστε [COLOR red]Force Close[/COLOR] ή [COLOR blue]Reload Profile[/COLOR]',
                                        nolabel='[COLOR red]Force Close[/COLOR]',yeslabel='[COLOR blue]Reload Profile[/COLOR]')
        if choice == 1: [
                         xbmcgui.Dialog().notification("[COLOR blue]Reload Profile[/COLOR]", "Παρακαλώ Περιμένετε...", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/Profile.png'),
                         xbmc.sleep(2000),
                         xbmc.executebuiltin("LoadProfile(Master user)"),]
        if choice == 0: [os._exit(1),]


def xmlskinversion2046():
    addon_downloader19       = xbmcaddon.Addon('plugin.program.downloader19')
    setting_downloader19     = addon_downloader19.getSetting
    setting_set_downloader19 = addon_downloader19.setSetting
    if setting_downloader19('xmlskinversion')=='2046':
        xbmcgui.Dialog().ok('[COLOR red] Skin[/COLOR] Menu Tools', 'Η επιλογή αυτή είναι διαθέσιμη μόνο στο Προκαθορισμένο Skin')
    else:
        xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/skin/SkinUp/set_setting_FixSkin.py")')


def xmlskinversion2047():
    addon_downloader19       = xbmcaddon.Addon('plugin.program.downloader19')
    setting_downloader19     = addon_downloader19.getSetting
    setting_set_downloader19 = addon_downloader19.setSetting
    if setting_downloader19('xmlskinversion')=='2046':
        xbmcgui.Dialog().ok('[COLOR red] Skin[/COLOR] Menu Tools', 'Η επιλογή αυτή είναι διαθέσιμη μόνο στο Προκαθορισμένο Skin')
    else:
        xbmc.executebuiltin('ActivateWindow(SkinSettings)')

SkinMenuTools()


