import os, xbmc, xbmcvfs, xbmcgui
xbmc.executebuiltin('ActivateWindow(Weather)')
xbmc.sleep(1000)
def FixWeather():
        choice = xbmcgui.Dialog().yesno('[B][COLOR orange]Weather Reset[/COLOR][/B]', '[COLOR white]Επαναφορά Πόλεων [B]Athens, Thessaloniki, Patra, Heraklion[/B][CR][CR]Θέλετε να συνεχίσετε;[/COLOR]',
                                        nolabel='[COLOR white]Όχι[/COLOR]',yeslabel='[COLOR white]Ναι[/COLOR]')
        if choice == 1: [xbmcgui.Dialog().notification("[B][COLOR orange]Weather[/COLOR][/B]", "Επαναφορά Πόλεων", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/Weather.ico'), 
                         xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/UpdaterMatrix_11.py")'),]
        if choice == 0: [
                         xbmc.executebuiltin('ActivateWindow(Home)'),]

xbmc.executebuiltin('ActivateWindow(Weather)')


FixWeather()
