import os, sys, glob, base64, xbmc, xbmcvfs, xbmcaddon, xbmcgui, shutil
from datetime import datetime
from urllib.parse import parse_qs
from urllib.request import Request, urlopen


def SkinMenuTools():
    funcs = (click_1, click_2, click_3, click_4, click_5)
    call = xbmcgui.Dialog().select('[B]SkinMenuTools[/B]', 
['[COLOR red] Skin [/COLOR] Επαναφόρτωση',
'[COLOR red] Skin [/COLOR] Ρυθμίσεις',
 
 '[COLOR=red]Skin [/COLOR] Αλλαγή',
 '[COLOR red] Skin [/COLOR] Menu Settings',
 '[B][COLOR red]<---                                                                      [COLOR grey]Back[/COLOR][/B]'
 ])
 



    if call:
        if call < 0:
            return
        func = funcs[call-5]
        return func()
    else:
        func = funcs[call]
        return func()
    return 






def click_1():
    xbmc.executebuiltin("ReloadSkin()")

def click_2():
    xbmc.executebuiltin('ActivateWindow(SkinSettings),return')

def click_3():
    xbmc.executebuiltin('PlayMedia("plugin://script.skinswitcher/?url=url&mode=1&name=Click+here+to+change+skins+&iconimage=C%3A%5CPortableApps%5Ckodi%5Ckodi+World+20%5CKodi%5Cportable_data%5Caddons%5Cscript.skinswitcher%5Cicon.png&fanart=C%3A%5CPortableApps%5Ckodi%5Ckodi+World+20%5CKodi%5Cportable_data%5Caddons%5Cscript.skinswitcher%5Cfanart.jpg")')

def click_4():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/skin/SkinUp/set_setting_FixSkin.py")')

def click_5():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/Tools/SkinTools.py")')



SkinMenuTools()
