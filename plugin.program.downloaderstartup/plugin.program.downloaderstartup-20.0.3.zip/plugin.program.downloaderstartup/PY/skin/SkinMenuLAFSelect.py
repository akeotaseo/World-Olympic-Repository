import os, xbmcgui

def SkinMenuLAFSelect():
        choice = xbmcgui.Dialog().yesno('[B][COLOR orange]Skin Menu Settings[/COLOR][/B]', '[COLOR white]Θέλετε να επαναφέρετε τα Settings του Skin [CR](Ρυθμίσεις - HOME) [CR]στην τελευταία ενημέρωση?[/COLOR]',
                                        nolabel='[COLOR white]Όχι[/COLOR]',yeslabel='[COLOR white]Ναι[/COLOR]')
        if choice == 1: xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/UpdaterMatrix_8.py")')

SkinMenuLAFSelect()