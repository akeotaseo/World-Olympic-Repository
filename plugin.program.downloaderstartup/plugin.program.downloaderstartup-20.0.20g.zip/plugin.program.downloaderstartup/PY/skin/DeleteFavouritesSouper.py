import xbmc, xbmcgui


def DeleteFavouritesSouper():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6)
    call = xbmcgui.Dialog().select('[B]Delete Favourites[/B]', 
['[COLOR White]Delete Favourites[/COLOR]',
 '[COLOR blue]Delete Souper Favourites[/COLOR]',
 '[COLOR orange]Delete MyPreferences[/COLOR]',
 '[COLOR white]Delete Lite Favourites[/COLOR]',
 '[COLOR gold]Delete Auto Widget[/COLOR]',
 '[COLOR coral]Delete Shortlist[/COLOR]'])
 



    if call:
        if call < 0:
            return
        func = funcs[call-6]
        return func()
    else:
        func = funcs[call]
        return func()
    return 





def click_1():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/skin/Favourites_Delete.py")')

def click_2():
    xbmcgui.Dialog().notification("[B][COLOR red]Προσοχή!!![/COLOR][/B]", "[COLOR orange]Με αυτή την επιλογή θα γίνει διαγραφεί όλων των Συντομεύσεων και των Ρυθμίσεων του Πρόσθετου! [/COLOR]", sound=True, icon='special://home/addons/skin.19MatrixWorld/media/top/doestworkalltime1.png')
    xbmc.executebuiltin('PlayMedia("plugin://plugin.program.G.K.N.Wizard/?mode=removedata&name=plugin.program.super.favourites")')

def click_3():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/skin/DialogMyPreferences.py")')

def click_4():
    xbmcgui.Dialog().notification("[B][COLOR red]Προσοχή!!![/COLOR][/B]", "[COLOR orange]Με αυτή την επιλογή θα γίνει διαγραφεί όλων των Συντομεύσεων και των Ρυθμίσεων του Πρόσθετου! [/COLOR]", sound=True, icon='special://home/addons/skin.19MatrixWorld/media/top/doestworkalltime1.png')
    xbmc.executebuiltin('PlayMedia("plugin://plugin.program.G.K.N.Wizard/?mode=removedata&name=plugin.program.lite.favourites")')

def click_5():
    xbmcgui.Dialog().notification("[B][COLOR red]Προσοχή!!![/COLOR][/B]", "[COLOR orange]Με αυτή την επιλογή θα γίνει διαγραφεί όλων των Συντομεύσεων και των Ρυθμίσεων του Πρόσθετου! [/COLOR]", sound=True, icon='special://home/addons/skin.19MatrixWorld/media/top/doestworkalltime1.png')
    xbmc.executebuiltin('PlayMedia("plugin://plugin.program.G.K.N.Wizard/?mode=removedata&name=plugin.program.autowidget")')

def click_6():
    xbmcgui.Dialog().notification("[B][COLOR red]Προσοχή!!![/COLOR][/B]", "[COLOR orange]Με αυτή την επιλογή θα γίνει διαγραφεί όλων των Συντομεύσεων και των Ρυθμίσεων του Πρόσθετου! [/COLOR]", sound=True, icon='special://home/addons/skin.19MatrixWorld/media/top/doestworkalltime1.png')
    xbmc.executebuiltin('PlayMedia("plugin://plugin.program.G.K.N.Wizard/?mode=removedata&name=plugin.program.shortlist")')


DeleteFavouritesSouper()
