import xbmc, xbmcgui


xbmcgui.Dialog().ok('[B][COLOR blue]Stalker Vod Client[/COLOR][/B]', 'Αν παρουσιαστεί σφάλμα ή η λίστα δεν λειτουργεί δοκιμάστε ξανά με το[COLOR lime] [COLOR blue]Stalker Vod ClienStalker Vod [COLOR=lime]Generator[/COLOR][CR][COLOR=white]Αλλιώς συνεχίστε με την υπάρχουσα Λίστα[/COLOR]')


xbmcgui.Dialog().notification("[B][COLOR deepskyblue]StalkerVod [COLOR lime]Generator[/COLOR][/B]", "[COLOR orange]Παρακαλώ περιμένετε...[/COLOR]", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/stalkervod.png')
xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/PVR/list_inside.py")')