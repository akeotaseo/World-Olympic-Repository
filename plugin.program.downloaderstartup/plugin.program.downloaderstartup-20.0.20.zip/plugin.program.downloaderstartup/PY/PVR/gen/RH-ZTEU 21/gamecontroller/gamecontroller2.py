import urllib.request
import xbmcgui
import xbmcaddon
import re
import os
import sys
import xbmcvfs

addon_id = 'plugin.video.worldclient'

if os.name == 'nt':  
    portable_data_path = os.path.join(os.getcwd(), 'portable_data')
    if os.path.isdir(portable_data_path):
        settings_path = os.path.join(portable_data_path, 'userdata', 'addon_data', addon_id, 'settings.xml')
    else:
        settings_path = os.path.join(os.getenv('APPDATA'), 'Kodi', 'userdata', 'addon_data', addon_id, 'settings.xml')
else:
    settings_path = os.path.join(xbmcvfs.translatePath('special://profile/addon_data'), addon_id, 'settings.xml')

def check_playlist(url):
    try:
        response = urllib.request.urlopen(url)
        return True
    except urllib.error.URLError:
        return False

group_urls = {
    'Grupa 1 - Razne Liste ': 'https://kodibalkan.com/WorldTv/grupa1.txt',
    'Grupa 2 - Zasticene Liste': 'https://kodibalkan.com/WorldTv/grupa2.txt',
    'Grupa 3 - Balkan SAT': 'https://kodibalkan.com/WorldTv/grupa3.txt',
    'Grupa 4 - M3U Fajl Liste (VOD)': 'https://kodibalkan.com/WorldTv/grupa4.txt',
}

group_names = list(group_urls.keys())
selected_group_index = xbmcgui.Dialog().select('Odaberite grupu', group_names)

if selected_group_index == -1:
    sys.exit()

selected_group_name = group_names[selected_group_index]
selected_group_url = group_urls[selected_group_name]

response = urllib.request.urlopen(selected_group_url)
playlist_data = response.read().decode('utf-8')
playlist_urls = re.findall(r'http\S+', playlist_data)

playlist_names = [f'Lista {i+1}' for i in range(len(playlist_urls))]

working_playlists = []
failed_playlists = []

dialog = xbmcgui.DialogProgress()
dialog.create('Provjera lista', 'Provjerava se ispravnost lista...')
for i, playlist_url in enumerate(playlist_urls):
    dialog.update(int((i / len(playlist_urls)) * 100), 'Provjerava se lista {}'.format(i + 1))
    if selected_group_name != 'Grupa 2 - Zasticene Liste':
        if check_playlist(playlist_url):
            working_playlists.append(playlist_url)
        else:
            failed_playlists.append(playlist_url)
    else:
        working_playlists.append(playlist_url)  

dialog.close()

for playlist_url in failed_playlists:
    index = playlist_urls.index(playlist_url)
    playlist_names[index] += ' - Ne radi'

while True:
    selected_playlist_index = xbmcgui.Dialog().select(f'Odaberite listu iz {selected_group_name}', playlist_names)

    if selected_playlist_index == -1:
        sys.exit()

    selected_playlist_url = playlist_urls[selected_playlist_index]

    with open(settings_path, 'r') as f:
        settings_xml = f.read()

    settings_xml = re.sub('<setting id="m3u_url">.*?</setting>', '<setting id="m3u_url">{}</setting>'.format(selected_playlist_url), settings_xml)

    with open(settings_path, 'w') as f:
        f.write(settings_xml)

    xbmc.sleep(1000)

    if check_playlist(selected_playlist_url):
        xbmcgui.Dialog().ok('Dodavanje izabrane liste u World Tv Client', 'Izabrana lista je dodata.Pokrenite World TV.')
        sys.exit()
    else:
        if not xbmcgui.Dialog().yesno('OBAVEZNO PROCITATI!!!', 'Ako ste izabrali Grupa 2 Zasticene liste to znaci da ove liste ne mogu da se provjere da li rade ili ne rade izaberite NO/NE da probate izabranu listu. Ako ste izabrali listu iz neke grupe gde pise da lista ne radi izaberite YES/DA da promenite listu'):
            sys.exit()
        else:
            playlist_names[selected_playlist_index] = f'Lista {selected_playlist_index+1} - Ne radi'
