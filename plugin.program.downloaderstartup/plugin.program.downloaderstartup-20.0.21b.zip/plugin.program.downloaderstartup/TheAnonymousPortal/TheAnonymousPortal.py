import os, xbmc, xbmcvfs, xbmcgui, shutil, glob


def TheAnonymousPortal():
    funcs = (click_1, click_2, click_3)
    call = xbmcgui.Dialog().select('[B]TheAnonymousPortal[/B]', 
['[COLOR=lime]Install[/COLOR] TheAnonymousPortal',
 '[B][COLOR=gold]Πρόσθετα βίντεο[/COLOR][/B]',
 '[COLOR=red]Delete[/COLOR] TheAnonymousPortal'])
 



    if call:
        if call < 0:
            return
        func = funcs[call-3]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/UpdaterMatrix_15.py")')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,"library://video/addons.xml/")')

def click_3(): DelTheAnonymousPortal()
    # xbmc.executebuiltin('RunScript("special://home/addons//plugin.program.downloaderstartup/TheAnonymousPortal/DeleteTheAnonymousPortal.py")')

def DelTheAnonymousPortal():

    base_path = xbmcvfs.translatePath('special://home/addons')
    
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.lagartixa"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.nebula.portal"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.portal.alado"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.topeleven"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.zeus.portal"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.ninja.portal"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.calimero.portal"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.train.mac.again"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.Gif.Peg.Tv"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.gloriosotv"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.chidori"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.mc.portal"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.sonic"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.twoaddons"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.neo.tv"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.TakeOneMac"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.Addon.GhostHaunt"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    
    # dir_list = glob.iglob(os.path.join(base_path, "plugin.video.pluginstreaming"))
    # for path in dir_list:
        # if os.path.isdir(path):
            # shutil.rmtree(path)
    
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.Addon.Teaddon"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.vegeta.tv-1.0.3"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.tvyes"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    
    
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.flix-mac"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.flixon"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.koditv"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    
    dir_list = glob.iglob(os.path.join(base_path, "script.module.clouddrive.common"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    
    dir_list = glob.iglob(os.path.join(base_path, "script.module.requests-cache"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    
    #############################################################################
    
    base_path = xbmcvfs.translatePath('special://home/userdata/addon_data')
    
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.lagartixa"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.nebula.portal"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.portal.alado"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.topeleven"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.zeus.portal"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.ninja.portal"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.calimero.portal"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.train.mac.again"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.Gif.Peg.Tv"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.gloriosotv"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.chidori"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.mc.portal"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.sonic"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.twoaddons"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.neo.tv"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.TakeOneMac"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.Addon.GhostHaunt"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.pluginstreaming"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.Addon.Teaddon"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    
    xbmc.sleep(2000)
    if os.path.exists(base_path): xbmcgui.Dialog().notification("[B][COLOR red]Delete[/COLOR] TheAnonymousPortal[/B]", "[COLOR white]Τα πρόσθετα [COLOR yellow]TheAnonymousPortal[/COLOR] αφαιρέθηκαν με επιτυχία![/COLOR]", icon='special://home/addons/plugin.program.downloaderstartup/resources/media/clean.png')
    xbmc.sleep(5000)
    xbmcgui.Dialog().notification("[B][COLOR red]Ok[/COLOR][/B]", "[COLOR white]Αναμονή για Reload Profile...[/COLOR]", icon='special://home/addons/plugin.program.downloaderstartup/resources/media/rp.png')
    xbmc.sleep(5000)
    xbmc.executebuiltin('RunPlugin(plugin://plugin.program.G.K.N.Wizard/?mode=forceprofile)')
    xbmc.sleep(5000)
    xbmcgui.Dialog().notification("[B][COLOR orange]Reload Profile[/COLOR][/B]", "[COLOR white]Παρακαλώ περιμένετε...[/COLOR]", icon='special://home/addons/plugin.program.downloaderstartup/resources/media/reloadprofile.png')
    
TheAnonymousPortal()
    