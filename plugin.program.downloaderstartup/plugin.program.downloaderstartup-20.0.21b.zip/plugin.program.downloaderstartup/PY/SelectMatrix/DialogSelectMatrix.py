﻿import xbmc, xbmcgui

def DialogSelectMatrix():
        choice = xbmcgui.Dialog().yesno('[CR]', 'Η επιλογή αυτή είναι για Test που κάνω στο build.[CR][CR][B]Παρακαλώ μη προχωράτε γιατί μπορεί να προκύψουν δυσλειτουργίες στο build...[/B]',
                                        nolabel='[B][COLOR white]Άκυρο[/COLOR][/B]',yeslabel='[B][COLOR orange]Select Matrix[/COLOR] - [COLOR red]Test[/COLOR][/B]')

        if choice == 1: SelectMatrix()



import xbmc, xbmcgui


def SelectMatrix():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7, click_8, click_9, click_10, click_11, click_12, click_13, click_14, click_15, click_16, click_17, click_18, click_19, click_20, click_21, click_22)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]  ~ [COLOR red]Test[/COLOR]  ~[/COLOR][/B]', 
['[B][COLOR=green]Fix All[/COLOR][/B] FixBuildUpdate',
 '[B][COLOR=orange]UpdaterMatrix_2[/COLOR][/B]  Εγκατάσταση (νέων) repository',
 '[B][COLOR=orange]UpdaterMatrix_3[/COLOR][/B]  Πρόσφατες αλλαγές addon_data',
 '[B][COLOR=orange]UpdaterMatrix_4[/COLOR][/B]  Download Intro',
 '[B][COLOR=orange]UpdaterMatrix_5[/COLOR][/B]  Εισαγωγή (νέων) διακομιστών του PvrStalker',
 '[B][COLOR=orange]UpdaterMatrix_6[/COLOR][/B]  TheMovieDb Helper (Players)',
 '[B][COLOR=red]Tools[/COLOR][/B]',
 '[B][COLOR=orange]UpdaterMatrix_7[/COLOR][/B]  Διάφορα Fix',
 '[B][COLOR=orange]UpdaterMatrix_8[/COLOR][/B]  (HomeWidget On)',
 '[B][COLOR=orange]UpdaterMatrix_9[/COLOR][/B]  mypreferences addon_data reset',
 '[B][COLOR=orange]UpdaterMatrix_15[/COLOR][/B]  The Anonymous portal',
 '[B][COLOR=orange]UpdaterMatrix_19[/COLOR][/B]  Robinhood TV Portal',
 '[B][COLOR=orange]UpdaterMatrix_20[/COLOR][/B]  World Updater - Tools... fix (test)',
 '[B][COLOR=orange]UpdaterMatrix_21[/COLOR][/B]  addons...',
 '[B][COLOR=orange]UpdaterMatrix_22[/COLOR][/B]  decoderfilter - playercorefactory - test',
 '[B][COLOR=orange]UpdaterMatrix_23[/COLOR][/B]  service.autoexec',
 '[B][COLOR=orange]UpdaterMatrix_24[/COLOR][/B]  sources.xml',
 '[B][COLOR=orange]UpdaterMatrix_29[/COLOR][/B]  reset settings resolveurl',
 #'[B][COLOR=orange]UpdaterMatrix_100[/COLOR][/B]  HomeWidget Delete',
 '[B][COLOR=orange]Run Downloader Startup[/COLOR][/B]  *if path exists',
 '[B][COLOR=orange]UpdaterMatrix_11[/COLOR][/B] Fix Whather',
 '[B][COLOR=orange]UpdaterMatrix_16[/COLOR][/B] _____',
 '[B][COLOR=orange]UpdaterMatrix_12[/COLOR][/B] kgen'
 ])


    if call:
        if call < 0:
            return
        func = funcs[call-22]
        return func()
    else:
        func = funcs[call]
        return func()
    return 


def click_1():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/FixBuild.py")')

def click_2():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/UpdaterMatrix_2.py")')

def click_3():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/UpdaterMatrix_3.py")')

def click_4():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/UpdaterMatrix_4.py")')
    
def click_5():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/UpdaterMatrix_5.py")')

def click_6():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/UpdaterMatrix_6.py")')
    
def click_7():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/Tools/Programs.py")')

def click_8():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/UpdaterMatrix_7.py")')

def click_9():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/UpdaterMatrix_8.py")')

def click_10():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/UpdaterMatrix_9.py")')

def click_11():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/UpdaterMatrix_15.py")')

def click_12():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/UpdaterMatrix_19.py")')

def click_13():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/UpdaterMatrix_20.py")')

def click_14():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/UpdaterMatrix_21.py")')

def click_15():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/UpdaterMatrix_22.py")')

def click_16():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/UpdaterMatrix_23.py")')

def click_17():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/UpdaterMatrix_24.py")')
    
def click_18():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/Tools/Resolveurl/SelectResolveurl.py")')

#def click_19():
    #xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/UpdaterMatrix_100.py")')

def click_19():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloader19/downloader_startup.py")')

def click_20():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/UpdaterMatrix_11.py")')

def click_21():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/UpdaterMatrix_16.py")')

def click_22():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/UpdaterMatrix_12.py")')



DialogSelectMatrix()
