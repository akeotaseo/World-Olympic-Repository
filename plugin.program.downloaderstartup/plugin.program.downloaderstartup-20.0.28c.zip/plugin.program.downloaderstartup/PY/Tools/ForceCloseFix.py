import os, xbmcgui

def killkodi():
        choice = xbmcgui.Dialog().yesno('[B][COLOR orange]World Build[/COLOR][/B]', '[COLOR white]Για να εφαρμοστούν οι αλλαγές[CR]πρέπει να κλείσετε το Kodi[/COLOR]',
                                        nolabel='[COLOR white]Όχι τώρα[/COLOR]',yeslabel='[COLOR white]Κλείσε[/COLOR]')
        if choice == 1: os._exit(1)

killkodi()