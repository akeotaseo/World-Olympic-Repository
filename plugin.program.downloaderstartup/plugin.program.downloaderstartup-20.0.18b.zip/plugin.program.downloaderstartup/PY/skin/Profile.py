import xbmc, xbmcgui


def Profile():
    funcs = (click_1, click_2)
    call = xbmcgui.Dialog().select('[B]Profile[/B]', 
['[COLOR blue] Profile [/COLOR]',

 '[COLOR green] LoadProfile - Master user [/COLOR]'])




    if call:
        if call < 0:
            return
        func = funcs[call-2]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('activatewindow(profiles)')

def click_2():
    xbmcgui.Dialog().notification("[B][COLOR orange]Reload Profile[/COLOR][/B]", "[COLOR white]Παρακαλώ περιμένετε...[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/reloadprofile.png')
    xbmc.sleep(1000)
    xbmc.executebuiltin("LoadProfile(Master user)")
Profile()
