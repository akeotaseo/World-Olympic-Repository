import os, xbmc, xbmcvfs, xbmcgui

def WeatherSettings():
    xbmc.executebuiltin('ActivateWindow(Weather)')
    xbmcgui.Dialog().notification("[B][COLOR orange]Weather[/COLOR][/B]", "Ρυθμίσεις Υπηρεσίας Καιρού", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/Weather.ico')
    xbmc.sleep(3000)
    xbmc.executebuiltin("ActivateWindowAndFocus(servicesettings, -193, )")
    xbmc.sleep(100)
    xbmc.executebuiltin('SendClick(-178)')
    xbmc.sleep(100)
    




WeatherSettings()
