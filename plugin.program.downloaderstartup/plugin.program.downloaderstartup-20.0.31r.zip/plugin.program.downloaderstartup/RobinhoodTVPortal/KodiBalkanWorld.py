
import xbmc, xbmcgui, xbmcvfs, sys, json, os


def KodiBalkanWorld():
    funcs = (click_1, click_2, click_3, click_4)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]  ~ KodiBalkan World ~[/COLOR][/B]', 
['[COLOR=blue]KodiBalkan World Client[/COLOR]',
 'KodiBalkan World Client - [COLOR=gold]Select URL[/COLOR]',
 'KodiBalkan World Client - [COLOR=orange]Select Portal[/COLOR]',
 'KodiBalkan World Client - [COLOR=burlywood]Add List[/COLOR]'])



    if call:
        if call < 0:
            return
        func = funcs[call-4]
        return func()
    else:
        func = funcs[call]
        return func()
    return 


def click_1():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('Action(Back)')
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.worldclient")')


def click_2():
    xbmc.executebuiltin('RunScript("special://home/addons//plugin.program.downloaderstartup/RobinhoodTVPortal/KodiBalkanWorldClientPortal.py")')

def click_3():
    xbmc.executebuiltin('RunScript("special://home/addons//plugin.program.downloaderstartup/RobinhoodTVPortal/gamecontroller2.py")')

def click_4():
    xbmc.executebuiltin('RunScript("special://home/addons//plugin.program.downloaderstartup/RobinhoodTVPortal/gamecontroller3.py")')





KodiBalkanWorld()
