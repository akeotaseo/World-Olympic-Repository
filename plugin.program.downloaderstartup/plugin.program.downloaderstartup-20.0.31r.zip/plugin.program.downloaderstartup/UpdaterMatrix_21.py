﻿
import os, glob, xbmc, xbmcgui, xbmcvfs, xbmcaddon, shutil
from updatervar import *
#from resources.lib.modules.delete_addons import del_dir
from resources.lib.GUIcontrol import txt_updater
from resources.lib.modules import db, addonsEnable
from resources.lib.modules.addonsEnable import enable_addons
#from resources.lib.modules.installer_addons import installAddon
#from resources.lib.GUIcontrol.txt_updater import get_skinshortcutsversion


#exists = os.path.exists
#skinshortcuts_version = get_skinshortcutsversion()

Database_Addons33 = [('repository.World', 'repository.World')]

addon_list = ['plugin.video.live.test', 'plugin.video.testt']


         ### Προσθέτεις εντός της αγκύλης τα πρόσθετα ή τα αρχεία που επιθυμείς να αφαιρέσεις [  ] ###

delete_addons = ['repository.test', 'repository.testt']



def Updater_Matrix():
    BG.create(Dialog_U1, Dialog_U2)
    xbmc.sleep(2000)
    BG.update(25, Dialog_U1, Dialog_U6)
    xbmc.sleep(2000)
    
    del_dir()
    installAddon()


    #BG.update(30, Dialog_U1, 'Delete UpdaterMatrix...')

    BG.update(45, Dialog_U1,  Dialog_U6)
    xbmc.sleep(2000)

                               ### delete addons ands files ### 



                                 #plugin.program.downloader
    if os.path.exists(UpdaterMatrix_path21): xbmcvfs.delete(UpdaterMatrix_path21), xbmc.sleep(1000)





            
    if not os.path.exists(UpdaterMatrix_path21):
        xbmc.sleep(2000)
        xbmc.executebuiltin(UpdaterMatrix_21)
        xbmc.sleep(7000)
        BG.update(78, Dialog_U1, 'Παρακαλώ περιμένετε...')  
        xbmc.sleep(7000)
        BG.update(90, Dialog_U1, Dialog_U6)
        xbmc.sleep(7000)
        BG.update(90, Dialog_U1, Dialog_U6)
        xbmc.sleep(7000)
        BG.update(100, Dialog_U1, 'Ok...')
        # addonsEnable.enable_addons()
        # xbmc.sleep(1000)
        # xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.stalker","enabled":false}}')
        # xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.iptvsimple","enabled":false}}')
        xbmc.sleep(15000)
        BG.close()
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('Action(Back)')
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10000)')
    xbmcgui.Dialog().notification("addonsEnable", "[COLOR cornflowerblue]enable_addons[/COLOR]", icon='special://home/addons/plugin.program.downloaderstartup/resources/media/addons.png', sound=False)
    xbmc.sleep(5000)
    addonsEnable.enable_addons()
    xbmc.sleep(1000)
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.stalker","enabled":false}}')
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.iptvsimple","enabled":false}}')





def installAddon():
    for addon_id in addon_list:
      xbmc.executebuiltin('InstallAddon(%s)' % (addon_id))
      xbmc.sleep(100)
      xbmc.executebuiltin('SendClick(11)')
      xbmc.sleep(100)


def del_dir():
    for ad in addons_data_path:
     for rr in delete_addons:
       dir_list = glob.iglob(os.path.join(ad, rr))
       for path in dir_list:
           if os.path.isdir(path):
               shutil.rmtree(path)
           if os.path.isfile(path):
              os.remove(path)


def enable_addons():
	conn =db_lib.connect(os.path.join(xbmc.translatePath('special://profile/Database'),'Addons33.db'))
	conn.text_factory = str
	conn.executemany('update installed set enabled=1 where addonID = (?)',((val,) for val in os.listdir(xbmc.translatePath(os.path.join('special://home','addons')))))
	conn.commit()
	xbmc.executebuiltin('UpdateLocalAddons')
	xbmc.executebuiltin('UpdateAddonRepos')


     #xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"videoplayer.stretch43","value":0}}')
     #xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"addons.updatemode","value":1}}')
     #xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"GUI.SetFullscreen","id":1,"params":{"fullscreen":"toggle"}}')
     #xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.ExecuteAction","id":1,"params":{"action":"togglefullscreen"}}')




#        choice = xbmcgui.Dialog().yesno('[B][COLOR orange]TechNEWSology[/COLOR][/B]', '[COLOR white]      Επιθυμείτε την απενεργοποίηση των ενημερώσεων [CR]                        του TechNEWSology Updater ?[/COLOR]',
#                                        nolabel='[COLOR lime]Ενεργοποίηση[/COLOR]',yeslabel='[COLOR orange]Απενεργοποίηση[/COLOR]')
#        if choice == 1: [xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "plugin.program.downloader19","enabled":false}}'), xbmcgui.Dialog().ok("[COLOR lime]TechNEWSology Updater-Tools[/COLOR]", "[COLOR orange]Απενεργοποήθηκαν οι αυτόματες ενημερώσεις         του TechNEWSology Updater.[/COLOR]")]
#        else:
#            xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "plugin.program.downloader19","enabled":true}}')

Updater_Matrix()
