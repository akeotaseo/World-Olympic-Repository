import os, glob, xbmc, xbmcgui, xbmcvfs, xbmcaddon, shutil
from updatervar import *
from resources.lib.GUIcontrol import txt_updater
from resources.lib.modules import db, addonsEnable
from resources.lib.modules.addonsEnable import enable_addons
from resources.lib.GUIcontrol.txt_updater import get_skinshortcutsversion, get_addonsrepos


exists = os.path.exists
skinshortcuts_version = get_skinshortcutsversion()

Database_Addons33 = [('repository.Worldolympic', 'repository.World'),
                     ('repository.World', 'repository.World'),
                     ('repository.Worldrepo', 'repository.World')]


                         ### Προσθέτεις εντός της αγκύλης τα πρόσθετα που επιθυμείς [  ] ###

addon_list = ['plugin.video.live.test', 'repository.thecrew', 'plugin.video.testt']


         ### Προσθέτεις εντός της αγκύλης τα πρόσθετα ή τα αρχεία που επιθυμείς να αφαιρέσεις [  ] ###

delete_addons = ['repository.test', 'repository.testt']



def Updater_Matrix():
    BG.create('Αναμονή για ολοκλήρωση', Dialog_U2)
    xbmc.sleep(2000)
    
    
    #BG.update(25, Dialog_U1, Dialog_U6)
    #xbmc.sleep(5000)
    


                               ### delete addons ands files ###

                                 #Εγκατάσταση νέων repository'
    #if exists(UpdaterMatrix_path2): xbmcvfs.delete(UpdaterMatrix_path2), xbmc.sleep(1000)





    del_dir()
    BG.update(45, 'Αναμονή για ολοκλήρωση', 'Παρακαλώ περιμένετε...')
    xbmc.sleep(3000)

                               ### delete addons ands files ###



                                             #Addons33
    if exists(UpdaterMatrix_path9): xbmcvfs.delete(UpdaterMatrix_path9), xbmc.sleep(1000)




###########################################################################
    installAddon()
    xbmc.sleep(3000)
         #UP plugin.program.downloader19
    #if not exists(UpdaterMatrix_path21):
        #xbmc.sleep(5000)
        #xbmc.executebuiltin(UpdaterMatrix_21)
        #xbmc.sleep(7000)
        #BG.update(60, Dialog_U1, 'Παρακαλώ περιμένετε...')
        #BG.update(50, Dialog_U1, Dialog_U6)


    if not exists(UpdaterMatrix_path9):
        xbmc.sleep(5000)
        xbmc.executebuiltin(UpdaterMatrix_9)
        xbmc.sleep(3000)
        BG.update(76, 'Αναμονή για ολοκλήρωση', 'Παρακαλώ περιμένετε...')

    #db.addon_database(Database_Addons33, 1, True)
    #xbmc.sleep(5000)
    #BG.update(40, Dialog_U1, 'Εισαγωγή αποθετηρίων στο Database/Addons33...')
    #xbmc.sleep(5000)
    #BG.update(77, Dialog_U1,  Dialog_U6)



    #xbmc.sleep(5000)
    #BG.update(82, Dialog_U1, 'Install all updates')
    #RunAddon()

    #xbmc.sleep(7000)
    #BG.update(90, Dialog_U1, Dialog_U6)
###########################################################################




    #xbmc.sleep(10000)
    #BG.update(92, Dialog_U1, 'Ελεγχος για ενημέρωση στο μενού του skin...')


    #if skinshortcuts_version > int(setting('skinshortcutsversion')):
        #xbmc.executebuiltin(skinshortcuts_menu)
        #xbmc.sleep(8000)
        #BG.update(96, Dialog_U1, 'Ενημέρωση μενού skin.')
        #setting_set('skinshortcutsversion', str(skinshortcuts_version))
        #xbmc.sleep(8000)
        #BG.update(100, Dialog_U4, 'Θα ακολουθήσει... επαναφόρτωση του προφίλ')
        #xbmc.sleep(8000)
        #BG.update(100, Dialog_U4, 'Θα ακολουθήσει... και πάγωμα της εικόνας')
        #xbmc.sleep(5000)
        #xbmc.executebuiltin("LoadProfile(Master user)")
    #xbmc.sleep(5000)
    #BG.update(100, Dialog_U4, Dialog_U5)
    xbmc.sleep(3000)
    BG.update(99, 'Αναμονή για ολοκλήρωση', 'ok')
    xbmc.sleep(3000)
    BG.update(100, 'Αναμονή για ολοκλήρωση', 'Θα ακολουθήσει... επαναφόρτωση του προφίλ')
    xbmc.sleep(3000)
    BG.update(100, 'Αναμονή για ολοκλήρωση', 'Θα ακολουθήσει... και πάγωμα της εικόνας')
    xbmc.sleep(3000)
    xbmc.executebuiltin("LoadProfile(Master user)")
    BG.close()
    xbmcvfs.delete(downloader_startup_delete)



    xbmc.sleep(7000)
    #BG.update(83, Dialog_U1, 'Ενεργοποίηση πρόσθετων...')
    addonsEnable.enable_addons()



def installAddon():
    for addon_id in addon_list:
      xbmc.executebuiltin('InstallAddon(%s)' % (addon_id))
      xbmc.sleep(100)
      xbmc.executebuiltin('SendClick(11)')
      xbmc.sleep(100)


def del_dir():
    for ad in addons_data_path:
     for rr in delete_addons:
       dir_list = glob.iglob(os.path.join(ad, rr))
       for path in dir_list:
           if os.path.isdir(path):
               shutil.rmtree(path)
           if os.path.isfile(path):
              os.remove(path)


def enable_addons():
	conn =db_lib.connect(os.path.join(xbmc.translatePath('special://profile/Database'),'Addons33.db'))
	conn.text_factory = str
	conn.executemany('update installed set enabled=1 where addonID = (?)',((val,) for val in os.listdir(xbmc.translatePath(os.path.join('special://home','addons')))))
	conn.commit()
	xbmc.executebuiltin('UpdateLocalAddons')
	xbmc.executebuiltin('UpdateAddonRepos')


     #xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"videoplayer.stretch43","value":0}}')
     #xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"addons.updatemode","value":1}}')
     #xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"GUI.SetFullscreen","id":1,"params":{"fullscreen":"toggle"}}')
     #xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.ExecuteAction","id":1,"params":{"action":"togglefullscreen"}}')




#        choice = xbmcgui.Dialog().yesno('[B][COLOR orange]TechNEWSology[/COLOR][/B]', '[COLOR white]      Επιθυμείτε την απενεργοποίηση των ενημερώσεων [CR]                        του TechNEWSology Updater ?[/COLOR]',
#                                        nolabel='[COLOR lime]Ενεργοποίηση[/COLOR]',yeslabel='[COLOR orange]Απενεργοποίηση[/COLOR]')
#        if choice == 1: [xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "plugin.program.downloader19","enabled":false}}'), xbmcgui.Dialog().ok("[COLOR lime]TechNEWSology Updater-Tools[/COLOR]", "[COLOR orange]Απενεργοποήθηκαν οι αυτόματες ενημερώσεις         του TechNEWSology Updater.[/COLOR]")]
#        else:
#            xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "plugin.program.downloader19","enabled":true}}')

Updater_Matrix()
