﻿import xbmc, xbmcgui


def programs():
    funcs = (click1, click2, click3, click4, click5, click6, click7)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]  ~ Tools ~[/COLOR][/B]', 
    
['[B][COLOR=lime]Check Fix[/COLOR][/B]',
 
 '[B][COLOR=white]Επαν-εκκίνηση [COLOR orange]World Updater - Tools[/COLOR][/B]',



 # '[COLOR lightslategray][B]ResolveUrl[/COLOR][/B]',
 # '[COLOR Silverl][B]CocoScrapers-Seren[/COLOR][/B]',


 '[COLOR blue]SearchSubs [/COLOR]',

 '[B]Delete All[COLOR pink] XXX[/COLOR] Addons[/B]',

 '[B][COLOR green] Γενικός καθαρισμός[/COLOR][/B]',

 '[B]Turn Skin Debuging On/Off[/B]',
 '[COLOR orange][B]Select Matrix[/B][/COLOR] - [COLOR red]Test[/COLOR]'])
  #'[B]Install[COLOR purple] TheCrew[/COLOR] ropsitory[/B]',
  #'[COLOR lightskyblue][B]Select Tools[/COLOR][/B]',
#'[B][COLOR=white][B][COLOR dodgerblue]GR[COLOR white]eco[COLOR dodgerblue]TM [COLOR white]Builds Wizard[/COLOR][/B]',
#'[B][COLOR=white][B][COLOR orange]World Updater - Tools[/COLOR][/B]',



    if call:
        if call < 0:
            return
        func = funcs[call-7]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



# def click1():
    # xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/Tools/SkinTools.py")')

def click1():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/Tools/CheckFix.py")')

def click2():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/service.py")')
    xbmc.sleep(1000)
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloader19/service.py")')


# def click3():
    # xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/Tools/Resolveurl/SelectResolveurl.py")')


def click3():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/Tools/SearchSubs.py")')

def click4():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/AddonsDelete/DialogDeleteAllXXXAddons.py")')

def click5():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/Tools/NotifyWorld/GenikosKatharismos.py")')

def click6():
    xbmc.executebuiltin('skin.toggledebug')

def click7():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/SelectMatrix/DialogSelectMatrix.py")')
########################################################################################
# def click7():
    # xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.autowidget/?group=28tools-28&mode=group&refresh&reload")')

# def click8():
    # xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/Wolf/InstalTheCrewRepository.py")')


#def click1():
    #xbmc.executebuiltin('ActivateWindow(10001,plugin://plugin.program.G.K.N.Wizard/)')

#def click2():
    #xbmc.executebuiltin('ActivateWindow(10001,plugin://plugin.program.downloader19/)')

programs()
