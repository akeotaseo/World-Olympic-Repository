import os, xbmc, xbmcvfs, xbmcgui, shutil, glob


xbmcvfs.delete('special://home/userdata/addon_data/plugin.video.themoviedb.helper/database_v6/ItemBuilder.db')
xbmc.sleep(100)
xbmcvfs.delete('special://home/userdata/addon_data/plugin.video.themoviedb.helper/database_v6/FanartTV.db')

xbmc.sleep(100)

base_path = xbmcvfs.translatePath('special://home/addons')

dir_list = glob.iglob(os.path.join(base_path, "temp"))
for path in dir_list:
    if os.path.isdir(path):
        shutil.rmtree(path)



base_path = xbmcvfs.translatePath('special://home/')

dir_list = glob.iglob(os.path.join(base_path, "temp"))
for path in dir_list:
    if os.path.isdir(path):
        shutil.rmtree(path)




#base_path = xbmcvfs.translatePath('special://home/addons')

#dir_list = glob.iglob(os.path.join(base_path, "script.tvaddons.debug.log"))
#for path in dir_list:
   # if os.path.isdir(path):
    #    shutil.rmtree(path)

#dialog = xbmcgui.Dialog()
#dialog.ok("[COLOR orange]World build[/COLOR]", "[COLOR white]Delete[/COLOR]")
#xbmc.executebuiltin('RunPlugin(plugin://plugin.program.G.K.N.Wizard/?mode=forceprofile)')
