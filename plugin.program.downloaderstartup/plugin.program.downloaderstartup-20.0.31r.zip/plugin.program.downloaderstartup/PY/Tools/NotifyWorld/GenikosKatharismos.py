import os, xbmc, xbmcvfs, xbmcgui, shutil, glob
from xbmc import executebuiltin
from xbmcaddon import Addon
from os.path import exists,join
from os import makedirs
from xbmcvfs import translatePath


def DialogeGenikosKatharismos():

        choice = xbmcgui.Dialog().yesno('[COLOR orange]Notify World[/COLOR]', '[COLOR white]Ανά (οχι και τόσο τακτά...) χρονικά διαστήματα προτείνεται[CR][COLOR green]Γενικός καθαρισμός[/COLOR][CR](Επαναφορά μνήμης ResolverURL, Καθαρισμός Παρόχων, Thumbnails, Packages, temp)[CR][COLOR orange]Θέλετε να τον κάνετε τώρα ;[/COLOR]',
                                        nolabel='[COLOR red]Μπααα.. άλλη φορά[/COLOR]',yeslabel='[COLOR green]Ναι[/COLOR]')

        if choice == 1: 
            GenikosKatharismos()


def GenikosKatharismos():
######################################################################################

    base_path = xbmcvfs.translatePath('special://home/addons')

    dir_list = glob.iglob(os.path.join(base_path, "packages"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)


    dir_list = glob.iglob(os.path.join(base_path, "temp"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)


    base_path = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.program.downloader19')

    dir_list = glob.iglob(os.path.join(base_path, "__pycache__"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)

    xbmc.sleep(1000)


    pack = translatePath('special://home/addons/packages')

    if not exists(pack):
        makedirs(pack)
    packfolders = 'packages'


    temp= translatePath('special://home/addons/temp')

    if not exists(temp):
        makedirs(temp)
    tempfolders = 'temp'
#############################################################################


    xbmcgui.Dialog().notification("[B][COLOR orange]Γίνεται έλεγχος![/COLOR][/B]", "[COLOR white]Παρακαλώ περιμένετε...[/COLOR]", sound=False, icon='special://home/addons/plugin.program.downloader19/resources/media/ok2.png')

    xbmcvfs.delete('special://home/userdata/addon_data/plugin.video.myiptv/cache.db')

    xbmc.sleep(3000)
    xbmc.executebuiltin('PlayMedia("plugin://plugin.program.downloader19/?url=&mode=23&name=%5BB%5D%5BCOLOR+white%5D%CE%9A%CE%B1%CE%B8%CE%B1%CF%81%CE%B9%CF%83%CE%BC%CF%8C%CF%82+%CE%A0%CE%B1%CF%81%CF%8C%CF%87%CF%89%CE%BD%5B%2FCOLOR%5D%5B%2FB%5D&icon=special%3A%2F%2Fhome%2Faddons%2Fplugin.program.downloader19%2Fresources%2Fmedia%2FWorld.png&fanart=C%3A%5CPortableApps%5Ckodi%5Ckodi+World+20%5CKodi%5Cportable_data%5Caddons%5Cplugin.program.downloader19%5Cfanart.jpg&description=&name2=&version=")')
    xbmc.sleep(5000)
    xbmcgui.Dialog().notification("[B][COLOR orange]Πραγματοποιείται Γενικός καθαρισμός...[/COLOR][/B]", "[COLOR white]Παρακαλώ περιμένετε...[/COLOR]", sound=False, icon='special://home/addons/plugin.program.downloader19/resources/media/clean.png')


    xbmc.sleep(15000)

    xbmc.executebuiltin("Action(Close)")

    xbmc.sleep(1000)

    xbmcvfs.delete('special://home/userdata/addon_data/plugin.program.downloader/settings.xml')
    # xbmc.sleep(500)
    # xbmcvfs.delete('special://home/userdata/addon_data/plugin.video.themoviedb.helper/database_v5/ItemBuilder.db')
    # xbmc.sleep(500)
    # xbmcvfs.delete('special://home/userdata/addon_data/plugin.video.themoviedb.helper/database_v5/FanartTV.db')
    # xbmc.sleep(500)
    # xbmcvfs.delete('special://home/userdata/addon_data/plugin.video.themoviedb.helper/database_v6/ItemBuilder.db')
    # xbmc.sleep(500)
    # xbmcvfs.delete('special://home/userdata/addon_data/plugin.video.themoviedb.helper/database_v6/FanartTV.db')
    xbmc.sleep(500)

    xbmcvfs.delete('special://home/addons/plugin.video.vnmedia/service.py')
    xbmc.sleep(500)
    xbmcvfs.delete('special://home/userdata/Database/MyVideos121.db')


    xbmc.sleep(1000)



    #                         Διαγραφή dead addons


    base_path = xbmcvfs.translatePath('special://home/addons')

    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.neo.tv"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)




                                  #plugin.video.stalker
    base_path = xbmcvfs.translatePath('special://home/userdata/addon_data')

    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.stalker"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)


                           #script.artistslideshow
    base_path = xbmcvfs.translatePath('special://home/userdata/addon_data/script.artistslideshow')

    dir_list = glob.iglob(os.path.join(base_path, "ArtistInformation"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)


    base_path = xbmcvfs.translatePath('special://home/userdata/addon_data/script.artistslideshow')

    dir_list = glob.iglob(os.path.join(base_path, "ArtistSlideshow"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)

    xbmc.sleep(5000)
    xbmc.executebuiltin('PlayMedia("plugin://plugin.program.G.K.N.Wizard/?mode=convertpath")')
    xbmc.sleep(5000)
    xbmcgui.Dialog().notification('[B][COLOR orange]Αναμονή λίγο ακόμη...[/COLOR][/B]', '[COLOR white]...[/COLOR]', icon='special://home/addons/plugin.program.downloader19/resources/media/Pleasewait.png', sound=False)

    xbmc.executebuiltin('PlayMedia("plugin://plugin.video.sporthdme/?url=clear&mode=clear&name=%5BB%5D%5BCOLOR+gold%5DClear+Addon+Data%5B%2FCOLOR%5D%5B%2FB%5D&iconimage=C%3A%5CPortableApps%5Ckodi%5Ckodi+World+21%5CKodi%5Cportable_data%5Caddons%5Cplugin.video.sporthdme%5Cicon.png&description=C%3A%5CPortableApps%5Ckodi%5Ckodi+World+21%5CKodi%5Cportable_data%5Caddons%5Cplugin.video.sporthdme%5Cfanart.jpg")")')
    xbmc.sleep(10000)
    xbmc.executebuiltin('PlayMedia("plugin://plugin.video.atlas/?url=&mode=9&name=%5BB%5D%5BCOLOR+white%5D%CE%95%CE%BA%CE%BA%CE%B1%CE%B8%CE%AC%CF%81%CE%B9%CF%83%CE%B7+Cache%5B%2FCOLOR%5D%5B%2FB%5D&iconimage=https%3A%2F%2Fi.imgur.com%2F2cPUPkf.png&description=")')
    xbmc.sleep(10000)
    xbmc.executebuiltin('PlayMedia("plugin://plugin.video.microjen/clear_cache_silent")')
    xbmc.sleep(20000)
    xbmc.executebuiltin('PlayMedia("plugin://plugin.program.G.K.N.Wizard/?mode=fullcleanNotAsk")')
    xbmcgui.Dialog().notification('[B][COLOR orange]Αναμονή λίγο ακόμη...[/COLOR][/B]', '[COLOR white]...[/COLOR]', icon='special://home/addons/plugin.program.downloader19/resources/media/Pleasewait.png', sound=False)
    xbmc.sleep(15000)
    xbmcgui.Dialog().notification("[B][COLOR orange]Αυτο ήταν...[/COLOR][/B]", "[COLOR white]...[/COLOR]", sound=True, icon='special://home/addons/plugin.program.downloader19/resources/media/ok2.png')


    xbmcgui.Dialog().ok("[COLOR orange]World build[/COLOR]", "[COLOR white]Πατήστε Εντάξει για επαναφόρτωση προφίλ[/COLOR]")


    xbmc.sleep(1000)

    xbmcgui.Dialog().notification("[B][COLOR red]Ok[/COLOR][/B]", "[COLOR white]Αναμονή για Reload Profile...[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/rp.png', sound=False)
    xbmc.sleep(3000)
    xbmc.executebuiltin('RunPlugin(plugin://plugin.program.G.K.N.Wizard/?mode=forceprofile)')
    xbmcgui.Dialog().notification("[B][COLOR orange]Reload Profile[/COLOR][/B]", "[COLOR white]Παρακαλώ περιμένετε...[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/reloadprofile.png', sound=False)


DialogeGenikosKatharismos()