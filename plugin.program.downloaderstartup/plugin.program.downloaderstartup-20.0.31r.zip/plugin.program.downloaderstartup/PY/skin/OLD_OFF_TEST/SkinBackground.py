import xbmc, xbmcgui


def SkinBackground():
    funcs = (click1, click2)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]~ Background ~[/COLOR][/B]', 
['On-[COLOR=orange]Single Global Background[/COLOR]-Off',
 # 'On-[COLOR=mediumvioletred]Weather Theme[/COLOR]-Off',
 # '   ',
 # 'On-[COLOR=blue]Blue Theme[/COLOR]-Off',




 '[B][COLOR red]<---                                                                      [COLOR grey]Back[/COLOR][/B]'
 ])


    if call:
        if call < 0:
            return
        func = funcs[call-2]
        return func()
    else:
        func = funcs[call]
        return func()
    return 


    
def click1():
    xbmc.executebuiltin('Skin.ToggleSetting(SingleGlobalBackground)')
    xbmc.sleep(1000)
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/skin/SkinBackground.py")')

# def click2():
    # xbmc.executebuiltin('Skin.ToggleSetting(GlobalLiveWeatherImage)')
    # xbmc.sleep(1000)
    # xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/skin/SkinBackground.py")')

# def click3():
    # xbmc.executebuiltin('Skin.ToggleSetting(HolidayEffects)')
    # xbmc.sleep(1000)
    # xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/skin/SkinBackground.py")')

def click2():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/Tools/SkinTools.py")')

SkinBackground()
