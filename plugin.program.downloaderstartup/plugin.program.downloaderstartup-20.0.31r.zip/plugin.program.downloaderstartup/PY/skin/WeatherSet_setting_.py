﻿import os, xbmc, xbmcvfs, xbmcgui, xbmcaddon, shutil, glob
xbmcgui.Dialog().notification("[B][COLOR orange]Weather[/COLOR][/B] [B][COLOR cornflowerblue]Gismeteo[/COLOR][/B]", "Reset", icon='special://home/addons/skin.19MatrixWorld/media/Weather.ico', sound=False)


def WeatherResetDialoge():
        choice = xbmcgui.Dialog().yesno('[B][COLOR cornflowerblue]Gismeteo[/COLOR][/B]', '[COLOR white]Επαναφορά Πόλεων [B]Athens, Thessaloniki, Patra, Heraklion[/B].[CR][CR]Θέλετε να συνεχίσετε;[/COLOR]',
                                        nolabel='[COLOR white]Όχι[/COLOR]',yeslabel='[COLOR white]Ναι[/COLOR]')
        if choice == 1: [xbmcgui.Dialog().notification("[B][COLOR orange]Weather[/COLOR][/B] [B][COLOR cornflowerblue]Gismeteo[/COLOR][/B] ", "Επαναφορά Πόλεων...", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/Weather.ico'), WeatherSet_setting(),]
                         # xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/UpdaterMatrix_11.py")')
                         
        if choice == 0: [
                         xbmc.executebuiltin('ActivateWindow(Home)'),]


def WeatherSet_setting():
    
    # xbmc.executebuiltin("ActivateWindowAndFocus(servicesettings, -193, )")
    # xbmc.sleep(100)
    # xbmc.executebuiltin('SendClick(-178)')
    # xbmc.sleep(1000)
    # xbmc.executebuiltin('ActivateWindow(Weather)')

# Gismeteo

    if xbmc.getCondVisibility('System.HasAddon({})'.format('weather.gismeteo')):
        addon_gismeteo       = xbmcaddon.Addon('weather.gismeteo')
        setting_gismeteo     = addon_gismeteo.getSetting
        setting_set_gismeteo = addon_gismeteo.setSetting
        if not setting_gismeteo('CurrentLocation')=='false':
            
            setting_set_gismeteo('CurrentLocation', 'false')


    if xbmc.getCondVisibility('System.HasAddon({})'.format('weather.gismeteo')):
        addon_gismeteo       = xbmcaddon.Addon('weather.gismeteo')
        setting_gismeteo     = addon_gismeteo.getSetting
        setting_set_gismeteo = addon_gismeteo.setSetting
        if not setting_gismeteo('Location1')=='Aaa':
            
            setting_set_gismeteo('Location1', 'Athens')


    if xbmc.getCondVisibility('System.HasAddon({})'.format('weather.gismeteo')):
        addon_gismeteo       = xbmcaddon.Addon('weather.gismeteo')
        setting_gismeteo     = addon_gismeteo.getSetting
        setting_set_gismeteo = addon_gismeteo.setSetting
        if not setting_gismeteo('Location1ID')=='10000':
            
            setting_set_gismeteo('Location1ID', '3673')


    if xbmc.getCondVisibility('System.HasAddon({})'.format('weather.gismeteo')):
        addon_gismeteo       = xbmcaddon.Addon('weather.gismeteo')
        setting_gismeteo     = addon_gismeteo.getSetting
        setting_set_gismeteo = addon_gismeteo.setSetting
        if not setting_gismeteo('Location2')=='Aaa':
            
            setting_set_gismeteo('Location2', 'Thessaloniki')


    if xbmc.getCondVisibility('System.HasAddon({})'.format('weather.gismeteo')):
        addon_gismeteo       = xbmcaddon.Addon('weather.gismeteo')
        setting_gismeteo     = addon_gismeteo.getSetting
        setting_set_gismeteo = addon_gismeteo.setSetting
        if not setting_gismeteo('Location2ID')=='10000':
            
            setting_set_gismeteo('Location2ID', '3635')


    if xbmc.getCondVisibility('System.HasAddon({})'.format('weather.gismeteo')):
        addon_gismeteo       = xbmcaddon.Addon('weather.gismeteo')
        setting_gismeteo     = addon_gismeteo.getSetting
        setting_set_gismeteo = addon_gismeteo.setSetting
        if not setting_gismeteo('Location3')=='Aaa':

            setting_set_gismeteo('Location3', 'Patra')


    if xbmc.getCondVisibility('System.HasAddon({})'.format('weather.gismeteo')):
        addon_gismeteo       = xbmcaddon.Addon('weather.gismeteo')
        setting_gismeteo     = addon_gismeteo.getSetting
        setting_set_gismeteo = addon_gismeteo.setSetting
        if not setting_gismeteo('Location3ID')=='10000':
            
            setting_set_gismeteo('Location3ID', '3672')


    if xbmc.getCondVisibility('System.HasAddon({})'.format('weather.gismeteo')):
        addon_gismeteo       = xbmcaddon.Addon('weather.gismeteo')
        setting_gismeteo     = addon_gismeteo.getSetting
        setting_set_gismeteo = addon_gismeteo.setSetting
        if not setting_gismeteo('Location4')=='Aaa':
            
            setting_set_gismeteo('Location4', 'Heraklion')


    if xbmc.getCondVisibility('System.HasAddon({})'.format('weather.gismeteo')):
        addon_gismeteo       = xbmcaddon.Addon('weather.gismeteo')
        setting_gismeteo     = addon_gismeteo.getSetting
        setting_set_gismeteo = addon_gismeteo.setSetting
        if not setting_gismeteo('Location4ID')=='10000':
            
            setting_set_gismeteo('Location4ID', '3679')
            # xbmc.sleep(2000)
            # xbmcgui.Dialog().notification("Πατήστε", "[B]Εντάξει[/B]", icon='special://home/addons/skin.19MatrixWorld/media/GE.png', sound=True)
            xbmc.executebuiltin('SendClick(28)')
            xbmc.executebuiltin('ActivateWindow(Weather)')


    # xbmc.sleep(2000)

    # xbmc.executebuiltin('Dialog.Close(all,true)')
    # xbmc.executebuiltin('SendClick(28)')
    # xbmc.executebuiltin('ActivateWindow(10000)')
    # xbmc.executebuiltin('ActivateWindow(Weather)')
    # xbmc.executebuiltin('Weather.LocationNext')


WeatherResetDialoge()
