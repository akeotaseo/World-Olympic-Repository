import os, xbmc, xbmcvfs, xbmcgui, shutil, glob

#base_path = xbmcvfs.translatePath('special://home/addons')

#dir_list = glob.iglob(os.path.join(base_path, "UpdaterMatrix"))
#for path in dir_list:
 #   if os.path.isdir(path):
 #       shutil.rmtree(path)

base_path = xbmcvfs.translatePath('special://home/userdata')

dir_list = glob.iglob(os.path.join(base_path, "UpdaterMatrix"))
for path in dir_list:
    if os.path.isdir(path):
        shutil.rmtree(path)

#base_path = xbmcvfs.translatePath('special://home/addons')

#dir_list = glob.iglob(os.path.join(base_path, "UpdaterMatrix"))
#for path in dir_list:
   # if os.path.isdir(path):
    #    shutil.rmtree(path)

#dialog = xbmcgui.Dialog()
#dialog.ok("[COLOR orange]World build[/COLOR]", "[COLOR white]Delete[/COLOR]")
#xbmc.executebuiltin('RunPlugin(plugin://plugin.program.G.K.N.Wizard/?mode=forceprofile)')