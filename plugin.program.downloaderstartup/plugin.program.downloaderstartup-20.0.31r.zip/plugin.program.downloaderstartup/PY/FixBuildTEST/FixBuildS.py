﻿# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcvfs
from updatervar import *
from resources.lib.modules import check



xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"general.addonupdates","value":1}}')
xbmc.sleep(5000)



if __name__ == '__main__':
	if not setting('updaterversion') == 'false':

		dialog.notification(Dialog_welcome, Dialog_Update, icon_Build, sound=False)
		xbmc.sleep(5000)

		check.notifyT()
		check.updater()  #downloader_startup#
		check.autoenable()
		check.var()
		check.delete()
		check.installation()
		check.players()
		check.zip1()
		check.zip2()
		check.zip3()
		check.zip4()
		check.zip5()
		check.pvr()
		check.setsetting()
		check.database()
		check.xmlskin()
#		check.UpdateAddonRepos()



