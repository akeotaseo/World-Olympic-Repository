######Tk######
import urllib.request
import xbmcgui, requests
import xbmcaddon
import random
import re
import os
import sys
import sqlite3
import xbmcvfs
import glob
import time
import json
import xbmc
from urllib.request import urlopen, Request

user_agent = 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.101 Safari/537.36'

addon_id = 'pvr.stalker'
icon ='special://home/addons/pvr.stalker/icon.png'


if not xbmc.getCondVisibility('System.HasAddon({})'.format(addon_id)):
    xbmc.executebuiltin('InstallAddon({})'.format(addon_id))

if os.name == 'r':
    portable_data_path = os.path.join(os.getcwd(), 'portable_data')
    if os.path.isdir(portable_data_path):
        settings_path = os.path.join(portable_data_path, 'userdata', 'addon_data', addon_id, 'settings.xml')
    else:
        settings_path = os.path.join(os.getenv('APPDATA'), 'Kodi', 'userdata', 'addon_data', addon_id, 'settings.xml')
else:  
    settings_path = os.path.join(xbmcvfs.translatePath('special://profile/addon_data'), addon_id, 'settings.xml')


def disable_addon(addon_id):
    my_request = {
        "jsonrpc": "2.0",
        "method": "Addons.SetAddonEnabled",
        "params": {"addonid": addon_id, "enabled": False},
        "id": 1
    }
    xbmc.executeJSONRPC(json.dumps(my_request))


def enable_addon(addon_id):
    my_request = {
        "jsonrpc": "2.0",
        "method": "Addons.SetAddonEnabled",
        "params": {"addonid": addon_id, "enabled": True},
        "id": 1
    }
    xbmc.executeJSONRPC(json.dumps(my_request))

disable_addon(addon_id)

class PVRMac:
    def pvr_client():
        dp = xbmcgui.Dialog()
        select = dp.select('[COLOR white]Επιλογή URL:[/COLOR]',
                          ['[B][COLOR lime]MAC [COLOR orange]List URL[COLOR white] --> [COLOR lime]1[/COLOR][/B]',
                           '[B][COLOR lime]MAC [COLOR orange]List URL[COLOR white] --> [COLOR lime]2[/COLOR][/B]',
                           '[B][COLOR lime]MAC [COLOR orange]List URL[COLOR white] --> [COLOR lime]3[/COLOR][/B]',
                           '[B][COLOR lime]MAC [COLOR orange]List URL[COLOR white] --> [COLOR lime]4[/COLOR][/B]'])
        if select == 0: url = 'https://bit.ly/42S1L7u'
        elif select == 1: url = 'https://bit.ly/4bvHUOq'    ###T###
        elif select == 2: url = 'https://bit.ly/3UoDodR'    ###W###
        elif select == 3: url = 'https://bit.ly/3IwIUpn'

        else:
            url = ''
            xbmcgui.Dialog().notification('[B][COLOR lime]Pvr Stalker[/COLOR][/B]',
                                          '[B][COLOR orange]Ακύρωση![/COLOR][/B]' , icon)
            return
#        disable_addon(addon_id)

        hdrs = {'Referer': url,
                'User-Agent': user_agent}
        server = requests.get(url, headers=hdrs).text

    #    response = urllib.request.urlopen(url)
    #    server = response.read().decode('utf-8')
        mac2=re.findall('(.*?:.*?:.*?:.*?:.*?:.*?..)', server)
        portal = re.findall('=(.*?)=', server)

        mac5 = re.findall('(.*?)=(.*?)=,', server)
        mac_server_login_password_dict = {pair[0]: pair[1:] for pair in mac5}
        chosen_pair = random.choice(list(mac_server_login_password_dict.items()))
        chosen_mac = chosen_pair[0]
        chosen_server = chosen_pair[1][0]

        mac = re.findall('(.*?)=(.*?)=,', server)
        dp = xbmcgui.Dialog()
        ret = dp.select('[COLOR white]Επιλογή MAC-URL:[/COLOR]',
                       ['[B][COLOR orange]Τυχαία [COLOR lime]MAC[/COLOR][/B]',
                        '[B][COLOR orange]Αλλαγή [COLOR lime]MAC[/COLOR][/B]',
                        '[B][COLOR orange]Συνεχίστε με την ίδια [COLOR lime]MAC[/COLOR][/B]'])
        lists = ['random','change','same']
        categories = lists[ret]

        if 'random' in categories:
            with open(settings_path, 'r') as f: settings_xml = f.read()
            settings_xml = re.sub('<setting id="mac_0">.*?</setting>', '<setting id="mac_0">{}</setting>'.format(chosen_mac), settings_xml)
            settings_xml = re.sub('<setting id="server_0">.*?</setting>', '<setting id="server_0">{}</setting>'.format(chosen_server), settings_xml)
            with open(settings_path, 'w') as f: f.write(settings_xml)

        if 'change' in categories:
            newmac=''
            newpor=''

            with open(settings_path, 'r') as f: settings_xml = f.read()

            selected = "[B][COLOR lime]Επιλογή τυχαίας MAC[/COLOR][/B]"
            for mc, port in mac:
                selected = selected + ',' + (mc +' --> '+ port)

            lista_macs = selected.split(",")
            dialog = xbmcgui.Dialog()
            ret = dialog.select('[B][COLOR white]Επιλέξτε: [COLOR orange]MAC --> URL[/COLOR][/B]',lista_macs)

            if ret == 0:
                with open(settings_path, 'r') as f: settings_xml = f.read()
                settings_xml = re.sub('<setting id="mac_0">.*?</setting>', '<setting id="mac_0">{}</setting>'.format(chosen_mac), settings_xml)
                settings_xml = re.sub('<setting id="server_0">.*?</setting>', '<setting id="server_0">{}</setting>'.format(chosen_server), settings_xml)
                with open(settings_path, 'w') as f: f.write(settings_xml)

            else:
                newmac = mac2[ret-1]
                newpor = portal[ret-1]
                settings_xml = re.sub('<setting id="mac_0">.*?</setting>', '<setting id="mac_0">{}</setting>'.format(newmac), settings_xml)
                settings_xml = re.sub('<setting id="server_0">.*?</setting>', '<setting id="server_0">{}</setting>'.format(newpor), settings_xml)
                with open(settings_path, 'w') as f: f.write(settings_xml)


        else:
            return

    #    xbmc.sleep(1000)
    def clear_pvr_data():
        db_files = glob.glob(xbmcvfs.translatePath('special://database/TV*.db'))  # clear_pvr_data
        db_file_names = [f for f in db_files if ('TV' in f or 'MyPVR' in f)]

        for db_file in db_file_names:
            conn = sqlite3.connect(db_file)
            cursor = conn.cursor()

            cursor.execute("DELETE FROM channels")
            cursor.execute("DELETE FROM timers")
            cursor.execute("DELETE FROM clients")
            cursor.execute("DELETE FROM channelgroups")
            cursor.execute("DELETE FROM map_channelgroups_channels")

            conn.commit()
            conn.close()

            xbmcgui.Dialog().notification('[B][COLOR lime]Pvr Stalker[/COLOR][/B]',
                                          '[B][COLOR orange]Αναμονή καθαρισμού λίστας ...[/COLOR][/B]' , icon)

    #    xbmcgui.Dialog().notification('[B][COLOR lime]Pvr Stalker[/COLOR][/B] - [B][COLOR orange]Πύλη [COLOR lime]1[/COLOR][/B]',
    #                                  '[COLOR white]Αν η λίστα εμφανίσει σφάλμα, εκτελούμε ξανά το [COLOR=lime]MAC Generator[/COLOR]' , icon)

    #    enable_addon(addon_id)

PVRMac.clear_pvr_data()
PVRMac.pvr_client()

disable_addon(addon_id)
enable_addon(addon_id)
xbmcgui.Dialog().notification('[B][COLOR lime]Pvr Stalker[/COLOR][/B] - [B][COLOR orange]Πύλη [COLOR lime]1[/COLOR][/B]',
                              '[COLOR white]Αν η λίστα εμφανίσει σφάλμα, εκτελούμε ξανά το [COLOR=lime]MAC Generator[/COLOR]' , icon)
