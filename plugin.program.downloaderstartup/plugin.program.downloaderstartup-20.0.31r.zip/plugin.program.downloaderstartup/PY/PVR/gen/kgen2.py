import urllib.request
import xbmcgui
import xbmcaddon
import random
import re
import os
import sys
import sqlite3
import xbmcvfs
import glob
import time
import json
import xbmc

#KodiBalkan Build. Dzon Dzoe , Robin Hood

pvr_client_id = 'pvr.stalker'

if not xbmc.getCondVisibility('System.HasAddon({})'.format(pvr_client_id)):
    xbmc.executebuiltin('InstallAddon({})'.format(pvr_client_id))

def disable_addon(addon_id):
    my_request = {
        "jsonrpc": "2.0",
        "method": "Addons.SetAddonEnabled",
        "params": {"addonid": addon_id, "enabled": False},
        "id": 1
    }
    xbmc.executeJSONRPC(json.dumps(my_request))

addon_id_to_disable = "pvr.stalker" 
disable_addon(addon_id_to_disable)

class PVRClient:
    def clear_pvr_data():
        db_files = glob.glob(xbmcvfs.translatePath('special://database/TV*.db'))
        db_file_names = [f for f in db_files if ('TV' in f or 'MyPVR' in f)]

        for db_file in db_file_names:
            conn = sqlite3.connect(db_file)
            cursor = conn.cursor()

            cursor.execute("DELETE FROM channels")
            cursor.execute("DELETE FROM timers")
            cursor.execute("DELETE FROM clients")
            cursor.execute("DELETE FROM channelgroups")
            cursor.execute("DELETE FROM map_channelgroups_channels")

            conn.commit()
            conn.close()

    def update_pvr_client():
        dialog = xbmcgui.DialogProgress()
        dialog.create('PVR MAC Generator', 'Generation MAC List')
        dialog.update(0, 'Generation MAC List, Please wait for the process to complete')
        PVRClient.clear_pvr_data()
        for i in range(0, 101, 4):
            dialog.update(i, 'Generation MAC List, Please wait for the process to complete')
            xbmc.sleep(600) 
        
        dialog.update(100, 'Generation MAC List is completed')

        xbmc.sleep(2000)
        dialog.close()

PVRClient.update_pvr_client()

addon_id = 'pvr.stalker'

if os.name == 'r':  
    portable_data_path = os.path.join(os.getcwd(), 'portable_data')
    if os.path.isdir(portable_data_path):
        settings_path = os.path.join(portable_data_path, 'userdata', 'addon_data', addon_id, 'settings.xml')
    else:
        settings_path = os.path.join(os.getenv('APPDATA'), 'Kodi', 'userdata', 'addon_data', addon_id, 'settings.xml')
else:  
    settings_path = os.path.join(xbmcvfs.translatePath('special://profile/addon_data'), addon_id, 'settings.xml')

url = 'https://bit.ly/3IwIUpn'

response = urllib.request.urlopen(url)
mac_server_login_password_data = response.read().decode('utf-8')

mac_server_login_password_pairs = re.findall(r'(\w{2}:\w{2}:\w{2}:\w{2}:\w{2}:\w{2})=(\S+)=(\S*),(\S*)', mac_server_login_password_data)
mac_server_login_password_dict = {pair[0]: pair[1:] for pair in mac_server_login_password_pairs}

chosen_pair = random.choice(list(mac_server_login_password_dict.items()))
chosen_mac = chosen_pair[0]
chosen_server = chosen_pair[1][0]
chosen_login = chosen_pair[1][1] if chosen_pair[1][1] else ""
chosen_password = chosen_pair[1][2] if chosen_pair[1][2] else ""

with open(settings_path, 'r') as f:
    settings_xml = f.read()

settings_xml = re.sub('<setting id="mac_0">.*?</setting>', '<setting id="mac_0">{}</setting>'.format(chosen_mac), settings_xml)
settings_xml = re.sub('<setting id="server_0">.*?</setting>', '<setting id="server_0">{}</setting>'.format(chosen_server), settings_xml)

with open(settings_path, 'w') as f:
    f.write(settings_xml)

xbmcgui.Dialog().ok('MAC List is generated', 'If the generated list shows you the error run again the generator.')

def enable_addon(addon_id):
    my_request = {
        "jsonrpc": "2.0",
        "method": "Addons.SetAddonEnabled",
        "params": {"addonid": addon_id, "enabled": True},
        "id": 1
    }
    xbmc.executeJSONRPC(json.dumps(my_request))

addon_id_to_enable = "pvr.stalker"
enable_addon(addon_id_to_enable)
