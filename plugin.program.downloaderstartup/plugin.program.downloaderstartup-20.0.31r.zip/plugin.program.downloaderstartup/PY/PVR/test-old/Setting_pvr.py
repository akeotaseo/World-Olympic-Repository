import os, xbmc, xbmcgui, xbmcvfs, xbmcaddon

icon ='special://home/addons/pvr.stalker/icon.png'
addon_pvr       = xbmcaddon.Addon('pvr.stalker')
setting_pvr     = addon_pvr.getSetting
setting_set_pvr = addon_pvr.setSetting

if   setting_pvr('active_portal') == '0': port = '1'
elif setting_pvr('active_portal') == '1': port = '2'
elif setting_pvr('active_portal') == '2': port = '3'
elif setting_pvr('active_portal') == '3': port = '4'
elif setting_pvr('active_portal') == '4': port = '5'


def pvr():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6)
    call = xbmcgui.Dialog().select(('[COLOR=lime] Επιλεγμένη Πύλη --> [COLOR=orange][ [COLOR=lime]%s [COLOR=orange]][/COLOR]' % port),
# ['[B][COLOR=lime]*[COLOR=orange] Αυτ/μένη αντικατάσταση πύλης [COLOR=white][1-5]  [COLOR=deepskyblue]ZTEU [COLOR=lime]Generator [/COLOR][/B]',
 # '[B][COLOR=lime]*[COLOR=orange] Αυτ/μένη αντικατάσταση πύλης [COLOR=white]1  [COLOR=deepskyblue]Mac [COLOR=lime]List Generator [/COLOR][/B]',
 ['[B][COLOR=white]Επιλογή Πύλης -[COLOR=lime] 1[/COLOR][/B]',
 '[B][COLOR=white]Επιλογή Πύλης -[COLOR=lime] 2[/COLOR][/B]',
 '[B][COLOR=white]Επιλογή Πύλης -[COLOR=lime] 3[/COLOR][/B]',
 '[B][COLOR=white]Επιλογή Πύλης -[COLOR=lime] 4[/COLOR][/B]',
 '[B][COLOR=white]Επιλογή Πύλης -[COLOR=lime] 5[/COLOR][/B]',
 '[B][COLOR=lime]Επαναφόρτωση καναλιών[/COLOR][/B]'
 ])

#('[B][COLOR=lime]Επιλεγμένη Πύλη -->[/COLOR][/B] [B][COLOR=orange]%s[/COLOR][/B]' % port)])


    if call:
        if call < 0:
            return
        func = funcs[call-6]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



# def click_1():
    # xbmcgui.Dialog().notification("[B][COLOR lime]Pvr Stalker[/COLOR][/B] - [B][COLOR orange]Πύλη [COLOR lime]1[/COLOR][/B]",'[B][COLOR white]Αν η λίστα είναι κενή, ξαναπατάμε [COLOR=orange]ZTEU Generator![/COLOR][/B]' , icon)
    # xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/PVR/gen_pvr.py")')

# def click_2():
#    xbmcgui.Dialog().notification("[B][COLOR lime]Pvr Stalker[/COLOR][/B] - [B][COLOR orange]Πύλη [COLOR lime]1[/COLOR][/B]",'[B][COLOR white]Αν η λίστα είναι κενή, ξαναπατάμε [COLOR=orange]ZTEU Generator![/COLOR][/B]' , icon)
    # xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/PVR/mac_list_0.py")')

def click_1():
    xbmcgui.Dialog().notification("[B][COLOR lime]Pvr Stalker[/COLOR][/B] - [COLOR orange]Πύλη [COLOR lime]1[/COLOR]",'[COLOR white]Αναμονή ολοκλήρωσης φόρτωσης καναλιών![/COLOR]' , icon)
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "pvr.stalker","enabled":false}}')
    setting_set_pvr('active_portal', '0')
    pvr_on_off()

def click_2():
    xbmcgui.Dialog().notification("[B][COLOR lime]Pvr Stalker[/COLOR][/B] - [COLOR orange]Πύλη [COLOR lime]2[/COLOR]",'[COLOR white]Αναμονή ολοκλήρωσης φόρτωσης καναλιών![/COLOR]' , icon)
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "pvr.stalker","enabled":false}}')
    setting_set_pvr('active_portal', '1')
    pvr_on_off()
#    cleaner()
#    xbmc.sleep(10000)
#    xbmc.executebuiltin('SendClick(28)')

def click_3():
    xbmcgui.Dialog().notification("[B][COLOR lime]Pvr Stalker[/COLOR][/B] - [COLOR orange]Πύλη [COLOR lime]3[/COLOR]",'[COLOR white]Αναμονή ολοκλήρωσης φόρτωσης καναλιών![/COLOR]' , icon)
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "pvr.stalker","enabled":false}}')
    setting_set_pvr('active_portal', '2')
    pvr_on_off()
#    cleaner()
#    xbmc.sleep(10000)
#    xbmc.executebuiltin('SendClick(28)')

def click_4():
    xbmcgui.Dialog().notification("[B][COLOR lime]Pvr Stalker[/COLOR][/B] - [COLOR orange]Πύλη [COLOR lime]4[/COLOR]",'[COLOR white]Αναμονή ολοκλήρωσης φόρτωσης καναλιών![/COLOR]' , icon)
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "pvr.stalker","enabled":false}}')
    setting_set_pvr('active_portal', '3')
    pvr_on_off()
#    cleaner()
#    xbmc.sleep(10000)
#    xbmc.executebuiltin('SendClick(28)')

def click_5():
    xbmcgui.Dialog().notification("[B][COLOR lime]Pvr Stalker[/COLOR][/B] - [COLOR orange]Πύλη [COLOR lime]5[/COLOR]",'[COLOR white]Αναμονή ολοκλήρωσης φόρτωσης καναλιών![/COLOR]' , icon)
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "pvr.stalker","enabled":false}}')
    setting_set_pvr('active_portal', '4')
    pvr_on_off()
#    cleaner()
#    xbmc.sleep(10000)
#    xbmc.executebuiltin('SendClick(28)')

def click_6():
    xbmcgui.Dialog().notification("[B][COLOR lime]Pvr Stalker[/COLOR][/B]",'[COLOR white]Αναμονή ολοκλήρωσης φόρτωσης καναλιών![/COLOR]' , icon)
    pvr_on_off()

    
    
def pvr_on_off():
    xbmc.sleep(100)
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "pvr.stalker","enabled":true}}')
    xbmc.sleep(100)
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "pvr.stalker","enabled":false}}')
    xbmc.sleep(100)
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "pvr.stalker","enabled":true}}')

def cleaner():
    xbmc.executebuiltin("ActivateWindowAndFocus(pvrsettings, 100,0 , -69,0)")
    xbmc.executebuiltin('SendClick(-69)')
    xbmc.executebuiltin('SendClick(11)')
    xbmc.executebuiltin("ActivateWindow(10700)")

pvr()
