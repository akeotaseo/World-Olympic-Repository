import urllib.request
import xbmcgui
import random
import re
import os
import xbmcvfs

# KodiBalkan Build. Dzon Dzoe , Robin Hood

addon_id = 'plugin.video.stalkervod'

def update_stalker_vod_addon():
    # Generisanje MAC liste
    url = 'https://bit.ly/3IwIUpn'
    response = urllib.request.urlopen(url)
    mac_server_login_password_data = response.read().decode('utf-8')

    mac_server_login_password_pairs = re.findall(r'(\w{2}:\w{2}:\w{2}:\w{2}:\w{2}:\w{2})=(\S+)=(\S*),(\S*)', mac_server_login_password_data)
    mac_server_login_password_dict = {pair[0]: pair[1:] for pair in mac_server_login_password_pairs}

    chosen_pair = random.choice(list(mac_server_login_password_dict.items()))
    chosen_mac = chosen_pair[0]
    chosen_server = chosen_pair[1][0]
    chosen_login = chosen_pair[1][1] if chosen_pair[1][1] else ""
    chosen_password = chosen_pair[1][2] if chosen_pair[1][2] else ""

    # Podešavanje putanje do settings.xml
    if os.name == 'r':  
        portable_data_path = os.path.join(os.getcwd(), 'portable_data')
        if os.path.isdir(portable_data_path):
            settings_path = os.path.join(portable_data_path, 'userdata', 'addon_data', addon_id, 'settings.xml')
        else:
            settings_path = os.path.join(os.getenv('APPDATA'), 'Kodi', 'userdata', 'addon_data', addon_id, 'settings.xml')
    else:  
        settings_path = os.path.join(xbmcvfs.translatePath('special://profile/addon_data'), addon_id, 'settings.xml')

    # Izmena settings.xml sa generisanim vrednostima
    with open(settings_path, 'r') as f: settings_xml = f.read()
    settings_xml = re.sub('<setting id="mac_address">.*?</setting>', '<setting id="mac_address">{}</setting>'.format(chosen_mac), settings_xml)
    settings_xml = re.sub('<setting id="server_address">.*?</setting>', '<setting id="server_address">{}</setting>'.format(chosen_server), settings_xml)

    settings_xml = re.sub('<setting id="mac_address" default="true">.*?</setting>', '<setting id="mac_address" default="true">{}</setting>'.format(chosen_mac), settings_xml)
    settings_xml = re.sub('<setting id="server_address" default="true">.*?</setting>', '<setting id="server_address" default="true">{}</setting>'.format(chosen_server), settings_xml)
    with open(settings_path, 'w') as f: f.write(settings_xml)

    # Prikaz jednostavnog obaveštenja da je nova lista generisana
    xbmcgui.Dialog().ok('stalkervod', '[COLOR lime]Η Αλλαγή Λίστας πραγματοποιήθηκε.[/COLOR][CR][CR]Διαλέξτε [B]VOD Ταινίες[/B] ή [B]VOD Σειρές.[/B]')
    # xbmc.sleep(4000)
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('Action(Back)')
    xbmc.executebuiltin('Dialog.Close(all,true)')

    xbmc.executebuiltin('ActivateWindow(Home)')
    # xbmc.sleep(2000)
    # xbmc.executebuiltin('ActivateWindow(Videos,Addons)')

    # xbmc.executebuiltin('Dialog.Close(all,true)')
    # xbmc.executebuiltin('Action(Back)')
    # xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.sleep(6000)
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.stalkervod/",return)')

    # xbmc.sleep(6000)
    # xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.myselect/folders/py/VOD.py")')

update_stalker_vod_addon()
