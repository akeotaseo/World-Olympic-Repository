######Tk######
import urllib.request
import os, re, sys, json, time, glob, xbmc, xbmcvfs, xbmcgui, xbmcaddon, sqlite3, random, requests
from urllib.request import urlopen, Request
addon_id = 'pvr.stalker'
exists     = os.path.exists
user_agent = 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.101 Safari/537.36'
addon_data_path = xbmcvfs.translatePath('special://home/userdata/addon_data/pvr.stalker')
icon ='special://home/addons/pvr.stalker/icon.png'

if os.name == 'r':
    portable_data_path = os.path.join(os.getcwd(), 'portable_data')
    if os.path.isdir(portable_data_path):
        if not os.path.exists(os.path.join(addon_data_path, 'instance-settings-1.xml')):
            settings_path = os.path.join(portable_data_path, 'userdata', 'addon_data', addon_id, 'settings.xml')
        else:
            settings_path = os.path.join(portable_data_path, 'userdata', 'addon_data', addon_id, 'instance-settings-1.xml')

    else:
        if not os.path.exists(os.path.join(addon_data_path, 'instance-settings-1.xml')):
            settings_path = os.path.join(os.getenv('APPDATA'), 'Kodi', 'userdata', 'addon_data', addon_id, 'settings.xml')
        else:
            settings_path = os.path.join(os.getenv('APPDATA'), 'Kodi', 'userdata', 'addon_data', addon_id, 'instance-settings-1.xml')
else:
    if not os.path.exists(os.path.join(addon_data_path, 'instance-settings-1.xml')):
        settings_path = os.path.join(xbmcvfs.translatePath('special://profile/addon_data'), addon_id, 'settings.xml')
    else:
        settings_path = os.path.join(xbmcvfs.translatePath('special://profile/addon_data'), addon_id, 'instance-settings-1.xml')

def disable_addon(addon_id):
    my_request = {
        "jsonrpc": "2.0",
        "method": "Addons.SetAddonEnabled",
        "params": {"addonid": addon_id, "enabled": False},
        "id": 1
    }
    xbmc.executeJSONRPC(json.dumps(my_request))
    # xbmcgui.Dialog().notification("[COLOR orange]Αναμονή...[/COLOR]", "[COLOR white]μέχρι να φορτώσουν τα κανάλια...[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/Pleasewait.png', sound=False)
    # xbmc.sleep(4000)
    # xbmcgui.Dialog().notification("[COLOR orange]Αναμονή...[/COLOR]", "[COLOR white]μέχρι να φορτώσουν τα κανάλια...[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/Pleasewait.png', sound=False)
    # xbmcgui.Dialog().notification('[B][COLOR lime]Pvr Stalker[/COLOR][/B] - [B][COLOR orange]Πύλη [COLOR lime]1[/COLOR][/B]', '[COLOR white]Αν η λίστα εμφανίσει σφάλμα, εκτελούμε ξανά το [COLOR=lime]Stalker_portal[/COLOR]' , icon)


def enable_addon(addon_id):
    my_request = {
        "jsonrpc": "2.0",
        "method": "Addons.SetAddonEnabled",
        "params": {"addonid": addon_id, "enabled": True},
        "id": 1
    }
    xbmc.executeJSONRPC(json.dumps(my_request))

disable_addon(addon_id)

class Pvr:
    def iptv():
    #    Pvr.clear_pvr_data()
        url = 'https://iptvlinkseuro.blogspot.com/'
        hdrs = {'Referer': url,
                'User-Agent': user_agent}
        p = requests.get(url, headers=hdrs).text
        m = re.compile('''<h3 class='post-title entry-title'>.*?<a href='(.*?)'>.*?<div class='r-snippetized'>\s+(.*?)\s+</div>''', re.DOTALL).findall(p)
        channels = "[B][COLOR lime]<= [COLOR orange]Πίσω[/COLOR][/B]"
        for url, name in m:
            name = name.replace('StbEmu codes ', '').replace('mac', 'Mac')
            name = '[B][COLOR lime]%s[/COLOR][/B]' % name
            channels = channels + ',' + name + ',' + url
            iptv_links = channels.split(",")

        ret = xbmcgui.Dialog().select('[B][COLOR white]Πατάμε το Link κάτω από την ημερομηνία[/COLOR][/B]', iptv_links)
        if ret <= 0:
            return 
        url_l = iptv_links[ret]
        if '[COLOR lime]' in url_l:
            xbmcgui.Dialog().notification('[B][COLOR lime]Pvr Stalker[/COLOR][/B]', '[B][COLOR orange]Επιλέξτε την κάτω γραμμή που αναγράφεται το Link[/COLOR][/B]' , icon)
            return
        hdrs = {'Referer': url_l,
                'User-Agent': user_agent}
        p1 = requests.get(url_l, headers=hdrs).text
        m1 = re.compile('/>(.*?)<b', re.DOTALL).findall(p1)
        newpor = ''
        newmac = ''
        channels = "[B][COLOR lime]<= [COLOR orange]Πίσω[/COLOR][/B]"
        for url in m1:
            if 'Stalker Portal' in url: url = '[B][COLOR lime]%s[/COLOR][/B]' % url
            if 'http' in url: url = '[B][COLOR orange]%s[/COLOR][/B]' % url
            url = url.replace(',', '').replace('StbEmu codes ', '').replace('<title>', '').replace('</title>', '')
            url = url.replace('MAC: ', '').replace('MAC : ', '').replace('MAC ', '').replace('&nbsp;', '[B][COLOR lime] -->[/COLOR][/B]')
            url = url.replace('''</a></div><p></p><span><a name='more'></a></span><p style="text-align: left;">''', '')
            url = url.replace('</p><p style="text-align: left;">', '').replace('</p>', '')
            url = url.replace('</div>', '----------------------------------------------------')
            url = url.replace('</a>', '----------------------------------------------------')

            prog = ',' + url
            channels = channels + prog
            lista_ch = channels.split(",")
        ret = xbmcgui.Dialog().select('[B][COLOR white]Επιλέγουμε Url και έπειτα Mac αν δεν λειτουργεί[/COLOR][/B]', lista_ch)

        if ret <= 0:
            return 

        newpor = m1[ret-1]
        newmac = m1[ret-1]
        newmac = newmac.replace('MAC: ', '').replace('MAC : ', '').replace('MAC ', '').replace('&nbsp;', '').replace(' 2024', '').replace(' 2025', '').replace(' 2026', '')
        newmac = newmac.replace('25,', '').replace('26,', '').replace('27,', '').replace('28,', '').replace('29,', '').replace('30,', '').replace(' Unlimited', '')
        newmac = newmac.replace('19,', '').replace('20,', '').replace('21,', '').replace('22,', '').replace('23,', '').replace('24,', '').replace('31,', '')
        newmac = newmac.replace('13,', '').replace('14,', '').replace('15,', '').replace('16,', '').replace('17,', '').replace('18,', '')
        newmac = newmac.replace('7,', '').replace('8,', '').replace('9,', '').replace('10,', '').replace('11,', '').replace('12,', '')
        newmac = newmac.replace('1,', '').replace('2,', '').replace('3,', '').replace('4,', '').replace('5,', '').replace('6,', '')
        newmac = newmac.replace(' ', '').replace('01.', '').replace('02.', '').replace('03.', '').replace('04.', '').replace('05.', '').replace('06.', '')
        newmac = newmac.replace('07.', '').replace('08.', '').replace('09.', '').replace('10.', '').replace('11.', '').replace('12.', '')
        newmac = newmac.replace('13.', '').replace('14.', '').replace('15.', '').replace('16.', '').replace('17.', '').replace('18.', '')
        newmac = newmac.replace('19.', '').replace('20.', '').replace('21.', '').replace('22.', '').replace('23.', '').replace('24.', '')
        newmac = newmac.replace('25.', '').replace('26.', '').replace('27.', '').replace('28.', '').replace('29.', '').replace('30.', '')
        newmac = newmac.replace('31.', '').replace('2024', '').replace('2025', '')
        newmac = newmac.replace('January', '').replace('February', '').replace('March', '').replace('April', '').replace('May', '').replace('June', '')
        newmac = newmac.replace('July', '').replace('August', '').replace('September', '').replace('October', '').replace('November', '').replace('December', '')
        newpor = newpor.replace('''</a></div><p></p><span><a name='more'></a></span><p style="text-align: left;">''', '')

        if 'http' in newpor:
            newmac = m1[ret]
            newmac = newmac.replace('MAC: ', '').replace('MAC : ', '').replace('MAC ', '').replace('&nbsp;', '').replace(' 2024', '').replace(' 2025', '').replace(' 2026', '')
            newmac = newmac.replace('25,', '').replace('26,', '').replace('27,', '').replace('28,', '').replace('29,', '').replace('30,', '').replace(' Unlimited', '')
            newmac = newmac.replace('19,', '').replace('20,', '').replace('21,', '').replace('22,', '').replace('23,', '').replace('24,', '').replace('31,', '')
            newmac = newmac.replace('13,', '').replace('14,', '').replace('15,', '').replace('16,', '').replace('17,', '').replace('18,', '')
            newmac = newmac.replace('7,', '').replace('8,', '').replace('9,', '').replace('10,', '').replace('11,', '').replace('12,', '')
            newmac = newmac.replace('1,', '').replace('2,', '').replace('3,', '').replace('4,', '').replace('5,', '').replace('6,', '')
            newmac = newmac.replace(' ', '').replace('01.', '').replace('02.', '').replace('03.', '').replace('04.', '').replace('05.', '').replace('06.', '')
            newmac = newmac.replace('07.', '').replace('08.', '').replace('09.', '').replace('10.', '').replace('11.', '').replace('12.', '')
            newmac = newmac.replace('13.', '').replace('14.', '').replace('15.', '').replace('16.', '').replace('17.', '').replace('18.', '')
            newmac = newmac.replace('19.', '').replace('20.', '').replace('21.', '').replace('22.', '').replace('23.', '').replace('24.', '')
            newmac = newmac.replace('25.', '').replace('26.', '').replace('27.', '').replace('28.', '').replace('29.', '').replace('30.', '')
            newmac = newmac.replace('31.', '').replace('2024', '').replace('2025', '')
            newmac = newmac.replace('January', '').replace('February', '').replace('March', '').replace('April', '').replace('May', '').replace('June', '')
            newmac = newmac.replace('July', '').replace('August', '').replace('September', '').replace('October', '').replace('November', '').replace('December', '')

            with open(settings_path, 'r') as f: settings_xml = f.read()
            settings_xml = re.sub('<setting id="server">.*?</setting>', '<setting id="server">{}</setting>'.format(newpor), settings_xml)
            settings_xml = re.sub('<setting id="server" default="true">.*?</setting>', '<setting id="server" default="true">{}</setting>'.format(newpor), settings_xml)
            settings_xml = re.sub('<setting id="server_0">.*?</setting>', '<setting id="server_0">{}</setting>'.format(newpor), settings_xml)
            settings_xml = re.sub('<setting id="mac">.*?</setting>', '<setting id="mac">{}</setting>'.format(newmac), settings_xml)
            settings_xml = re.sub('<setting id="mac" default="true">.*?</setting>', '<setting id="mac" default="true">{}</setting>'.format(newmac), settings_xml)
            settings_xml = re.sub('<setting id="mac_0">.*?</setting>', '<setting id="mac_0">{}</setting>'.format(newmac), settings_xml)
            with open(settings_path, 'w') as f: f.write(settings_xml)
        else:
            with open(settings_path, 'r') as f: settings_xml = f.read()
            settings_xml = re.sub('<setting id="mac">.*?</setting>', '<setting id="mac">{}</setting>'.format(newmac), settings_xml)
            settings_xml = re.sub('<setting id="mac" default="true">.*?</setting>', '<setting id="mac" default="true">{}</setting>'.format(newmac), settings_xml)
            settings_xml = re.sub('<setting id="mac_0">.*?</setting>', '<setting id="mac_0">{}</setting>'.format(newmac), settings_xml)
            with open(settings_path, 'w') as f: f.write(settings_xml)


    def clear_pvr_data():
        db_files = glob.glob(xbmcvfs.translatePath('special://database/TV*.db'))  # clear_pvr_data
        db_file_names = [f for f in db_files if ('TV' in f or 'MyPVR' in f)]

        for db_file in db_file_names:
            conn = sqlite3.connect(db_file)
            cursor = conn.cursor()

            cursor.execute("DELETE FROM channels")
            cursor.execute("DELETE FROM timers")
            cursor.execute("DELETE FROM clients")
            cursor.execute("DELETE FROM channelgroups")
            cursor.execute("DELETE FROM map_channelgroups_channels")

            conn.commit()
            conn.close()

            xbmcgui.Dialog().notification('[B][COLOR lime]Pvr Stalker[/COLOR][/B]',
                                          '[B][COLOR orange]Αναμονή καθαρισμού λίστας ...[/COLOR][/B]' , icon)

Pvr.iptv()

disable_addon(addon_id)
enable_addon(addon_id)
