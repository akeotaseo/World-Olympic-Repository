﻿import os, xbmc, xbmcvfs, xbmcgui, xbmcaddon, shutil, glob

def DeleteIntro():
        choice = xbmcgui.Dialog().yesno('[COLOR orange]Διαγραφή Intro[/COLOR]', 'Επιθυμείτε την διαγραφή του Intro?[CR]',
                                        nolabel='[B][COLOR white]Όχι τώρα...[/COLOR][/B]',yeslabel='[B][COLOR red]Διαγραφή[/COLOR][/B]')

        if choice == 1: [xbmcvfs.delete('special://home/media/KODI-Intro-Video.mp4'),
                         xbmc.sleep(2000),
                         xbmc.executebuiltin('Skin.ToggleSetting(HideKodiIntro)'),
                         xbmc.sleep(2000),
                         xbmcgui.Dialog().notification("[B][COLOR orange]Διαγραφή Intro[/COLOR][/B]", "[COLOR white]Ok![/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/clean.png'),
                         xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/UpdaterMatrix_7.py")')]
        if choice == 0: xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/Tools/SkinTools.py")')
DeleteIntro()
