import os, xbmc, xbmcvfs, xbmcgui


def streamarmy():
        choice = xbmcgui.Dialog().yesno('[COLOR orange]Fix NemesisAio[/COLOR]', 'Επιλέξτε [COLOR green]Remove Data[/COLOR][CR]Στην συνέχεια ανοίξτε τo πρόσθετo [COLOR orange]NemesisAio[/COLOR][CR]απο το SubMenu στις κατηγορίες[CR]MOVIES & TV (StreamArmy) - SPORTS (Live Now)',
                                        nolabel='[B][COLOR white]Όχι τώρα...[/COLOR][/B]',yeslabel='[B][COLOR green]Remove Data[/COLOR][/B]')

        # if choice == 1: xbmcvfs.delete('special://home/userdata/addon_data/plugin.program.downloader/settings.xml'),xbmc.sleep(1000),xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/UpdaterMatrix_12.py")'),


        if choice == 1: xbmcvfs.delete('special://home/userdata/addon_data/plugin.program.downloader/settings.xml'),xbmc.sleep(1000),xbmc.executebuiltin('Addon.Opensettings(plugin.program.downloader)'),xbmc.sleep(1000),xbmc.executebuiltin('SendClick(28)'),



streamarmy()
