import os, xbmc, xbmcvfs, xbmcgui, shutil, glob

base_path = xbmcvfs.translatePath('special://home/addons')

dir_list = glob.iglob(os.path.join(base_path, "plugin.program.downloader19"))
for path in dir_list:
    if os.path.isdir(path):
        shutil.rmtree(path)

base_path = xbmcvfs.translatePath('special://home/userdata/addon_data')

dir_list = glob.iglob(os.path.join(base_path, "plugin.program.downloader19"))
for path in dir_list:
    if os.path.isdir(path):
        shutil.rmtree(path)

#base_path = xbmcvfs.translatePath('special://home/addons')

#dir_list = glob.iglob(os.path.join(base_path, "script.tvaddons.debug.log"))
#for path in dir_list:
   # if os.path.isdir(path):
    #    shutil.rmtree(path)

dialog = xbmcgui.Dialog()
dialog.ok("[COLOR orange]World build[/COLOR]", "[COLOR white]Delete[/COLOR]")
xbmcgui.Dialog().notification("[B][COLOR orange]Διαγραφή με επιτυχία ![/COLOR][/B]", "[COLOR white]Αναμονή για Reload Profile...[/COLOR]", icon='special://home/addons/plugin.program.downloader/icon_autoexec.gif'),
xbmc.executebuiltin('RunPlugin(plugin://plugin.program.G.K.N.Wizard/?mode=forceprofile)')
xbmc.sleep(2000),
xbmcgui.Dialog().notification("[B][COLOR orange]Reload Profile[/COLOR][/B]", "[COLOR white]Παρακαλώ περιμένετε...[/COLOR]", icon='special://home/addons/plugin.program.downloader/icon_autoexec.gif')