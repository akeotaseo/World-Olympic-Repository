import xbmc, xbmcgui


def SkinTools():
    funcs = (click1, click2, click3, click4, click5, click6, click7)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]~ Skin tools ~[/COLOR][/B]', 
['Home Widget [COLOR=red]OFF[/COLOR] / [COLOR=green]ON[/COLOR]',
 'Single Global Background',

  '[COLOR red] Skin[/COLOR] Tools',
 'Txt / Graph [COLOR red] Skin[/COLOR]',
 'Intro [COLOR=green]Enable[/COLOR] / [COLOR=red]Disable[/COLOR]',
 '   ',


 '[B]                                                                                             [COLOR grey]Back[/COLOR][/B]'
 ])


    if call:
        if call < 0:
            return
        func = funcs[call-7]
        return func()
    else:
        func = funcs[call]
        return func()
    return 


def click1():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/skin/HomeWidgetONOFF.py")')

def click2():
    #xbmc.executebuiltin('Skin.ToggleSetting(SingleGlobalBackground)')
    #xbmc.sleep(1000)
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/skin/SkinBackground.py")')

def click3():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/skin/SkinMenuTools.py")')

def click4():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/skin/DialogTextGraph.py")')

def click5():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/skin/Introonoff.py")')

def click6():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/Tools/SkinTools.py")')

def click7():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/Tools/Programs.py")')



    #xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/Tools/downloaderstartupOnOff/DialogEnableDisabledownloaderstartup.py")')




SkinTools()
