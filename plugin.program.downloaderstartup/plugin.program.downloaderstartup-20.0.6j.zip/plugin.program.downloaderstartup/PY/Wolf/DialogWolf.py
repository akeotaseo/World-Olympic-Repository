﻿import os, xbmc, xbmcvfs, xbmcgui, xbmcaddon, shutil, glob

def DialogWolf():
        choice = xbmcgui.Dialog().yesno('[B][COLOR orange]Wolf[/COLOR][/B]', 'Η τελευταία ενημερώση των πρόσθετων[CR][B][COLOR white]No Lives Matter, Wolf Pack, Big Bad Wolf[/COLOR][/B][CR](και άλλων)[CR]απο τα αποθετήρια[CR][B]Wherethemonsterslive, EnCryptic & madhouse Repository[/B],[CR]δεν επιτρέπει την πλήρη χρήση τους, βγάζοντας σχετικό μήνυμα στην οθόνη,[CR]εφόσον έχετε εγκατεστημένο το πρόσθετο [B][COLOR purple]THE CREW[/COLOR][/B][CR][CR](Η επιλογή δική σας...)[CR][CR]Για να συνεχίσετε πατήστε [B][COLOR orange]Wolf[/COLOR][/B][CR]',
                                        nolabel='[B][COLOR white]Πίσω[/COLOR][/B]',yeslabel='[B][COLOR orange]Wolf[/COLOR][/B]')

        if choice == 1: [xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/Wolf/Wolf.py")'),]

DialogWolf()
