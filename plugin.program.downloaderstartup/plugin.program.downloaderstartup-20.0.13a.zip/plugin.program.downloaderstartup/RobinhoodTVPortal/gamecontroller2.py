import urllib.request
import xbmcgui
import xbmcaddon
import random
import re
import os
import sys
import xbmcvfs

addon_id = 'plugin.video.worldclient'

if os.name == 'r':  
    portable_data_path = os.path.join(os.getcwd(), 'portable_data')
    if os.path.isdir(portable_data_path):
        settings_path = os.path.join(portable_data_path, 'userdata', 'addon_data', addon_id, 'settings.xml')
    else:
        settings_path = os.path.join(os.getenv('APPDATA'), 'Kodi', 'userdata', 'addon_data', addon_id, 'settings.xml')
else:
    settings_path = os.path.join(xbmcvfs.translatePath('special://profile/addon_data'), addon_id, 'settings.xml')

def check_playlist(url):
    try:
        response = urllib.request.urlopen(url)
        return True
    except urllib.error.URLError:
        return False

group_urls = {
    'Group 1 - Various lists ': 'https://kodibalkan.com/WorldTv/grupa1.txt',
    'Grupa 2 - Protected lists': 'https://kodibalkan.com/WorldTv/grupa2.txt',
    'Group 3 - Balkan SAT': 'https://kodibalkan.com/WorldTv/grupa3.txt',
    'Group 4 - M3U File list (VOD)': 'https://kodibalkan.com/WorldTv/grupa4.txt',
    'Group 5 - 71iptvtree. net  X.T.R.E.A.M ': 'https://raw.githubusercontent.com/akeotaseo/world_repo/main/Updater_Matrix/XML/71iptvtree.%20net%20.txt',
    'Group 6 - M3U File list (Telegram)': 'https://raw.githubusercontent.com/akeotaseo/world_repo/main/Updater_Matrix/XML/%5BK_B_W_%20Client%5D.txt',
}

group_names = list(group_urls.keys())
selected_group_index = xbmcgui.Dialog().select('Select the group', group_names)

if selected_group_index == -1:
    sys.exit()

selected_group_name = group_names[selected_group_index]
selected_group_url = group_urls[selected_group_name]

response = urllib.request.urlopen(selected_group_url)
playlist_data = response.read().decode('utf-8')
playlist_urls = re.findall(r'http\S+', playlist_data)

playlist_names = [f'List {i+1}' for i in range(len(playlist_urls))]

working_playlists = []
failed_playlists = []

dialog = xbmcgui.DialogProgress()
dialog.create('List check', 'Checks the list correctness...')
for i, playlist_url in enumerate(playlist_urls):
    dialog.update(int((i / len(playlist_urls)) * 100), 'The list is checked {}'.format(i + 1))
    if check_playlist(playlist_url):
        working_playlists.append(playlist_url)
    else:
        failed_playlists.append(playlist_url)
dialog.close()

for playlist_url in failed_playlists:
    index = playlist_urls.index(playlist_url)
    playlist_names[index] += ' - Does not work'

while True:
    selected_playlist_index = xbmcgui.Dialog().select(f'Select a list from {selected_group_name}', playlist_names)

    if selected_playlist_index == -1:
        sys.exit()

    selected_playlist_url = playlist_urls[selected_playlist_index]

    with open(settings_path, 'r') as f:
        settings_xml = f.read()

    settings_xml = re.sub('<setting id="m3u_url">.*?</setting>', '<setting id="m3u_url">{}</setting>'.format(selected_playlist_url), settings_xml)

    with open(settings_path, 'w') as f:
        f.write(settings_xml)

    xbmc.sleep(1000)

    if check_playlist(selected_playlist_url):
        xbmcgui.Dialog().ok('Add selected list in World TV Client', 'The selected list has been added[CR]Come on [COLOR=blue]KodiBalkan World Client[/COLOR]')
        xbmc.sleep(1000)
        xbmc.executebuiltin('RunScript("special://home/addons//plugin.program.downloaderstartup/RobinhoodTVPortal/KodiBalkanWorld.py")')
        sys.exit()
    else:
        if not xbmcgui.Dialog().yesno('Add selected list in World TV Client', 'The selected list does not work[CR]Would you like to choose another list?'):
            sys.exit()
        else:
            playlist_names[selected_playlist_index] = f'List {selected_playlist_index+1} - Does not wor'
