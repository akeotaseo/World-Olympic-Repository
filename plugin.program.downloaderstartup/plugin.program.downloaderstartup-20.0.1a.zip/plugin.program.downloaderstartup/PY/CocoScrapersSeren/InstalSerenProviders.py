import os, xbmc, xbmcgui

def DialogSerenProviders():


    xbmc.executebuiltin('ActivateWindow(10001,"plugin://plugin.program.downloader/seren_package_install",return)')

DialogSerenProviders()                        