import xbmc, xbmcgui


def AddonsBrowser():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6)
    call = xbmcgui.Dialog().select('[B]AddonsBrowser[/B]', 
['[B] ---Περιηγητής Προσθέτων--- [/B]',

 ' Video Add-ons',
 'Programs',
 'Music',
 'Pictures',
 '*Διαχείριση εξαρτήσεων*'
 ])
 



    if call:
        if call < 0:
            return
        func = funcs[call-6]
        return func()
    else:
        func = funcs[call]
        return func()
    return 




#def click_1():
#    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.apex_sports/?category=live_sport&amp;mode=search)')
#    xbmcgui.Dialog().notification("[B][COLOR orange]TechNEWSology[/COLOR][/B]",'[COLOR white]Για την αναζήτηση αγώνων, πληκτρολογήστε την Ομάδα ή την Χώρα με λατινικούς χαρακτήρες ...[/COLOR]' , icon ='special://home/addons/skin.TechNEWSology/icon.png')

def click_1():
    xbmc.executebuiltin('ActivateWindow(AddonBrowser,return)')

def click_2():
    xbmc.executebuiltin('ActivateWindow(Videos,Addons)')

def click_3():
    xbmc.executebuiltin('ActivateWindow(Programs,Addons)')

def click_4():
    xbmc.executebuiltin('ActivateWindow(Music,Addons)')

def click_5():
    xbmc.executebuiltin('ActivateWindow(pictures,Addons)')

def click_6():
    xbmc.executebuiltin('ActivateWindow(10040,"addons://dependencies/")')

def click_7():
    xbmc.executebuiltin('ActivateWindow(10040,"addons://recently_updated/",return)')

def click_8():
    xbmc.executebuiltin('ActivateWindow(10040,"addons://outdated/",return)')


AddonsBrowser()
