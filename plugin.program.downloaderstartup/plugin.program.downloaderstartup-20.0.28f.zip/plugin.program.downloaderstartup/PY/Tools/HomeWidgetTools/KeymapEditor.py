﻿import xbmc, xbmcgui
xbmcgui.Dialog().notification("[COLOR orange]Keymap Editor[/COLOR]", "   ", sound=False, icon='special://home/addons/script.keymapedit/icon.png')

# xbmc.executebuiltin('ActivateWindow(10000)')
# xbmc.sleep(4000)
xbmc.executebuiltin('ActivateWindow(10001,"plugin://script.keymap",return)')




