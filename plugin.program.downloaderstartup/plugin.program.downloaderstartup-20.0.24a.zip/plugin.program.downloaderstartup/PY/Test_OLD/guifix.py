import xbmc, xbmcgui


def guifix():
    funcs = (click_1click_2)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]Gui fix[/COLOR][/B]', 
['[COLOR=white]Gui fix [COLOR=blue](Omega[/COLOR]'])



    if call:
        if call < 0:
            return
        func = funcs[call-2]
        return func()
    else:
        func = funcs[call]
        return func()
    return 0






def click_1():
    xbmc.executebuiltin('PlayMedia("plugin://plugin.program.G.K.N.Wizard/?mode=install&name=World+-Omega-&url=gui")')

def click_2():
    xbmc.executebuiltin('PlayMedia("plugin://plugin.program.G.K.N.Wizard/?mode=install&name=World+-Omega-&url=gui")')
guifix()
