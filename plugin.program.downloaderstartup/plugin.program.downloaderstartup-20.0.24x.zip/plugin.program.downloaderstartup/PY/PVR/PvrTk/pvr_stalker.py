import xbmc

def pvr_stalker():
    if xbmc.getCondVisibility('System.HasAddon({})'.format('pvr.stalker')):
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.stalker","enabled":true}}')
        xbmc.sleep(1000)
        xbmc.executebuiltin('SendClick(11)')
        xbmc.sleep(100)
        xbmc.executebuiltin('ActivateWindow(TVChannels)')
pvr_stalker()
