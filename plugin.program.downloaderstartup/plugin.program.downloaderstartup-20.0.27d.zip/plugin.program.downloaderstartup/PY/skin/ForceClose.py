import os, xbmc, xbmcgui
def ForceClose():
    if xbmc.getCondVisibility('System.HasAddon(service.coreelec.settings)') or xbmc.getCondVisibility('System.HasAddon(service.libreelec.settings)'): CoreLibre()
    # if not xbmc.getCondVisibility('System.Platform.Windows') or xbmc.getCondVisibility('System.Platform.Android'): killkodi()
    else: killkodi()



def killkodi():
        choice = xbmcgui.Dialog().yesno('[B][COLOR orange]World Build[/COLOR][/B]', '[COLOR white]Το Kodi θα κλείσει...[CR]Θέλετε να συνεχίσετε;[/COLOR]',
                                        nolabel='[COLOR white]Όχι[/COLOR]',yeslabel='[COLOR white]Ναι[/COLOR]')
        if choice == 1: [
                         xbmcgui.Dialog().notification("[B][COLOR orange]Bye bye![/COLOR][/B]", "[COLOR green]Να είστε καλά![/COLOR]", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/Bye.png'),
                         xbmc.sleep(2000),
                         os._exit(1),]
        if choice == 0: [xbmcgui.Dialog().notification("[B][COLOR orange]Ακόμα εδω;[/COLOR][/B]", "Να φύγετε![CR]Να πάτε αλλού!", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/angry.png'),]


def CoreLibre():
        choice = xbmcgui.Dialog().yesno('[B][COLOR orange]World Build[/COLOR][/B]', '[COLOR white]Επανεκκίνηση Συστήματος...[CR]Θέλετε να συνεχίσετε;[/COLOR]',
                                        nolabel='[COLOR white]Όχι[/COLOR]',yeslabel='[COLOR white]Ναι[/COLOR]')
        if choice == 1: [
                         xbmcgui.Dialog().notification("[B][COLOR orange]Επανεκκίνηση[/COLOR][/B]", "   ", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/restart.png'),
                         xbmc.sleep(2000),
                         os._exit(1),]
        if choice == 0: [xbmcgui.Dialog().notification("[B][COLOR orange]Ακόμα εδω;[/COLOR][/B]", "Να φύγετε![CR]Να πάτε αλλού!", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/angry.png'),]


ForceClose()