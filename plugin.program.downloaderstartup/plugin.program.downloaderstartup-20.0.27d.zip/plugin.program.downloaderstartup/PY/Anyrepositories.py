﻿import xbmc

def Anyrepositories():
    # xbmc.executebuiltin("Action(Close)")
    xbmc.executebuiltin("ActivateWindowAndFocus(SystemSettings, -195, )")
    xbmc.sleep(500)
    xbmc.executebuiltin('SendClick(-173)')
    xbmc.sleep(500)
    xbmc.executebuiltin('SendClick(-145)')
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"addons.updatemode","value":1}}')
    xbmc.sleep(500)
    xbmc.executebuiltin("Action(Close)")
    xbmc.executebuiltin('Action(Back)')
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10000)')
    

    # while xbmc.getCondVisibility("Window.IsVisible(ServiceSettings)") or xbmc.getCondVisibility("Window.IsVisible(dialog)"):
        # xbmc.sleep(100)
    # xbmc.executebuiltin("Action(Play)")

Anyrepositories()

