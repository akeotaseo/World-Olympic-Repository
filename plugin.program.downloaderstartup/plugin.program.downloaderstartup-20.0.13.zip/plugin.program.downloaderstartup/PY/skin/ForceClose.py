import os, xbmc, xbmcgui
def killkodi():
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"general.addonupdates","value":1}}')
        xbmc.sleep(200)
        choice = xbmcgui.Dialog().yesno('[B][COLOR orange]World Build[/COLOR][/B]', '[COLOR white]Το Kodi θα κλείσει...[CR]Θέλετε να συνεχίσετε?[/COLOR]',
                                        nolabel='[COLOR white]Όχι[/COLOR]',yeslabel='[COLOR white]Ναι[/COLOR]')
        if choice == 1: [
                         xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.stalker","enabled":false}}'),
                         xbmc.sleep(200),
                         xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.iptvsimple","enabled":false}}'),
                         xbmc.sleep(200),
                         
                         xbmcgui.Dialog().notification("[B][COLOR orange]Bye bye![/COLOR][/B]", "[COLOR green]Να είστε καλά![/COLOR]", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/Bye.png'),
                         xbmc.sleep(2000),
                         os._exit(1),]
        if choice == 0: [xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"general.addonupdates","value":0}}'),]

killkodi()