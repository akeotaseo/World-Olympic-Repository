import xbmc, xbmcgui


def SkinMenuLAF():
    funcs = (click_1, click_2, click_3, click_4)
    call = xbmcgui.Dialog().select('[B]SkinMenuLAF[/B]', 
['[COLOR red] Skin [/COLOR] Text',
 '[COLOR red] Skin [/COLOR] Graph',
 '[COLOR red] Skin [/COLOR] GraphFocused',
  '[B][COLOR red]<---                                                                      [COLOR grey]Back[/COLOR][/B]'
 ])
 



    if call:
        if call < 0:
            return
        func = funcs[call-4]
        return func()
    else:
        func = funcs[call]
        return func()
    return 




#def click_1():
#    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.apex_sports/?category=live_sport&amp;mode=search)')
#    xbmcgui.Dialog().notification("[B][COLOR orange]TechNEWSology[/COLOR][/B]",'[COLOR white]Για την αναζήτηση αγώνων, πληκτρολογήστε την Ομάδα ή την Χώρα με λατινικούς χαρακτήρες ...[/COLOR]' , icon ='special://home/addons/skin.TechNEWSology/icon.png')

def click_1():
    xbmc.executebuiltin('Skin.Reset(MenuLAF)')
    xbmc.executebuiltin("ReloadSkin()")

def click_2():
    xbmc.executebuiltin('Skin.SetString(MenuLAF,Graph)')
    xbmc.executebuiltin("ReloadSkin()")

def click_3():
    xbmc.executebuiltin('Skin.SetString(MenuLAF,GraphFocused)')
    xbmc.executebuiltin("ReloadSkin()")

def click_4():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/Tools/SkinTools.py")')


SkinMenuLAF()
