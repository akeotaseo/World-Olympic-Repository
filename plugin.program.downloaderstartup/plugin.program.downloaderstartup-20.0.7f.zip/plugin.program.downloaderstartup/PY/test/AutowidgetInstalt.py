﻿import os, glob, xbmc, xbmcgui, xbmcvfs, xbmcaddon, shutil
from updatervar import *
from resources.lib.modules.delete_addons import del_dir
from resources.lib.GUIcontrol import txt_updater
from resources.lib.modules import db, addonsEnable
from resources.lib.modules.addonsEnable import enable_addons
from resources.lib.modules.installer_addons import installAddon
from resources.lib.GUIcontrol.txt_updater import get_skinshortcutsversion

def installautowidget(): 
         xbmc.executebuiltin('InstallAddon(plugin.video.subsmovies)')
         xbmc.sleep(1000)
         xbmc.executebuiltin('SendClick(11)')
         addon_path = xbmc.translatePath('special://home/addons')
         dir_list = glob.iglob(os.path.join(addon_path, "plugin.video.subsmovies"))
         for path in dir_list:
             if os.path.exists(addon_path): xbmcgui.Dialog().notification("[B][COLOR orange]AutoWidget[/COLOR][/B]", "[COLOR white]Είναι ήδη εγκατεστημένο![/COLOR]"),
installautowidget()
