﻿import xbmc



xbmc.executebuiltin("ActivateWindow(Home,Item,15,Master)")

