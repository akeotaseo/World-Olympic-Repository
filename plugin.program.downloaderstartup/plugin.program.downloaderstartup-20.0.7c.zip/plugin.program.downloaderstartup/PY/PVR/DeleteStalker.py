﻿import os, xbmc, xbmcvfs, xbmcgui, shutil, glob

#base_path = xbmcvfs.translatePath('special://addons')

#dir_list = glob.iglob(os.path.join(base_path, "plugin.video.stalker"))
#for path in dir_list:
    #if os.path.isdir(path):
        #shutil.rmtree(path)



base_path = xbmcvfs.translatePath('special://home/userdata/addon_data')

dir_list = glob.iglob(os.path.join(base_path, "plugin.video.stalker"))
for path in dir_list:
    if os.path.isdir(path):
        shutil.rmtree(path)