﻿import os, xbmc, xbmcvfs, xbmcgui, xbmcaddon, shutil, glob

def DialogSelectForceClose():
        choice = xbmcgui.Dialog().yesno('[CR]', 'Για να  αποθηκευτούν οι αλλαγές [B]πρέπει να [COLOR red]κλείσετε[/COLOR] το kodi...[/B]',
                                        nolabel='[B][COLOR white]Οχι τώρα...[/COLOR][/B]',yeslabel='[B][COLOR red]Κλείσε[/COLOR][/B]')

        if choice == 1: [xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/skin/ForceClose.py")'),
                         ]

DialogSelectForceClose()
