import os, sys, xbmc, xbmcgui, xbmcvfs, xbmcaddon

xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "pvr.stalker","enabled":true}}')

icon ='special://home/addons/pvr.stalker/icon.png'
addon_pvr       = xbmcaddon.Addon('pvr.stalker')
setting_pvr     = addon_pvr.getSetting
setting_set_pvr = addon_pvr.setSetting

if   setting_pvr('active_portal') == '0': port = '1'
elif setting_pvr('active_portal') == '1': port = '2'
elif setting_pvr('active_portal') == '2': port = '3'
elif setting_pvr('active_portal') == '3': port = '4'
elif setting_pvr('active_portal') == '4': port = '5'


def pvr():
    funcs = (click_1, click_2, click_3)
    call = xbmcgui.Dialog().select(('[COLOR=lime] Αυτ/μένη αντικατάσταση πύλης [COLOR=orange][ [COLOR=lime]%s [COLOR=orange]][/COLOR]' % port),
['[B][COLOR=lime][COLOR=deepskyblue]ZTEU [COLOR=lime]Generator [[COLOR=white]Πύλες 1-5[COLOR=lime]][/COLOR][/B]',
 '[B][COLOR=lime][COLOR=deepskyblue]Mac [COLOR=lime]List Generator [[COLOR=white]Πύλη 1[COLOR=lime]][/COLOR][/B]',
 '[B][COLOR=lime][COLOR=deepskyblue]XC Mac M3U[COLOR=lime] List[/COLOR][/B]'])


    if call:
        if call < 0:
            return
        func = funcs[call-3]
        return func()
    else:
        func = funcs[call]
        return func()
    return 


def click_1():
    xbmcgui.Dialog().notification("[B][COLOR lime]Pvr Stalker[/COLOR][/B] - [B][COLOR orange]Πύλη [COLOR lime]1[/COLOR][/B]",'[B][COLOR white]Αν η λίστα είναι κενή, ξαναπατάμε [COLOR=orange]ZTEU Generator![/COLOR][/B]' , icon)
    xbmc.executebuiltin('RunScript("special://skin/16x9/Pvr/gen_pvr.py")')

def click_2():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/PVR/mac_list_0.py")')

def click_3():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.macvod/?action=tulista&title=&url=&thumbnail=&plot=&extra=&page=)')


pvr()
