import os, xbmc, xbmcgui

def install_stalker():
        choice = xbmcgui.Dialog().yesno('[COLOR orange]PVR Stalker[/COLOR]', '[COLOR white]Μετά την εγκατάσταση του πρόσθετου ανοίξτε ξανά το PVR Stalker. Χρησιμοποιήστε την [COLOR lime]Αυτοματοποιημένη αντικατάσταση πύλης[/COLOR] ή περάστε δικές πύλες με την βοήθεια των Ιστότοπων Stalker Portal.[/COLOR]',
                                        nolabel='[B][COLOR orange]Άκυρο[/COLOR][/B]',yeslabel='[B][COLOR lime]Ok[/COLOR][/B]')

        if choice == 1: (xbmc.executebuiltin('InstallAddon(pvr.stalker)'))
                         # xbmc.sleep(1000),
                         # xbmc.executebuiltin('SendClick(11)'))
install_stalker()
