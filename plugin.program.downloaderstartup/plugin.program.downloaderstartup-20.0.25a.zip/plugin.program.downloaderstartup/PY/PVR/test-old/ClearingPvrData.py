import xbmc,xbmcgui

def ClearingPvrData():
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "pvr.stalker","enabled":false}}')
    xbmc.sleep(5000)
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "pvr.stalker","enabled":true}}')
    # xbmc.executebuiltin("ActivateWindowAndFocus(pvrsettings, 100,0 , -69,0)")
    # xbmc.executebuiltin('SendClick(-69)')
    # xbmc.executebuiltin('SendClick(11)')
    # xbmc.executebuiltin("ActivateWindow(10700)")
    xbmcgui.Dialog().notification("[B][COLOR orange]Stalker[/COLOR][/B]", "[COLOR white]Περιμένουμε να ολοκληρωθεί η εισαγωγή οδηγού από πελάτες της διαχείρισης PVR. Μην ξεχάσετε να κάνετε αλλαγή Γκρουπ στην χώρα ή στην κατηγορία που επιθυμείτε.[/COLOR]", icon='special://home/addons/skin.19MatrixWorld/media/pvr.png')

ClearingPvrData()

