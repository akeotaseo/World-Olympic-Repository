import xbmcgui
xbmcgui.Dialog().notification("[B][COLOR orange]Χρήσιμες Πληροφορίες![/COLOR][/B]", "   ", sound=False, icon='special://home/addons/plugin.program.downloader19/resources/media/information.png')

import os, xbmc, xbmcvfs
# xbmc.executebuiltin('PlayMedia("special://home/media/Join_file.mp4")')
# xbmc.sleep(20000)

def Changelog():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]Χρήσιμες Πληροφορίες[/COLOR][/B]',
['[COLOR=lime][B]Απαραίτητα βήματα για την εύρυθμη λειτουργία του Kodi[/B][/COLOR]',

 '[COLOR=orange]_____[/COLOR]',
 '[COLOR=red]Προβολή Σφαλμάτων[/COLOR]',
 '[COLOR=orange]_____[/COLOR]',
 '[COLOR orange]Ενημέρωση build & Διατήρηση στοιχείων...[/COLOR]',
 '[B][COLOR blue]Μήνυμα καταγραφής ενημερώσεων του build[/COLOR][/B]'])


    if call:
        if call < 1:
            return
        func = funcs[call-6]
        return func()
    else:
        func = funcs[call]
        return func()
    return 




def click_1():
    change()
    xbmcgui.Dialog().notification("[B][COLOR orange]Χρήσιμες Πληροφορίες![/COLOR][/B]", "   ", sound=False, icon='special://home/addons/plugin.program.downloader19/resources/media/information.png')
    How_To()

    # xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/Changelog/Changelog.py")')

def click_2():
    change2()
    xbmcgui.Dialog().notification("[B][COLOR orange]Χρήσιμες Πληροφορίες![/COLOR][/B]", "   ", sound=False, icon='special://home/addons/plugin.program.downloader19/resources/media/information.png')

    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/Changelog/Changelog.py")')


def click_3():
    # change3()
    Error()
    # xbmcgui.Dialog().notification("[B][COLOR orange]Χρήσιμες Πληροφορίες![/COLOR][/B]", "   ", sound=False, icon='special://home/addons/plugin.program.downloader19/resources/media/information.png')

    # xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/Changelog/Changelog.py")')


def click_4():
    change4()
    xbmcgui.Dialog().notification("[B][COLOR orange]Χρήσιμες Πληροφορίες![/COLOR][/B]", "   ", sound=False, icon='special://home/addons/plugin.program.downloader19/resources/media/information.png')


    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/Changelog/Changelog.py")')


def click_5():
    change5()
    xbmc.executebuiltin('ActivateWindow(10001,"plugin://plugin.program.G.K.N.Wizard/?mode=savedata")')
    
def click_6():
    xbmc.executebuiltin('Action(Back)')
    xbmc.executebuiltin('PlayMedia("plugin://plugin.program.downloader19/?url=&mode=100&name=%CE%9C%CE%AE%CE%BD%CF%85%CE%BC%CE%B1+%CE%BA%CE%B1%CF%84%CE%B1%CE%B3%CF%81%CE%B1%CF%86%CE%AE%CF%82+%CE%B5%CE%BD%CE%B7%CE%BC%CE%B5%CF%81%CF%8E%CF%83%CE%B5%CF%89%CE%BD&icon=special%3A%2F%2Fhome%2Faddons%2Fplugin.program.downloader19%2Fresources%2Fmedia%2Fm.png&fanart=C%3A%5CPortableApps%5Ckodi%5Ckodi+World+21%5CKodi%5Cportable_data%5Caddons%5Cplugin.program.downloader19%5Cfanart.jpg&description=Bring+up+the+notifications+dialog&name2=&version=")')




def textBox(heading, announce):
    class TextBox():

        def __init__(self, *args, **kwargs):
            self.WINDOW = 10147
            self.CONTROL_LABEL = 1
            self.CONTROL_TEXTBOX = 5
            xbmc.executebuiltin("ActivateWindow(%d)" % (self.WINDOW, ))
            self.win = xbmcgui.Window(self.WINDOW)
            xbmc.sleep(500)
            self.setControls()

        def setControls(self):
            self.win.getControl(self.CONTROL_LABEL).setLabel(heading)
            try:
                f = open(announce)
                text = f.read()
            except:
                text = announce
            self.win.getControl(self.CONTROL_TEXTBOX).setText(str(text))
            return

    TextBox()
    while xbmc.getCondVisibility('Window.IsVisible(10147)'):
        xbmc.sleep(500)

def change():
    changelog = xbmcvfs.translatePath(os.path.join('special://home/addons/plugin.program.downloaderstartup/PY/Changelog/changelog.txt'))
    heading = '[B][COLOR orange]*** 1 ***[/COLOR][/B]'
    f = open(changelog, 'r', encoding='utf-8')
    lines = f.readlines()
    announce = ''
    for line in lines:
        if not line.strip():
            break

        announce += line
    f.close()
    textBox(heading, announce)

def change2():
    changelog = xbmcvfs.translatePath(os.path.join('special://home/addons/plugin.program.downloaderstartup/PY/Changelog/changelog2.txt'))
    heading = '[B][COLOR orange]*** 2 ***[/COLOR][/B]'
    f = open(changelog, 'r', encoding='utf-8')
    lines = f.readlines()
    announce = ''
    for line in lines:
        if not line.strip():
            break

        announce += line
    f.close()
    textBox(heading, announce)

def change3():
    changelog = xbmcvfs.translatePath(os.path.join('special://home/addons/plugin.program.downloaderstartup/PY/Changelog/changelog3.txt'))
    heading = '[B][COLOR orange]*** 3 ***[/COLOR][/B]'
    f = open(changelog, 'r', encoding='utf-8')
    lines = f.readlines()
    announce = ''
    for line in lines:
        if not line.strip():
            break

        announce += line
    f.close()
    textBox(heading, announce)

def change4():
    changelog = xbmcvfs.translatePath(os.path.join('special://home/addons/plugin.program.downloaderstartup/PY/Changelog/changelog4.txt'))
    heading = '[B][COLOR orange]*** 4 ***[/COLOR][/B]'
    f = open(changelog, 'r', encoding='utf-8')
    lines = f.readlines()
    announce = ''
    for line in lines:
        if not line.strip():
            break

        announce += line
    f.close()
    textBox(heading, announce)

def change5():
    changelog = xbmcvfs.translatePath(os.path.join('special://home/addons/plugin.program.downloaderstartup/PY/Changelog/changelog5.txt'))
    heading = '[B][COLOR orange][COLOR dodgerblue]Save Data Menu[/COLOR][/COLOR][/B]'
    f = open(changelog, 'r', encoding='utf-8')
    lines = f.readlines()
    announce = ''
    for line in lines:
        if not line.strip():
            break

        announce += line
    f.close()
    textBox(heading, announce)


def Error():
    funcs = (click__1, click__2, click__3)
    call = xbmcgui.Dialog().select('[B][COLOR=red]Errors[/COLOR][/B]', 
['[B][COLOR blue]Προβολή τελευταίου σφάλματος στο Log[/COLOR][/B]',
 '[COLOR blue]Προβολή σφαλμάτων στο Log[/COLOR]',
 'View Log'
 ])



    if call:
        if call < 0:
            return
        func = funcs[call-3]
        return func()
    else:
        func = funcs[call]
        return func()
    return 0



def click__1():
    xbmc.executebuiltin('PlayMedia("plugin://plugin.program.G.K.N.Wizard/?mode=viewerrorlast")')
    

def click__2():
    xbmc.executebuiltin('PlayMedia("plugin://plugin.program.G.K.N.Wizard/?mode=viewerrorlog")')

def click__3():
    xbmc.executebuiltin('PlayMedia("plugin://plugin.program.downloader19/?url=&mode=32&name=View+Log&icon=special%3A%2F%2Fhome%2Faddons%2Fplugin.program.downloader19%2Fresources%2Fmedia%2FLog.png&fanart=C%3A%5CPortableApps%5Ckodi%5Ckodi+World+20%5CKodi%5Cportable_data%5Caddons%5Cplugin.program.downloader19%5Cfanart.jpg&description=&name2=&version=")')



def How_To():
    funcs = (click___1, click___2, click___3)
    call = xbmcgui.Dialog().select('[B][COLOR=lime]How To[/COLOR][/B]', 
['[B]Πως Αλλάζουμε DNS SERVERS IPV4 και IPV6 Σε Android Συσκευές και για MOBILE DATA[/B]',
 '[COLOR blue]Πως αλλάζουμε DNS[/COLOR]',
 'Advanced Settings'
 ])



    if call:
        if call < 0:
            return
        func = funcs[call-3]
        return func()
    else:
        func = funcs[call]
        return func()
    return 0



def click___1():
    xbmc.executebuiltin('PlayMedia("plugin://plugin.video.youtube/play/?video_id=zHyTn_EOVyw",playlist_type_hint=1)')
    

def click___2():
    xbmc.executebuiltin('PlayMedia("plugin://plugin.video.youtube/play/?video_id=qJz2vQ2XCRI",playlist_type_hint=1)')

def click___3():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/memory_size.py")')


Changelog()
