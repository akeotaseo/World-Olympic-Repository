﻿import xbmc, xbmcgui
xbmcgui.Dialog().notification("[COLOR orange]Ενεργοποίηση πρόσθετων[/COLOR]", "Ανακατεύθυνση...", sound=False, icon='special://home/addons/plugin.program.downloader19/resources/media/enable.png')

xbmc.executebuiltin('ActivateWindow(10000)')
xbmc.sleep(4000)
xbmc.executebuiltin('ActivateWindow(10001,"plugin://plugin.program.downloader19/?description&fanart=C%3a%5cPortableApps%5ckodi%5cKODI%20TEST%5cKodi%5cportable_data%5caddons%5cplugin.program.downloader19%5cfanart.jpg&icon=special%3a%2f%2fhome%2faddons%2fplugin.program.downloader19%2fresources%2fmedia%2fenable.png&mode=28&name=%ce%95%ce%bd%ce%b5%cf%81%ce%b3%ce%bf%cf%80%ce%bf%ce%af%ce%b7%cf%83%ce%b7%20%cf%80%cf%81%cf%8c%cf%83%ce%b8%ce%b5%cf%84%cf%89%ce%bd&name2&url&version",return)')




