import xbmc, xbmcgui


def F4mtesterMac():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7, click_8, click_9, click_10)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]~ F4mtester Mac ~[/COLOR][/B]', 
['[B]SERVIDOR 2 (ONEPLAY PROXY)[/B]',
 '[COLOR coral]IPTV Buster[/COLOR]',
 '[COLOR gold]FLIXTVON[/COLOR] F4mtester',
 '[COLOR gold]FlixTvON MAC[/COLOR]',
 '[COLOR orange]TRAIN MAC AGAIN[/COLOR]',
 '[COLORcyan]fenix[COLORgrey]Mac[/COLOR]',
 '[COLOR aquamarine]GIF PEG TV[/COLOR] F4mtester',
 '[COLOR chocolate]Glorioso Tv[/COLOR] TV AO VIVO',
 '[COLOR white]KODIvertiDO Tv[/COLOR]',
 '[COLOR grey]IPTV Stalker[/COLOR]'
 ])
 #'[B][COLOR orange]TakeOne.TV[/COLOR][/B] F4mtester',
 #'[COLOR white]IPTV Europa[/COLOR] F4mtester',
 #'[B][COLOR white]NEO tv[/COLOR][/B] F4mtester   [COLOR red]OFF...[/COLOR]',



    if call:
        if call < 0:
            return
        func = funcs[call-10]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.OnePlay.Matrix/tv_servidor2/name%3D%255BB%255DSERVIDOR%2B2%2B%2528ONEPLAY%2BPROXY%2529%255B%252FB%255D%26iconimage%3DC%253A%255CPortableApps%255Ckodi%255Ckodi%2BWorld%2B20%255CKodi%255Cportable_data%255Caddons%255Cplugin.video.OnePlay.Matrix%255Cresources%255Cimages%255Ctv.png%26description%3D")')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.iptvbuster/")')

def click_3():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.flixon/")')

def click_4():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.flix-mac/")')

def click_5():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.train.mac.again/")')

def click_6():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.fenix-mac/")')

def click_7():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.Gif.Peg.Tv/?fanart=https%3a%2f%2fi.imgur.com%2fWLIuKre.jpg&mode=1&name=%5bB%5d%5bCOLOR%20lightgrey%5dTV%5b%2fCOLOR%5d%5b%2fB%5d&url=https%3a%2f%2fbit.ly%2f3uIBNWT")')

def click_8():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.gloriosotv/?fanart=https%3a%2f%2fi.imgur.com%2fKTlJI9t.jpg&mode=1&name=%5bB%5d%5bCOLOR%20lime%5d%2a%5b%2fCOLOR%5d%20%5bCOLOR%20white%5dTV%20AO%20VIVO%5b%2fCOLOR%5d%5b%2fB%5d&url=https%3a%2f%2fgitlab.com%2fTUXIPTV%2fMenu%2f-%2fraw%2fmaster%2fMenu_Tv")')

def click_9():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.KODIvertiDO/?action=iptv_v&extra=0&page&plot&thumbnail=https%3a%2f%2fi.postimg.cc%2fm2tT1bYP%2fIMG-20230706-WA0006.jpg&title=%5bCOLOR%20white%5d%5bB%5dKODIvertiDO%20Tv%5b%2fB%5d%5b%2fCOLOR%5d&url")')

def click_10():
    xbmc.executebuiltin('RunScript("special://home/addons/service.World.Build/PY/AddonsDelete/DeleteStalker.py")')
    xbmc.sleep(1000)
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.stalker/",return)')


F4mtesterMac()
