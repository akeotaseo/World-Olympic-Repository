import xbmc, xbmcgui


def Introonoff():
    funcs = (click_1, click_2, click_3)
    call = xbmcgui.Dialog().select('[B][COLOR=green]Enable[/COLOR][/B]/[B][COLOR=red]Disable[/COLOR]Intro[/B]', 
['[COLOR=green]Download Intro...[/COLOR] (18MB)',

 '[COLOR=red]Delete Intro...[/COLOR]',
 '[B]                                                                                             [COLOR grey]Back[/COLOR][/B]'
 ])
 



    if call:
        if call < 0:
            return
        func = funcs[call-3]
        return func()
    else:
        func = funcs[call]
        return func()
    return 




def click_1():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/UpdaterMatrix_4.py")')

def click_2():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/AddonsDelete/DeleteIntro.py")')

def click_3():

    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/Tools/SkinTools.py")')
Introonoff()
