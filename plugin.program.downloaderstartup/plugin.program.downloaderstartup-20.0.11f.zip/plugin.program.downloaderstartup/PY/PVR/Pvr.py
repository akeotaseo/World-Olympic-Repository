import xbmc, xbmcgui


def pvr():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7, click_8)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]~ PVR~[/COLOR][/B]', 
['[COLOR=white][COLOR grey]Ιστότοποι[/COLOR][/COLOR]',

 '[COLOR=white][COLOR blue]Προσθήκη/Αλλαγή πύλης[/COLOR] [/COLOR]',

 '[COLOR=white][COLOR cornflowerblue]Τυχαία αλλαγή πύλης 1[/COLOR]   [COLOR cornflowerblue]kgen[/COLOR]',
 '[COLOR=white][COLOR cornflowerblue]Τυχαία αλλαγή πύλης 1[/COLOR]   [COLOR limegreen]kgen1[/COLOR]',
 '[COLOR=white][COLOR cornflowerblue]Τυχαία αλλαγή πύλης 1[/COLOR]   [COLOR mediumorchid]kgen2[/COLOR]',
   
 '[COLOR=white][COLOR lightskyblue]Τυχαία αλλαγή πύλης 1-5[/COLOR]   ZTEU PVR gen [/COLOR]',
 
 '[COLOR=red][COLOR yellow]Restart Pvr Stalker[/COLOR][/COLOR]',
 '[COLOR=white][COLOR lime]Install  last updete addon data[/COLOR][/COLOR] Pvr Stalker'
 ],)


    if call:
        if call < 0:
            return
        func = funcs[call-8]
        return func()
    else:
        func = funcs[call]
        return func()
    return 


def click_1():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/PVR/Browser_Portal_Stalker.py")')

def click_2():
    xbmc.executebuiltin('Addon.Opensettings(pvr.stalker)')

def click_3():
    xbmc.executebuiltin('RunScript("script.module.kgen")')

def click_4():
    xbmc.executebuiltin('RunScript("script.module.kgen1")')

def click_5():
    xbmc.executebuiltin('RunScript("script.module.kgen2")')

def click_6():
    xbmc.executebuiltin('RunScript("script.module.pvr-gen")')

def click_7():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/PVR/ClearingPvrData.py")')

def click_8():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/UpdaterMatrix_5.py")')



pvr()
