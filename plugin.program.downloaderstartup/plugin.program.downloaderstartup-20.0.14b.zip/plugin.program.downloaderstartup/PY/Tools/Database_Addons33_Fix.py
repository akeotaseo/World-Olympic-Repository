﻿import os, xbmc, xbmcvfs, xbmcgui

def Database_Addons33_Fix():

    xbmcgui.Dialog().notification("[B][COLOR orange]Γίνεται έλεγχος![/COLOR][/B]", "[COLOR white]Παρακαλώ περιμένετε...[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/ok2.png')
    xbmc.executebuiltin('RunScript("special://home/userdata/addon_data/plugin.program.downloader19/set_setting_Database_Addons33.py")')
    xbmc.sleep(2000)
    xbmcgui.Dialog().notification("[B][COLOR orange]Παρακαλώ περιμένετε ![/COLOR][/B]", "[COLOR white]Αναμονή για Reload Profile...[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/rp.png')
    xbmc.sleep(1000),
    xbmc.executebuiltin('LoadProfile("Master user")')
    xbmc.sleep(2000),
    xbmcgui.Dialog().notification("[B][COLOR orange]Reload Profile[/COLOR][/B]", "[COLOR white]Παρακαλώ περιμένετε...[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/reloadprofile.png')


Database_Addons33_Fix()