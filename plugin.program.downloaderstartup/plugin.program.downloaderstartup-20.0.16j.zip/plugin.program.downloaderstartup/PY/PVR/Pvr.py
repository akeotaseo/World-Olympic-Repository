import xbmc, xbmcgui


def pvr():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7, click_8, click_9, click_10)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]~ PVR~[/COLOR][/B]', 
    

['[COLOR lime]Αυτ/μένη αντικατάσταση πύλης[/COLOR] (Mac-Url)',
 '[COLOR darkorchid]Επιλογή Γκρουπ[/COLOR]',

 '[COLOR=white][COLOR blue]Ρυθμίσεις Stalker[/COLOR] [/COLOR]',
  '[COLOR orange]Restart Pvr Stalker[/COLOR]', 



 '[COLOR lime]Stalker_portal[/COLOR]',
 
 '[COLOR coral]Βοηθός ρύθμισης [COLOR blue]Stalker Client[/COLOR]',

 
 'Ρυθμίσεις PVR',

 '[COLOR deepskyblue]Ιστότοποι Stalker[/COLOR]',

 'Καθαρισμός δεδομένων',

 '[COLOR lime]Install  last update [COLOR yellow]addon data [COLOR=blue]Pvr Stalker[/COLOR]'
 ],)


    if call:
        if call < 0:
            return
        func = funcs[call-10]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



# def click_1():
    # xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/PVR/Generator_list.py")')
def click_1():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/PVR/mac_list_0.py")')

def click_2():
    xbmc.executebuiltin('SendClick(28)')

def click_3():
    xbmc.executebuiltin('Addon.Opensettings(pvr.stalker)')

def click_4():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/PVR/DialogRestartPvrStalker.py")')

def click_5():
    
    # xbmc.sleep(100)
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/PVR/Stalker_portal.py")')

def click_6():
    xbmc.executebuiltin('ActivateWindow(10001,"plugin://plugin.program.downloader/stalkerindex/")')

def click_7():
    xbmc.executebuiltin('ActivateWindow(pvrsettings)')

def click_8():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/PVR/Browser_Portal_Stalker.py")')

def click_9():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/PVR/clear_pvr_data.py")')

def click_10():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/PVR/ResetPvrSettings.py")')
    # xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/UpdaterMatrix_5.py")')

pvr()
