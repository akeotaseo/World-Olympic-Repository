﻿import xbmc, xbmcgui
xbmcgui.Dialog().notification("[COLOR orange]Update[/COLOR]", "   ", sound=False, icon='special://home/addons/plugin.program.downloader19/resources/media/update.png')

def Update():
    funcs = (click_1, click_2)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]Update[/COLOR][/B]', 
['[COLOR dodgerblue]Force Update Addons[/COLOR]',
 '[COLOR dodgerblue]Fix Addons Not Updating[/COLOR]'])


    if call:
        if call < 0:
            return
        func = funcs[call-2]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('PlayMedia("plugin://plugin.program.G.K.N.Wizard/?mode=forceupdate")')

def click_2():
    xbmc.executebuiltin('PlayMedia("plugin://plugin.program.G.K.N.Wizard/?mode=fixaddonupdate")')


Update()
