import xbmc, xbmcvfs, xbmcgui, glob, sqlite3


def clear_pvr_data():
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "pvr.stalker","enabled":false}}')
    dialog = xbmcgui.DialogProgress()
    dialog.create('Καθαρισμός δεδομένων', 'Καθαρισμός δεδομένων')
    dialog.update(0, 'Περιμένετε να ολοκληρωθεί η διαδικασία ...[CR]Θα πραγματοποιηθεί καθαρισμός δεδομένων και μετά φόρτωση της τελευταίας λίστας που χρησιμοποιούσαμε.')
    for i in range(0, 101, 4):
        dialog.update(i, '[COLOR white]Περιμένετε να ολοκληρωθεί η διαδικασία ...[CR][CR]Θα πραγματοποιηθεί καθαρισμός δεδομένων και μετά φόρτωση της τελευταίας λίστας που χρησιμοποιούσαμε.[/COLOR]')
        xbmc.sleep(600) 
    dialog.update(100, '[COLOR white]Περιμένετε να ολοκληρωθεί η διαδικασία ...[CR][CR]Θα πραγματοποιηθεί καθαρισμός δεδομένων και μετά φόρτωση της τελευταίας λίστας που χρησιμοποιούσαμε.[/COLOR]')
    xbmc.sleep(2000)
    dialog.close()
    db_files = glob.glob(xbmcvfs.translatePath('special://database/TV*.db'))
    db_file_names = [f for f in db_files if ('TV' in f or 'MyPVR' in f)]

    for db_file in db_file_names:
        conn = sqlite3.connect(db_file)
        cursor = conn.cursor()

        cursor.execute("DELETE FROM channels")
        cursor.execute("DELETE FROM timers")
        cursor.execute("DELETE FROM clients")
        cursor.execute("DELETE FROM channelgroups")
        cursor.execute("DELETE FROM map_channelgroups_channels")

        conn.commit()
        conn.close()
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "pvr.stalker","enabled":true}}')


clear_pvr_data()
