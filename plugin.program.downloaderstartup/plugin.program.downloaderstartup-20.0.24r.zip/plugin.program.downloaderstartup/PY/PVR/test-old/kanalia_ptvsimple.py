import os, xbmc, xbmcgui
def DialogkanaliaIPTVSimpleClient():
        choice = xbmcgui.Dialog().yesno('ΚΑΝΑΛΙΑ', 'Θέλετε να εισέλθετε στα ΚΑΝΑΛΙΑ?',
                                        nolabel='[B][COLOR white]Οχι τώρα...[/COLOR][/B]',yeslabel='[B][COLOR white]Ναι[/COLOR][/B]')

        if choice == 1: kanalia_ptvsimple()

                         

def kanalia_ptvsimple():
    if not xbmc.getCondVisibility('System.HasAddon({})'.format('pvr.iptvsimple')):
        choice = xbmcgui.Dialog().yesno('[COLOR orange]IPTV Simple Client[/COLOR]', '[COLOR white]Μετά την εγκατάσταση του πρόσθετου ανοίξτε το PVR ptvsimple απο τα [B]ΚΑΝΑΛΙΑ[/B].[/COLOR]',
                                        nolabel='[B][COLOR orange]Άκυρο[/COLOR][/B]',yeslabel='[B][COLOR lime]Εγκατάσταση[/COLOR][/B]')

        if choice == 1: installptvsimple()
                        # (xbmc.executebuiltin('InstallAddon(pvr.stalker)'),
                         # xbmc.sleep(1000),
                         # xbmc.executebuiltin('SendClick(11)'))
    if xbmc.getCondVisibility('System.HasAddon({})'.format('pvr.iptvsimple')):
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.iptvsimple","enabled":true}}')
        # xbmcgui.Dialog().notification("[COLOR orange]Υπομονή...[/COLOR]", "[COLOR white]μέχρι να φορτώσουν τα κανάλια...[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/Pleasewait.png', sound=True)
        # xbmc.sleep(4000)
        
        
        # xbmc.sleep(1000)
        
        # xbmc.executebuiltin('SendClick(11)')
        # xbmc.sleep(500)
        xbmc.executebuiltin('ActivateWindow(TVChannels)')
        xbmcgui.Dialog().notification("[COLOR orange]Αναμονή...[/COLOR]", "[COLOR white]μέχρι να φορτώσουν τα κανάλια...[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/Pleasewait.png', sound=True)
        xbmc.sleep(4000)
def installptvsimple():
        xbmc.executebuiltin('InstallAddon(pvr.iptvsimple)')



DialogkanaliaIPTVSimpleClient(()
# kanalia()
