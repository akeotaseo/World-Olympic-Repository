import os, xbmc, xbmcvfs, xbmcgui, xbmcaddon, shutil, glob
xbmcgui.Dialog().notification("[B][COLOR orange]They don't always work[/COLOR][/B]", "[COLOR green]Δεν λειτουργούν πάντα...[/COLOR]", sound=False, icon='special://home/addons/plugin.video.macvod/DialogPleaseWait/doestworkalltime.png')
# xbmc.sleep(4000)
def vod():
    funcs = (click_1, click_2)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]~ Stalker VOD ~[/COLOR][/B]', 
[
'[COLOR=blue]Stalker Vod[/COLOR]',

 '[COLOR=lime]Προεπιλογές[/COLOR]'



 ])


    if call:
        if call < 0:
            return
        func = funcs[call-2]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.stalkervod/",return)')



# def click_3():
    # choice = xbmcgui.Dialog().yesno('[COLOR orange]Stalker VOD[/COLOR]', 'Επιλέξτε Τυχαία αλλαγή[CR]απο [B][COLOR blue]kodibalkan[/COLOR][/B] ή απο [B][COLOR orange]optimus-tv[/COLOR][/B]',
        # nolabel='[B][COLOR orange]optimus-tv[/COLOR][/B]',yeslabel='[B][COLOR blue]kodibalkan[/COLOR][/B]')

    # if choice == 1: xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/PVR/kgenvod.py")')
    
    # if choice == 0: xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/PVR/kgenvod2.py")')
    


def click_2():
    xbmcaddon.Addon('plugin.video.stalkervod').openSettings()
    xbmc.sleep(3000)
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.stalkervod/",return)')
    # xbmc.sleep(6000)



vod()
