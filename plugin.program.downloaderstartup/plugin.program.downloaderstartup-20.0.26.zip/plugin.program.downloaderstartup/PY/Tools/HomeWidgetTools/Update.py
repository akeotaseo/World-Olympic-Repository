﻿import xbmc, xbmcgui
xbmcgui.Dialog().notification("[COLOR orange]Update[/COLOR]", "Ανακατεύθυνση...", sound=False, icon='special://home/addons/plugin.program.downloader19/resources/media/update.png')

xbmc.executebuiltin('ActivateWindow(10000)')
xbmc.sleep(4000)
xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.mypreferences/?content_type=video&fanart=C%3a%5cPortableApps%5ckodi%5cKODI%20TEST%5cKodi%5cportable_data%5caddons%5cplugin.program.mypreferences%5cfanart.jpg&image=special%3a%2f%2fhome%2faddons%5cplugin.program.G.K.N.Wizard%2fresources%2fart%2fmaintenance.png&label=Update&mode=400&path=special%3a%2f%2fprofile%2faddon_data%2fplugin.program.mypreferences%5cSuper%20Favourites%5cEX%20-Simple%20Favourites%5cUpdate",return)')




