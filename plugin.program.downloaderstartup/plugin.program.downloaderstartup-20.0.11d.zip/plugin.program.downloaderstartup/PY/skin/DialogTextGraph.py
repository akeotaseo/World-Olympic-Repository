import os, xbmc, xbmcgui, glob, shutil

def DialogTextGraph():
        choice = xbmcgui.Dialog().yesno('[B][COLOR orange]TextGraph[/COLOR][/B]', '[COLOR white]Για αλλαγή του skin απο "Γραμματοσειρά" σε "Εικονίδια", [/COLOR] επιλέξτε "Graph"[CR](Για να επαναφέρετε το skin στη Γραμματοσειρά επιλέξτε "Text")',
                                        nolabel='[COLOR orange]Κλείσε[/COLOR]',yeslabel='[COLOR red]Text Graph[/COLOR]')

        if choice == 1: xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/skin/SkinMenuLAF.py")'),
        if choice == 0: xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/Tools/SkinTools.py")')

DialogTextGraph()
