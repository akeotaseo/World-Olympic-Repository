import os, xbmc, xbmcvfs, xbmcgui, shutil, glob


def RobinhoodTVPortal():
    funcs = (click_1, click_2, click_3)
    call = xbmcgui.Dialog().select('[B]Robinhood TV Portal &...[/B]', 
['[COLOR=lime]Install[/COLOR] Robinhood TV Portal &...',

 '[B][COLOR green]Robinhood[/COLOR] & [COLOR orange]Bee[/COLOR] TV[/B] --> [COLOR silver]Πρόσθετα βίντεο[/COLOR]',

 '[COLOR=red]Delete[/COLOR] Robinhood TV  Portal &...'])
 



    if call:
        if call < 0:
            return
        func = funcs[call-3]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    DelRobinhoodTVPortal()
    xbmc.sleep(1000)
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/UpdaterMatrix_19.py")')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,"library://video/addons.xml/")')

def click_3():
    DelRobinhoodTVPortal()
    DialogDelRobinhoodTVPortal()

def DelRobinhoodTVPortal():



    base_path = xbmcvfs.translatePath('special://home/addons')
    
    
    # dir_list = glob.iglob(os.path.join(base_path, "plugin.video.playlistbee"))
    # for path in dir_list:
        # if os.path.isdir(path):
            # shutil.rmtree(path)
    
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.balkanclient"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    #dir_list = glob.iglob(os.path.join(base_path, "plugin.video.worldclient"))
    #for path in dir_list:
        #if os.path.isdir(path):
            #shutil.rmtree(path)
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.worldclient2"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.worldclient3"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.x-codes2"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.x-codes-x"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.edemro"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.cataddon"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.chro"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.free"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.ohato"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.optimustv"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.rdslive"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.romanianpack"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.romyTVlist"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.fshd"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.fsonline"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.x-codes"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)


    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.liveinzadar"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)


    #############################################################################
    
    base_path = xbmcvfs.translatePath('special://home/userdata/addon_data')
    
    
    
    # dir_list = glob.iglob(os.path.join(base_path, "plugin.video.playlistbee"))
    # for path in dir_list:
        # if os.path.isdir(path):
            # shutil.rmtree(path)


    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.balkanclient"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    #dir_list = glob.iglob(os.path.join(base_path, "plugin.video.worldclient"))
    #for path in dir_list:
        #if os.path.isdir(path):
            #shutil.rmtree(path)
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.worldclient2"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.worldclient3"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.x-codes2"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.x-codes-x"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    
    # dir_list = glob.iglob(os.path.join(base_path, "plugin.video.edemro"))
    # for path in dir_list:
        # if os.path.isdir(path):
            # shutil.rmtree(path)
    
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.cataddon"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.chro"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.free"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.ohato"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.optimustv"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.rdslive"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.romanianpack"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.romyTVlist"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.fshd"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    
    dir_list = glob.iglob(os.path.join(base_path, "plugin.video.fsonline"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)
    
    
    # dir_list = glob.iglob(os.path.join(base_path, "plugin.video.x-codes"))
    # for path in dir_list:
        # if os.path.isdir(path):
            # shutil.rmtree(path)




def DialogDelRobinhoodTVPortal():
    xbmc.sleep(2000)
    xbmcgui.Dialog().notification("[B][COLOR red]Delete[/COLOR] Robinhood TV Portal[/B]", "[COLOR white]Τα πρόσθετα [COLOR yellow]Robinhood TV Portal &... [/COLOR] αφαιρέθηκαν με επιτυχία![/COLOR]", icon='special://home/addons/plugin.program.downloaderstartup/resources/media/clean.png')
    xbmc.sleep(5000)
    xbmcgui.Dialog().notification("[B][COLOR red]Ok[/COLOR][/B]", "[COLOR white]Αναμονή για Reload Profile...[/COLOR]", icon='special://home/addons/plugin.program.downloaderstartup/resources/media/rp.png')
    xbmc.sleep(5000)
    xbmc.executebuiltin('RunPlugin(plugin://plugin.program.G.K.N.Wizard/?mode=forceprofile)')
    xbmc.sleep(1000)
    xbmcgui.Dialog().notification("[B][COLOR orange]Reload Profile[/COLOR][/B]", "[COLOR white]Παρακαλώ περιμένετε...[/COLOR]", icon='special://home/addons/plugin.program.downloaderstartup/resources/media/reloadprofile.png')


RobinhoodTVPortal()
    