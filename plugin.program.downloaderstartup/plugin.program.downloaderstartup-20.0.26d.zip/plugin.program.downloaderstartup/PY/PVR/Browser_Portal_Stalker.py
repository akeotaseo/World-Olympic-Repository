import os, xbmc, xbmcvfs, xbmcgui, webbrowser


def browser_portal_stalker():
        choice = xbmcgui.Dialog().yesno('[COLOR deepskyblue]Ιστότοποι Stalker[/COLOR]', '[COLOR white]Αν επιθυμείτε, προσθέστε νέους διακομιστές στις πύλες, αντιγράφοντας την [COLOR lime]Διεύθυνση MAC[COLOR white] και την [COLOR lime]Διεύθυνση Διακομιστή[COLOR white] από τους παρακάτω ιστότοπους.[/COLOR]',
                                        nolabel='[COLOR orange]Άκυρο[/COLOR]',yeslabel='[COLOR deepskyblue]Ιστότοποι Stalker[/COLOR]')

        if choice == 1: SitesMenu()


def SitesMenu():
    dialog = xbmcgui.Dialog()
    funcs = (site1, site2, site3, site4, site5)
    xbmcgui.Dialog().ok("[COLOR orange]Αλλαγή πύλης [/COLOR]", "[COLOR blue]Ρυθμίσεις Stalker[COLOR white] > Πύλη προς αλλαγή > Προσθήκη [COLOR lime]Διεύθυνσης MAC[COLOR white] και [COLOR lime]Διεύθυνσης Διακομιστή[COLOR white].[CR]Μετά από κάθε αλλαγή χρησιμοποιούμε τον καθαρισμό δεδομένων.[/COLOR]")
    call = dialog.select('[B][COLOR=orange]Ιστότοποι Portal Stalker...[/COLOR][/B]', 


['[B][COLOR=white]iptvlinkseuro[/COLOR][/B]', 
 '[B][COLOR=white]stbemuiptv.codes[/COLOR][/B]',
 '[B][COLOR=white]stbemuiptv[/COLOR][/B]',
 '[B][COLOR=white]IPTV RO.[/COLOR][/B] [B][COLOR=deepskyblue]Telegram[/COLOR][/B]',
 '[B][COLOR=white]IPTV Europa[/COLOR][/B] [B][COLOR=deepskyblue]Telegram[/COLOR][/B]'])

    if call:
        if call < 0:
            return
        func = funcs[call-5]
        return func()
    else:
        func = funcs[call]
        return func()
    return


def platform():
    if xbmc.getCondVisibility('system.platform.android'):
        return 'android'
    elif xbmc.getCondVisibility('system.platform.linux'):
        return 'linux'
    elif xbmc.getCondVisibility('system.platform.windows'):
        return 'windows'
    elif xbmc.getCondVisibility('system.platform.osx'):
        return 'osx'
    elif xbmc.getCondVisibility('system.platform.atv2'):
        return 'atv2'
    elif xbmc.getCondVisibility('system.platform.ios'):
        return 'ios'

myplatform = platform()

def site1():
    if myplatform == 'android': opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://iptvlinkseuro.blogspot.com' ) )
    else: opensite = webbrowser . open('https://iptvlinkseuro.blogspot.com')

def site2():
    if myplatform == 'android': opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://stbemuiptv.codes/category/stbemu-codes/' ) )
    else: opensite = webbrowser . open('https://stbemuiptv.codes/category/stbemu-codes/')

def site3():
    if myplatform == 'android': opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://stbemuiptv.com/' ) )
    else: opensite = webbrowser . open('https://stbemuiptv.com/')

def site4():
    if myplatform == 'android': opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://web.telegram.org/a/#-1002391376446_160' ) )
    else: opensite = webbrowser . open('https://web.telegram.org/a/#-1002391376446_160')

def site5():
    if myplatform == 'android': opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://web.telegram.org/a/#-1001882390853' ) )
    else: opensite = webbrowser . open('https://web.telegram.org/a/#-1001882390853')



browser_portal_stalker()
