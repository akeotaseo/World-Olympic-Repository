﻿import xbmc, xbmcgui
xbmcgui.Dialog().notification("[COLOR orange]Update[/COLOR]", "   ", sound=False, icon='special://home/addons/plugin.program.downloader19/resources/media/update.png')

# xbmc.executebuiltin('ActivateWindow(10000)')
# xbmc.sleep(4000)
xbmc.executebuiltin('ActivateWindow(10001,"plugin://plugin.program.simple.favourites/index_of/special%3A%2F%2Fhome%2Faddons%2Fplugin.program.simple.favourites%2Ffolders%2FUpdate%2F",return))')




