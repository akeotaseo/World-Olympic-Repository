import xbmc, xbmcgui


def CocoScrapersSeren():
    funcs = (click_1, click_2, click_3)
    call = xbmcgui.Dialog().select('[COLOR=orange]~ CocoScrapers/Seren ~[/COLOR]', 
['[COLOR=orange]Coco Scrapers[/COLOR]',

 '[COLOR=gold]HELP[/COLOR]',
 '[COLOR=darkorange]Seren Providers[/COLOR]'])



    if call:
        if call < 0:
            return
        func = funcs[call-3]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    if not xbmc.getCondVisibility('System.HasAddon({})'.format('script.module.cocoscrapers')):
        choice = xbmcgui.Dialog().yesno('[B][COLOR orange]Coco Scrapers[/COLOR][/B]', 'Για να λειτουργήσουν τα πρόσθετα [B][COLOR white]Umbrella, Fen κ.α[/COLOR][/B][CR]πρέπει να γίνει εγκατάσταση των[CR][B]Coco Scrapers[/B][CR]Για να συνεχίσετε πατήστε [B][COLOR orange]Coco Scrapers[/COLOR][/B][CR]',
                                        nolabel='[B][COLOR white]Πίσω[/COLOR][/B]',yeslabel='[B][COLOR orange]Coco Scrapers[/COLOR][/B]')

        if choice == 1: xbmc.executebuiltin('ActivateWindow(10001,"plugin://script.module.cocoscrapers/")')
        if choice == 0: [xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/CocoScrapersSeren/CocoScrapersSeren.py")'),]


    if xbmc.getCondVisibility('System.HasAddon({})'.format('script.module.cocoscrapers')):
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "script.module.cocoscrapers","enabled":true}}')
        xbmc.executebuiltin('ActivateWindow(10001,"plugin://script.module.cocoscrapers/")')
        # xbmc.sleep(4000)


def click_2():
    xbmc.executebuiltin('ActivateWindow(10002,"special://home/media/Coco Scrapers/",)')

def click_3():
        choice = xbmcgui.Dialog().yesno('[B][COLOR orange]SerenProviders[/COLOR][/B]', 'Για να λειτουργήσει τα πρόσθετο [B][COLOR white] Seren[/COLOR][/B][CR]πρέπει να γίνει εγκατάσταση των[CR][B]Seren Providers[/B][CR]Για να συνεχίσετε πατήστε [B][COLOR orange]Seren Providers[/COLOR][/B][CR]',
                                        nolabel='[B][COLOR white]Πίσω[/COLOR][/B]',yeslabel='[B][COLOR orange]Seren Providers[/COLOR][/B]')

        if choice == 1: xbmc.executebuiltin('ActivateWindow(10001,"plugin://plugin.program.downloader/seren_package_install")')
        if choice == 0: [xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/CocoScrapersSeren/CocoScrapersSeren.py")'),]

def click_5():
    xbmc.executebuiltin('ActivateWindow(10001,"plugin://plugin.program.downloader/seren_package_install")')



CocoScrapersSeren()
