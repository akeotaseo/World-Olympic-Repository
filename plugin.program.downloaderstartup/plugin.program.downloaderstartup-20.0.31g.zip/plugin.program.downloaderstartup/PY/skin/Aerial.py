import xbmc, xbmcgui
xbmcgui.Dialog().ok('[B][COLOR=orange]Aerial[/COLOR][/B]', 'Επιλέξτε Προφύλαξη Οθόνης.')

def Aerial():
  #  xbmc.executebuiltin("Action(Close)")
    
    xbmc.executebuiltin('ActivateWindow(interfacesettings,screensaver.mode)')

    # xbmc.sleep(500)
    # if xbmc.getCondVisibility('system.platform.android'):
    xbmc.executebuiltin('SendClick(-179)')

    # else:
        # xbmc.executebuiltin('SendClick(-179)')

Aerial()
