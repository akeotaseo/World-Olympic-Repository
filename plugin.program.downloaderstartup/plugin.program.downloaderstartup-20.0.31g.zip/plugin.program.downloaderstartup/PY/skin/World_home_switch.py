import os, sys, glob, base64, xbmc, xbmcvfs, xbmcaddon, xbmcgui, shutil, subprocess
import os
import shutil
import subprocess
import xbmcgui
import xbmcvfs
import xbmc, xbmcaddon



dialog = xbmcgui.Dialog()
# settings_path = xbmcvfs.translatePath('special://home/userdata/addon_data/s/skin.19MatrixWorld/')



def World_home_switch():
        flavor_list = ['[B][COLOR orange]World[/COLOR][/B]', '[B][COLOR blue]Movies & TV[/COLOR][/B]', '[B][COLOR lime]Sports[/COLOR][/B]']
        select = dialog.select('Home Switch', flavor_list)
        if select == None:
            return


        if select == 0:
            Dialog_Choice_0()


        if select == 1:
            Foto_Movies_Series()
            Dialog_Choice_1()


        if select == 2:
            Foto_Sports()
            Dialog_Choice_2()


def Foto_Movies_Series():
    xbmc.executebuiltin('ShowPicture("special://home/media/MOVIES_TV.png")')
    xbmcgui.Dialog().notification("[B][COLOR blue]Movies & TV[/COLOR][/B]", "Ετσι θα φαίνεται.", icon='special://home/addons/skin.19MatrixWorld/media/cinema.png', sound=True)
    xbmc.sleep(4000)

def Foto_Sports():
    xbmc.executebuiltin('ShowPicture("special://home/media/SPORTS.png")')
    xbmcgui.Dialog().notification("[B][COLOR lime]Sports[/COLOR][/B]", "Ετσι θα φαίνεται.", icon='special://home/addons/skin.19MatrixWorld/media/sportsdevil.png', sound=True)
    xbmc.sleep(4000)


def xmlskinversion():
    addon_downloader19       = xbmcaddon.Addon('plugin.program.downloader19')
    setting_downloader19     = addon_downloader19.getSetting
    setting_set_downloader19 = addon_downloader19.setSetting
    if not setting_downloader19('xmlskinversion')=='2046':
        xbmc.sleep(500)
        setting_set_downloader19('xmlskinversion', '2046')


def xmlskinversion0():
    addon_downloader19       = xbmcaddon.Addon('plugin.program.downloader19')
    setting_downloader19     = addon_downloader19.getSetting
    setting_set_downloader19 = addon_downloader19.setSetting
    if not setting_downloader19('xmlskinversion')=='0':
        xbmc.sleep(500)
        setting_set_downloader19('xmlskinversion', '0')

#######################################################################################

def Dialog_Choice_0():
        choice = xbmcgui.Dialog().yesno('[B][COLOR orange]World[/COLOR][/B]', 'Επιστροφή στο Προκαθορισμένο [B]HOME MENU[/B][CR]& Ενεργοποίηση Αυτόματων Ενημερώσεων των settings του Skin.[CR]Θέλετε να εφαρμοστούν οι αλλαγές;',
                                        nolabel='Οχι',yeslabel='Ναι')
        if choice == 1: [Dialog_Choice_0_Ok()]
        if choice == 0: [xbmc.executebuiltin('Dialog.Close(all,true)'), xbmc.executebuiltin('Action(Back)'), xbmc.executebuiltin('Dialog.Close(all,true)'), xbmc.executebuiltin('ActivateWindow(10000)'),]


def Dialog_Choice_1():
        choice = xbmcgui.Dialog().yesno('[B]Skin [COLOR blue]Movies & TV[/COLOR][/B] [B][COLOR lime]V 3[/COLOR][/B]', 'Θέλετε να εφαρμοστούν οι αλλαγές;',
                                        nolabel='Οχι',yeslabel='Ναι')
        if choice == 1: [Dialog_Choice_1_Ok(),]
        if choice == 0: [xbmc.executebuiltin('Dialog.Close(all,true)'), xbmc.executebuiltin('Action(Back)'), xbmc.executebuiltin('Dialog.Close(all,true)'), xbmc.executebuiltin('ActivateWindow(10000)'),]


def Dialog_Choice_2():
        choice = xbmcgui.Dialog().yesno('[B]Skin [COLOR green]Sports[/COLOR][/B] [B][COLOR lime]V 1.4[/COLOR][/B]', 'Θέλετε να εφαρμοστούν οι αλλαγές;',
                                        nolabel='Οχι',yeslabel='Ναι')
        if choice == 1: [Dialog_Choice_2_Ok(),]
        if choice == 0: [xbmc.executebuiltin('Dialog.Close(all,true)'), xbmc.executebuiltin('Action(Back)'), xbmc.executebuiltin('Dialog.Close(all,true)'), xbmc.executebuiltin('ActivateWindow(10000)'),]

#######################################################################################




def Dialog_Choice_0_Ok():
    xmlskinversion0()
    Restore_from_Backup_Skin_Set()


def Restore_from_Backup_Skin_Set():
    src_settings = xbmcvfs.translatePath('special://home/backup/skin.19MatrixWorld/settings.xml')
    dst_settings = xbmcvfs.translatePath('special://home/userdata/addon_data/skin.19MatrixWorld/settings.xml')
    src_home = xbmcvfs.translatePath('special://home/backup/skin.19MatrixWorld/Home.xml')
    dst_home = xbmcvfs.translatePath('special://home/addons/skin.19MatrixWorld/xml/Home.xml')
    addon_downloader19       = xbmcaddon.Addon('plugin.program.downloader19')
    setting_downloader19     = addon_downloader19.getSetting
    xbmc.sleep(500)
    # setting_set_downloader19 = addon_downloader19.setSetting
    if setting_downloader19('xmlskinversion')=='0':
        xbmc.sleep(500)
        # setting_set_downloader19('xmlskinversion', '2046')
        shutil.copyfile(src_settings, dst_settings)
        xbmc.sleep(500)
        shutil.copyfile(src_home, dst_home)
        xbmc.sleep(500)
        xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloader19/SkinMenuLAST3.py")')


def Dialog_Choice_1_Ok():
                dialog = xbmcgui.Dialog()
                settings_path = xbmcvfs.translatePath('special://home/userdata/addon_data/skin.19MatrixWorld/')
                #απο εδω Choose Movies & TV
                src_settings = xbmcvfs.translatePath('special://home/addons/plugin.program.downloaderstartup/PY/skin/switch/Movies_TV/settings.xml')
                #παει εδω
                dst_settings = xbmcvfs.translatePath('special://home/userdata/addon_data/skin.19MatrixWorld/settings.xml')
                
                
                if os.path.exists(os.path.join(settings_path)):
                        try:
                                shutil.copyfile(src_settings, dst_settings)
                                xmlskinversion()
                                Home_1_Ok()
                                xbmcgui.Dialog().ok('[B][COLOR blue]Movies & TV[/COLOR][/B]', 'Οι Αυτόματες ενημερώσεις των settings του Skin[CR]έχουν απενεργοποιηθεί.')
                                Dialog_Force_Profile()
                        except:
                                xbmcgui.Dialog().ok('Switcher Skin Settings', 'Error switching skin settings')
                else:
                        xbmcgui.Dialog().ok('Movies & TV Switcher', 'Error switching skin')


def Dialog_Choice_2_Ok():
                dialog = xbmcgui.Dialog()
                settings_path = xbmcvfs.translatePath('special://home/userdata/addon_data/skin.19MatrixWorld/')
                #απο εδω Choose Sports
                src_settings = xbmcvfs.translatePath('special://home/addons/plugin.program.downloaderstartup/PY/skin/switch/Sports/settings.xml')
                #παει εδω
                dst_settings = xbmcvfs.translatePath('special://home/userdata/addon_data/skin.19MatrixWorld/settings.xml')
                
                
                if os.path.exists(os.path.join(settings_path)): 
                        try:
                                shutil.copyfile(src_settings, dst_settings)
                                xmlskinversion()
                                Home_2_Ok()
                                xbmcgui.Dialog().ok('[B][COLOR lime]Sports[/COLOR][/B]', 'Οι Αυτόματες ενημερώσεις των settings του Skin[CR]έχουν απενεργοποιηθεί.')
                                Dialog_Force_Profile()
                        except:
                                xbmcgui.Dialog().ok('Switcher Skin Settings', 'Error switching skin settings')
                else:
                        xbmcgui.Dialog().ok('Sports', 'Error switching skin')


def Home_1_Ok():
                dialog = xbmcgui.Dialog()
                home_path = xbmcvfs.translatePath('special://home/addons/skin.19MatrixWorld/xml/')
                #απο εδω Choose Movies & TV Home
                src_home = xbmcvfs.translatePath('special://home/addons/plugin.program.downloaderstartup/PY/skin/switch/Movies_TV_Home/Home.xml')
                #παει εδω
                dst_home = xbmcvfs.translatePath('special://home/addons/skin.19MatrixWorld/xml/Home.xml')
                
                
                if os.path.exists(os.path.join(home_path)):
                        try:
                                shutil.copyfile(src_home, dst_home)
                                xbmcgui.Dialog().notification("Home Menu", "Η αλλαγή πραγματοποιήθηκε.", icon='special://home/addons/plugin.program.downloader19/resources/media/itsok.jpg', sound=True)
                        except:
                                xbmcgui.Dialog().ok('Movies & TV Home xml Switcher', 'Error switching Home xml')
                else:
                        xbmcgui.Dialog().ok('Movies & TV Home xml Switcher', 'Error switching Home xml')


def Home_2_Ok():
                dialog = xbmcgui.Dialog()
                home_path = xbmcvfs.translatePath('special://home/addons/skin.19MatrixWorld/xml/')
                #απο εδω Choose Sports Home
                src_home = xbmcvfs.translatePath('special://home/addons/plugin.program.downloaderstartup/PY/skin/switch/Sports_Home/Home.xml')
                #παει εδω
                dst_home = xbmcvfs.translatePath('special://home/addons/skin.19MatrixWorld/xml/Home.xml')
                
                
                if os.path.exists(os.path.join(home_path)):
                        try:
                                shutil.copyfile(src_home, dst_home)
                                xbmcgui.Dialog().notification("Home Menu", "Η αλλαγή πραγματοποιήθηκε.", icon='special://home/addons/plugin.program.downloader19/resources/media/itsok.jpg', sound=True)
                        except:
                                xbmcgui.Dialog().ok('Sports Home xml Switcher', 'Error switching Home xml')
                else:
                        xbmcgui.Dialog().ok('Sports Home xml Switcher', 'Error switching Home xml')


def Dialog_Force_Profile():
        choice = xbmcgui.Dialog().yesno('[B][COLOR gold]HOME MENU[/COLOR][/B]', 'Για να εφαρμοστούν οι αλλαγές[CR]Πατήστε [COLOR red]Force Close[/COLOR] ή [COLOR blue]Reload Profile[/COLOR]',
                                        nolabel='[COLOR red]Force Close[/COLOR]',yeslabel='[COLOR blue]Reload Profile[/COLOR]')
        if choice == 1: [
                         xbmcgui.Dialog().notification("[COLOR blue]Reload Profile[/COLOR]", "Παρακαλώ Περιμένετε...", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/Profile.png'),
                         xbmc.sleep(2000),
                         xbmc.executebuiltin("LoadProfile(Master user)"),]
        if choice == 0: [os._exit(1),]


World_home_switch()
