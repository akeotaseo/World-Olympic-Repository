import os, sys, glob, base64, xbmc, xbmcvfs, xbmcaddon, xbmcgui, shutil, subprocess


def SkinLookandFeel():
    funcs = (click1, click2, click3, click4, click5)
    call = xbmcgui.Dialog().select('[B]Skin Look and Feel[/B]', 
['Home Widget [COLOR=red]OFF[/COLOR] / [COLOR=green]ON[/COLOR]',
 'Single Global Background',
 'Intro [COLOR=green]Enable[/COLOR] / [COLOR=red]Disable[/COLOR]',
 'Txt / Graph [COLOR red] Skin[/COLOR]',
 '[COLOR red] Skin[/COLOR] Menu Tools'
 ])


    if call:
        if call < 0:
            return
        func = funcs[call-5]
        return func()
    else:
        func = funcs[call]
        return func()
    return 


def click1():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/skin/World_widget_OnOff.py")')
    # xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/skin/HomeWidgetONOFF.py")')

def click2(): # Single Global Background
    SkinBackground()
    #xbmc.executebuiltin('Skin.ToggleSetting(SingleGlobalBackground)')
    #xbmc.sleep(1000)
    # xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/skin/SkinBackground.py")')

def click3():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/skin/Introonoff.py")')

def click4():# TextGraph
    xmlskinversion2048()

def click5():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/skin/SkinMenuTools.py")')

####################################################
# TextGraph
def xmlskinversion2048():
    addon_downloader19       = xbmcaddon.Addon('plugin.program.downloader19')
    setting_downloader19     = addon_downloader19.getSetting
    setting_set_downloader19 = addon_downloader19.setSetting
    if setting_downloader19('xmlskinversion')=='2046':
        xbmcgui.Dialog().ok('[COLOR red] Skin[/COLOR] Menu Tools', 'Η επιλογή αυτή είναι διαθέσιμη μόνο στο Προκαθορισμένο Skin')
    else: DialogTextGraph()



def DialogTextGraph():
        choice = xbmcgui.Dialog().yesno('[B][COLOR orange]TextGraph[/COLOR][/B]', '[COLOR white]Για αλλαγή του skin απο "Γραμματοσειρά" σε "Εικονίδια", [/COLOR] επιλέξτε "Graph"[CR](Για να επαναφέρετε το skin στη Γραμματοσειρά επιλέξτε "Text")',
                                        nolabel='[COLOR orange]Κλείσε[/COLOR]',yeslabel='[COLOR red]Text Graph[/COLOR]')

        if choice == 1: SkinMenuLAF(),
        if choice == 0: xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/skin/SkinLookandFeel.py")')



def SkinMenuLAF():
    funcs = (click__1, click__2, click__3, click__4)
    call = xbmcgui.Dialog().select('[B]SkinMenuLAF[/B]', 
['[COLOR red] Skin [/COLOR] Text',
 '[COLOR red] Skin [/COLOR] Graph',
 '[COLOR red] Skin [/COLOR] GraphFocused',
  '[B][COLOR red]<---                                                                      [COLOR grey]Back[/COLOR][/B]'
 ])
 



    if call:
        if call < 0:
            return
        func = funcs[call-4]
        return func()
    else:
        func = funcs[call]
        return func()
    return 


def click__1():
    xbmc.executebuiltin('Skin.Reset(MenuLAF)')
    xbmc.executebuiltin("ReloadSkin()")

def click__2():
    xbmc.executebuiltin('Skin.SetString(MenuLAF,Graph)')
    xbmc.executebuiltin("ReloadSkin()")

def click__3():
    xbmc.executebuiltin('Skin.SetString(MenuLAF,GraphFocused)')
    xbmc.executebuiltin("ReloadSkin()")

def click__4():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/skin/SkinLookandFeel.py")')


####################################################
 # Single Global Background
def SkinBackground():
    funcs = (click___1, click___2)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]~ Background ~[/COLOR][/B]', 
['On-[COLOR=orange]Single Global Background[/COLOR]-Off',
 # 'On-[COLOR=mediumvioletred]Weather Theme[/COLOR]-Off',
 # '   ',
 # 'On-[COLOR=blue]Blue Theme[/COLOR]-Off',

 '[B][COLOR red]<---                                                                      [COLOR grey]Back[/COLOR][/B]'
 ])


    if call:
        if call < 0:
            return
        func = funcs[call-2]
        return func()
    else:
        func = funcs[call]
        return func()
    return 


    
def click___1():
    xbmc.executebuiltin('Skin.ToggleSetting(SingleGlobalBackground)')
    xbmc.sleep(2000)
    SkinBackground()

# def click2():
    # xbmc.executebuiltin('Skin.ToggleSetting(GlobalLiveWeatherImage)')
    # xbmc.sleep(1000)
    # xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/skin/SkinBackground.py")')

# def click3():
    # xbmc.executebuiltin('Skin.ToggleSetting(HolidayEffects)')
    # xbmc.sleep(1000)
    # xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/skin/SkinBackground.py")')

def click___2():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/skin/SkinLookandFeel.py")')



SkinLookandFeel()
