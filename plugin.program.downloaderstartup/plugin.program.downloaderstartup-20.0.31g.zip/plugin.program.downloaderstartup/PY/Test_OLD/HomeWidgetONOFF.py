import xbmc, xbmcgui


def HomeWidgetONOFF():
    funcs = (click_1, click_2)
    call = xbmcgui.Dialog().select('[B][COLOR=green]Enable[/COLOR][/B]/[B][COLOR=red]Disable[/COLOR]Home Widget[/B]', 
['HomeWidget [COLOR red]OFF[/COLOR]',
 'HomeWidget [COLOR green]ON[/COLOR]'])
 



    if call:
        if call < 0:
            return
        func = funcs[call-2]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    #xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/UpdaterMatrix_4.py")')
    #xbmc.sleep(3000)
    xbmc.executebuiltin('Skin.SetString(CustomWidgets,0)')
    xbmc.executebuiltin("ReloadSkin()")

def click_2():
    xbmc.executebuiltin('Skin.SetString(CustomWidgets,100)')
    xbmc.executebuiltin("ReloadSkin()")


HomeWidgetONOFF()
