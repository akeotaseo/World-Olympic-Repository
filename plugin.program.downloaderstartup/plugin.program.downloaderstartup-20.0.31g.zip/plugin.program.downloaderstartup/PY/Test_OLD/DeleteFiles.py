﻿import os, xbmc, xbmcvfs, xbmcgui, xbmcaddon, shutil, glob

def DeleteFiles():


                        #[xbmcvfs.delete('special://home/userdata/addon_data/plugin.video.themoviedb.helper/players/atla_oipeirates.json'), 
                         #xbmc.sleep(1000),
                         #xbmcvfs.delete('special://home/userdata/addon_data/plugin.program.downloader19/settings.xml'),
                         #xbmc.sleep(1000),
                         #xbmc.executebuiltin('RunScript("special://home/addons/program.downloaderstartup/PY/UpdaterMatrixDelete.py")'),
                         #xbmc.sleep(1000),
                         #xbmcgui.Dialog().notification("[B][COLOR orange]Διαγραφή με επιτυχία ![/COLOR][/B]", "[COLOR white]Αναμονή για Reload Profile...[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/rp.png'),
                         #xbmc.executebuiltin('RunPlugin(plugin://plugin.program.G.K.N.Wizard/?mode=forceprofile)'),
                         #xbmc.sleep(2000),
                         #xbmcgui.Dialog().notification("[B][COLOR orange]Reload Profile[/COLOR][/B]", "[COLOR white]Παρακαλώ περιμένετε...[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/reloadprofile.png')
                         #]

DeleteFiles()
