﻿import xbmc, xbmcgui
xbmcgui.Dialog().notification("[COLOR orange]Advanced Settings[/COLOR]", "   ", sound=False, icon='special://home/addons/plugin.image.World/resources/media/iloveimg-resized(2)/QuickConfigureAdvancedSettings.png')

# xbmc.executebuiltin('ActivateWindow(10000)')
# xbmc.sleep(4000)
xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/AdvancedSettings.py")')




