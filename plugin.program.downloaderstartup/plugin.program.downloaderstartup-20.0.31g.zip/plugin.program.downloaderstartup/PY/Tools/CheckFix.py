import os, xbmc, xbmcvfs, xbmcgui


def CheckFix():
    funcs = (click1, click2, click3, click4)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]~ Check Fix ~[/COLOR][/B]', 

[ '[B][COLOR gold]Fix [/COLOR]build update[/B]',

 '[COLOR blue][B]gui fix [/B][/COLOR]',
 
 # '[COLOR=lime]Check Fix [COLOR=slategray]Database_Addons33[/COLOR]',
 '[B][COLOR orange]Check Fix [/COLOR][CR]delete_files / addons_list_installation / set_setting[/B]',
 '[COLOR yellow][B]NemesisAio[/COLOR] [B]Fix [/B]'
 #'[COLOR white][B]Alphatv.gr & Antenna.gr[/COLOR] [B]Fix [/B]',
 
 ])
 #'[B][COLOR=white][B][COLOR grey]Fix build update [/COLOR][/B]',
 
 #'Check Fix [COLOR=red]delete_files[/COLOR]',
 #'Check Fix [COLOR=green]addons_list_installation[/COLOR]',

 

    if call:
        if call < 0:
            return
        func = funcs[call-4]
        return func()
    else:
        func = funcs[call]
        return func()
    return 




def click1():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/FixBuild/FixBuild.py")')

def click2(): guifix()
             
        

# def click3():
    # Database()
    # Addons33()

def click3():
    CheckAll()
    

def click4():
    streamarmy()



# def click3(): streamarmy()


# def click4():
    # xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/UpdaterMatrix_7.py")')

#def click1():
    #xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/FixBuildTEST/FixBuildOLD.py")')


#def click3():
    #xbmc.executebuiltin('RunScript("special://home/userdata/addon_data/plugin.program.downloader19/delete_files.py")')

#def click4():
    #xbmc.executebuiltin('RunScript("special://home/userdata/addon_data/plugin.program.downloader19/addons_list_installation.py")')

#def click5():
    #xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/Tools/Database_Addons33_Fix.py")')







def guifix():
    funcs = (click_1, click_2)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]Gui fix[/COLOR][/B]', 
['[COLOR=white]Gui fix [COLOR=blue](Omega)[/COLOR]'])



    if call:
        if call < 0:
            return
        func = funcs[call-2]
        return func()
    else:
        func = funcs[call]
        return func()
    return 0






def click_1():
    xbmc.executebuiltin('PlayMedia("plugin://plugin.program.G.K.N.Wizard/?mode=install&name=World+-Omega-&url=gui")')

def click_2():
    xbmc.executebuiltin('PlayMedia("plugin://plugin.program.G.K.N.Wizard/?mode=install&name=World+-Omega-&url=gui")')


def streamarmy():
        choice = xbmcgui.Dialog().yesno('[COLOR orange]Fix NemesisAio[/COLOR]', 'Επιλέξτε [COLOR green]Remove Data[/COLOR][CR]Στην συνέχεια ανοίξτε τo πρόσθετo [COLOR orange]NemesisAio[/COLOR][CR]απο το SubMenu στην κατηγορία[CR]ALL IN ONE [COLOR yellow]NemesisAio[/COLOR]',
                                        nolabel='[B][COLOR white]Όχι τώρα...[/COLOR][/B]',yeslabel='[B][COLOR green]Remove Data[/COLOR][/B]')

        # if choice == 1: xbmcvfs.delete('special://home/userdata/addon_data/plugin.program.downloader/settings.xml'),xbmc.sleep(1000),xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/UpdaterMatrix_12.py")'),


        if choice == 1: xbmcvfs.delete('special://home/userdata/addon_data/plugin.program.downloader/settings.xml'),xbmc.sleep(1000),xbmc.executebuiltin('Addon.Opensettings(plugin.program.downloader)'),xbmc.sleep(1000),xbmc.executebuiltin('SendClick(28)'),






# def textBox(heading, announce):
    # class TextBox():

        # def __init__(self, *args, **kwargs):
            # self.WINDOW = 10147
            # self.CONTROL_LABEL = 1
            # self.CONTROL_TEXTBOX = 5
            # xbmc.executebuiltin("ActivateWindow(%d)" % (self.WINDOW, ))
            # self.win = xbmcgui.Window(self.WINDOW)
            # xbmc.sleep(500)
            # self.setControls()

        # def setControls(self):
            # self.win.getControl(self.CONTROL_LABEL).setLabel(heading)
            # try:
                # f = open(announce)
                # text = f.read()
            # except:
                # text = announce
            # self.win.getControl(self.CONTROL_TEXTBOX).setText(str(text))
            # return

    # TextBox()
    # while xbmc.getCondVisibility('Window.IsVisible(10147)'):
        # xbmc.sleep(500)

# def Database():
    # changelog = xbmcvfs.translatePath(os.path.join('special://home/addons/plugin.program.downloaderstartup/PY/Changelog/Database_Addons33.txt'))
    # heading = '[B][COLOR orange]Database_Addons33[/COLOR][/B]'
    # f = open(changelog, 'r', encoding='utf-8')
    # lines = f.readlines()
    # announce = ''
    # for line in lines:
        # if not line.strip():
            # break

        # announce += line
    # f.close()
    # textBox(heading, announce)





# def Addons33():
        # choice = xbmcgui.Dialog().yesno('[COLOR orange]Database ~ Addons33[/COLOR]', 'Θέλετε να προχωρήσετε?',
        
                                        # nolabel='[B][COLOR red]Όχι τώρα...[/COLOR][/B]',yeslabel='[B][COLOR lime]Ναι[/COLOR][/B]')

        # if choice == 1: [xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/UpdaterMatrix_16.py")'),
                         
                         # ]

def CheckAll():
    xbmc.executebuiltin('RunScript("special://home/userdata/addon_data/plugin.program.downloader19/delete_files.py")')
    xbmc.sleep(4000)
    xbmc.executebuiltin('RunScript("special://home/userdata/addon_data/plugin.program.downloader19/addons_list_installation.py")')
    xbmc.sleep(15000)
    xbmcgui.Dialog().notification("[B][COLOR orange]Γίνεται έλεγχος...[/COLOR][/B]", "[COLOR red]Παρακαλώ περιμένετε...[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/Pleasewait.png', sound=False)
    xbmc.sleep(20000)
    xbmc.executebuiltin('RunScript("special://home/userdata/addon_data/plugin.program.downloader19/set_setting.py")')


CheckFix()
