import xbmcgui
xbmcgui.Dialog().notification("[B][COLOR orange]They don't always work[/COLOR][/B]", "[COLOR green]Δεν λειτουργούν πάντα...[/COLOR]", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/doestworkalltime.png')
import os, xbmc, xbmcvfs, xbmcgui, xbmcaddon, shutil, glob
# xbmc.sleep(4000)
def list_0():
    funcs = (click_1, click_2, click_3)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]~ Stalker VOD ~[/COLOR][/B]', 
[
 '[COLOR=blue]Stalker Vod Client[/COLOR]',

 '[B][COLOR lime]Stalker Vod Generator[/COLOR][/B]',
 '[COLOR=lime]Προεπιλογές[/COLOR]'



 ])


    if call:
        if call < 0:
            return
        func = funcs[call-3]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.stalkervod/")')


def click_2():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/PVR/list_inside.py")')
    # xbmc.sleep(6000)
   
   
   
   
# def click_3():
    # choice = xbmcgui.Dialog().yesno('[COLOR orange]Stalker VOD[/COLOR]', 'Επιλέξτε Τυχαία αλλαγή[CR]απο [B][COLOR blue]kodibalkan[/COLOR][/B] ή απο [B][COLOR orange]optimus-tv[/COLOR][/B]',
        # nolabel='[B][COLOR orange]optimus-tv[/COLOR][/B]',yeslabel='[B][COLOR blue]kodibalkan[/COLOR][/B]')

    # if choice == 1: xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/PVR/kgenvod.py")')
    
    # if choice == 0: xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/PVR/kgenvod2.py")')
    


def click_3():
    xbmcaddon.Addon('plugin.video.stalkervod').openSettings()
    # xbmc.sleep(4000)
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('Action(Back)')
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(Home)')
    xbmc.sleep(6000)
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.stalkervod/",return)')
    xbmc.sleep(4000)
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/PVR/list_0.py")')




list_0()








    def list_0():
        funcs = (click_1, click_2, click_3)
        call = xbmcgui.Dialog().select('[B][COLOR=orange]~ Stalker VOD ~[/COLOR][/B]', 
    [
     '[COLOR=blue]Stalker Vod Client[/COLOR]',

     '[B][COLOR lime]Stalker Vod Generator[/COLOR][/B]',
     '[COLOR=lime]Προεπιλογές[/COLOR]'



     ])


        if call:
            if call < 0:
                return
            func = funcs[call-3]
            return func()
        else:
            func = funcs[call]
            return func()
        return 



    def click_1():
        xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.stalkervod/")')


    def click_2():
        xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/PVR/list_inside.py")')
    # xbmc.sleep(6000)
   
   
   
   
    # def click_3():
        # choice = xbmcgui.Dialog().yesno('[COLOR orange]Stalker VOD[/COLOR]', 'Επιλέξτε Τυχαία αλλαγή[CR]απο [B][COLOR blue]kodibalkan[/COLOR][/B] ή απο [B][COLOR orange]optimus-tv[/COLOR][/B]',
            # nolabel='[B][COLOR orange]optimus-tv[/COLOR][/B]',yeslabel='[B][COLOR blue]kodibalkan[/COLOR][/B]')

        # if choice == 1: xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/PVR/kgenvod.py")')
    
        # if choice == 0: xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/PVR/kgenvod2.py")')
    


    def click_3():
        xbmcaddon.Addon('plugin.video.stalkervod').openSettings()
        # xbmc.sleep(4000)
        xbmc.executebuiltin('Dialog.Close(all,true)')
        xbmc.executebuiltin('Action(Back)')
        xbmc.executebuiltin('Dialog.Close(all,true)')
        xbmc.executebuiltin('ActivateWindow(Home)')
        xbmc.sleep(6000)
        xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.stalkervod/",return)')
        xbmc.sleep(4000)
        PVR.list_0()

