import xbmc, xbmcgui


def HomeWidgetONOFF():
    funcs = (click_1, click_2)
    call = xbmcgui.Dialog().select('[B][COLOR=green]ON[/COLOR][/B]/[B][COLOR=red]OFF[/COLOR] HomeWidget[/B]', 
['[COLOR=green]ON[/COLOR]',
 '[COLOR=red] OFF[/COLOR]'])



    if call:
        if call < 0:
            return
        func = funcs[call-2]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    choice = xbmcgui.Dialog().yesno('[COLOR orange]Ενεργοποίηση HomeWidget[/COLOR]', 'Ενεργοποίηση HomeWidget.[CR]Για να συνεχίσετε πατήστε [B][COLOR green]HomeWidget ON[/COLOR][/B][CR]και περιμένετε...',
                                    nolabel='[B][COLOR white]Όχι τώρα...[/COLOR][/B]',yeslabel='[B][COLOR green]HomeWidget ON[/COLOR][/B]')

    if choice == 1: [xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/UpdaterMatrix_8.py")'),]
    if choice == 0: HomeWidget()

def click_2():
    choice = xbmcgui.Dialog().yesno('[COLOR orange]Απενεργοποίηση HomeWidget[/COLOR]', 'Απενεργοποίηση HomeWidget.[CR]Για να συνεχίσετε πατήστε [B][COLOR red]HomeWidget Off[/COLOR][/B][CR]και περιμένετε...',
                                    nolabel='[B][COLOR white]Όχι τώρα...[/COLOR][/B]',yeslabel='[B][COLOR red]HomeWidget OFF[/COLOR][/B]')

    if choice == 1: [xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/UpdaterMatrix_100.py")'),]
    if choice == 0: HomeWidget()

HomeWidgetONOFF()
