﻿import os, xbmc, xbmcvfs, xbmcgui, xbmcaddon, shutil, glob

def DialogEnableDisabledownloaderstartup():        
        choice = xbmcgui.Dialog().yesno('Build Updates', '[COLOR=green]Ενεργοποίηση[/COLOR] [COLOR=red]Απενεργοποίηση[/COLOR][CR]αυτόματης ενημέρωσης του build...',
                                        nolabel='[COLOR white]Όχι τώρα...[/COLOR]',yeslabel='[COLOR orange]Συνέχεια[/COLOR]')
                                        
        if choice == 1: EnableDisabledownloaderstartup()
        if choice == 0: xbmc.executebuiltin('Action(Back)')






def EnableDisabledownloaderstartup():
    funcs = (click_1, click_2)
    call = xbmcgui.Dialog().select('[B]Build Updates[/B]', 
['[COLOR=green]Enable Build Updates[/COLOR]',
 '[COLOR=red]Disable Build Updates[/COLOR]'])
 



    if call:
        if call < 0:
            return
        func = funcs[call-2]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    if xbmc.getCondVisibility('System.AddonIsEnabled({})'.format('service.world.build')):
        xbmcgui.Dialog().notification("[B][COLOR green]World Build Updates[/COLOR][/B]", "[COLOR white]Οι αυτόματες ενημεώσεις του build είναι ήδη ενεργοποιημένες![/COLOR]", icon='special://home/addons/service.World.Build/World.png', sound=True)
        # return
    if not xbmc.getCondVisibility('System.AddonIsEnabled({})'.format('service.world.build')):
        xbmc.executebuiltin('ActivateWindow(10001,"plugin://plugin.program.downloader19/?description&fanart=C%3a%5cPortableApps%5ckodi%5cKodi%20World%5cKodi%5cportable_data%5caddons%5cplugin.program.downloader19%5cfanart.jpg&icon=special%3a%2f%2fhome%2faddons%2fplugin.program.downloader19%2fresources%2fmedia%2fWorld.png&mode=30&name=E%ce%bd%ce%b5%cf%81%ce%b3%ce%bf%cf%80%ce%bf%ce%af%ce%b7%cf%83%ce%b7%20%ce%b1%cf%85%cf%84%cf%8c%ce%bc%ce%b1%cf%84%cf%89%ce%bd%20%ce%b5%ce%bd%ce%b7%ce%bc%ce%b5%cf%81%cf%8e%cf%83%ce%b5%cf%89%ce%bd%20%cf%84%ce%bf%cf%85%20Downloader%20Startup&name2&url&version")')

def click_2():
    if xbmc.getCondVisibility('System.AddonIsEnabled({})'.format('service.world.build')): 
        xbmc.executebuiltin('ActivateWindow(10001,"plugin://plugin.program.downloader19/?description&fanart=C%3a%5cPortableApps%5ckodi%5cKodi%20World%5cKodi%5cportable_data%5caddons%5cplugin.program.downloader19%5cfanart.jpg&icon=special%3a%2f%2fhome%2faddons%2fplugin.program.downloader19%2fresources%2fmedia%2fWorld.png&mode=29&name=%ce%91%cf%80%ce%b5%ce%bd%ce%b5%cf%81%ce%b3%ce%bf%cf%80%ce%bf%ce%af%ce%b7%cf%83%ce%b7%20%ce%b1%cf%85%cf%84%cf%8c%ce%bc%ce%b1%cf%84%cf%89%ce%bd%20%ce%b5%ce%bd%ce%b7%ce%bc%ce%b5%cf%81%cf%8e%cf%83%ce%b5%cf%89%ce%bd%20%cf%84%ce%bf%cf%85%20Downloader%20Startup&name2&url&version")')
    if not xbmc.getCondVisibility('System.AddonIsEnabled({})'.format('service.world.build')): xbmcgui.Dialog().notification("[B][COLOR red]World Build Updates[/COLOR][/B]", "[COLOR white]Οι αυτόματες ενημεώσεις του build είναι ήδη απενεργοποιημένες![/COLOR]", icon='special://home/addons/service.World.Build/World.png', sound=True)

DialogEnableDisabledownloaderstartup()
