def clear_title_mac(txt):
    txt = txt.replace('╠═ၜ✅ ♏️ac ', '').replace('╠═ၜ ✅ ♏️ac ', '').replace('⍟', '').replace('⧼⧽', '').replace('╟≻✮Mᴀᴄ➢ ', '').replace(' Unlimited', '').replace('╠ADRESA ', '').replace('╠•◈𝐌𝐚𝐜 ➤ ', '').replace('├● Mac ➨ ', '').replace('├⭕Mac ➩ ', '').replace('║∘Mᴀᴄ➛ ', '').replace(' addr: ', '')
    txt = txt.replace('╠═▪️Mac ', '').replace('┣❖ ', '').replace('➩', '').replace('╠═▪', '').replace('𝗠𝗮𝗰 ➤ ', '').replace('🎲𝐌𝐀𝐂➤', '').replace('𝐌𝐀𝐂', '')
    txt = txt.replace('🎲', '').replace('➤', '').replace('║┗⪼ ', '').replace('<br />', ',').replace('<p>', '').replace('╠', '')
    txt = txt.replace('╠═▪️Mac ➩', '').replace('🔑 ', '').replace('Mac : ', '').replace('║∘Mᴀᴄ➛ ', ',').replace('╠•◈𝐌𝐚𝐜 ➤ ', '')
    txt = txt.replace('╟≻✮Mᴀᴄ➢ ', '').replace('║┗⪼ ', '').replace('𝗠𝗮𝗰 ➤ ', '').replace('✅ ', '').replace('&#8211;', '')
    txt = txt.replace('Mac : ', '').replace('Mac: ', '').replace('MAC: ', '').replace('MAC : ', '').replace('MAC ', '').replace('MAC', '').replace('Mac', '')
    txt = txt.replace(' ', '').replace('✮', '').replace('╟≻', '').replace('╠', '').replace('║', '').replace('╠═', '')
    txt = txt.replace('•', '').replace('◈', '').replace('➤', '').replace('┗⪼', '').replace('➢', '').replace('∘', '')
    txt = txt.replace('➛', '').replace('𝐌𝐚𝐜', '').replace('⭕', '').replace('├', '').replace('➨', '').replace('➩', '')
    txt = txt.replace('🔑', '').replace('addr', '').replace('❖', '').replace('▪', '').replace('◉', '').replace('│', '')
    txt = txt.replace('Mᴀᴄ', '').replace('🌀', '').replace('❱❱❱', '').replace('≻', '').replace('Ⓜ️', '').replace('●', '')
    txt = txt.replace('»', '').replace('«', '').replace('ADD:', '').replace('【】', '').replace('─', '').replace('🔘', '')
    txt = txt.replace('🟢', '').replace('♏️ac', '').replace('♏️', '').replace('✅', '').replace('ၜ ', '').replace('☑️', '')
    txt = txt.replace('♦️', '').replace('★', '').replace('🅜🅐🅒', '').replace('🅐🅓🅡🅔🅢🅢', '').replace('𝕄𝙰𝙲:', '').replace('ミ', '')
    txt = txt.replace('PORTAL:', '').replace('Panel', '').replace('Real', '').replace('PortalUrl', '').replace('Portal:', '').replace('PORTAL', '')
    txt = txt.replace('REALURL', '').replace('┊', '').replace('⋆', '').replace('💎', '').replace('⣿', '').replace('⚫️', '').replace('》', '').replace('✬', '')
    txt = txt.replace('❖', '').replace('⇥', '').replace('ᴍᴀᴄ', '').replace('┣', '').replace('ADD', '').replace('𝐌𝐀𝐂', '').replace('➢', '')
    return txt

#### TechNEWSology - World Builder####

import os, re, sys, glob, json, time, sqlite3, random, xbmc, xbmcvfs, xbmcgui, xbmcaddon, requests
import urllib.request
from urllib.request import urlopen, Request

SELECT   = '[COLOR deepskyblue]Stalker Vod Client [COLOR white]\u0395\u03c0\u03b9\u03bb\u03bf\u03b3\u03ae :[/COLOR]'
MAC_URL  = '[COLOR white]\u0395\u03c0\u03b9\u03bb\u03bf\u03b3\u03ae MAC-URL:[/COLOR]'
WAIT     = '[COLOR white]   \u0391\u03bd\u03b1\u03bc\u03bf\u03bd\u03ae...[/COLOR]'
WAIT2    = '[B][COLOR orange]\u0391\u03bd\u03b1\u03bc\u03bf\u03bd\u03ae [COLOR lime]\u03c4\u03b7\u03bd \u03c0\u03c1\u03ce\u03c4\u03b7 \u03c6\u03bf\u03c1\u03ac[/COLOR][/B]'
INSTALL  = '[B][COLOR lime]\u03bc\u03ad\u03c7\u03c1\u03b9 \u03c4\u03b7\u03bd \u03b5\u03b3\u03ba\u03b1\u03c4\u03ac\u03c3\u03c4\u03b1\u03c3\u03b7 \u03c4\u03bf\u03c5 \u03c0\u03c1\u03cc\u03c3\u03b8\u03b5\u03c4\u03bf\u03c5 ![/COLOR][/B]'
SET_STAL = '[B][COLOR lime]- \u03a1\u03c5\u03b8\u03bc\u03af\u03c3\u03b5\u03b9\u03c2 Stalker Vod[/COLOR][/B]'
SET_XCOD = '[B][COLOR lime]- \u03a1\u03c5\u03b8\u03bc\u03af\u03c3\u03b5\u03b9\u03c2 X-Codes[/COLOR][/B]'
REST_S   = '[B][COLOR deepskyblue]- \u0395\u03c0\u03b1\u03bd\u03b1\u03c6\u03bf\u03c1\u03ac \u03a0\u03c1\u03bf\u03b5\u03c0\u03b9\u03bb\u03bf\u03b3\u03ce\u03bd Stalker Vod[/COLOR][/B]'
REST_X   = '[B][COLOR white]- \u0395\u03c0\u03b1\u03bd\u03b1\u03c6\u03bf\u03c1\u03ac \u03a0\u03c1\u03bf\u03b5\u03c0\u03b9\u03bb\u03bf\u03b3\u03ce\u03bd X-Codes[/COLOR][/B]'
CANCEL   = '[B][COLOR white]\u0391\u03ba\u03cd\u03c1\u03c9\u03c3\u03b7![/COLOR][/B]'
BACK     = "[B][COLOR lime]<= [COLOR orange]\u03a0\u03af\u03c3\u03c9[/COLOR][/B]"
SELECT_M = '[B][COLOR white]\u0395\u03c0\u03b9\u03bb\u03bf\u03b3\u03ae [COLOR tomato]MAC -> [COLOR lime]00:1A... [COLOR white]:[/COLOR][/B]'
SELECT_U2 = '[B][COLOR white]\u0395\u03c0\u03b9\u03bb\u03bf\u03b3\u03ae [COLOR deepskyblue]URL -> [COLOR lime]http://... [COLOR white]:[/COLOR][/B]'
SELECT_M_U = '[B][COLOR white]\u0395\u03c0\u03b9\u03bb\u03ad\u03be\u03c4\u03b5: [COLOR orange]MAC --> URL[/COLOR][/B]'
PLEASE   = '[COLOR white]\u03a0\u03b1\u03c1\u03b1\u03ba\u03b1\u03bb\u03ce \u03c0\u03b5\u03c1\u03b9\u03bc\u03ad\u03bd\u03b5\u03c4\u03b5...[/COLOR]'
PLEASE2  = '[COLOR white]\u03a0\u03b1\u03c1\u03b1\u03ba\u03b1\u03bb\u03ce \u03c0\u03b5\u03c1\u03b9\u03bc\u03ad\u03bd\u03b5\u03c4\u03b5...[/COLOR]'
RANDOM   = '[B][COLOR lime]\u03a4\u03c5\u03c7\u03b1\u03af\u03b1[/COLOR][/B]'
MANUALLY = '[B][COLOR lime]\u03a7\u03b5\u03b9\u03c1\u03bf\u03ba\u03af\u03bd\u03b7\u03c4\u03b1[/COLOR][/B]'
RANDOM_M = "[B][COLOR lime]\u0395\u03c0\u03b9\u03bb\u03bf\u03b3\u03ae \u03c4\u03c5\u03c7\u03b1\u03af\u03b1\u03c2 MAC[/COLOR][/B]"
SELECT_D = '[B][COLOR white]\u0395\u03c0\u03b9\u03bb\u03bf\u03b3\u03ae \u03b7\u03bc\u03b5\u03c1\u03bf\u03bc\u03b7\u03bd\u03af\u03b1\u03c2:[/COLOR][/B]'
LIST_D   = '[COLOR lime]\u03a0\u03c1\u03b1\u03b3\u03bc\u03b1\u03c4\u03bf\u03c0\u03bf\u03b9\u03ae\u03b8\u03b7\u03ba\u03b5 \u03b1\u03bb\u03bb\u03b1\u03b3\u03ae \u03c4\u03b7\u03c2 \u03bb\u03af\u03c3\u03c4\u03b1\u03c2![/COLOR][CR][COLOR white]\u0391\u03bd \u03b7 \u03bb\u03af\u03c3\u03c4\u03b1 \u03b4\u03b5\u03bd \u03bb\u03b5\u03b9\u03c4\u03bf\u03c5\u03c1\u03b3\u03b5\u03af \u03ae \u03b5\u03bc\u03c6\u03b1\u03bd\u03af\u03c3\u03b5\u03b9 \u03c3\u03c6\u03ac\u03bb\u03bc\u03b1,[CR]\u03b5\u03ba\u03c4\u03b5\u03bb\u03bf\u03cd\u03bc\u03b5 \u03be\u03b1\u03bd\u03ac \u03c4\u03bf [B][COLOR deepskyblue]Stalker Vod [COLOR lime]Generator.[/COLOR][/B][CR][B][COLOR lime]\u0391\u03bd \u03bb\u03b5\u03b9\u03c4\u03bf\u03c5\u03c1\u03b3\u03b5\u03af, \u03c3\u03c5\u03bd\u03b5\u03c7\u03af\u03b6\u03bf\u03c5\u03bc\u03b5 \u03bc\u03b5 \u03c4\u03b7\u03bd \u03c5\u03c0\u03ac\u03c1\u03c7\u03bf\u03c5\u03c3\u03b1...[/COLOR][/B]'
LIST_D_N = '[COLOR lime]\u03a0\u03b1\u03c1\u03b1\u03bc\u03ad\u03bd\u03b5\u03b9 \u03b7 \u03bb\u03af\u03c3\u03c4\u03b1 \u03c0\u03bf\u03c5 \u03c7\u03c1\u03b7\u03c3\u03b9\u03bc\u03bf\u03c0\u03bf\u03b9\u03ae\u03c3\u03b1\u03c4\u03b5 \u03c4\u03b5\u03bb\u03b5\u03c5\u03c4\u03b1\u03af\u03b1![/COLOR][CR][COLOR white]\u0391\u03bd \u03b7 \u03bb\u03af\u03c3\u03c4\u03b1 \u03b4\u03b5\u03bd \u03bb\u03b5\u03b9\u03c4\u03bf\u03c5\u03c1\u03b3\u03b5\u03af \u03ae \u03b5\u03bc\u03c6\u03b1\u03bd\u03af\u03c3\u03b5\u03b9 \u03c3\u03c6\u03ac\u03bb\u03bc\u03b1,[CR]\u03b5\u03ba\u03c4\u03b5\u03bb\u03bf\u03cd\u03bc\u03b5 \u03be\u03b1\u03bd\u03ac \u03c4\u03bf [B][COLOR deepskyblue]Stalker Vod [COLOR lime]Generator.[/COLOR][/B][CR][B][COLOR lime]\u0391\u03bd \u03bb\u03b5\u03b9\u03c4\u03bf\u03c5\u03c1\u03b3\u03b5\u03af, \u03c3\u03c5\u03bd\u03b5\u03c7\u03af\u03b6\u03bf\u03c5\u03bc\u03b5 \u03bc\u03b5 \u03c4\u03b7\u03bd \u03c5\u03c0\u03ac\u03c1\u03c7\u03bf\u03c5\u03c3\u03b1...[/COLOR][/B]'
LIST_D_X = '[COLOR lime]\u03a0\u03b1\u03c1\u03b1\u03bc\u03ad\u03bd\u03b5\u03b9 \u03b7 \u03bb\u03af\u03c3\u03c4\u03b1 \u03c0\u03bf\u03c5 \u03c7\u03c1\u03b7\u03c3\u03b9\u03bc\u03bf\u03c0\u03bf\u03b9\u03ae\u03c3\u03b1\u03c4\u03b5 \u03c4\u03b5\u03bb\u03b5\u03c5\u03c4\u03b1\u03af\u03b1![/COLOR][CR][COLOR white]\u0391\u03bd \u03b7 \u03bb\u03af\u03c3\u03c4\u03b1 \u03b4\u03b5\u03bd \u03bb\u03b5\u03b9\u03c4\u03bf\u03c5\u03c1\u03b3\u03b5\u03af \u03ae \u03b5\u03bc\u03c6\u03b1\u03bd\u03af\u03c3\u03b5\u03b9 \u03c3\u03c6\u03ac\u03bb\u03bc\u03b1,[CR]\u03b5\u03ba\u03c4\u03b5\u03bb\u03bf\u03cd\u03bc\u03b5 \u03be\u03b1\u03bd\u03ac \u03c4\u03bf [B][COLOR red]XCUI Streams [COLOR lime]Generator.[/COLOR][/B][CR][B][COLOR lime]\u0391\u03bd \u03bb\u03b5\u03b9\u03c4\u03bf\u03c5\u03c1\u03b3\u03b5\u03af, \u03c3\u03c5\u03bd\u03b5\u03c7\u03af\u03b6\u03bf\u03c5\u03bc\u03b5 \u03bc\u03b5 \u03c4\u03b7\u03bd \u03c5\u03c0\u03ac\u03c1\u03c7\u03bf\u03c5\u03c3\u03b1...[/COLOR][/B]'
SELECT_M_U2  = '[B][COLOR white]\u0395\u03c0\u03b9\u03bb\u03ad\u03b3\u03bf\u03c5\u03bc\u03b5 [COLOR orange]Url[/COLOR] \u03ba\u03b1\u03b9 \u03ad\u03c0\u03b5\u03b9\u03c4\u03b1 [COLOR orange]Mac[/COLOR][/B]'
SELECT_M_N   = '[B][COLOR white]\u0395\u03c0\u03b9\u03bb\u03ad\u03b3\u03bf\u03c5\u03bc\u03b5 [COLOR orange]Url[/COLOR] \u03ba\u03b1\u03b9 \u03ad\u03c0\u03b5\u03b9\u03c4\u03b1 [COLOR orange]Mac[/COLOR] \u03b1\u03bd \u03b4\u03b5\u03bd \u03bb\u03b5\u03b9\u03c4\u03bf\u03c5\u03c1\u03b3\u03b5\u03af[/COLOR][/B]'
SAME         = '[B]=> \u03a3\u03c5\u03bd\u03b5\u03c7\u03af\u03c3\u03c4\u03b5 \u03bc\u03b5 \u03c4\u03b7\u03bd \u03af\u03b4\u03b9\u03b1 [COLOR lime]\u039b\u03af\u03c3\u03c4\u03b1...[/COLOR][/B]'

user_agent      = 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.101 Safari/537.36'
addon_data_path = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.video.stalkervod')
addon_id        = 'plugin.video.stalkervod'
addon_mac_id    = 'plugin.video.macvod'
addon_xc_id     = 'plugin.video.xcodes'
addon_iptvxc_id = 'plugin.video.iptvxc'
icon            = 'special://home/addons/plugin.video.stalkervod/resources/media/icon.png'
icon_build      = 'special://home/addons/skin.19MatrixWorld/resources/icon.png'
icon_xcodes     = 'special://home/addons/plugin.video.xcodes/icon.png'
icon_macvod     = 'special://home/addons/plugin.video.macvod/icon.png'
icon_iptvxc     = 'special://home/addons/plugin.video.iptvxc/icon.png'
dp = xbmcgui.Dialog()
BG = xbmcgui.DialogProgressBG()


if xbmc.getCondVisibility('System.HasAddon({})'.format(addon_id)):
    addon_st_vod       = xbmcaddon.Addon(addon_id)
    setting_st_vod     = addon_st_vod.getSetting
    setting_set_st_vod = addon_st_vod.setSetting
else:
    BG.create('[B]\u0388\u03bd\u03b1\u03c1\u03be\u03b7 \u03b4\u03b9\u03b1\u03b4\u03b9\u03ba\u03b1\u03c3\u03af\u03b1\u03c2[/B]', '\u0395\u03b3\u03ba\u03b1\u03c4\u03ac\u03c3\u03c4\u03b1\u03c3\u03b7\u03c2 \u03c0\u03c1\u03cc\u03c3\u03b8\u03b5\u03c4\u03c9\u03bd...')
    BG.update(2, '[B]\u0388\u03bd\u03b1\u03c1\u03be\u03b7 \u03b4\u03b9\u03b1\u03b4\u03b9\u03ba\u03b1\u03c3\u03af\u03b1\u03c2[/B]', '\u0395\u03b3\u03ba\u03b1\u03c4\u03ac\u03c3\u03c4\u03b1\u03c3\u03b7\u03c2 \u03c0\u03c1\u03cc\u03c3\u03b8\u03b5\u03c4\u03c9\u03bd...')
    xbmc.sleep(2000)

    xbmcgui.Dialog().notification(WAIT2, INSTALL, '', sound=False)
    xbmc.executebuiltin('InstallAddon({})'.format(addon_id))
    xbmc.executebuiltin('RunPlugin(plugin://plugin.program.downloader19/?url=https%3A%2F%2Fgithub.com%2FTechNEWSologyBuilder%2FUpdater%2Fraw%2Fmain%2FSettings_StalkerVOD.zip&mode=9)')
    BG.update(5, '[B]\u0388\u03bd\u03b1\u03c1\u03be\u03b7 \u03b4\u03b9\u03b1\u03b4\u03b9\u03ba\u03b1\u03c3\u03af\u03b1\u03c2[/B]', '\u0391\u03bd\u03b1\u03bc\u03bf\u03bd\u03ae \u03c0\u03c1\u03bf\u03c2 \u03bf\u03bb\u03bf\u03ba\u03bb\u03ae\u03c1\u03c9\u03c3\u03b7...')
    xbmc.sleep(1000)
    if xbmc.getCondVisibility("Window.isVisible(yesnodialog)"):
        xbmc.executebuiltin('SendClick(11)')
    BG.update(20, '[B]\u0388\u03b3\u03ba\u03b1\u03c4\u03ac\u03c3\u03c4\u03b1\u03c3\u03b7 \u03c0\u03c1\u03cc\u03c3\u03b8\u03b5\u03c4\u03bf\u03c5[/B]', '[COLOR deepskyblue]Stalker Vod...[/COLOR]')
    xbmc.sleep(5000)
    addon_st_vod       = xbmcaddon.Addon(addon_id)
    setting_st_vod     = addon_st_vod.getSetting
    setting_set_st_vod = addon_st_vod.setSetting
    BG.update(40, '[B]\u03a3\u03c5\u03bd\u03ad\u03c7\u03b5\u03b9\u03b1 \u03b4\u03b9\u03b1\u03b4\u03b9\u03ba\u03b1\u03c3\u03af\u03b1\u03c2[/B]', '\u0391\u03bd\u03b1\u03bc\u03bf\u03bd\u03ae \u03c0\u03c1\u03bf\u03c2 \u03bf\u03bb\u03bf\u03ba\u03bb\u03ae\u03c1\u03c9\u03c3\u03b7...')
    xbmc.sleep(5000)
    BG.update(50, '[B]\u03a3\u03c5\u03bd\u03ad\u03c7\u03b5\u03b9\u03b1 \u03b4\u03b9\u03b1\u03b4\u03b9\u03ba\u03b1\u03c3\u03af\u03b1\u03c2[/B]', '\u0391\u03bd\u03b1\u03bc\u03bf\u03bd\u03ae \u03bb\u03af\u03b3\u03bf \u03b1\u03ba\u03cc\u03bc\u03b7...')
    xbmc.sleep(3000)

if xbmc.getCondVisibility('System.HasAddon({})'.format(addon_mac_id)):
    addon_mac_vod       = xbmcaddon.Addon(addon_mac_id)
    setting_mac_vod     = addon_mac_vod.getSetting
    setting_set_mac_vod = addon_mac_vod.setSetting
else:
    xbmcgui.Dialog().notification(WAIT2, INSTALL, '', sound=False)
    xbmc.executebuiltin('InstallAddon({})'.format(addon_mac_id))
    xbmc.executebuiltin('RunPlugin(plugin://plugin.program.downloader19/?url=https%3A%2F%2Fgithub.com%2FTechNEWSologyBuilder%2FUpdater%2Fraw%2Fmain%2FSettings_MACVOD.zip&mode=9)')
    xbmc.sleep(1000)
    if xbmc.getCondVisibility("Window.isVisible(yesnodialog)"):
        xbmc.executebuiltin('SendClick(11)')
    xbmc.sleep(5000)

if xbmc.getCondVisibility('System.HasAddon({})'.format(addon_xc_id)):
    addon_xcod       = xbmcaddon.Addon(addon_xc_id)
    setting_xcod     = addon_xcod.getSetting
    setting_set_xcod = addon_xcod.setSetting

if xbmc.getCondVisibility('System.HasAddon({})'.format('plugin.video.iptvxc')):
    addon_iptvxc       = xbmcaddon.Addon(addon_iptvxc_id)
    setting_iptvxc     = addon_iptvxc.getSetting
    setting_set_iptvxc = addon_iptvxc.setSetting
else:
    xbmcgui.Dialog().notification(WAIT2, INSTALL, '', sound=False)
    xbmc.executebuiltin('InstallAddon({})'.format('plugin.video.iptvxc'))
    xbmc.executebuiltin('RunPlugin(plugin://plugin.program.downloader19/?url=https%3A%2F%2Fgithub.com%2FTechNEWSologyBuilder%2FUpdater%2Fraw%2Fmain%2FSettings_XCUI.zip&mode=9)')
    xbmc.sleep(1000)
    if xbmc.getCondVisibility("Window.isVisible(yesnodialog)"):
        xbmc.executebuiltin('SendClick(11)')
    BG.update(65, '[B]\u0388\u03b3\u03ba\u03b1\u03c4\u03ac\u03c3\u03c4\u03b1\u03c3\u03b7 \u03c0\u03c1\u03cc\u03c3\u03b8\u03b5\u03c4\u03bf\u03c5[/B]', '[COLOR red]XCUI Streams...[/COLOR]')
    xbmc.sleep(5000)
    BG.update(95, '[B]\u03a3\u03c5\u03bd\u03ad\u03c7\u03b5\u03b9\u03b1 \u03b4\u03b9\u03b1\u03b4\u03b9\u03ba\u03b1\u03c3\u03af\u03b1\u03c2[/B]', '\u0391\u03bd\u03b1\u03bc\u03bf\u03bd\u03ae \u03c0\u03c1\u03bf\u03c2 \u03bf\u03bb\u03bf\u03ba\u03bb\u03ae\u03c1\u03c9\u03c3\u03b7...')
    xbmc.sleep(2000)
    BG.update(100, '[B]\u039f\u03bb\u03bf\u03ba\u03bb\u03b7\u03c1\u03ce\u03b8\u03b7\u03ba\u03b5 \u03bc\u03b5 \u03b5\u03c0\u03b9\u03c4\u03c5\u03c7\u03af\u03b1![/B]', '[COLOR lime]\u038c\u03bb\u03b1 \u0388\u03c4\u03bf\u03b9\u03bc\u03b1![/COLOR]')
    xbmc.sleep(3000)
    BG.close()


if os.name == 'r':
    portable_data_path = os.path.join(os.getcwd(), 'portable_data')
    if os.path.isdir(portable_data_path):
        settings_path = os.path.join(portable_data_path, 'userdata', 'addon_data', addon_id, 'settings.xml')
    else:
        settings_path = os.path.join(os.getenv('APPDATA'), 'Kodi', 'userdata', 'addon_data', addon_id, 'settings.xml')
else:
    settings_path = os.path.join(xbmcvfs.translatePath('special://profile/addon_data'), addon_id, 'settings.xml')

class PVRMac:
    def pvr_client():
        dp = xbmcgui.Dialog()
        select = dp.select('[B][COLOR lime]Generator IPTV List[/COLOR][/B]',
                          [SAME,                                                                  # 0 
                           '[B][COLOR deepskyblue]Stalker Vod Client[/COLOR][/B] - StbEmu codes', # 1 
                           '[B][COLOR red]XCUI Streams[/COLOR][/B] - Xtream codes'])             # 2 
                           # '[B][COLOR deeppink]Mac Vod Client[/COLOR][/B] - Xtream codes'])       # 3 

        if select == 0:
            addon_iptvxc       = xbmcaddon.Addon(addon_iptvxc_id)
            setting_iptvxc     = addon_iptvxc.getSetting
            setting_set_iptvxc = addon_iptvxc.setSetting
            group_same = dp.select(SELECT,
                                  [BACK,
                                   '[B][COLOR lime]=> Stalker Vod Client[/COLOR][/B] (\u039f \u0394\u03b9\u03b1\u03ba\u03bf\u03bc\u03b9\u03c3\u03c4\u03ae\u03c2 \u03c3\u03b1\u03c2)...',
                                   '[COLOR white]Server :[/COLOR] ' + '[COLOR gray]'+setting_st_vod ("server_address")+'[/COLOR]',
                                   '[COLOR white]Mac    :[/COLOR] ' + '[COLOR gray]'+setting_st_vod ("mac_address")+'[/COLOR]',
                                   '',
                                   '[B][COLOR red]=> XCUI Streams[/COLOR][/B] (\u039f \u0394\u03b9\u03b1\u03ba\u03bf\u03bc\u03b9\u03c3\u03c4\u03ae\u03c2 \u03c3\u03b1\u03c2)...',
                                   'Dns      : ' + '[COLOR gray]'+ setting_iptvxc ("DNS")+'[/COLOR]',
                                   'Username : ' + '[COLOR gray]'+ setting_iptvxc ("Username")+'[/COLOR]',
                                   'Password : ' + '[COLOR gray]'+ setting_iptvxc ("Password")+'[/COLOR]',
                                   'URL M3u List : [COLOR gray]'+ setting_iptvxc ("listam3u")+'[/COLOR]',
                                   '',
                                   '[B][COLOR deeppink]=> Mac Vod Client[/COLOR][/B] (\u039f \u0394\u03b9\u03b1\u03ba\u03bf\u03bc\u03b9\u03c3\u03c4\u03ae\u03c2 \u03c3\u03b1\u03c2)...',
                                   'Portal   : ' + '[COLOR gray]'+ setting_mac_vod ("portalxc")+'[/COLOR]',
                                   'Username : ' + '[COLOR gray]'+ setting_mac_vod ("usernamexc")+'[/COLOR]',
                                   'Password : ' + '[COLOR gray]'+ setting_mac_vod ("passxc")+'[/COLOR]',
                                   'M3u : [COLOR gray]'+setting_mac_vod ("listam3u")+'[/COLOR]',
                                   'M3u2 : [COLOR gray]'+setting_mac_vod ("listam3u2")+'[/COLOR]',
                            #      'M3u3 : [COLOR gray]'+setting_mac_vod ("listam3u3")+'[/COLOR]',
                                   '[B][COLOR cyan]URL[/COLOR][/B] M3u List : [COLOR gray]'+setting_mac_vod ("listam3u3")+'[/COLOR]'])

            if group_same   == 0: return PVRMac.pvr_client()

            elif group_same == 1:
                if not xbmc.getCondVisibility('System.HasAddon({})'.format('plugin.video.stalkervod')):
                    xbmcgui.Dialog().notification(WAIT2, INSTALL, '', sound=False)
                    xbmc.executebuiltin('InstallAddon({})'.format('plugin.video.stalkervod'))
                    xbmc.executebuiltin('RunPlugin(plugin://plugin.program.downloader19/?url=https%3A%2F%2Fgithub.com%2FTechNEWSologyBuilder%2FUpdater%2Fraw%2Fmain%2FSettings_StalkerVOD.zip&mode=9)')
                    xbmc.sleep(1000)
                    if xbmc.getCondVisibility("Window.isVisible(yesnodialog)"):
                        xbmc.executebuiltin('SendClick(11)')
                    xbmc.sleep(10000)
                PVRMac.list_Dialog(), PVRMac.openStalker(), PVRMac.list_error()

            elif group_same == 2:
                keyb = xbmc.Keyboard(setting_st_vod ('server_address'), 'Server address: http://....')
                keyb.doModal()
                if (keyb.isConfirmed()):
                    search = keyb.getText()
                    setting_set_st_vod('server_address', '%s' % search)

                keyb = xbmc.Keyboard(setting_st_vod ('mac_address'), 'Mac address: 00:1A:....')
                keyb.doModal()
                if (keyb.isConfirmed()):
                    search = keyb.getText()
                    setting_set_st_vod('mac_address', '%s' % search)
                    PVRMac.list_Dialog(), PVRMac.openStalker(), PVRMac.list_error()

            elif group_same == 3:
                keyb = xbmc.Keyboard('', 'Mac address: 00:1A:....')
                keyb.doModal()
                if (keyb.isConfirmed()):
                    search = keyb.getText()
                    setting_set_st_vod('mac_address', '%s' % search)
                    PVRMac.list_Dialog(), PVRMac.openStalker(), PVRMac.list_error()

            elif group_same == 5: PVRMac.list_Dialog_xc(), PVRMac.openXCUI(), PVRMac.list_error_xc()

            elif group_same == 6:
                keyb = xbmc.Keyboard(setting_iptvxc ('DNS'), '\u0395\u03b9\u03c3\u03ac\u03b3\u03b5\u03c4\u03b5 DNS...')
                keyb.doModal()
                if (keyb.isConfirmed()):
                    search = keyb.getText()
                    setting_set_iptvxc('DNS', '%s' % search)

                keyb = xbmc.Keyboard(setting_iptvxc ('Username'), '\u0395\u03b9\u03c3\u03ac\u03b3\u03b5\u03c4\u03b5 Username...')
                keyb.doModal()
                if (keyb.isConfirmed()):
                    search = keyb.getText()
                    setting_set_iptvxc('Username', '%s' % search)

                keyb = xbmc.Keyboard(setting_iptvxc ('Password'), '\u0395\u03b9\u03c3\u03ac\u03b3\u03b5\u03c4\u03b5 Password...')
                keyb.doModal()
                if (keyb.isConfirmed()):
                    search = keyb.getText()
                    setting_set_iptvxc('Password', '%s' % search)
                    PVRMac.list_Dialog_xc(), PVRMac.openXCUI(), PVRMac.list_error_xc()

            elif group_same == 7:
                keyb = xbmc.Keyboard(setting_iptvxc ('Username'), '\u0395\u03b9\u03c3\u03ac\u03b3\u03b5\u03c4\u03b5 Username...')
                keyb.doModal()
                if (keyb.isConfirmed()):
                    search = keyb.getText()
                    setting_set_iptvxc('Username', '%s' % search)

                keyb = xbmc.Keyboard(setting_iptvxc ('Password'), '\u0395\u03b9\u03c3\u03ac\u03b3\u03b5\u03c4\u03b5 Password...')
                keyb.doModal()
                if (keyb.isConfirmed()):
                    search = keyb.getText()
                    setting_set_iptvxc('Password', '%s' % search)
                    PVRMac.list_Dialog_xc(), PVRMac.openXCUI(), PVRMac.list_error_xc()

            elif group_same == 8:
                keyb = xbmc.Keyboard(setting_iptvxc ('Password'), '\u0395\u03b9\u03c3\u03ac\u03b3\u03b5\u03c4\u03b5 Password...')
                keyb.doModal()
                if (keyb.isConfirmed()):
                    search = keyb.getText()
                    setting_set_iptvxc('Password', '%s' % search)
                    PVRMac.list_Dialog_xc(), PVRMac.openXCUI(), PVRMac.list_error_xc()

            elif group_same == 9:
                keyb = xbmc.Keyboard(setting_iptvxc ('listam3u'), '\u0395\u03b9\u03c3\u03ac\u03b3\u03b5\u03c4\u03b5 URL M3u3 List...')
                keyb.doModal()
                if (keyb.isConfirmed()):
                    search = keyb.getText()
                    setting_set_iptvxc('listam3u', '%s' % search)
                    m1 = re.compile('h(.*?)username=.*?&password=.*?&type=.*?', re.DOTALL).findall(search)
                    m2 = re.compile('h.*?username=(.*?)&password=.*?&type=.*?', re.DOTALL).findall(search)
                    m3 = re.compile('h.*?username=.*?&password=(.*?)&type=.*?', re.DOTALL).findall(search)
                    username = ''
                    password = ''
                    for portal in m1:
                        portal = portal.replace('/get.php?', '')
                        portal = 'h' + portal
                    for user in m2:
                        username = user
                    for pas in m3:
                        password = pas
                    settings_path = os.path.join(xbmcvfs.translatePath('special://profile/addon_data'), addon_iptvxc_id, 'settings.xml')
                    with open(settings_path, 'r') as f: settings_xml = f.read()
                    settings_xml = re.sub('<setting id="DNS">.*?</setting>', '<setting id="DNS">{}</setting>'.format(portal), settings_xml)
                    settings_xml = re.sub('<setting id="DNS" default="true" />.*?', '<setting id="DNS">{}</setting>'.format(portal), settings_xml)
                    settings_xml = re.sub('<setting id="DNS" default="true">.*?</setting>', '<setting id="DNS" default="true">{}</setting>'.format(portal), settings_xml)

                    settings_xml = re.sub('<setting id="Username">.*?</setting>', '<setting id="Username">{}</setting>'.format(username), settings_xml)
                    settings_xml = re.sub('<setting id="Username" default="true" />.*?', '<setting id="Username">{}</setting>'.format(username), settings_xml)
                    settings_xml = re.sub('<setting id="Username" default="true">.*?</setting>', '<setting id="Username" default="true">{}</setting>'.format(username), settings_xml)

                    settings_xml = re.sub('<setting id="Password">.*?</setting>', '<setting id="Password">{}</setting>'.format(password), settings_xml)
                    settings_xml = re.sub('<setting id="Password" default="true" />.*?', '<setting id="Password">{}</setting>'.format(password), settings_xml)
                    settings_xml = re.sub('<setting id="Password" default="true">.*?</setting>', '<setting id="Password" default="true">{}</setting>'.format(password), settings_xml)
                    with open(settings_path, 'w') as f: f.write(settings_xml)

                    PVRMac.list_Dialog_xc()
                    PVRMac.openXCUI()
                    PVRMac.list_error_xc()

            elif group_same == 11: PVRMac.list_Dialog_mac(), PVRMac.openMacVod(), PVRMac.list_error()

            elif group_same == 12:
                keyb = xbmc.Keyboard(setting_mac_vod ('portalxc'), '\u0395\u03b9\u03c3\u03ac\u03b3\u03b5\u03c4\u03b5 Portal...')
                keyb.doModal()
                if (keyb.isConfirmed()):
                    search = keyb.getText()
                    setting_set_mac_vod('portalxc', '%s' % search)

                keyb = xbmc.Keyboard(setting_mac_vod ('usernamexc'), '\u0395\u03b9\u03c3\u03ac\u03b3\u03b5\u03c4\u03b5 Username...')
                keyb.doModal()
                if (keyb.isConfirmed()):
                    search = keyb.getText()
                    setting_set_mac_vod('usernamexc', '%s' % search)
                #    PVRMac.list_Dialog_mac(), PVRMac.openMacVod(), PVRMac.list_error()

                keyb = xbmc.Keyboard(setting_mac_vod ('passxc'), '\u0395\u03b9\u03c3\u03ac\u03b3\u03b5\u03c4\u03b5 Password...')
                keyb.doModal()
                if (keyb.isConfirmed()):
                    search = keyb.getText()
                    setting_set_mac_vod('passxc', '%s' % search)
                    PVRMac.list_Dialog_mac(), PVRMac.openMacVod(), PVRMac.list_error()

            elif group_same == 13:
                keyb = xbmc.Keyboard(setting_mac_vod ('usernamexc'), '\u0395\u03b9\u03c3\u03ac\u03b3\u03b5\u03c4\u03b5 Username...')
                keyb.doModal()
                if (keyb.isConfirmed()):
                    search = keyb.getText()
                    setting_set_mac_vod('usernamexc', '%s' % search)
                #    PVRMac.list_Dialog(), PVRMac.openMacVod(), PVRMac.list_error()

                keyb = xbmc.Keyboard(setting_mac_vod ('passxc'), '\u0395\u03b9\u03c3\u03ac\u03b3\u03b5\u03c4\u03b5 Password...')
                keyb.doModal()
                if (keyb.isConfirmed()):
                    search = keyb.getText()
                    setting_set_mac_vod('passxc', '%s' % search)
                    PVRMac.list_Dialog_mac(), PVRMac.openMacVod(), PVRMac.list_error()

            elif group_same == 14:
                keyb = xbmc.Keyboard(setting_mac_vod ('passxc'), '\u0395\u03b9\u03c3\u03ac\u03b3\u03b5\u03c4\u03b5 Password...')
                keyb.doModal()
                if (keyb.isConfirmed()):
                    search = keyb.getText()
                    setting_set_mac_vod('passxc', '%s' % search)
                    PVRMac.list_Dialog_mac(), PVRMac.openMacVod(), PVRMac.list_error()

            elif group_same == 15:
                keyb = xbmc.Keyboard(setting_mac_vod ('listam3u'), '\u0395\u03b9\u03c3\u03ac\u03b3\u03b5\u03c4\u03b5 M3u List...')
                keyb.doModal()
                if (keyb.isConfirmed()):
                    search = keyb.getText()
                    setting_set_mac_vod('listam3u', '%s' % search)
                    PVRMac.list_Dialog(), PVRMac.openMacVod_m3u(), PVRMac.list_error()

            elif group_same == 16:
                keyb = xbmc.Keyboard(setting_mac_vod ('listam3u2'), '\u0395\u03b9\u03c3\u03ac\u03b3\u03b5\u03c4\u03b5 M3u2 List...')
                keyb.doModal()
                if (keyb.isConfirmed()):
                    search = keyb.getText()
                    setting_set_mac_vod('listam3u2', '%s' % search)
                    PVRMac.list_Dialog(), PVRMac.openMacVod_m3u(), PVRMac.list_error()

            elif group_same == 17:
                keyb = xbmc.Keyboard(setting_mac_vod ('listam3u3'), '\u0395\u03b9\u03c3\u03ac\u03b3\u03b5\u03c4\u03b5 URL M3u3 List...')
                keyb.doModal()
                if (keyb.isConfirmed()):
                    search = keyb.getText()
                    setting_set_mac_vod('listam3u3', '%s' % search)
                    m1 = re.compile('h(.*?)username=.*?&password=.*?&type=.*?', re.DOTALL).findall(search)
                    m2 = re.compile('h.*?username=(.*?)&password=.*?&type=.*?', re.DOTALL).findall(search)
                    m3 = re.compile('h.*?username=.*?&password=(.*?)&type=.*?', re.DOTALL).findall(search)
                    username = ''
                    password = ''
                    for portal in m1:
                        portal = portal.replace('/get.php?', '')
                        portal = 'h' + portal
                    for user in m2:
                        username = user
                    for pas in m3:
                        password = pas
                    settings_path = os.path.join(xbmcvfs.translatePath('special://profile/addon_data'), addon_mac_id, 'settings.xml')
                    with open(settings_path, 'r') as f: settings_xml = f.read()
                    settings_xml = re.sub('<setting id="portalxc">.*?</setting>', '<setting id="portalxc">{}</setting>'.format(portal), settings_xml)
                    settings_xml = re.sub('<setting id="portalxc" default="true">.*?</setting>', '<setting id="portalxc">{}</setting>'.format(portal), settings_xml)
                    settings_xml = re.sub('<setting id="portalxc" default="true" />.*?', '<setting id="portalxc">{}</setting>'.format(portal), settings_xml)

                    settings_xml = re.sub('<setting id="usernamexc">.*?</setting>', '<setting id="usernamexc">{}</setting>'.format(username), settings_xml)
                    settings_xml = re.sub('<setting id="usernamexc" default="true">.*?</setting>', '<setting id="usernamexc">{}</setting>'.format(username), settings_xml)
                    settings_xml = re.sub('<setting id="usernamexc" default="true" />.*?', '<setting id="usernamexc">{}</setting>'.format(username), settings_xml)

                    settings_xml = re.sub('<setting id="passxc">.*?</setting>', '<setting id="passxc">{}</setting>'.format(password), settings_xml)
                    settings_xml = re.sub('<setting id="passxc" default="true">.*?</setting>', '<setting id="passxc">{}</setting>'.format(password), settings_xml)
                    settings_xml = re.sub('<setting id="passxc" default="true" />.*?', '<setting id="passxc">{}</setting>'.format(password), settings_xml)

                    with open(settings_path, 'w') as f: f.write(settings_xml)

                    PVRMac.list_Dialog()
                    PVRMac.openMacVod()
                    PVRMac.list_error()


            else: return PVRMac.pvr_client()

        elif select == 1:
            if not xbmc.getCondVisibility('System.HasAddon({})'.format(addon_id)):
                xbmcgui.Dialog().notification(WAIT2, INSTALL, '', sound=False)
                xbmc.executebuiltin('InstallAddon({})'.format(addon_id))
                xbmc.executebuiltin('RunPlugin(plugin://plugin.program.downloader19/?url=https%3A%2F%2Fgithub.com%2FTechNEWSologyBuilder%2FUpdater%2Fraw%2Fmain%2FSettings_StalkerVOD.zip&mode=9)')
                xbmc.sleep(1000)
                if xbmc.getCondVisibility("Window.isVisible(yesnodialog)"):
                    xbmc.executebuiltin('SendClick(11)')
                xbmc.sleep(10000)
            group_stalker = dp.select(SELECT,
                                     [BACK,
                                      SAME,
                                      '[B][COLOR orange]IPTV Links [/COLOR][/B][COLOR lime](Site 1)[/COLOR]',
                                      '[B][COLOR deepskyblue]IPTV Links [/COLOR][/B][COLOR lime](Site 2)[/COLOR]',
                                      '[B][COLOR deeppink]IPTV Links [/COLOR][/B][COLOR lime](Site 3)[/COLOR]',
                                      '[B][COLOR tomato]IPTV Links [/COLOR][/B][COLOR lime](Site 4)[/COLOR]',
                                      '[B][COLOR lime]MAC [COLOR orange]List URL [COLOR deepskyblue]1[/COLOR][/B]',
                                      # '[B][COLOR lime]MAC [COLOR orange]List URL [COLOR blue]2[/COLOR][/B]',
                                      # '[B][COLOR lime]MAC [COLOR orange]List URL [COLOR blue]3[/COLOR][/B]',
                                #      '[B][COLOR lime]MAC [COLOR orange]List URL [COLOR deepskyblue]4[/COLOR][/B]',
                                #      '[B][COLOR lime]MAC [COLOR orange]List URL [COLOR deepskyblue]5[/COLOR][/B]',
                                      SET_STAL,
                                      '\u03a7\u03b5\u03b9\u03c1\u03bf\u03ba\u03af\u03bd\u03b7\u03c4\u03b7 \u03b1\u03bb\u03bb\u03b1\u03b3\u03ae => [B][COLOR deepskyblue]Server :[/COLOR][/B] ' + '[COLOR gray]'+setting_st_vod ("server_address")+'[/COLOR]',
                                      '\u03a7\u03b5\u03b9\u03c1\u03bf\u03ba\u03af\u03bd\u03b7\u03c4\u03b7 \u03b1\u03bb\u03bb\u03b1\u03b3\u03ae => [B][COLOR tomato]Mac    :[/COLOR][/B] ' + '[COLOR gray]'+setting_st_vod ("mac_address")+'[/COLOR]',
                                      REST_S])
            if group_stalker   == 0: return PVRMac.pvr_client()
            elif group_stalker == 1: PVRMac.list_Dialog(), PVRMac.openStalker(), PVRMac.list_error()
            elif group_stalker == 2: return PVRMac.iptv()
            elif group_stalker == 3: return PVRMac.iptv_tv()
            elif group_stalker == 4: return PVRMac.iptv_stb_stalker()
            elif group_stalker == 5: return PVRMac.iptv_stb()
            elif group_stalker == 6: url = 'https://pastebin.com/raw/dR8WfK5J'    #####  kvod Last
            # elif group_stalker == 6: url = 'https://bit.ly/4bLX0A3'               #####  kgen W(4)
            # elif group_stalker == 8: url = 'https://bit.ly/4aTEzs3'               #####  kgen W 
        #    elif group_stalker == 8: url = 'https://bit.ly/3IwIUpn'               #####  balkan 1
        #    elif group_stalker == 9: url = 'https://bit.ly/42S1L7u'               #####  balkan 2
            elif group_stalker == 7: return xbmcaddon.Addon(addon_id).openSettings()

            elif group_stalker == 8:
                keyb = xbmc.Keyboard(setting_st_vod ('server_address'), 'Server address: http://....')
                keyb.doModal()
                if (keyb.isConfirmed()):
                    search = keyb.getText()
                    setting_set_st_vod('server_address', '%s' % search)

                keyb = xbmc.Keyboard(setting_st_vod ('mac_address'), 'Mac address: 00:1A:....')
                keyb.doModal()
                if (keyb.isConfirmed()):
                    search = keyb.getText()
                    setting_set_st_vod('mac_address', '%s' % search)
                    PVRMac.list_Dialog(), PVRMac.openStalker(), PVRMac.list_error()

            elif group_stalker == 11: 
                keyb = xbmc.Keyboard('', 'Mac address: 00:1A:....')
                keyb.doModal()
                if (keyb.isConfirmed()):
                    search = keyb.getText()
                    setting_set_st_vod('mac_address', '%s' % search)
                    PVRMac.list_Dialog(), PVRMac.openStalker(), PVRMac.list_error()

            elif group_stalker == 12: return xbmc.executebuiltin('RunPlugin(plugin://plugin.program.downloader19/?url=https%3A%2F%2Fgithub.com%2FTechNEWSologyBuilder%2FUpdater%2Fraw%2Fmain%2FSettings_StalkerVOD.zip&mode=9)'), xbmc.sleep(1000), PVRMac.list_Dialog_not(), PVRMac.openStalker(), PVRMac.list_error()

            else: return PVRMac.pvr_client()

            hdrs = {'Referer': url,
                    'User-Agent': user_agent}
            server = requests.get(url, headers=hdrs).text

            mac2=re.findall('(.*?:.*?:.*?:.*?:.*?:.*?..)', server)
            portal = re.findall('=(.*?)=', server)

            mac5 = re.findall('(.*?)=(.*?)=,', server)
            mac_server_login_password_dict = {pair[0]: pair[1:] for pair in mac5}
            chosen_pair = random.choice(list(mac_server_login_password_dict.items()))
            chosen_mac = chosen_pair[0]
            chosen_server = chosen_pair[1][0]

            mac = re.findall('(.*?)=(.*?)=,', server)
            dp = xbmcgui.Dialog()
            sel = dp.select(MAC_URL,
                           [SAME,
                            RANDOM,
                            MANUALLY])

            if sel == 0: PVRMac.list_Dialog_not(), PVRMac.openStalker(), PVRMac.list_error()

            elif sel == 1:
                settings_path = os.path.join(xbmcvfs.translatePath('special://profile/addon_data'), addon_id, 'settings.xml')
                with open(settings_path, 'r') as f: settings_xml = f.read()
                settings_xml = re.sub('<setting id="mac_address">.*?</setting>', '<setting id="mac_address">{}</setting>'.format(chosen_mac), settings_xml)
                settings_xml = re.sub('<setting id="server_address">.*?</setting>', '<setting id="server_address">{}</setting>'.format(chosen_server), settings_xml)
                settings_xml = re.sub('<setting id="mac_address" default="true">.*?</setting>', '<setting id="mac_address" default="true">{}</setting>'.format(chosen_mac), settings_xml)
                settings_xml = re.sub('<setting id="server_address" default="true">.*?</setting>', '<setting id="server_address" default="true">{}</setting>'.format(chosen_server), settings_xml)
                settings_xml = re.sub('<setting id="mac_address" default="true" />.*?', '<setting id="mac_address">{}</setting>'.format(chosen_mac), settings_xml)
                settings_xml = re.sub('<setting id="server_address" default="true" />.*?', '<setting id="server_address">{}</setting>'.format(chosen_server), settings_xml)
                with open(settings_path, 'w') as f: f.write(settings_xml)
                PVRMac.list_Dialog()
                PVRMac.openStalker()
                PVRMac.list_error()

            elif sel == 2:
                newmac=''
                newpor=''
                settings_path = os.path.join(xbmcvfs.translatePath('special://profile/addon_data'), addon_id, 'settings.xml')
                with open(settings_path, 'r') as f: settings_xml = f.read()

                selected = RANDOM_M
                for mc, port in mac:
                    selected = selected + ',' + (mc +' --> '+ port)

                lista_macs = selected.split(",")
                dialog = xbmcgui.Dialog()
                ret = dialog.select(SELECT_M_U,lista_macs)
                if ret <= 0:
                    return PVRMac.pvr_client()
                if ret == 0:
                    with open(settings_path, 'r') as f: settings_xml = f.read()
                    settings_xml = re.sub('<setting id="mac_address">.*?</setting>', '<setting id="mac_address">{}</setting>'.format(chosen_mac), settings_xml)
                    settings_xml = re.sub('<setting id="server_address">.*?</setting>', '<setting id="server_address">{}</setting>'.format(chosen_server), settings_xml)
                    settings_xml = re.sub('<setting id="mac_address" default="true">.*?</setting>', '<setting id="mac_address" default="true">{}</setting>'.format(chosen_mac), settings_xml)
                    settings_xml = re.sub('<setting id="server_address" default="true">.*?</setting>', '<setting id="server_address" default="true">{}</setting>'.format(chosen_server), settings_xml)
                    settings_xml = re.sub('<setting id="mac_address" default="true" />.*?', '<setting id="mac_address">{}</setting>'.format(chosen_mac), settings_xml)
                    settings_xml = re.sub('<setting id="server_address" default="true" />.*?', '<setting id="server_address">{}</setting>'.format(chosen_server), settings_xml)
                    with open(settings_path, 'w') as f: f.write(settings_xml)
                    PVRMac.list_Dialog()
                    PVRMac.openStalker()
                    PVRMac.list_error()

                else:
                    newmac = mac2[ret-1]
                    newpor = portal[ret-1]
                    settings_xml = re.sub('<setting id="mac_address">.*?</setting>', '<setting id="mac_address">{}</setting>'.format(newmac), settings_xml)
                    settings_xml = re.sub('<setting id="server_address">.*?</setting>', '<setting id="server_address">{}</setting>'.format(newpor), settings_xml)
                    settings_xml = re.sub('<setting id="mac_address" default="true">.*?</setting>', '<setting id="mac_address" default="true">{}</setting>'.format(newmac), settings_xml)
                    settings_xml = re.sub('<setting id="server_address" default="true">.*?</setting>', '<setting id="server_address" default="true">{}</setting>'.format(newpor), settings_xml)
                    settings_xml = re.sub('<setting id="mac_address" default="true" />.*?', '<setting id="mac_address" default="true">{}</setting>'.format(newmac), settings_xml)
                    settings_xml = re.sub('<setting id="server_address" default="true" />.*?', '<setting id="server_address" default="true">{}</setting>'.format(newpor), settings_xml)
                    with open(settings_path, 'w') as f: f.write(settings_xml)
                    PVRMac.list_Dialog()
                    PVRMac.openStalker()
                    PVRMac.list_error()

            else:
                return PVRMac.pvr_client()

        elif select == 2:
            if not xbmc.getCondVisibility('System.HasAddon({})'.format('plugin.video.iptvxc')):
                xbmcgui.Dialog().notification(WAIT2, INSTALL, '', sound=False)
                xbmc.executebuiltin('InstallAddon({})'.format('plugin.video.iptvxc'))
                xbmc.executebuiltin('RunPlugin(plugin://plugin.program.downloader19/?url=https%3A%2F%2Fgithub.com%2FTechNEWSologyBuilder%2FUpdater%2Fraw%2Fmain%2FSettings_XCUI.zip&mode=9)')
                xbmc.sleep(1000)
                if xbmc.getCondVisibility("Window.isVisible(yesnodialog)"):
                   xbmc.executebuiltin('SendClick(11)')
                xbmc.sleep(10000)
            return xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/PVR/xclist.py")')

        elif select == 3: return xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/PVR/xlist.py")')

        else: return xbmcgui.Dialog().notification('[B][COLOR lime]Generator IPTV List[/COLOR][/B]', CANCEL , 'special://home/addons/resource.images.alivegr.logos/resources/logos/na2.png')


    def iptv_tv():
        url = 'https://www.tvappapk.com/tag/stb-emu-codes/'
        hdrs = {'Referer': url,
                'User-Agent': user_agent}
        p = requests.get(url, headers=hdrs).text
        m = re.compile('<h2 class=.*?><a href="(.*?)" rel="bookmark">(.*?)</a></h2>', re.DOTALL).findall(p)
        if not m: return xbmcgui.Dialog().notification('[B][COLOR orange]\u0394\u03b5\u03bd \u03b5\u03af\u03bd\u03b1\u03b9 \u03b4\u03b9\u03b1\u03b8\u03ad\u03c3\u03b9\u03bc\u03bf \u03c4\u03bf site[/COLOR][/B]', '[COLOR white]\u0394\u03bf\u03ba\u03b9\u03bc\u03ac\u03c3\u03c4\u03b5 \u03be\u03b1\u03bd\u03ac \u03b1\u03c1\u03b3\u03cc\u03c4\u03b5\u03c1\u03b1![/COLOR]' , icon), PVRMac.pvr_client()
        channels = BACK
        for url, name in m:
            name = name.replace('STB Emu Codes Daily Lists ', '').replace('Stalker Portal mac ', '')
            name = '[B][COLOR deepskyblue]%s[/COLOR][/B]' % name
            url = url.replace('https://www.tvappapk.com/stb-emu-codes-daily-lists-', '').replace('/', '')

            channels = channels + ',' + url
            iptv_links = channels.split(",")

        ret = xbmcgui.Dialog().select(SELECT_D, iptv_links)
        if ret <= 0:
            return PVRMac.pvr_client()
        url_l = iptv_links[ret]
        url_l = 'https://www.tvappapk.com/stb-emu-codes-daily-lists-' + url_l
        hdrs = {'Referer': url_l,
                'User-Agent': user_agent}
        p1 = requests.get(url_l, headers=hdrs).text
        m1 = re.compile('<p><span style="color: #000000;">.*?h(.*?)</span><br/><span style="color: #000000;">.*?00:(.*?)<(.*?)></p>', re.DOTALL).findall(p1)
    #    m1 = re.compile('<span style="color: #000000;">.*?00:(.*?)</span><br/>', re.DOTALL).findall(p1)
        newpor = ''
        newmac = ''
        channels = BACK

        for url, mac1, mac2 in m1:
            url = clear_title_mac(url)
            url = 'h' + url
            url  = '[B][COLOR deepskyblue]%s[/COLOR][/B]' % url
            mac1 = clear_title_mac(mac1)
            mac1 = '00:' + mac1
            mac1 = mac1.replace('</span>', ',').replace('</p><spanstyle="color:#000000;">', '').replace('</p></br><spanstyle="color:#000000;">', '')
            mac2 = clear_title_mac(mac2)

            mac2 = mac2.replace('</span>', ',').replace('</p><spanstyle="color:#000000;">', '').replace('</p></br><spanstyle="color:#000000;">', '')
            mac2 = mac2.replace('<br/><spanstyle="color:#000000;">', '').replace('/span>', '').replace('</span', '').replace('/span', '')

            channels = channels + ',' + url + ',' + mac1 + ',' + mac2 + ','
            iptv_links = channels.split(",")

        ret = xbmcgui.Dialog().select(SELECT_U2, iptv_links)
        if ret <= 0:
            return PVRMac.iptv_tv()
        newpor = iptv_links[ret]
        newpor = newpor.replace('[B][COLOR deepskyblue]', '').replace('[/COLOR][/B]', '')

        with open(settings_path, 'r') as f: settings_xml = f.read()
        settings_xml = re.sub('<setting id="server_address">.*?</setting>', '<setting id="server_address">{}</setting>'.format(newpor), settings_xml)
        settings_xml = re.sub('<setting id="server_address" default="true">.*?</setting>', '<setting id="server_address" default="true">{}</setting>'.format(newpor), settings_xml)
        settings_xml = re.sub('<setting id="server_address" default="true" />.*?', '<setting id="server_address">{}</setting>'.format(newpor), settings_xml)

        with open(settings_path, 'w') as f: f.write(settings_xml)

        xbmcgui.Dialog().notification('[B][COLOR white]\u0395\u03c0\u03b9\u03bb\u03ad\u03b3\u03bf\u03c5\u03bc\u03b5 [COLOR tomato]MAC [COLOR white]\u03c3\u03c4\u03bf \u03b1\u03bd\u03c4\u03af\u03c3\u03c4\u03bf\u03b9\u03c7\u03bf [COLOR deepskyblue]URL[/COLOR][/B]', '[COLOR white]\u03c0\u03bf\u03c5 \u03b5\u03c0\u03b9\u03bb\u03ad\u03be\u03b1\u03bc\u03b5 \u03c0\u03c1\u03b9\u03bd![/COLOR]' , icon)
        xbmc.sleep(1500)
        ret = xbmcgui.Dialog().select(SELECT_M, iptv_links)
        if ret <= 0:
            return PVRMac.iptv_tv()

        newmac = iptv_links[ret]
        with open(settings_path, 'r') as f: settings_xml = f.read()
        settings_xml = re.sub('<setting id="mac_address">.*?</setting>', '<setting id="mac_address">{}</setting>'.format(newmac), settings_xml)
        settings_xml = re.sub('<setting id="mac_address" default="true">.*?</setting>', '<setting id="mac_address" default="true">{}</setting>'.format(newmac), settings_xml)
        settings_xml = re.sub('<setting id="mac_address" default="true" />.*?', '<setting id="mac_address">{}</setting>'.format(newmac), settings_xml)
        with open(settings_path, 'w') as f: f.write(settings_xml)
        PVRMac.list_Dialog()
        PVRMac.openStalker()
        PVRMac.list_error()


    def iptv():
        url = 'https://iptvlinkseuro.blogspot.com/'
        hdrs = {'Referer': url,
                'User-Agent': user_agent}
        p = requests.get(url, headers=hdrs).text
        m = re.compile('''<h3 class='post-title entry-title'>.*?<a href='(.*?)'>.*?<div class='r-snippetized'>\s+(.*?)\s+</div>''', re.DOTALL).findall(p)
        channels = BACK
        for url, name in m:
            name = name.replace('StbEmu codes ', '').replace('Stalker Portal mac ', '')
            name = '[B][COLOR deepskyblue]%s[/COLOR][/B]' % name
            url = url.replace('https://iptvlinkseuro.blogspot.com/', '')
            url2 = url.replace('.html', '').replace('-april', '').replace('-march', '')
            url2 = url2.replace('stbemu-codes-stalker-portal-mac-', '*').replace('stbemu-code-stalker-portal-mac-', ' ')

            channels = channels + ',' + url2
            iptv_links = channels.split(",")

        ret = xbmcgui.Dialog().select(SELECT_D, iptv_links)
        if ret <= 0:
            return PVRMac.pvr_client()
        url_l = iptv_links[ret]
        url_l = url_l.replace('*', 'stbemu-codes-stalker-portal-mac-').replace(' ', 'stbemu-code-stalker-portal-mac-')
        url_l = 'https://iptvlinkseuro.blogspot.com/' + url_l + '.html'

        if '[COLOR deepskyblue]' in url_l:
            xbmcgui.Dialog().notification('[B][COLOR deepskyblue]Stalker Vod[/COLOR][/B]', SELECT_D , icon)
            return PVRMac.iptv()

        hdrs = {'Referer': url_l,
                'User-Agent': user_agent}
        p1 = requests.get(url_l, headers=hdrs).text
        m1 = re.compile('/>(.*?)<b', re.DOTALL).findall(p1)
        newpor = ''
        newmac = ''
        channels = BACK
        for url in m1:
            if 'Stalker Portal' in url: url = '[B][COLOR lime]%s[/COLOR][/B]' % url
            if 'http' in url: url = '[B][COLOR orange]%s[/COLOR][/B]' % url
            url = url.replace(',', '').replace('StbEmu codes ', '').replace('<title>', '').replace('</title>', '')
            url = url.replace('Mac : ', '').replace('Mac: ', '').replace('MAC: ', '').replace('MAC : ', '').replace('MAC ', '').replace('Mac&nbsp;', '').replace('MAC&nbsp;', '').replace('MAC &nbsp;', '').replace('MAC &nbsp; ', '').replace('MAC ', '').replace('&nbsp;', '[B][COLOR lime] -->[/COLOR][/B]')
            url = url.replace('Mac &#10152; ', '')
            url = url.replace('''</a></div><p></p><span><a name='more'></a></span><p style="text-align: left;">''', '')
            url = url.replace('</p><p style="text-align: left;">', '').replace('</p>', '')
            url = url.replace('</div>', '----------------------------------------------------')
            url = url.replace('</a>', '----------------------------------------------------')

            prog = ',' + url
            channels = channels + prog
            lista_ch = channels.split(",")
        ret = xbmcgui.Dialog().select(SELECT_M_N, lista_ch)

        if ret <= 0:
            return PVRMac.iptv()

        newpor = m1[ret-1]
        newmac = m1[ret-1]
        newmac = clear_Title(newmac)
        newpor = newpor.replace('''</a></div><p></p><span><a name='more'></a></span><p style="text-align: left;">''', '')

        if 'http' in newpor:
            newmac = m1[ret]
            newpor = newpor.replace('&nbsp;', '').replace(' ( Adult only )', '')
            newpor = newpor.replace('''</a></div><p></p><span><a name='more'></a></span><p style="text-align: left;">''', '')
            newmac = clear_Title(newmac)
            with open(settings_path, 'r') as f: settings_xml = f.read()
            settings_xml = re.sub('<setting id="mac_address">.*?</setting>', '<setting id="mac_address">{}</setting>'.format(newmac), settings_xml)
            settings_xml = re.sub('<setting id="server_address">.*?</setting>', '<setting id="server_address">{}</setting>'.format(newpor), settings_xml)
            settings_xml = re.sub('<setting id="mac_address" default="true">.*?</setting>', '<setting id="mac_address" default="true">{}</setting>'.format(newmac), settings_xml)
            settings_xml = re.sub('<setting id="server_address" default="true">.*?</setting>', '<setting id="server_address" default="true">{}</setting>'.format(newpor), settings_xml)
            settings_xml = re.sub('<setting id="mac_address" default="true" />.*?', '<setting id="mac_address">{}</setting>'.format(newmac), settings_xml)
            settings_xml = re.sub('<setting id="server_address" default="true" />.*?', '<setting id="server_address">{}</setting>'.format(newpor), settings_xml)
            with open(settings_path, 'w') as f: f.write(settings_xml)
            PVRMac.list_Dialog()
            PVRMac.openStalker()
            PVRMac.list_error()
        else:
            with open(settings_path, 'r') as f: settings_xml = f.read()
            settings_xml = re.sub('<setting id="mac_address">.*?</setting>', '<setting id="mac_address">{}</setting>'.format(newmac), settings_xml)
            settings_xml = re.sub('<setting id="mac_address" default="true">.*?</setting>', '<setting id="mac_address" default="true">{}</setting>'.format(newmac), settings_xml)
            settings_xml = re.sub('<setting id="mac_address" default="true" />.*?', '<setting id="mac_address">{}</setting>'.format(newmac), settings_xml)
            with open(settings_path, 'w') as f: f.write(settings_xml)
            PVRMac.list_Dialog()
            PVRMac.openStalker()
            PVRMac.list_error()


    def iptv_stb():
        url = 'https://stbemuiptv.codes/category/stbemu-codes/'
        hdrs = {'Referer': url,
                'User-Agent': user_agent}
        p = requests.get(url, headers=hdrs).text
        m = re.compile('<h2 class="entry-title" itemprop="headline"><a href="(.*?)" rel="bookmark">(.*?)</a></h2>', re.DOTALL).findall(p)
        channels = BACK
        for url, name in m:
            name = name.replace('Stbemu İPTV Codes ', '').replace('Stalker Portal mac ', '')
            name = '[B][COLOR deepskyblue]%s[/COLOR][/B]' % name
            url = url.replace('https://stbemuiptv.codes/stbemu-iptv-codes-', '').replace('/', '')

            channels = channels + ',' + url
            iptv_links = channels.split(",")

        ret = xbmcgui.Dialog().select(SELECT_D, iptv_links)
        if ret <= 0:
            return PVRMac.pvr_client()
        url_l = iptv_links[ret]
        url_l = 'https://stbemuiptv.codes/stbemu-iptv-codes-' + url_l
        hdrs = {'Referer': url_l,
                'User-Agent': user_agent}
        p1 = requests.get(url_l, headers=hdrs).text
        m1 = re.compile('<a class="elementor-toggle-title" tabindex="0">(.*?)</a>', re.DOTALL).findall(p1)

        newpor = ''
        newmac = ''
        channels = BACK
        for url in m1: 
            prog = ',' + url
            channels = channels + prog
            lista_ch = channels.split(",")
        ret = xbmcgui.Dialog().select(SELECT_M_U2, lista_ch)
        if ret <= 0:
            return PVRMac.iptv_stb()
        newpor = lista_ch[ret]
        if 'http' in newpor:
            with open(settings_path, 'r') as f: settings_xml = f.read()
            settings_xml = re.sub('<setting id="server_address">.*?</setting>', '<setting id="server_address">{}</setting>'.format(newpor), settings_xml)
            settings_xml = re.sub('<setting id="server_address" default="true">.*?</setting>', '<setting id="server_address" default="true">{}</setting>'.format(newpor), settings_xml)
            settings_xml = re.sub('<setting id="server_address" default="true" />.*?', '<setting id="server_address">{}</setting>'.format(newpor), settings_xml)
            with open(settings_path, 'w') as f: f.write(settings_xml)
        hdrs = {'Referer': url_l,
                'User-Agent': user_agent}
        p1 = requests.get(url_l, headers=hdrs).text
        m2 = re.compile('<div id="elementor-tab-content-(.*?").*?>(.*?)</p></div>', re.DOTALL).findall(p1)
    #    m2 = re.findall('<div id="elementor-tab-content-(.*?)".*?>(.*?:.*?:.*?:.*?:.*?:.*?)</p></div>', p1)

        channels = BACK
        if ret == 1:
            for id, mac in m2:
              if '2481"' in id:
                if '00:' in mac:
                    mac = clear_title_mac(mac)
                    prog = ',' + mac
                    channels = channels + prog
                    lista_ch = channels.split(",")
            ret = xbmcgui.Dialog().select(SELECT_M, lista_ch)
            if ret <= 0:
                return PVRMac.iptv_stb()
            newmac = lista_ch[ret]
            with open(settings_path, 'r') as f: settings_xml = f.read()
            settings_xml = re.sub('<setting id="mac_address">.*?</setting>', '<setting id="mac_address">{}</setting>'.format(newmac), settings_xml)
            settings_xml = re.sub('<setting id="mac_address" default="true">.*?</setting>', '<setting id="mac_address" default="true">{}</setting>'.format(newmac), settings_xml)
            settings_xml = re.sub('<setting id="mac_address" default="true" />.*?', '<setting id="mac_address">{}</setting>'.format(newmac), settings_xml)
            with open(settings_path, 'w') as f: f.write(settings_xml)
            PVRMac.list_Dialog()
            PVRMac.openStalker()
            PVRMac.list_error()

        elif ret == 2:
            for id, mac in m2:
              if '2482' in id:
                if '00:' in mac:
                    mac = clear_title_mac(mac)
                    prog = ',' + mac
                    channels = channels + prog
                    lista_ch = channels.split(",")
            ret = xbmcgui.Dialog().select(SELECT_M, lista_ch)
            if ret <= 0:
                return PVRMac.iptv_stb()
            newmac = lista_ch[ret]
            with open(settings_path, 'r') as f: settings_xml = f.read()
            settings_xml = re.sub('<setting id="mac_address">.*?</setting>', '<setting id="mac_address">{}</setting>'.format(newmac), settings_xml)
            settings_xml = re.sub('<setting id="mac_address" default="true">.*?</setting>', '<setting id="mac_address" default="true">{}</setting>'.format(newmac), settings_xml)
            settings_xml = re.sub('<setting id="mac_address" default="true" />.*?', '<setting id="mac_address">{}</setting>'.format(newmac), settings_xml)
            with open(settings_path, 'w') as f: f.write(settings_xml)
            PVRMac.list_Dialog()
            PVRMac.openStalker()
            PVRMac.list_error()

        elif ret == 3:
            for id, mac in m2:
              if '2483' in id:
                if '00:' in mac:
                    mac = clear_title_mac(mac)
                    prog = ',' + mac
                    channels = channels + prog
                    lista_ch = channels.split(",")
            ret = xbmcgui.Dialog().select(SELECT_M, lista_ch)
            if ret <= 0:
                return PVRMac.iptv_stb()
            newmac = lista_ch[ret]
            with open(settings_path, 'r') as f: settings_xml = f.read()
            settings_xml = re.sub('<setting id="mac_address">.*?</setting>', '<setting id="mac_address">{}</setting>'.format(newmac), settings_xml)
            settings_xml = re.sub('<setting id="mac_address" default="true">.*?</setting>', '<setting id="mac_address" default="true">{}</setting>'.format(newmac), settings_xml)
            settings_xml = re.sub('<setting id="mac_address" default="true" />.*?', '<setting id="mac_address">{}</setting>'.format(newmac), settings_xml)
            with open(settings_path, 'w') as f: f.write(settings_xml)
            PVRMac.list_Dialog()
            PVRMac.openStalker()
            PVRMac.list_error()

        elif ret == 4:
            for id, mac in m2:
              if '2484' in id:
                if '00:' in mac:
                    mac = clear_title_mac(mac)
                    prog = ',' + mac
                    channels = channels + prog
                    lista_ch = channels.split(",")
            ret = xbmcgui.Dialog().select(SELECT_M, lista_ch)
            if ret <= 0:
                return PVRMac.iptv_stb()
            newmac = lista_ch[ret]
            with open(settings_path, 'r') as f: settings_xml = f.read()
            settings_xml = re.sub('<setting id="mac_address">.*?</setting>', '<setting id="mac_address">{}</setting>'.format(newmac), settings_xml)
            settings_xml = re.sub('<setting id="mac_address" default="true">.*?</setting>', '<setting id="mac_address" default="true">{}</setting>'.format(newmac), settings_xml)
            settings_xml = re.sub('<setting id="mac_address" default="true" />.*?', '<setting id="mac_address">{}</setting>'.format(newmac), settings_xml)
            with open(settings_path, 'w') as f: f.write(settings_xml)
            PVRMac.list_Dialog()
            PVRMac.openStalker()
            PVRMac.list_error()

        elif ret == 5:
            for id, mac in m2:
              if '2485' in id:
                if '00:' in mac:
                    mac = clear_title_mac(mac)
                    prog = ',' + mac
                    channels = channels + prog
                    lista_ch = channels.split(",")
            ret = xbmcgui.Dialog().select(SELECT_M, lista_ch)
            if ret <= 0:
                return PVRMac.iptv_stb()
            newmac = lista_ch[ret]
            with open(settings_path, 'r') as f: settings_xml = f.read()
            settings_xml = re.sub('<setting id="mac_address">.*?</setting>', '<setting id="mac_address">{}</setting>'.format(newmac), settings_xml)
            settings_xml = re.sub('<setting id="mac_address" default="true">.*?</setting>', '<setting id="mac_address" default="true">{}</setting>'.format(newmac), settings_xml)
            settings_xml = re.sub('<setting id="mac_address" default="true" />.*?', '<setting id="mac_address">{}</setting>'.format(newmac), settings_xml)
            with open(settings_path, 'w') as f: f.write(settings_xml)
            PVRMac.list_Dialog()
            PVRMac.openStalker()
            PVRMac.list_error()

        elif ret == 6:
            for id, mac in m2:
              if '2486' in id:
                if '00:' in mac:
                    mac = clear_title_mac(mac)
                    prog = ',' + mac
                    channels = channels + prog
                    lista_ch = channels.split(",")
            ret = xbmcgui.Dialog().select(SELECT_M, lista_ch)
            if ret <= 0:
                return PVRMac.iptv_stb()
            newmac = lista_ch[ret]
            with open(settings_path, 'r') as f: settings_xml = f.read()
            settings_xml = re.sub('<setting id="mac_address">.*?</setting>', '<setting id="mac_address">{}</setting>'.format(newmac), settings_xml)
            settings_xml = re.sub('<setting id="mac_address" default="true">.*?</setting>', '<setting id="mac_address" default="true">{}</setting>'.format(newmac), settings_xml)
            settings_xml = re.sub('<setting id="mac_address" default="true" />.*?', '<setting id="mac_address">{}</setting>'.format(newmac), settings_xml)
            with open(settings_path, 'w') as f: f.write(settings_xml)
            PVRMac.list_Dialog()
            PVRMac.openStalker()
            PVRMac.list_error()

        elif ret == 7:
            for id, mac in m2:
              if '2487' in id:
                if '00:' in mac:
                    mac = clear_title_mac(mac)
                    prog = ',' + mac
                    channels = channels + prog
                    lista_ch = channels.split(",")
            ret = xbmcgui.Dialog().select(SELECT_M, lista_ch)
            if ret <= 0:
                return PVRMac.iptv_stb()
            newmac = lista_ch[ret]
            with open(settings_path, 'r') as f: settings_xml = f.read()
            settings_xml = re.sub('<setting id="mac_address">.*?</setting>', '<setting id="mac_address">{}</setting>'.format(newmac), settings_xml)
            settings_xml = re.sub('<setting id="mac_address" default="true">.*?</setting>', '<setting id="mac_address" default="true">{}</setting>'.format(newmac), settings_xml)
            settings_xml = re.sub('<setting id="mac_address" default="true" />.*?', '<setting id="mac_address">{}</setting>'.format(newmac), settings_xml)
            with open(settings_path, 'w') as f: f.write(settings_xml)
            PVRMac.list_Dialog()
            PVRMac.openStalker()
            PVRMac.list_error()

        elif ret == 8:
            for id, mac in m2:
              if '2488' in id:
                if '00:' in mac:
                    mac = clear_title_mac(mac)
                    prog = ',' + mac
                    channels = channels + prog
                    lista_ch = channels.split(",")
            ret = xbmcgui.Dialog().select(SELECT_M, lista_ch)
            if ret <= 0:
                return PVRMac.iptv_stb()
            newmac = lista_ch[ret]
            with open(settings_path, 'r') as f: settings_xml = f.read()
            settings_xml = re.sub('<setting id="mac_address">.*?</setting>', '<setting id="mac_address">{}</setting>'.format(newmac), settings_xml)
            settings_xml = re.sub('<setting id="mac_address" default="true">.*?</setting>', '<setting id="mac_address" default="true">{}</setting>'.format(newmac), settings_xml)
            settings_xml = re.sub('<setting id="mac_address" default="true" />.*?', '<setting id="mac_address">{}</setting>'.format(newmac), settings_xml)
            with open(settings_path, 'w') as f: f.write(settings_xml)
            PVRMac.list_Dialog()
            PVRMac.openStalker()
            PVRMac.list_error()

        elif ret == 9:
            for id, mac in m2:
              if '2489' in id:
                if '00:' in mac:
                    mac = clear_title_mac(mac)
                    prog = ',' + mac
                    channels = channels + prog
                    lista_ch = channels.split(",")
            ret = xbmcgui.Dialog().select(SELECT_M, lista_ch)
            if ret <= 0:
                return PVRMac.iptv_stb()
            newmac = lista_ch[ret]
            with open(settings_path, 'r') as f: settings_xml = f.read()
            settings_xml = re.sub('<setting id="mac_address">.*?</setting>', '<setting id="mac_address">{}</setting>'.format(newmac), settings_xml)
            settings_xml = re.sub('<setting id="mac_address" default="true">.*?</setting>', '<setting id="mac_address" default="true">{}</setting>'.format(newmac), settings_xml)
            settings_xml = re.sub('<setting id="mac_address" default="true" />.*?', '<setting id="mac_address">{}</setting>'.format(newmac), settings_xml)
            with open(settings_path, 'w') as f: f.write(settings_xml)
            PVRMac.list_Dialog()
            PVRMac.openStalker()
            PVRMac.list_error()

        elif ret == 10:
            for id, mac in m2:
              if '24810' in id:
                if '00:' in mac:
                    mac = clear_title_mac(mac)
                    prog = ',' + mac
                    channels = channels + prog
                    lista_ch = channels.split(",")
            ret = xbmcgui.Dialog().select(SELECT_M, lista_ch)
            if ret <= 0:
                return PVRMac.iptv_stb()
            newmac = lista_ch[ret]
            with open(settings_path, 'r') as f: settings_xml = f.read()
            settings_xml = re.sub('<setting id="mac_address">.*?</setting>', '<setting id="mac_address">{}</setting>'.format(newmac), settings_xml)
            settings_xml = re.sub('<setting id="mac_address" default="true">.*?</setting>', '<setting id="mac_address" default="true">{}</setting>'.format(newmac), settings_xml)
            settings_xml = re.sub('<setting id="mac_address" default="true" />.*?', '<setting id="mac_address">{}</setting>'.format(newmac), settings_xml)
            with open(settings_path, 'w') as f: f.write(settings_xml)
            PVRMac.list_Dialog()
            PVRMac.openStalker()
            PVRMac.list_error()

        elif ret == 11:
            for id, mac in m2:
              if '24811' in id:
                if '00:' in mac:
                    mac = clear_title_mac(mac)
                    prog = ',' + mac
                    channels = channels + prog
                    lista_ch = channels.split(",")
            ret = xbmcgui.Dialog().select(SELECT_M, lista_ch)
            if ret <= 0:
                return PVRMac.iptv_stb()
            newmac = lista_ch[ret]
            with open(settings_path, 'r') as f: settings_xml = f.read()
            settings_xml = re.sub('<setting id="mac_address">.*?</setting>', '<setting id="mac_address">{}</setting>'.format(newmac), settings_xml)
            settings_xml = re.sub('<setting id="mac_address" default="true">.*?</setting>', '<setting id="mac_address" default="true">{}</setting>'.format(newmac), settings_xml)
            settings_xml = re.sub('<setting id="mac_address" default="true" />.*?', '<setting id="mac_address">{}</setting>'.format(newmac), settings_xml)
            with open(settings_path, 'w') as f: f.write(settings_xml)
            PVRMac.list_Dialog()
            PVRMac.openStalker()
            PVRMac.list_error()
        else:
            return PVRMac.pvr_client()


    def iptv_stb_stalker():
        dp = xbmcgui.Dialog()
        select = dp.select(SELECT,
                          ['[B][COLOR lime]2025[/COLOR][/B]',
                           '[B][COLOR lime]2024[/COLOR][/B]'])
        #                   '[B][COLOR lime]2023[/COLOR][/B]',
        #                   '[B][COLOR lime]2022[/COLOR][/B]'])

        if select == 0:
            select = dp.select(SELECT,
                              ['[B][COLOR lime]\u039c\u03ac\u03b9\u03bf\u03c2[/COLOR][/B]',
                               '[B][COLOR lime]\u0391\u03c0\u03c1\u03af\u03bb\u03b9\u03bf\u03c2[/COLOR][/B]',
                               '[B][COLOR lime]\u039c\u03ac\u03c1\u03c4\u03b9\u03bf\u03c2[/COLOR][/B]',
                               '[B][COLOR lime]\u03a6\u03b5\u03b2\u03c1\u03bf\u03c5\u03ac\u03c1\u03b9\u03bf\u03c2[/COLOR][/B]',
                               '[B][COLOR lime]\u0399\u03b1\u03bd\u03bf\u03c5\u03ac\u03c1\u03b9\u03bf\u03c2[/COLOR][/B]'])

            if select == 0:
                url = 'https://stbstalker.alaaeldinee.com/2025/05'
                stb = 'https://stbstalker.alaaeldinee.com/2025/05/smart-stb-emu-pro-'
            elif select == 1:
                url = 'https://stbstalker.alaaeldinee.com/2025/04'
                stb = 'https://stbstalker.alaaeldinee.com/2025/04/smart-stb-emu-pro-'
            elif select == 2:
                url = 'https://stbstalker.alaaeldinee.com/2025/03'
                stb = 'https://stbstalker.alaaeldinee.com/2025/03/smart-stb-emu-pro-'
            elif select == 3:
                url = 'https://stbstalker.alaaeldinee.com/2025/02'
                stb = 'https://stbstalker.alaaeldinee.com/2025/02/smart-stb-emu-pro-'
            elif select == 4:
                url = 'https://stbstalker.alaaeldinee.com/2025/01'
                stb = 'https://stbstalker.alaaeldinee.com/2025/01/smart-stb-emu-pro-'

            else:
                return PVRMac.iptv_stb_stalker()
        elif select == 1:
            select = dp.select(SELECT,
                              ['[B][COLOR lime]\u0394\u03b5\u03ba\u03ad\u03bc\u03b2\u03c1\u03b9\u03bf\u03c2[/COLOR][/B]',
                               '[B][COLOR lime]\u039d\u03bf\u03ad\u03bc\u03b2\u03c1\u03b9\u03bf\u03c2[/COLOR][/B]',
                               '[B][COLOR lime]\u039f\u03ba\u03c4\u03ce\u03b2\u03c1\u03b9\u03bf\u03c2[/COLOR][/B]',
                               '[B][COLOR lime]\u03a3\u03b5\u03c0\u03c4\u03ad\u03bc\u03b2\u03c1\u03b9\u03bf\u03c2[/COLOR][/B]',
                               '[B][COLOR lime]\u0391\u03cd\u03b3\u03bf\u03c5\u03c3\u03c4\u03bf\u03c2[/COLOR][/B]',
                               '[B][COLOR lime]\u0399\u03bf\u03cd\u03bb\u03b9\u03bf\u03c2[/COLOR][/B]',
                               '[B][COLOR lime]\u0399\u03bf\u03cd\u03bd\u03b9\u03bf\u03c2[/COLOR][/B]',
                               '[B][COLOR lime]\u039c\u03ac\u03b9\u03bf\u03c2[/COLOR][/B]',
                               '[B][COLOR lime]\u0391\u03c0\u03c1\u03af\u03bb\u03b9\u03bf\u03c2[/COLOR][/B]',
                               '[B][COLOR lime]\u039c\u03ac\u03c1\u03c4\u03b9\u03bf\u03c2[/COLOR][/B]',
                               '[B][COLOR lime]\u03a6\u03b5\u03b2\u03c1\u03bf\u03c5\u03ac\u03c1\u03b9\u03bf\u03c2[/COLOR][/B]',
                               '[B][COLOR lime]\u0399\u03b1\u03bd\u03bf\u03c5\u03ac\u03c1\u03b9\u03bf\u03c2[/COLOR][/B]'])

            if select == 0:
                url = 'https://stbstalker.alaaeldinee.com/2024/12'
                stb = 'https://stbstalker.alaaeldinee.com/2024/12/smart-stb-emu-pro-'
            elif select == 1:
                url = 'https://stbstalker.alaaeldinee.com/2024/11'
                stb = 'https://stbstalker.alaaeldinee.com/2024/11/smart-stb-emu-pro-'
            elif select == 2:
                url = 'https://stbstalker.alaaeldinee.com/2024/10'
                stb = 'https://stbstalker.alaaeldinee.com/2024/10/smart-stb-emu-pro-'
            elif select == 3:
                url = 'https://stbstalker.alaaeldinee.com/2024/09'
                stb = 'https://stbstalker.alaaeldinee.com/2024/09/smart-stb-emu-pro-'
            elif select == 4:
                url = 'https://stbstalker.alaaeldinee.com/2024/08'
                stb = 'https://stbstalker.alaaeldinee.com/2024/08/smart-stb-emu-pro-'
            elif select == 5:
                url = 'https://stbstalker.alaaeldinee.com/2024/07'
                stb = 'https://stbstalker.alaaeldinee.com/2024/07/smart-stb-emu-pro-'
            elif select == 6:
                url = 'https://stbstalker.alaaeldinee.com/2024/06'
                stb = 'https://stbstalker.alaaeldinee.com/2024/06/smart-stb-emu-pro-'
            elif select == 7:
                url = 'https://stbstalker.alaaeldinee.com/2024/05'
                stb = 'https://stbstalker.alaaeldinee.com/2024/05/smart-stb-emu-pro-'
            elif select == 8:
                url = 'https://stbstalker.alaaeldinee.com/2024/04'
                stb = 'https://stbstalker.alaaeldinee.com/2024/04/smart-stb-emu-pro-'
            elif select == 9:
                url = 'https://stbstalker.alaaeldinee.com/2024/03'
                stb = 'https://stbstalker.alaaeldinee.com/2024/03/smart-stb-emu-pro-'
            elif select == 10:
                url = 'https://stbstalker.alaaeldinee.com/2024/02'
                stb = 'https://stbstalker.alaaeldinee.com/2024/02/smart-stb-emu-pro-'
            elif select == 11:
                url = 'https://stbstalker.alaaeldinee.com/2024/01'
                stb = 'https://stbstalker.alaaeldinee.com/2024/01/smart-stb-emu-pro-'

            else:
                return PVRMac.iptv_stb_stalker()
        else:
            return PVRMac.pvr_client()

        hdrs = {'Referer': url,
                'User-Agent': user_agent}
        p = requests.get(url, headers=hdrs).text
        m = re.compile('''<li>\s+<a href='(.*?)'>(.*?)</a>\s+</li>''', re.DOTALL).findall(p)
        channels = BACK
        for url, name in m:
            name = name.replace('Smart STB Emu pro   ', '')
            name = '[B][COLOR deepskyblue]%s[/COLOR][/B]' % name

            if 'https://stbstalker.alaaeldinee.com/p/privacy-policy.html' in url: continue
            if 'https://stbstalker.alaaeldinee.com/p/website-terms-of-use.html' in url: continue
            if 'https://stbstalker.alaaeldinee.com/p/contact-us.html' in url: continue
            if 'https://stbstalker.alaaeldinee.com/p/archive-page.html' in url: continue
            if stb + '27-04-2025.html' in url: continue
            if stb + '26-04-2025.html' in url: continue
            if stb + '25-04-2025.html' in url: continue
            if stb + '01-05-2025.html' in url: continue

            url = url.replace(stb, '').replace('.html', '')
            channels = channels + ',' + url
            iptv_links = channels.split(",")

        ret = xbmcgui.Dialog().select(SELECT_D, iptv_links)
        if ret <= 0:
            return PVRMac.pvr_client()
        url_l = iptv_links[ret]

        url_l = stb + url_l + '.html'
        hdrs = {'Referer': url_l,
                'User-Agent': user_agent}
        p1 = requests.get(url_l, headers=hdrs).text
        m1 = re.compile('<p>.*?</p>.*? PORTAL : (.*?)</p><p>.*? MAC : (.*?)</p><p>', re.DOTALL).findall(p1)
        m2 = re.compile('<p>.*?</p>.*? PORTAL : (.*?)</p><p>.*? MAC : .*?</p><p>', re.DOTALL).findall(p1)
        m3 = re.compile('<p>.*?</p>.*? PORTAL : .*?</p><p>.*? MAC : (.*?)</p><p>', re.DOTALL).findall(p1)

        newpor = ''
        newmac = ''
        channels = BACK
        for portal, mac in m1: 
            prog = ',' + '[B][COLOR deepskyblue]PORTAL: [/COLOR][/B]' + portal + ' | ' + '[B][COLOR lime]MAC: [/COLOR][/B]' + mac
            prog = prog.replace('</span>', '')
            channels = channels + prog
            lista_ch = channels.split(",")
        ret = xbmcgui.Dialog().select(SELECT, lista_ch)
        if ret <= 0:
            return PVRMac.iptv_stb_stalker()
        newpor = m2[ret-1]
        newmac = m3[ret-1]

        with open(settings_path, 'r') as f: settings_xml = f.read()
        settings_xml = re.sub('<setting id="server_address">.*?</setting>', '<setting id="server_address">{}</setting>'.format(newpor), settings_xml)
        settings_xml = re.sub('<setting id="mac_address">.*?</setting>', '<setting id="mac_address">{}</setting>'.format(newmac), settings_xml)
        settings_xml = re.sub('<setting id="server_address" default="true">.*?</setting>', '<setting id="server_address" default="true">{}</setting>'.format(newpor), settings_xml)
        settings_xml = re.sub('<setting id="mac_address" default="true">.*?</setting>', '<setting id="mac_address" default="true">{}</setting>'.format(newmac), settings_xml)
        settings_xml = re.sub('<setting id="server_address" default="true" />.*?', '<setting id="server_address">{}</setting>'.format(newpor), settings_xml)
        settings_xml = re.sub('<setting id="mac_address" default="true" />.*?', '<setting id="mac_address">{}</setting>'.format(newmac), settings_xml)
        with open(settings_path, 'w') as f: f.write(settings_xml)

        PVRMac.list_Dialog()
        PVRMac.openStalker()
        PVRMac.list_error()

    def list_error():
        if xbmc.getCondVisibility("Window.IsVisible(notification)") or xbmc.getCondVisibility("Window.IsVisible(busydialog)"):
            xbmcgui.Dialog().notification('[B][COLOR deepskyblue]Generator IPTV List[/COLOR][/B]', PLEASE, icon)
            xbmc.sleep(5000)
            PVRMac.pvr_client()

    def list_error_xc():
        if xbmc.getCondVisibility("Window.IsVisible(notification)") or xbmc.getCondVisibility("Window.IsVisible(busydialog)"):
            dp.notification('[B][COLOR deepskyblue]Generator IPTV List[/COLOR][/B]', PLEASE, icon_iptvxc)
            xbmc.sleep(5000)
            return xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/PVR/xclist.py")')

    def openStalker():
        xbmcgui.Dialog().notification('[B][COLOR deepskyblue]StalkerVod[/COLOR][/B]', PLEASE, icon)
        xbmc.executebuiltin('Dialog.Close(all,true)')
        xbmc.executebuiltin('Action(Back)')
        xbmc.executebuiltin('Dialog.Close(all,true)')
        xbmc.executebuiltin('ActivateWindow(Home)')
        xbmc.sleep(5000)
        xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.stalkervod/")')
        xbmc.sleep(10000)

    def openMacVod():
        dp.notification('[B][COLOR deeppink]MacVod Client[/COLOR][/B]', PLEASE2, icon_macvod)
        xbmc.executebuiltin('Dialog.Close(all,true)')
        xbmc.executebuiltin('Action(Back)')
        xbmc.executebuiltin('Dialog.Close(all,true)')
        xbmc.executebuiltin('ActivateWindow(Home)')
        xbmc.sleep(5000)
        xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.macvod/?action=ipkoditv_enigmax&extra&page&plot&thumbnail=special://home/addons/plugin.video.macvod/icon.png&title=%5bB%5d%5bCOLOR%20orange%5dXtream%20Codes%20-%20%5bCOLOR%20lime%5d%ce%9f%20%ce%94%ce%b9%ce%b1%ce%ba%ce%bf%ce%bc%ce%b9%cf%83%cf%84%ce%ae%cf%82%20%cf%83%ce%b1%cf%82%5b%2fCOLOR%5d%5b%2fB%5d&url=")')
        xbmc.sleep(10000)

    def openMacVod_m3u():
        dp.notification('[B][COLOR deeppink]MacVod Client[/COLOR][/B]', PLEASE2, icon_macvod)
        xbmc.executebuiltin('Dialog.Close(all,true)')
        xbmc.executebuiltin('Action(Back)')
        xbmc.executebuiltin('Dialog.Close(all,true)')
        xbmc.executebuiltin('ActivateWindow(Home)')
        xbmc.sleep(5000)
        xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.macvod/?action=listam3u1&extra&page&plot&thumbnail=special://home/addons/plugin.video.macvod/icon.png&title=%5bB%5d%5bCOLOR%20orange%5dXtream%20Codes%20-%20%5bCOLOR%20lime%5d%ce%9f%20%ce%94%ce%b9%ce%b1%ce%ba%ce%bf%ce%bc%ce%b9%cf%83%cf%84%ce%ae%cf%82%20%cf%83%ce%b1%cf%82%5b%2fCOLOR%5d%5b%2fB%5d&url=")')
        xbmc.sleep(10000)

    def openXCUI():
        dp.notification('[B][COLOR red]XCUI Streams[/COLOR][/B]', PLEASE, icon_iptvxc)
        xbmc.executebuiltin('Dialog.Close(all,true)')
        xbmc.executebuiltin('Action(Back)')
        xbmc.executebuiltin('Dialog.Close(all,true)')
        xbmc.executebuiltin('ActivateWindow(Home)')
        xbmc.sleep(5000)
        xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.iptvxc/")')
        xbmc.sleep(10000)

    def list_Dialog():
        dialog = xbmcgui.DialogProgress()
        dialog.create('[B][COLOR deepskyblue]StalkerVod [COLOR lime]Generator[/COLOR][/B]', '[B][COLOR deepskyblue]StalkerVod [COLOR lime]Generator[/COLOR][/B]')
        dialog.update(0, LIST_D)
        for i in range(0, 30, 10):
            dialog.update(i, LIST_D)
            xbmc.sleep(600) 
        dialog.update(100, LIST_D)
        xbmc.sleep(2000)
        dialog.close()

    def list_Dialog_mac():
        dialog = xbmcgui.DialogProgress()
        dialog.create('[B][COLOR deeppink]MacVod Client[COLOR lime] Generator[/COLOR][/B]', '[B][COLOR deeppink]MacVod [COLOR lime]Generator[/COLOR][/B]')
        dialog.update(0, LIST_D)
        for i in range(0, 30, 10):
            dialog.update(i, LIST_D)
            xbmc.sleep(600) 
        dialog.update(100, LIST_D)
        xbmc.sleep(2000)
        dialog.close()

    def list_Dialog_not():
        dialog = xbmcgui.DialogProgress()
        dialog.create('[B][COLOR deepskyblue]StalkerVod [COLOR lime]Generator[/COLOR][/B]', '[B][COLOR deepskyblue]StalkerVod [COLOR lime]Generator[/COLOR][/B]')
        dialog.update(0, LIST_D_N)
        for i in range(0, 30, 10):
            dialog.update(i, LIST_D_N)
            xbmc.sleep(600) 
        dialog.update(100, LIST_D_N)
        xbmc.sleep(2000)
        dialog.close()

    def list_Dialog_xc():
        dialog = xbmcgui.DialogProgress()
        dialog.create('[B][COLOR red]XCUI Streams[COLOR lime] Generator[/COLOR][/B]', '[B][COLOR red]XCUI Streams [COLOR lime]Generator[/COLOR][/B]')
        dialog.update(0, LIST_D_X)
        for i in range(0, 30, 10):
            dialog.update(i, LIST_D_X)
            xbmc.sleep(600) 
        dialog.update(100, LIST_D_X)
        xbmc.sleep(2000)
        dialog.close()

def clear_Title(txt):
    import six
    if six.PY2:
        txt = txt.encode('utf-8', 'ignore')
    else:
        txt = six.ensure_text(txt, encoding='utf-8', errors='ignore')
    txt = re.sub(r'<.+?>', '', txt)
    txt = re.sub(r'var\s+cp.+?document.write\(\'\'\);\s*', '', txt)
    txt = txt.replace('Mac : ', '').replace('Mac: ', '').replace('Mac', '').replace('MAC: ', '').replace('MAC : ', '').replace('MAC ', '').replace('MAC', '').replace('&nbsp;', '').replace(' 2024', '').replace(' 2025', '').replace(' 2026', '').replace('&#10152;', '')
    txt = txt.replace('01,', '').replace('02,', '').replace('03,', '').replace('04,', '').replace('05,', '').replace('06,', '').replace('07,', '').replace('08,', '').replace('09,', '')
    txt = txt.replace('25,', '').replace('26,', '').replace('27,', '').replace('28,', '').replace('29,', '').replace('30,', '').replace(' Unlimited', '')
    txt = txt.replace('19,', '').replace('20,', '').replace('21,', '').replace('22,', '').replace('23,', '').replace('24,', '').replace('31,', '')
    txt = txt.replace('13,', '').replace('14,', '').replace('15,', '').replace('16,', '').replace('17,', '').replace('18,', '')
    txt = txt.replace('7,', '').replace('8,', '').replace('9,', '').replace('10,', '').replace('11,', '').replace('12,', '')
    txt = txt.replace('1,', '').replace('2,', '').replace('3,', '').replace('4,', '').replace('5,', '').replace('6,', '')
    txt = txt.replace('01.', '').replace('02.', '').replace('03.', '').replace('04.', '').replace('05.', '').replace('06.', '')
    txt = txt.replace('07.', '').replace('08.', '').replace('09.', '').replace('10.', '').replace('11.', '').replace('12.', '')
    txt = txt.replace('13.', '').replace('14.', '').replace('15.', '').replace('16.', '').replace('17.', '').replace('18.', '')
    txt = txt.replace('19.', '').replace('20.', '').replace('21.', '').replace('22.', '').replace('23.', '').replace('24.', '')
    txt = txt.replace('25.', '').replace('26.', '').replace('27.', '').replace('28.', '').replace('29.', '').replace('30.', '')
    txt = txt.replace('.31', '').replace('.30', '').replace('.29', '').replace('.28', '').replace('.27', '').replace('.26', '')
    txt = txt.replace('.25', '').replace('.24', '').replace('.23', '').replace('.22', '').replace('.21', '').replace('.20', '')
    txt = txt.replace('.19', '').replace('.18', '').replace('.17', '').replace('.16', '').replace('.15', '').replace('.14', '')
    txt = txt.replace('.13', '').replace('.12', '').replace('.11', '').replace('.10', '').replace('.09', '').replace('.08', '')
    txt = txt.replace('.07', '').replace('.06', '').replace('.05', '').replace('.04', '').replace('.03', '').replace('.02', '').replace('.01', '')
    txt = txt.replace('31.', '').replace('2024', '').replace('2025', '').replace(' 31', '')
    txt = txt.replace(' 25', '').replace(' 26', '').replace(' 27', '').replace(' 28', '').replace(' 29', '').replace(' 30', '')
    txt = txt.replace(' 19', '').replace(' 20', '').replace(' 21', '').replace(' 22', '').replace(' 23', '').replace(' 24', '')
    txt = txt.replace(' 13', '').replace(' 14', '').replace(' 15', '').replace(' 16', '').replace(' 17', '').replace(' 18', '')
    txt = txt.replace(' 7', '').replace(' 8', '').replace(' 9', '').replace(' 10', '').replace(' 11', '').replace(' 12', '')
    txt = txt.replace(' 1', '').replace(' 2', '').replace(' 3', '').replace(' 4', '').replace(' 5', '').replace(' 6', '').replace(' ', '')
    txt = txt.replace('January', '').replace('February', '').replace('March', '').replace('April', '').replace('May', '').replace('June', '')
    txt = txt.replace('July', '').replace('August', '').replace('September', '').replace('October', '').replace('November', '').replace('December', '')
    txt = txt.replace('Október', '').replace('Szeptember ', '').replace(':00 pm', '')
    txt = txt.replace(',:00pm', '').replace(',:01pm', '').replace(',:02pm', '').replace(',:03pm', '').replace(',:04pm', '').replace(',:05pm', '').replace(',:06pm', '').replace(',:07pm', '').replace(',:08pm', '').replace(',:09pm', '')
    txt = txt.replace(',:10pm', '').replace(',:11pm', '').replace(',:12pm', '').replace(',:13pm', '').replace(',:14pm', '').replace(',:15pm', '').replace(',:16pm', '').replace(',:17pm', '').replace(',:18pm', '').replace(',:19pm', '')
    txt = txt.replace(',:20pm', '').replace(',:21pm', '').replace(',:22pm', '').replace(',:23pm', '').replace(',:24pm', '').replace(',:25pm', '').replace(',:26pm', '').replace(',:27pm', '').replace(',:28pm', '').replace(',:29pm', '')
    txt = txt.replace(',:30pm', '').replace(',:31pm', '').replace(',:32pm', '').replace(',:33pm', '').replace(',:34pm', '').replace(',:35pm', '').replace(',:36pm', '').replace(',:37pm', '').replace(',:38pm', '').replace(',:39pm', '')
    txt = txt.replace(',:40pm', '').replace(',:41pm', '').replace(',:42pm', '').replace(',:43pm', '').replace(',:44pm', '').replace(',:45pm', '').replace(',:46pm', '').replace(',:47pm', '').replace(',:48pm', '').replace(',:49pm', '')
    txt = txt.replace(',:50pm', '').replace(',:51pm', '').replace(',:52pm', '').replace(',:53pm', '').replace(',:54pm', '').replace(',:55pm', '').replace(',:56pm', '').replace(',:57pm', '').replace(',:58pm', '').replace(',:59pm', '')
    txt = txt.replace(',:00am', '').replace(',:01am', '').replace(',:02am', '').replace(',:03am', '').replace(',:04am', '').replace(',:05am', '').replace(',:06am', '').replace(',:07am', '').replace(',:08am', '').replace(',:09am', '')
    txt = txt.replace(',:10am', '').replace(',:11am', '').replace(',:12am', '').replace(',:13am', '').replace(',:14am', '').replace(',:15am', '').replace(',:16am', '').replace(',:17am', '').replace(',:18am', '').replace(',:19am', '')
    txt = txt.replace(',:20am', '').replace(',:21am', '').replace(',:22am', '').replace(',:23am', '').replace(',:24am', '').replace(',:25am', '').replace(',:26am', '').replace(',:27am', '').replace(',:28am', '').replace(',:29am', '')
    txt = txt.replace(',:30am', '').replace(',:31am', '').replace(',:32am', '').replace(',:33am', '').replace(',:34am', '').replace(',:35am', '').replace(',:36am', '').replace(',:37am', '').replace(',:38am', '').replace(',:39am', '')
    txt = txt.replace(',:40am', '').replace(',:41am', '').replace(',:42am', '').replace(',:43am', '').replace(',:44am', '').replace(',:45am', '').replace(',:46am', '').replace(',:47am', '').replace(',:48am', '').replace(',:49am', '')
    txt = txt.replace(',:50am', '').replace(',:51am', '').replace(',:52am', '').replace(',:53am', '').replace(',:54am', '').replace(',:55am', '').replace(',:56am', '').replace(',:57am', '').replace(',:58am', '').replace(',:59am', '')
    txt = txt.replace('''</a></div><p></p><span><a name='more'></a></span><p style="text-align: left;">''', '')
    return txt

if __name__ == '__main__':
    if os.path.exists(xbmcvfs.translatePath('special://home/addons/skin.19MatrixWorld')) and os.path.exists(xbmcvfs.translatePath('special://home/addons/plugin.image.World')):
    # if os.path.exists(xbmcvfs.translatePath('special://home/addons/skin.TechNEWSology')) and os.path.exists(xbmcvfs.translatePath('special://home/addons/plugin.image.TechNEWSology')):
        PVRMac.pvr_client()
