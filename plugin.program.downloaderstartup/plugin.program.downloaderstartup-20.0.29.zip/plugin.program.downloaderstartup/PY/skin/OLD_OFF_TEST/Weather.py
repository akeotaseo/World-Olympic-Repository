import os, xbmc, xbmcvfs, xbmcgui

def Weather():
    Services()
    xbmcgui.Dialog().notification("[B][COLOR orange]Weather[/COLOR][/B]", "Υπηρεσίες Καιρού", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/Weather.ico')
    xbmc.executebuiltin('ActivateWindow(Weather)')
    xbmc.sleep(3000)

    
    xbmc.executebuiltin("ActivateWindowAndFocus(servicesettings, -193, )")
    xbmc.sleep(500)
# if xbmc.getCondVisibility('system.platform.android'):
   # xbmc.executebuiltin('SendClick(-177)')
# else:
    xbmc.executebuiltin('SendClick(-179)')


def textBox(heading, announce):
    class TextBox():

        def __init__(self, *args, **kwargs):
            self.WINDOW = 10147
            self.CONTROL_LABEL = 1
            self.CONTROL_TEXTBOX = 5
            xbmc.executebuiltin("ActivateWindow(%d)" % (self.WINDOW, ))
            self.win = xbmcgui.Window(self.WINDOW)
            xbmc.sleep(500)
            self.setControls()

        def setControls(self):
            self.win.getControl(self.CONTROL_LABEL).setLabel(heading)
            try:
                f = open(announce)
                text = f.read()
            except:
                text = announce
            self.win.getControl(self.CONTROL_TEXTBOX).setText(str(text))
            return

    TextBox()
    while xbmc.getCondVisibility('Window.IsVisible(10147)'):
        xbmc.sleep(500)


def Services():
    changelog = xbmcvfs.translatePath(os.path.join('special://home/addons/plugin.program.downloaderstartup/PY/Changelog/Weather.txt'))
    heading = '[B][COLOR orange]Weather[/COLOR][/B]'
    f = open(changelog, 'r', encoding='utf-8')
    lines = f.readlines()
    announce = ''
    for line in lines:
        if not line.strip():
            break

        announce += line
    f.close()
    textBox(heading, announce)


Weather()
