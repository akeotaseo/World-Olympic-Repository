import os, xbmcgui

def DialogF4mtesterMac():
        choice = xbmcgui.Dialog().yesno('[B][COLOR orange]F4mtesterMac[/COLOR][/B]', '[COLOR grey]Θα γίνει διαγραφή των παρακάτω addons...[CR][COLOR white]FLIXTVON, FlixTvON MAC, TRAIN MAC AGAIN, GIF PEG TV, IPTV Stalker[/COLOR][CR]Θέλετε να συνεχίσετε?[/COLOR]',
                                        nolabel='[COLOR white]Όχι[/COLOR]',yeslabel='[COLOR white]Ναι[/COLOR]')
        if choice == 1: [
                         xbmc.executebuiltin('RunScript("special://home/addons//plugin.program.downloaderstartup/F4mtesterMac/DeleteF4mtesterMac.py")'),]

DialogF4mtesterMac()