import xbmc, xbmcgui


def SkinTools():
    funcs = (click1, click2, click3, click4, click5)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]~ Skin tools ~[/COLOR][/B]', 
['Home Widget [COLOR=red]OFF[/COLOR] / [COLOR=green]ON[/COLOR]',
 'Single Global Background [COLOR=green](Enabled)[/COLOR]',
 '[COLOR red] Skin[/COLOR] Txt / Graph',
 'Intro [COLOR=green]Enable[/COLOR] / [COLOR=red]Disable[/COLOR]',
 '   ',


 'Αυτόματη ενημέρωση του build [COLOR=green]ON[/COLOR] / [COLOR=red]OFF[/COLOR]'])


    if call:
        if call < 0:
            return
        func = funcs[call-5]
        return func()
    else:
        func = funcs[call]
        return func()
    return 


def click1():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/skin/HomeWidgetONOFF.py")')
    
def click2():
    xbmc.executebuiltin('Skin.ToggleSetting(SingleGlobalBackground,Enabled)')

def click3():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/skin/SkinMenuLAF.py")')

def click4():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/skin/Introonoff.py")')

def click5():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/Tools/SkinTools.py")')

#def click6():
    #xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/Tools/downloaderstartupOnOff/DialogEnableDisabledownloaderstartup.py")')




SkinTools()
