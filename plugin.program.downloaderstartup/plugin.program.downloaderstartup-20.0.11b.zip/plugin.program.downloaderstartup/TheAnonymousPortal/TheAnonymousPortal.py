import xbmc, xbmcgui


def TheAnonymousPortal():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7, click_8, click_9, click_10, click_11)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]  ~ TheAnonymousPortal &... ~[/COLOR][/B]', 
['lagartixa',
 'nebula',
 'alado',
 'zeus',
 'topeleven',
 'ninja',
 'calimero',
 'chidori',
 '[COLORorange]TRAIN MAC AGAIN[/COLOR]',
 '[COLOR white]Take One Mac[/COLOR]',
 'GIF PEG TV'
 ])



    if call:
        if call < 0:
            return
        func = funcs[call-11]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.lagartixa")')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.nebula.portal")')

def click_3():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.portal.alado")')

def click_4():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.zeus.portal/")')
    
def click_5():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.topeleven")')

def click_6():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.ninja.portal/")')

def click_7():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.calimero.portal/")')

def click_7():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin:/plugin.video.chidori")')

def click_8():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.train.mac.again/")')

def click_9():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.TakeOneMac/")')

def click_10():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.Gif.Peg.Tv/")')

TheAnonymousPortal()
