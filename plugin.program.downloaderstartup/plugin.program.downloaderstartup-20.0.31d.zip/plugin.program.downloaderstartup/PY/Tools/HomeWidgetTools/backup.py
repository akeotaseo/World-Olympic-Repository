﻿import xbmc, xbmcgui
xbmcgui.Dialog().notification("[COLOR orange]Backup[/COLOR]", "   ", sound=False, icon='special://home/addons/plugin.program.downloader19/resources/media/backup.png')
xbmc.executebuiltin('ActivateWindow(10001,"plugin://plugin.program.simple.favourites/index_of/special%3A%2F%2Fhome%2Faddons%2Fplugin.program.simple.favourites%2Ffolders%2FBackup%2F")')




