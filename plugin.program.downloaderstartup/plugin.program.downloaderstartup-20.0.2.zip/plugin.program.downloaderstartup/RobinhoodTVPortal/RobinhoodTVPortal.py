import xbmc, xbmcgui


def RobinhoodTVPortal():
    funcs = (click_1, click_2, click_3, click_4, click_5)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]  ~ Robinhood TV Portal &.... ~[/COLOR][/B]', 
['KodiBalkan Balkan Client',
  'KodiBalkan World Client',
  'KodiBalkan World Client 2',
  'Live in Zadar',

  '[COLORtomato]Romania[/COLOR][COLORgold](V)Edem[/COLOR]'
 ])



    if call:
        if call < 0:
            return
        func = funcs[call-5]
        return func()
    else:
        func = funcs[call]
        return func()
    return 




def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.balkanclient/",return)')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.worldclient/",return)')

def click_3():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.worldclient2/",return)')

def click_4():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.liveinzadar/",return))')

def click_5():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.edemro/",return)')

RobinhoodTVPortal()
