import xbmc, xbmcgui


def InDelRobinhoodTVPortal():
    funcs = (click_1, click_2, click_3)
    call = xbmcgui.Dialog().select('[B]Robinhood TV Portal &...[/B]', 
['[COLOR=green]Install[/COLOR] Robinhood TV Portal &...',
 '[B][COLOR=white]Robinhood TV Portal[/COLOR][/B]',
 '[COLOR=red]Delete[/COLOR] Robinhood TV  Portal &...'])
 



    if call:
        if call < 0:
            return
        func = funcs[call-3]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/UpdaterMatrix_19.py")')

def click_2():
    xbmc.executebuiltin('RunScript("special://home/addons//plugin.program.downloaderstartup/RobinhoodTVPortal/RobinhoodTVPortal.py")')

def click_3():
    xbmc.executebuiltin('RunScript("special://home/addons//plugin.program.downloaderstartup/RobinhoodTVortal/DeleteRobinhoodTVPortal.py")')

InDelRobinhoodTVPortal()
