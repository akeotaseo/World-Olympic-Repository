import os, xbmc, xbmcgui
def install_stalker():
    if xbmc.getCondVisibility('System.HasAddon({})'.format('pvr.stalker')): xbmcgui.Dialog().notification("[B][COLOR blue]Το PVR Stalker[/COLOR][/B]", "[COLOR white] είναι εγκατεστημένο![/COLOR]", icon='special://home/addons/plugin.program.downloaderstartup/resources/media/not.png')
    
    if not xbmc.getCondVisibility('System.HasAddon({})'.format('pvr.stalker')): install()

def install():
        choice = xbmcgui.Dialog().yesno('[COLOR orange]PVR Stalker[/COLOR]', '[COLOR white]Μετά την εγκατάσταση του πρόσθετου ανοίξτε το PVR Stalker απο τα [B]ΚΑΝΑΛΙΑ[/B]. Χρησιμοποιήστε την [COLOR lime]Αυτοματοποιημένη αντικατάσταση πύλης[/COLOR] ή περάστε δικές πύλες με την βοήθεια των Ιστότοπων Stalker Portal.[/COLOR]',
                                        nolabel='[B][COLOR orange]Άκυρο[/COLOR][/B]',yeslabel='[B][COLOR lime]Ok[/COLOR][/B]')

        if choice == 1: (xbmc.executebuiltin('InstallAddon(pvr.stalker)'))
                        # (xbmc.executebuiltin('InstallAddon(pvr.stalker)'),
                         # xbmc.sleep(1000),
                         # xbmc.executebuiltin('SendClick(11)'))
install_stalker()
