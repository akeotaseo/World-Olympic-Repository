import xbmc, xbmcgui


def Realdebrid():
    funcs = (click_1, click_2, click_3)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]~ Real Debrid / URL Resolver ~[/COLOR][/B]', 
['[B][COLOR=white]Foto[/COLOR][/B]',

 '[B][COLOR=white]video[/COLOR][/B]',

 '[B][COLOR=white]Site[/COLOR][/B]',
  ])


    if call:
        if call < 0:
            return
        func = funcs[call-3]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('ActivateWindow(10002,"special://home/media/ResolveURL/",return)')

def click_2():
    xbmc.executebuiltin('PlayMedia("plugin://plugin.video.youtube/play/?video_id=HrZctOPGvdM")')

def click_3():
    xbmc.executebuiltin('RunScript("script.realdebridsite")')


Realdebrid()
