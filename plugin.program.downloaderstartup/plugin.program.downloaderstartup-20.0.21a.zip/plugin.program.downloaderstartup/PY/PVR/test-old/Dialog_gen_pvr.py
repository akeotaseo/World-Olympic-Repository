﻿import os, xbmc, xbmcvfs, xbmcgui, xbmcaddon, shutil, glob

def Dialog_gen_pvr():
        choice = xbmcgui.Dialog().yesno('[B][COLOR=lime][COLOR=deepskyblue]ZTEU [COLOR=lime]Generator [COLOR=white][1-5][/COLOR][/B]', 'Μετά την φόρτωση καναλιών ίσως χρειαστεί (απο το [COLOR darkorchid]Επιλογή Γκρουπ[/COLOR]) να κάνετε μια αλλαγή...',
                                        nolabel='Ακυρο',yeslabel='[B][COLOR=lime][COLOR=deepskyblue]ZTEU [COLOR=lime]Generator [COLOR=white][1-5][/COLOR][/B]')

        if choice == 1: xbmcgui.Dialog().ok("[COLOR orange]ZTEU Generator [1-5][/COLOR]", "Αν η λίστα είναι κενή, ξαναπατάμε [COLOR=orange]ZTEU Generator![/COLOR]")

        if choice == 1: xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/PVR/gen_pvr.py")')
        
        if choice == 0: xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/PVR/Pvr.py")')
Dialog_gen_pvr()
