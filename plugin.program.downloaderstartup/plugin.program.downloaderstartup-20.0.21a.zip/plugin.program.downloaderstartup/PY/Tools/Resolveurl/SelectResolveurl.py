import os, xbmc, xbmcvfs, xbmcgui, xbmcaddon, shutil, glob


def SelectResolveurl():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7, click_8, click_9)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]  ~ Resolveurl ~[/COLOR][/B]', 
['[B]ResolveURL[/B] : Settings',
 '[B]Reset Settings ResolveURL[/B]',

 'Εξουσιοδότηση - Επαναφορά Derbid',
 'HELP',
 'RealDebrid',
 'Realizer (py3)',
 'Premiumizer (py3)',
 'RealDebrid VPN info',

 'Account Manager'

 ])


    if call:
        if call < 0:
            return
        func = funcs[call-9]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('PlayMedia("plugin://plugin.video.blacklodge/?action=smuSettings")')

def click_2():
    ResolveurlDialog()

def click_3():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/Tools/Resolveurl/derbid_authorize.py")')
    
def click_4():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/Tools/Resolveurl/Realdebrid.py")')

def click_5():
    xbmc.executebuiltin('ActivateWindow(10001,"plugin://script.realdebrid/",return)')

def click_6():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.realizerx/",return)')
    
def click_7():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.premiumizerx/",return)')

def click_8():
    xbmc.executebuiltin('ActivateWindow(10001,"plugin://script.RealDebrid.vpn/",return)')

def click_9():
    xbmc.executebuiltin('RunScript("script.module.accountmgr")')


def ResolveurlDialog():
        choice = xbmcgui.Dialog().yesno('[COLOR orange]Διαγραφή addon_data Resolveurl[/COLOR]', 'Με αυτή την επιλογή θα διαγραφούν οι ρυθμίσεις του [COLOR orange]Resolveurl[/COLOR]',
                                        nolabel='[B][COLOR white]Άκυρο...[/COLOR][/B]',yeslabel='[B][COLOR green]Διαγραφή[/COLOR][/B]')

        if choice == 1: [ResolveurlDelete(),
                         xbmc.sleep(1000),
                         xbmc.executebuiltin('PlayMedia("plugin://plugin.video.blacklodge/?action=smuSettings")'),]

def ResolveurlDelete():
    base_path = xbmcvfs.translatePath('special://home/userdata/addon_data')

    dir_list = glob.iglob(os.path.join(base_path, "script.module.resolveurl"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)



SelectResolveurl()
