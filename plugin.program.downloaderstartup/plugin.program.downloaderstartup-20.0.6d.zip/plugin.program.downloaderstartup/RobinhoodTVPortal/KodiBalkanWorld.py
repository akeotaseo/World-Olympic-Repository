import xbmc, xbmcgui


def KodiBalkanWorld():
    funcs = (click_1, click_2)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]  ~ KodiBalkan World ~[/COLOR][/B]', 
['KodiBalkan World Client - Select Portal',
 '[COLOR=blue]KodiBalkan World Client[/COLOR]'])



    if call:
        if call < 0:
            return
        func = funcs[call-2]
        return func()
    else:
        func = funcs[call]
        return func()
    return 




def click_1():
    xbmc.executebuiltin('RunScript("special://home/addons//plugin.program.downloaderstartup/RobinhoodTVPortal/KodiBalkanWorldClientPortal.py")')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.worldclient/")')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.worldclient/")')



kanWorld()
