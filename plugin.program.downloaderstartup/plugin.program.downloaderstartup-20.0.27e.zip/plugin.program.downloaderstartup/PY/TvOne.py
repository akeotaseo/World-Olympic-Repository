import xbmc, xbmcgui


def tvone():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7, click_8, click_9, click_10)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]~ TvOne All ~[/COLOR][/B]', 
['[B][COLOR=white]script.module.xenon4k/?mode=1[/COLOR][/B]',
 '[B][COLOR=white]script.module.xenon4k/?mode=2[/COLOR][/B]',
 '[B][COLOR=white]5000[/COLOR][/B]',
 '[B][COLOR=white]5001[/COLOR][/B]',
 '[B][COLOR=white]5002[/COLOR][/B]',
 '[B][COLOR=white]5003[/COLOR][/B]',
 '[B][COLOR=white]5004[/COLOR][/B]',
 '[B][COLOR=white]5005[/COLOR][/B]',
 '[B][COLOR=white]TvOne1112[/COLOR][/B]',
 '[B][COLOR=white]TvOne112[/COLOR][/B]'])


    if call:
        if call < 0:
            return
        func = funcs[call-10]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('RunPlugin(plugin://script.module.xenon4k/?mode=1)')

def click_2():
    xbmc.executebuiltin('RunPlugin(plugin://script.module.xenon4k/?mode=2)')

def click_3():
    xbmc.executebuiltin('ActivateWindow(5000)')

def click_4():
    xbmc.executebuiltin('ActivateWindow(5001)')
    
def click_5():
    xbmc.executebuiltin('ActivateWindow(5002)')

def click_6():
    xbmc.executebuiltin('ActivateWindow(5003)')

def click_7():
    xbmc.executebuiltin('ActivateWindow(5004)')

def click_8():
    xbmc.executebuiltin('ActivateWindow(5005)')

def click_9():
    xbmc.executebuiltin('RunPlugin(plugin://script.module.xenon4k/?mode=4)')
    
def click_10():
    xbmc.executebuiltin('ActivateWindow(1107)')


tvone()
