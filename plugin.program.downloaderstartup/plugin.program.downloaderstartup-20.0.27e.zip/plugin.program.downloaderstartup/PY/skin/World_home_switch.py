import os
import shutil
import subprocess
import xbmcgui
import xbmcvfs
import xbmc, xbmcaddon
dialog = xbmcgui.Dialog()
settings_path = xbmcvfs.translatePath('special://userdata/addon_data/skin.19MatrixWorld/')

def World_home_switch():
        flavor_list = ['Save Your Settings', 'Choose Your Settings', ' Free', 'Choose Movies & TV', 'Choose Sports']
        select = dialog.select('Choose Settings', flavor_list)
        if select == None:
            return          



        if select == 0:
                Save()



        if select == 1:
            #απο εδω Choose Your Settings
                src_settings = xbmcvfs.translatePath('special://home/addons/plugin.program.downloaderstartup/PY/skin/switch/Choose_Your_Setting/settings.xml')
                #παει εδω
                dst_settings = xbmcvfs.translatePath('special://userdata/addon_data/skin.19MatrixWorld/settings.xml')
                
                if os.path.exists(os.path.join(settings_path)):
                        try:
                                shutil.copyfile(src_settings, dst_settings)
                                Choose()
                                # xbmcgui.Dialog().ok('Choose Your Settings', 'To save skin changes, please close Kodi, Press OK to force close Kodi')
                                # os._exit(1)
                        except:
                                xbmcgui.Dialog().ok('Choose Your Settings', 'Error...')
                else:
                        xbmcgui.Dialog().ok('Choose Your Settings', 'Error...')



        if select == 2:
            #απο εδω Free
                src_settings = xbmcvfs.translatePath('special://home/addons/plugin.program.downloaderstartup/PY/skin/switch/Xenon_Plus_TMDBH/settings.xml')
                #παει εδω
                dst_settings = xbmcvfs.translatePath('special://userdata/addon_data/skin.19MatrixWorld/settings.xml')
                
                if os.path.exists(os.path.join(settings_path)):
                        try:
                                shutil.copyfile(src_settings, dst_settings)
                                Choose()
                        except:
                                xbmcgui.Dialog().ok(' Switcher Skin Settings', 'Error switching skin settings')
                else:
                        xbmcgui.Dialog().ok('Xenon Plus Switcher', 'Error switching skin, please contact developer')



        if select == 3:
            #απο εδω Choose Choose Movies & TV
                src_settings = xbmcvfs.translatePath('special://home/addons/plugin.program.downloaderstartup/PY/skin/switch/Xenon_Plus_Coalition/settings.xml')
                #παει εδω
                dst_settings = xbmcvfs.translatePath('special://userdata/addon_data/skin.19MatrixWorld/settings.xml')
                
                if os.path.exists(os.path.join(settings_path)):
                        try:
                                shutil.copyfile(src_settings, dst_settings)
                                xbmcgui.Dialog().ok('Xenon Plus Switcher', 'To save skin changes, please close Kodi, Press OK to force close Kodi')
                                # os._exit(1)
                        except:
                                xbmcgui.Dialog().ok('Xenon Plus Switcher', 'Error switching skin, please contact developer')
                else:
                        xbmcgui.Dialog().ok('Xenon Plus Switcher', 'Error switching skin, please contact developer')



        if select == 4:
            #απο εδω Choose Sports
                src_settings = xbmcvfs.translatePath('special://home/addons/plugin.program.downloaderstartup/PY/skin/switch/Xenon_Plus_TMDBH/settings.xml')
                #παει εδω
                dst_settings = xbmcvfs.translatePath('special://userdata/addon_data/skin.19MatrixWorld/settings.xml')
                
                if os.path.exists(os.path.join(settings_path)):
                        try:
                                shutil.copyfile(src_settings, dst_settings)
                                xbmcgui.Dialog().ok('Xenon Plus Switcher', 'To save skin changes, please close Kodi, Press OK to force close Kodi')
                                # os._exit(1)
                        except:
                                xbmcgui.Dialog().ok('Xenon Plus Switcher', 'Error switching skin, please contact developer')
                else:
                        xbmcgui.Dialog().ok('Xenon Plus Switcher', 'Error switching skin, please contact developer')




def Choose():
        choice = xbmcgui.Dialog().yesno('[B][COLOR orange]Choose Skin Settings[/COLOR][/B]', 'Για να εφαρμοστούν οι αλλαγές[CR]Πατήστε [COLOR red]Force Close[/COLOR] ή [COLOR blue]Reload Profile[/COLOR]',
                                        nolabel='[COLOR red]Force Close[/COLOR]',yeslabel='[COLOR blue]Reload Profile[/COLOR]')
        if choice == 1: [
                         xbmcgui.Dialog().notification("[COLOR blue]Reload Profile[/COLOR]", "Παρακαλώ Περιμένετε...", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/Profile.png'),
                         xbmc.sleep(2000),
                         xbmc.executebuiltin("LoadProfile(Master user)"),]
        if choice == 0: [os._exit(1),]




def Save():
        choice = xbmcgui.Dialog().yesno('[B][COLOR orange]Save Skin Settings[/COLOR][/B]', '[COLOR red]Προσοχή![/COLOR] Αν έχετε ξανασώσει τα settings του Skin..[CR]θα αντικατασταθούν με αυτά![CR]Θέλετε να συνεχίσετε;',
                                        nolabel='Οχι',yeslabel='Ναι')
        if choice == 1: [Save0(), 
                         xbmcgui.Dialog().notification("[COLOR line]Save Skin Settings[/COLOR]", "Τα Settings αποθυκεύτηκαν με επιτυχί!", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/Profile.png'),]
                         # xbmc.sleep(2000),
                         # xbmc.executebuiltin("LoadProfile(Master user)"),]
        # if choice == 0: [os._exit(1),]


def Save0():
                #απο εδω Save Your Settings
                src_settings = xbmcvfs.translatePath('special://userdata/addon_data/skin.19MatrixWorld/settings.xml')
                #παει εδω
                dst_settings = xbmcvfs.translatePath('special://home/addons/plugin.program.downloaderstartup/PY/skin/switch/Save_Your_Settings/settings.xml')
                
                
                if os.path.exists(os.path.join(settings_path)):
                        try:
                                shutil.copyfile(src_settings, dst_settings)
                                
                                # xbmcgui.Dialog().ok('Choose Your Settings', 'To save skin changes, please close Kodi, Press OK to force close Kodi')
                                # os._exit(1)
                        except:
                                xbmcgui.Dialog().ok('Save Your Settings', 'Error...')
                else:
                        xbmcgui.Dialog().ok('Save Your Settings', 'Error...')



World_home_switch()
