import os, xbmc, xbmcgui, glob, shutil

def addon_disable():
        choice = xbmcgui.Dialog().yesno('[B][COLOR orange]World[/COLOR][/B]', '[COLOR white] Για αλλαγή του skin απο "Γραμματοσειρά" σε "Εικονίδια", πατήστε[/COLOR]  [COLOR red]Skin[/COLOR] στο [COLOR lime]DialogButtonMenu[/COLOR] και επιλέξτε "Graph"[CR](Για να επαναφέρετε το skin στη Γραμματοσειρά ακολουθήστε την ίδια διαδικασία και επιλέξτε "Text")',
                                        nolabel='[COLOR orange]Κλείσε[/COLOR]',yeslabel='[COLOR lime]DialogButtonMenu[/COLOR]')

        if choice == 1: xbmc.executebuiltin('activatewindow(shutdownmenu)'),

addon_disable()
