import xbmc, xbmcgui


def Error():
    funcs = (click_1, click_2, click_3)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]Errors[/COLOR][/B]', 
['[B][COLOR blue]Προβολή σφαλμάτων στο Log[/COLOR][/B]',
 '[COLOR blue]Προβολή τελευταίου σφάλματος στο Log[/COLOR]',
 'View Log'
 ])



    if call:
        if call < 0:
            return
        func = funcs[call-3]
        return func()
    else:
        func = funcs[call]
        return func()
    return 0



def click_1():
    xbmc.executebuiltin('PlayMedia("plugin://plugin.program.G.K.N.Wizard/?mode=viewerrorlog",return)')

def click_2():
    xbmc.executebuiltin('PlayMedia("plugin://plugin.program.G.K.N.Wizard/?mode=viewerrorlast")')

def click_3():
    xbmc.executebuiltin('PlayMedia("plugin://plugin.program.downloader19/?url=&mode=32&name=View+Log&icon=special%3A%2F%2Fhome%2Faddons%2Fplugin.program.downloader19%2Fresources%2Fmedia%2FLog.png&fanart=C%3A%5CPortableApps%5Ckodi%5Ckodi+World+20%5CKodi%5Cportable_data%5Caddons%5Cplugin.program.downloader19%5Cfanart.jpg&description=&name2=&version=")')
    
Error()
