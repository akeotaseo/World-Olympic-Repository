import xbmc, xbmcgui


def KodiBalkanWorld():
    funcs = (click_1, click_2)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]  ~ KodiBalkan World ~[/COLOR][/B]', 
['KodiBalkan World Client - Select Portal',
 '[COLOR=blue]KodiBalkan World Client[/COLOR]'])



    if call:
        if call < 0:
            return
        func = funcs[call-2]
        return func()
    else:
        func = funcs[call]
        return func()
    return 




def click_1():
    xbmc.executebuiltin('RunScript("special://home/addons//plugin.program.downloaderstartup/RobinhoodTVPortal/KodiBalkanWorldClientPortal.py")')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.worldclient/")')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.worldclient/")')

def click_3():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.worldclient2/",return)')

def click_4():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.worldclient3/",return)')

def click_5():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.liveinzadar/",return))')

def click_6():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.x-codes2/",return)')

def click_7():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.edemro/",return)')

def click_8():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.worldclient3/",return)')

def click_9():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.liveinzadar/",return))')

def click_10():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.x-codes2/",return)')

def click_11():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.edemro/",return)')
KodiBalkanWorld()
