import os, xbmcgui

def killkodi():
        choice = xbmcgui.Dialog().yesno('[B][COLOR orange]World Build[/COLOR][/B]', '[COLOR white]Το Kodi θα κλείσει άμεσα...[CR]Θέλετε να συνεχίσετε?[/COLOR]',
                                        nolabel='[COLOR white]Όχι[/COLOR]',yeslabel='[COLOR white]Ναι[/COLOR]')
        if choice == 1: [
                         xbmcgui.Dialog().notification("[B][COLOR orange]Αντίο![/COLOR][/B]", "[COLOR green]Να είστε καλά![/COLOR]", sound=False, icon='special://home/addons/skin.19MatrixWorld/media/Bye.png'),
                         xbmc.sleep(7000),
                         os._exit(1),]

killkodi()