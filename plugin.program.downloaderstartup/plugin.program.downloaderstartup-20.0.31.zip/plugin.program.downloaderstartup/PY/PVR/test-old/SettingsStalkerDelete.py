import os, xbmc, xbmcgui, xbmcvfs, glob, shutil

xbmcvfs.delete('special://home/userdata/addon_data/pvr.stalker/instance-settings-1.xml')
xbmcvfs.delete('special://home/userdata/addon_data/pvr.stalker/epg_provider.json')
xbmcvfs.delete('special://home/userdata/addon_data/pvr.stalker/cache.xml')
xbmcvfs.delete('special://home/userdata/addon_data/pvr.stalker/settings.xml')



SettingsStalkerDelete()
