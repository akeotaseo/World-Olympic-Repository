import os, xbmc, xbmcvfs, xbmcgui, xbmcaddon, shutil, glob


def SelectResolveurl():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7, click_8, click_9, click_10, click_11)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]  ~ Resolveurl ~[/COLOR][/B]', 
['[B]ResolveURL[/B] : Settings',
 '[B]Reset Settings ResolveURL[/B]',

 'Εξουσιοδότηση - Επαναφορά Derbid',
 'HELP',
 '[COLOR orange]____[/COLOR]',
 'RealDebrid',
 'Realizer (py3)',
 'Premiumizer (py3)',
 'RealDebrid VPN info',
 'Debrid Manager',
 '[COLOR teal]Account Manager[/COLOR]'

 ])


    if call:
        if call < 0:
            return
        func = funcs[call-11]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('PlayMedia("plugin://plugin.video.blacklodge/?action=smuSettings")')

def click_2():
    ResolveurlDialog()

def click_3():
    derbid_authorize()
    
def click_4():
    Help_Realdebrid()

def click_5():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/Tools/Resolveurl/SelectResolveurl.py")')

def click_6():
    xbmc.executebuiltin('ActivateWindow(10001,"plugin://script.realdebrid/")')

def click_7():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.realizerx/")')
    
def click_8():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.premiumizerx/")')

def click_9():
    xbmc.executebuiltin('ActivateWindow(10001,"plugin://script.RealDebrid.vpn/")')

def click_10():
    # xbmc.executebuiltin('ActivateWindow(10001,"plugin://script.module.debridmgr")')
    if xbmc.getCondVisibility('System.HasAddon({})'.format('script.module.debridmgr')):
    # xbmc.executebuiltin('Dialog.Close(all,true)')
    # xbmc.executebuiltin('Action(Back)')
    # xbmc.executebuiltin('Dialog.Close(all,true)')
        xbmc.executebuiltin('RunScript("script.module.debridmgr")')
    
    if not xbmc.getCondVisibility('System.HasAddon({})'.format('script.module.debridmgr')):
        
        
        xbmc.executebuiltin('ActivateWindow(10025,"plugin://script.module.debridmgr")')
        xbmc.sleep(12000)
        xbmc.executebuiltin('Dialog.Close(all,true)')
        xbmc.executebuiltin('Action(Back)')
        xbmc.executebuiltin('Dialog.Close(all,true)')
        xbmc.executebuiltin('ActivateWindow(10000)')
        xbmc.executebuiltin('RunScript("script.module.debridmgr")')
        xbmc.executebuiltin('RunScript("script.module.debridmgr")')
        xbmc.executebuiltin('RunScript("script.module.debridmgr")')


def click_11():
    if xbmc.getCondVisibility('System.HasAddon({})'.format('script.module.accountmgr')):
    # xbmc.executebuiltin('Dialog.Close(all,true)')
    # xbmc.executebuiltin('Action(Back)')
    # xbmc.executebuiltin('Dialog.Close(all,true)')
        xbmc.executebuiltin('RunScript("script.module.accountmgr")')
    
    if not xbmc.getCondVisibility('System.HasAddon({})'.format('script.module.accountmgr')):
        
        
        xbmc.executebuiltin('ActivateWindow(10025,"plugin://script.module.accountmgr")')
        xbmc.sleep(12000)
        xbmc.executebuiltin('Dialog.Close(all,true)')
        xbmc.executebuiltin('Action(Back)')
        xbmc.executebuiltin('Dialog.Close(all,true)')
        xbmc.executebuiltin('ActivateWindow(10000)')
        xbmc.executebuiltin('RunScript("script.module.accountmgr")')
        xbmc.executebuiltin('RunScript("script.module.accountmgr")')
        xbmc.executebuiltin('RunScript("script.module.accountmgr")')


#######################
def ResolveurlDialog():
        choice = xbmcgui.Dialog().yesno('[COLOR orange]Διαγραφή addon_data Resolveurl[/COLOR]', 'Με αυτή την επιλογή θα διαγραφούν οι ρυθμίσεις του [COLOR orange]Resolveurl[/COLOR]',
                                        nolabel='[B][COLOR white]Άκυρο...[/COLOR][/B]',yeslabel='[B][COLOR green]Διαγραφή[/COLOR][/B]')

        if choice == 1: [ResolveurlDelete(),
                         xbmc.sleep(1000),
                         xbmc.executebuiltin('PlayMedia("plugin://plugin.video.blacklodge/?action=smuSettings")'),]

def ResolveurlDelete():
    base_path = xbmcvfs.translatePath('special://home/userdata/addon_data')

    dir_list = glob.iglob(os.path.join(base_path, "script.module.resolveurl"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)



#######################
def Help_Realdebrid():
    funcs = (click__1, click__2, click__3)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]~ Real Debrid / URL Resolver ~[/COLOR][/B]', 
['[B][COLOR=white]Foto[/COLOR][/B]',

 '[B][COLOR=white]video[/COLOR][/B]',

 '[B][COLOR=white]Site[/COLOR][/B]',
  ])


    if call:
        if call < 0:
            return
        func = funcs[call-3]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click__1():
    xbmc.executebuiltin('ActivateWindow(10002,"special://home/media/ResolveURL/",return)')

def click__2():
    xbmc.executebuiltin('PlayMedia("plugin://plugin.video.youtube/play/?video_id=HrZctOPGvdM")')

def click__3():
    xbmc.executebuiltin('RunScript("script.realdebridsite")')


#######################
def derbid_authorize():
    funcs = (action___1, action___2, action___3, action___4, action___5, action___6, action___7, action___8, action___9, action___10)
    selection = xbmcgui.Dialog().select('[B][COLOR=orange]Εξουσιοδότηση - Επαναφορά Derbid[/COLOR][/B]', 
['[B][COLOR=white][COLOR=lime]Authorize [COLOR=white]Real-Derbid[/COLOR][/B]',
 '[B][COLOR=white][COLOR=lime]Authorize [COLOR=white]AllDerbid[/COLOR][/B]',
 '[B][COLOR=white][COLOR=lime]Authorize [COLOR=white]Premiumize.me[/COLOR][/B]',
 '[B][COLOR=white][COLOR=lime]Authorize [COLOR=white]Debrid-Link.fr[/COLOR][/B]',
 '[B][COLOR=white][COLOR=lime]Authorize [COLOR=white]Link Snappy[/COLOR][/B]',
 '[B][COLOR=white][COLOR=orange]Reset [COLOR=white]Real-Debrid[/COLOR][/B]',
 '[B][COLOR=white][COLOR=orange]Reset [COLOR=white]AllDebrid[/COLOR][/B]',
 '[B][COLOR=white][COLOR=orange]Reset [COLOR=white]Premiumize.me[/COLOR][/B]',
 '[B][COLOR=white][COLOR=orange]Reset [COLOR=white]Debrid-Link.fr[/COLOR][/B]',
 '[B][COLOR=white][COLOR=orange]Reset [COLOR=white]Link Snappy[/COLOR][/B]'])

    if selection:
        if selection < 0:
            return 
        func = funcs[selection-10]
        return func()
    else:
        func = funcs[selection]
        return func()
    return 

def action___1():
    xbmc.executebuiltin('RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)')

def action___2():
    xbmc.executebuiltin('RunPlugin(plugin://script.module.resolveurl/?mode=auth_ad)')

def action___3():
    xbmc.executebuiltin('RunPlugin(plugin://script.module.resolveurl/?mode=auth_pm)')

def action___4():
    xbmc.executebuiltin('RunPlugin(plugin://script.module.resolveurl/?mode=auth_dl)')

def action___5():
    xbmc.executebuiltin('RunPlugin(plugin://script.module.resolveurl/?mode=auth_ls)')

def action___6():
    xbmc.executebuiltin('RunPlugin(plugin://script.module.resolveurl/?mode=reset_rd)')

def action___7():
    xbmc.executebuiltin('RunPlugin(plugin://script.module.resolveurl/?mode=reset_ad)')

def action___8():
    xbmc.executebuiltin('RunPlugin(plugin://script.module.resolveurl/?mode=reset_pm)')

def action___9():
    xbmc.executebuiltin('RunPlugin(plugin://script.module.resolveurl/?mode=reset_dl)')

def action___10():
    xbmc.executebuiltin('RunPlugin(plugin://script.module.resolveurl/?mode=reset_ls)')

SelectResolveurl()
