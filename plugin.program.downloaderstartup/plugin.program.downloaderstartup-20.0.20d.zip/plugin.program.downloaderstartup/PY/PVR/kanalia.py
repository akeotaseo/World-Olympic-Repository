import os, xbmc, xbmcvfs, xbmcgui, xbmcaddon, shutil, glob
# xbmcgui.Dialog().notification("[B][COLOR orange]They don't always work[/COLOR][/B]", "[COLOR green]Δεν λειτουργούν πάντα...[/COLOR]", sound=False, icon='special://home/addons/plugin.video.macvod/DialogPleaseWait/doestworkalltime.png')
# xbmc.sleep(4000)






def DialogkanaliaYesNo():
        choice = xbmcgui.Dialog().yesno('ΚΑΝΑΛΙΑ', '[COLOR lime]Είσοδος[/COLOR] στα [B]ΚΑΝΑΛΙΑ?[/B]',
                                        nolabel='[B][COLOR white]Οχι τώρα...[/COLOR][/B]',yeslabel='[B][COLOR white]Ναι[/COLOR][/B]')

        if choice == 1: kanalia()
        if choice == 0: xbmc.executebuiltin('Dialog.Close(all,true)'), xbmc.executebuiltin('Action(Back)')



def kanalia():
    funcs = (click_1, click_2, click_3)
    call = xbmcgui.Dialog().select('[B][COLOR=silver]~ PVR ~[/COLOR][/B]', 
['[COLOR=cornflowerblue]IPTV Simple Client[/COLOR]',
 '[COLOR=blue]PVR Stalker[/COLOR]',
 '[COLOR=cyan]PVR ALL[/COLOR]'
])


    if call:
        if call < 0:
            return
        func = funcs[call-3]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    choice = xbmcgui.Dialog().yesno('ΚΑΝΑΛΙΑ', '[COLOR lime]Είσοδος[/COLOR] στα [B]ΚΑΝΑΛΙΑ?[/B]',
                                        nolabel='[B][COLOR white]Οχι τώρα...[/COLOR][/B]',yeslabel='[B][COLOR white]Ναι[/COLOR][/B]')

    if choice == 1: kanalia_iptvsimple()
    if choice == 0: xbmc.executebuiltin('Dialog.Close(all,true)'), xbmc.executebuiltin('Action(Back)')

def click_2():
    choice = xbmcgui.Dialog().yesno('ΚΑΝΑΛΙΑ', '[COLOR lime]Είσοδος[/COLOR] στα [B]ΚΑΝΑΛΙΑ?[/B]',
                                        nolabel='[B][COLOR white]Οχι τώρα...[/COLOR][/B]',yeslabel='[B][COLOR white]Ναι[/COLOR][/B]')

    if choice == 1: kanaliaStalker()
    if choice == 0: xbmc.executebuiltin('Dialog.Close(all,true)'), xbmc.executebuiltin('Action(Back)')

def click_3():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('Action(Back)')
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(10000)')
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.iptvsimple","enabled":true}}')
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.stalker","enabled":true}}')
    # xbmc.sleep(1000)
    choice = xbmcgui.Dialog().yesno('ΚΑΝΑΛΙΑ', '[COLOR lime]Είσοδος[/COLOR] στα [B]ΚΑΝΑΛΙΑ?[/B]',
                                        nolabel='[B][COLOR white]Οχι τώρα...[/COLOR][/B]',yeslabel='[B][COLOR white]Ναι[/COLOR][/B]')

    if choice == 1: xbmc.executebuiltin('ActivateWindow(TVChannels)')
    if choice == 0: xbmc.executebuiltin('Action(Back)')



#iptvsimple
def kanalia_iptvsimple():
    if not xbmc.getCondVisibility('System.HasAddon({})'.format('pvr.iptvsimple')):
        xbmcgui.Dialog().ok('[B][COLOR orange]cornflowerblue[/COLOR][/B]', 'Επιλέξτε αν θέλετε να εγκαταστήσετε το [COLOR=cornflowerblue]IPTV Simple Client[/COLOR]')
        choice = xbmcgui.Dialog().yesno('[COLOR cornflowerblue]IPTV Simple Client[/COLOR]', '[COLOR white]Μετά την εγκατάσταση του πρόσθετου ανοίξτε το [COLOR cornflowerblue]IPTV Simple Client[/COLOR] απο τα [B]ΚΑΝΑΛΙΑ[/B].[/COLOR]',
                                        nolabel='[B][COLOR orange]Άκυρο[/COLOR][/B]',yeslabel='[B][COLOR lime]Εγκατάσταση[/COLOR][/B]')

        if choice == 1: installiptvsimple()
                         # (xbmc.executebuiltin('InstallAddon(pvr.stalker)'),
                         # xbmc.sleep(1000),
                         # xbmc.executebuiltin('SendClick(11)'))
    if xbmc.getCondVisibility('System.HasAddon({})'.format('pvr.iptvsimple')):
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.stalker","enabled":false}}')
        xbmc.sleep(500)
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.iptvsimple","enabled":true}}')
        # xbmc.sleep(1000)
        # xbmc.executebuiltin('SendClick(11)')
        # xbmc.sleep(500)
        xbmc.sleep(500)
        xbmc.executebuiltin('Dialog.Close(all,true)')
        xbmc.executebuiltin('Action(Back)')
        xbmc.executebuiltin('Dialog.Close(all,true)')
        xbmc.executebuiltin('ActivateWindow(10000)')
        xbmc.executebuiltin('ActivateWindow(TVChannels)')
        xbmcgui.Dialog().notification("[COLOR=cornflowerblue]IPTV Simple Client[/COLOR]", "[COLOR white]Αναμονή...μέχρι να φορτώσουν τα κανάλια...[/COLOR]", icon='special://home/addons/pvr.iptvsimple/icon.png', sound=True)
        xbmc.sleep(4000)
def installiptvsimple():
        xbmc.executebuiltin('InstallAddon(pvr.iptvsimple)')




#Stalker
def kanaliaStalker():
    if not xbmc.getCondVisibility('System.HasAddon({})'.format('pvr.stalker')):
        xbmcgui.Dialog().ok('[B][COLOR blue]PVR[/COLOR][/B]', 'Επιλέξτε αν θέλετε να εγκαταστήσετε το [COLOR=blue]PVR Stalker[/COLOR]')
        choice = xbmcgui.Dialog().yesno('[COLOR blue]PVR Stalker[/COLOR]', '[COLOR white]Μετά την εγκατάσταση του πρόσθετου ανοίξτε το [COLOR blue]PVR Stalker[/COLOR] απο τα [B]ΚΑΝΑΛΙΑ[/B]. Χρησιμοποιήστε την [COLOR lime]Αυτοματοποιημένη αντικατάσταση πύλης[/COLOR] ή περάστε δικές πύλες με την βοήθεια των Ιστότοπων Stalker Portal.[/COLOR]',
                                        nolabel='[B][COLOR orange]Άκυρο[/COLOR][/B]',yeslabel='[B][COLOR lime]Εγκατάσταση[/COLOR][/B]')

        if choice == 1: installStalker()
                         # (xbmc.executebuiltin('InstallAddon(pvr.stalker)'),
                         # xbmc.sleep(1000),
                         # xbmc.executebuiltin('SendClick(11)'))
    if xbmc.getCondVisibility('System.HasAddon({})'.format('pvr.stalker')):
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.iptvsimple","enabled":false}}')
        xbmc.sleep(500)
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.stalker","enabled":true}}')
        # xbmc.sleep(1000)
        # xbmc.executebuiltin('SendClick(11)')
        # xbmc.sleep(500)
        xbmc.sleep(500)
        xbmc.executebuiltin('Dialog.Close(all,true)')
        xbmc.executebuiltin('Action(Back)')
        xbmc.executebuiltin('Dialog.Close(all,true)')
        xbmc.executebuiltin('ActivateWindow(10000)')
        xbmc.executebuiltin('ActivateWindow(TVChannels)')
        xbmcgui.Dialog().notification("[COLOR blue]PVR Stalker[/COLOR]", "[COLOR white]Αναμονή...μέχρι να φορτώσουν τα κανάλια...[/COLOR]", icon='special://home/addons/pvr.stalker/icon.png', sound=True)
        xbmc.sleep(4000)
def installStalker():
        xbmc.executebuiltin('InstallAddon(pvr.stalker)')



kanalia()

