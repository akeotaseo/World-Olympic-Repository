﻿import xbmc, xbmcgui

def DialogeUp():
        
        choice = xbmcgui.Dialog().yesno('[B][COLOR green]Ενημερώσεις Πρόσθετων[/COLOR][/B]', 'Θέλετε να δείτε τις ενημερώσεις των πρόσθετων ;',
                                        nolabel='[COLOR red]Οχι ReloadSkin[/COLOR]',yeslabel='[COLOR green]Ναι[/COLOR]')

        if choice == 1: Up()
        if choice == 0: UpNo()



def DialogeReloadSkin():
        
        choice = xbmcgui.Dialog().yesno('[B][COLOR red]ReloadSkin[/COLOR][/B]', 'Πατήστε [COLOR red]ReloadSkin...[/COLOR]',
                                        nolabel='Οχι',yeslabel='[COLOR red]ReloadSkin[/COLOR]')

        if choice == 1: [xbmc.executebuiltin("ReloadSkin()"),]
        #if choice == 0: [xbmc.executebuiltin("ReloadSkin()"),]


def Up():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('UpdateAddonRepos()')
    xbmc.executebuiltin('UpdateLocalAddons()')

    xbmc.executebuiltin("ActivateWindow(10040,addons://recently_updated)")


def UpNo():
    ('Dialog.Close(all,true)')
    DialogeReloadSkin()

DialogeUp()
