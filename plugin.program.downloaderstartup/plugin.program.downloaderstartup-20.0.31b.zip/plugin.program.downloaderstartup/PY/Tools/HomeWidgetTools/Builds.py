﻿import xbmc, xbmcgui
xbmcgui.Dialog().notification("[COLOR orange]Builds[/COLOR]", "   ", sound=False, icon='special://home/addons/plugin.program.G.K.N.Wizard/icon.png')

# xbmc.executebuiltin('ActivateWindow(10000)')
# xbmc.sleep(4000)
xbmc.executebuiltin('ActivateWindow(10001,"plugin://plugin.program.G.K.N.Wizard/?mode=builds",return)')




