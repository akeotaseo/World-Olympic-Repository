import os, xbmc, xbmcgui

def killkodi():
        choice = xbmcgui.Dialog().yesno('[B][COLOR orange]TechNEWSology[/COLOR][/B]', '[COLOR white]Το Kodi θα κλείσει άμεσα...[CR]Θέλετε να συνεχίσετε?[/COLOR]',
                                        nolabel='[COLOR white]Όχι[/COLOR]',yeslabel='[COLOR white]Ναι[/COLOR]')
        if choice == 1:
                       
                       
                       if xbmc.getCondVisibility('System.HasAddon({})'.format('pvr.stalker')):
                           xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.stalker","enabled":false}}')
                       os._exit(1)
killkodi()