import os, xbmc, xbmcvfs, xbmcgui, xbmcaddon, shutil, glob


def SkinTools():
    funcs = (click1, click2, click3, click4, click5, click6, click7)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]~ Skin tools ~[/COLOR][/B]', 
['Home Widget [COLOR=red]OFF[/COLOR] / [COLOR=green]ON[/COLOR]',
 'Single Global Background',

  '[COLOR red] Skin[/COLOR] Tools',
 'Txt / Graph [COLOR red] Skin[/COLOR]',
 'Intro [COLOR=green]Enable[/COLOR] / [COLOR=red]Disable[/COLOR]',
 '   ',


 '[B][COLOR red]<---                                                                      [COLOR grey]Back[/COLOR][/B]'
 ])


    if call:
        if call < 0:
            return
        func = funcs[call-7]
        return func()
    else:
        func = funcs[call]
        return func()
    return 


def click1():
    HomeWidget()

def click2():
    #xbmc.executebuiltin('Skin.ToggleSetting(SingleGlobalBackground)')
    #xbmc.sleep(1000)
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/skin/SkinBackground.py")')

def click3():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/skin/SkinMenuTools.py")')

def click4():
    choice = xbmcgui.Dialog().yesno('[B][COLOR orange]TextGraph[/COLOR][/B]', '[COLOR white]Για αλλαγή του skin απο "Γραμματοσειρά" σε "Εικονίδια", [/COLOR] επιλέξτε "Graph"[CR](Για να επαναφέρετε το skin στη Γραμματοσειρά επιλέξτε "Text")',
                                    nolabel='[COLOR orange]Κλείσε[/COLOR]',yeslabel='[COLOR red]Text Graph[/COLOR]')

    if choice == 1: SkinMenuLAF()
    if choice == 0: xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/Tools/SkinTools.py")')
    # xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/skin/DialogTextGraph.py")')

def click5():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/skin/Introonoff.py")')

def click6():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/Tools/SkinTools.py")')

def click7():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/Tools/Programs.py")')





def HomeWidget():
    funcs = (click_1, click_2)
    call = xbmcgui.Dialog().select('[B][COLOR=green]ON[/COLOR][/B]/[B][COLOR=red]OFF[/COLOR] HomeWidget[/B]', 
['[COLOR=green]ON[/COLOR]',
 '[COLOR=red] OFF[/COLOR]'])



    if call:
        if call < 0:
            return
        func = funcs[call-2]
        return func()
    else:
        func = funcs[call]
        return func()
    return 

def HomeWidgetON():
    choice = xbmcgui.Dialog().yesno('[COLOR orange]Ενεργοποίηση HomeWidget[/COLOR]', 'Ενεργοποίηση HomeWidget.[CR]Για να συνεχίσετε πατήστε [B][COLOR green]HomeWidget ON[/COLOR][/B][CR]και περιμένετε...',
                                    nolabel='[B][COLOR white]Όχι τώρα...[/COLOR][/B]',yeslabel='[B][COLOR green]HomeWidget ON[/COLOR][/B]')
    if choice == 1: [xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/UpdaterMatrix_8.py")'),]
def click_1(): HomeWidgetON()
    


def HomeWidgetONOFF():
    choice = xbmcgui.Dialog().yesno('[COLOR orange]Απενεργοποίηση HomeWidget[/COLOR]', 'Απενεργοποίηση HomeWidget.[CR]Για να συνεχίσετε πατήστε [B][COLOR red]HomeWidget Off[/COLOR][/B][CR]και περιμένετε...',
                                    nolabel='[B][COLOR white]Όχι τώρα...[/COLOR][/B]',yeslabel='[B][COLOR red]HomeWidget OFF[/COLOR][/B]')

    if choice == 1: [xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/UpdaterMatrix_100.py")'),]

def click_2(): HomeWidgetONOFF()
    
    #xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/Tools/downloaderstartupOnOff/DialogEnableDisabledownloaderstartup.py")')

















def SkinMenuLAF():
    funcs = (click_1, click_2, click_3, click_4)
    call = xbmcgui.Dialog().select('[B]SkinMenuLAF[/B]', 
['[COLOR red] Skin [/COLOR] Text',
 '[COLOR red] Skin [/COLOR] Graph',
 '[COLOR red] Skin [/COLOR] GraphFocused',
  '[B][COLOR red]<---                                                                      [COLOR grey]Back[/COLOR][/B]'
 ])
 



    if call:
        if call < 0:
            return
        func = funcs[call-4]
        return func()
    else:
        func = funcs[call]
        return func()
    return 





def click_1():
    xbmc.executebuiltin('Skin.Reset(MenuLAF)')
    xbmc.executebuiltin("ReloadSkin()")

def click_2():
    xbmc.executebuiltin('Skin.SetString(MenuLAF,Graph)')
    xbmc.executebuiltin("ReloadSkin()")

def click_3():
    xbmc.executebuiltin('Skin.SetString(MenuLAF,GraphFocused)')
    xbmc.executebuiltin("ReloadSkin()")

def click_4():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/Tools/SkinTools.py")')







SkinTools()
