import os, xbmc, xbmcvfs, xbmcgui
# Dialog = xbmcgui.Dialog()


def ResetPvrSettings():
        choice = xbmcgui.Dialog().yesno('[COLOR orange]Reset Pvr Settings[/COLOR]', '[COLOR white]Θέλετε να επαναφέρετε τις ρυθμίσεις του PVR Stalker στην [COLOR lime]τελευταία[COLOR white] ενημέρωση ;[/COLOR]',
                                        nolabel='[COLOR orange]Άκυρο[/COLOR]',yeslabel='[COLOR lime]Επαναφορά[/COLOR]')


        if choice == 1: xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "pvr.stalker","enabled":false}}')
        if choice == 1: xbmc.sleep(1000)
        if choice == 1: xbmcgui.Dialog().ok("[COLOR orange]World[/COLOR]", "[COLOR white]Περιμένουμε να ολοκληρωθεί η εισαγωγή οδηγού από πελάτες της διαχείρισης PVR.[CR]Αν δεν ξεκινήσει η διαχείριση PVR, θα χρειαστεί να κάνουμε επανεκκίνηση στο kodi.[CR]Επίσης μην ξεχάσετε να κάνετε αλλαγή Γκρουπ στην χώρα που επιθυμείτε.[/COLOR]")
        if choice == 1: xbmc.sleep(1000)
        xbmc.executebuiltin('ActivateWindow(Home)')
        if choice == 1: xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/UpdaterMatrix_5.py")')
        
        if choice == 0: xbmc.sleep(1000)
        if choice == 0: xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/PVR/Pvr.py")')

ResetPvrSettings()
