﻿import os, xbmc, xbmcvfs, xbmcgui, xbmcaddon, shutil, glob

def fixbuildin():
        choice = xbmcgui.Dialog().yesno('[COLOR orange]Επανέλεγχος ενημερώσεων του build[/COLOR]', 'Θέλετε να κάνετε επανέλεγχο για ενημερώσεις του build?[CR][COLOR blue][CR]Με αυτή την επιλογή, θα εγκατασταθούν (ξανά) οι τελευταίες ενημερώσεις του build.[/COLOR]',
        
                                        nolabel='[B][COLOR white]Όχι τώρα...[/COLOR][/B]',yeslabel='[B][COLOR gold]Επανέλεγχος[/COLOR][/B]')

        if choice == 1: [xbmcgui.Dialog().ok('[B][COLOR orange]Επανέλεγχος ενημερώσεων του build[/COLOR][/B]', 'Η διαδκασία θα διαρκέσει [COLOR orange]5-10 λεπτα[/COLOR].'),
                         xbmcvfs.delete('special://home/addons/plugin.program.downloader19/downloader_startup.py'), 
                         xbmc.sleep(500),
                         UpdaterMatrixDelete(),
                         # xbmc.executebuiltin('RunScript("special://home/addons/service.World.Build/PY/UpdaterMatrixDelete.py")'),
                         xbmcvfs.delete('special://home/userdata/addon_data/plugin.program.downloader19/settings.xml'),
                         xbmc.sleep(500),
                         # xbmcgui.Dialog().notification("[B][COLOR orange]Επανέλεγχος...[/COLOR][/B]", "[COLOR white]Παρακαλώ περιμένετε...[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/FixBuild.png'),
                         # xbmc.sleep(4000),
                         xbmcvfs.delete('special://home/userdata/addon_data/plugin.program.downloader19/Database_Addons33.py'),
                         xbmc.sleep(500),
                         xbmcvfs.delete('special://home/userdata/addon_data/plugin.program.downloader19/addons_list_installation.py'),
                         xbmc.sleep(500),
                         xbmcvfs.delete('special://home/userdata/addon_data/plugin.program.downloader19/delete_files.py'),
                         xbmc.sleep(500),
                         xbmcvfs.delete('special://home/userdata/addon_data/plugin.program.downloader19/set_setting.py'),
                         xbmc.sleep(1000),

                         # xbmc.executebuiltin('RunScript("special://home/userdata/addon_data/plugin.program.downloader19/set_setting_FixBuild.py")'),
                         #xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloader19/service.py")'),
                         xbmcgui.Dialog().notification("[B][COLOR orange]Επανέλεγχος ![/COLOR][/B]", "[COLOR white]Αναμονή για Reload Profile...[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/rp.png'),
                         xbmc.sleep(1000),
                         xbmc.executebuiltin('LoadProfile("Master user")'),
                         #xbmc.sleep(2000),
                         ]
                         
       
def UpdaterMatrixDelete():


    #base_path = xbmcvfs.translatePath('special://home/addons')

    #dir_list = glob.iglob(os.path.join(base_path, "UpdaterMatrix"))
    #for path in dir_list:
     #   if os.path.isdir(path):
     #       shutil.rmtree(path)

    base_path = xbmcvfs.translatePath('special://home/userdata')

    dir_list = glob.iglob(os.path.join(base_path, "UpdaterMatrix"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)

    #base_path = xbmcvfs.translatePath('special://home/addons')

    #dir_list = glob.iglob(os.path.join(base_path, "UpdaterMatrix"))
    #for path in dir_list:
       # if os.path.isdir(path):
        #    shutil.rmtree(path)

    #dialog = xbmcgui.Dialog()
    #dialog.ok("[COLOR orange]World build[/COLOR]", "[COLOR white]Delete[/COLOR]")
    #xbmc.executebuiltin('RunPlugin(plugin://plugin.program.G.K.N.Wizard/?mode=forceprofile)')




       
fixbuildin()
