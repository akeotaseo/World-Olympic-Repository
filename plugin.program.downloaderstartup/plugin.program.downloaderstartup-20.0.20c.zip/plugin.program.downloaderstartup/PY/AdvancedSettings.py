import xbmc, xbmcgui



def AdvancedSettings():
    funcs = (click_1, click_2, click_2)
    call = xbmcgui.Dialog().select('[B][COLOR=grey]       AdvancedSettings[/COLOR][/B]',
['[COLOR=silver]Caching[/COLOR] (Kodi)',
 '[COLOR=blue]Quick Configure AdvancedSettings[/COLOR] (G.K.N.Wizard)',


 
 '[COLOR=orange]Advanced Settings[/COLOR] (World Updater - Tools)'
 ])




    if call:
        if call < 1:
            return
        func = funcs[call-3]
        return func()
    else:
        func = funcs[call]
        return func()
    return 




def click_1(): advanced_qui_set()

def click_2():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('PlayMedia("plugin://plugin.program.G.K.N.Wizard/?mode=autoadvanced")')
    #xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.myselect/folders/py/sporthdme.py")')

def click_3():
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('Action(Back)')
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(Home)')
    xbmc.executebuiltin('PlayMedia("plugin://plugin.program.downloader19/?url=&mode=4&name=Advanced+Settings&icon=special%3A%2F%2Fhome%2Faddons%2Fplugin.program.downloader19%2Fresources%2Fmedia%2FSettings.png&fanart=C%3A%5CPortableApps%5Ckodi%5Ckodi+World+21%5CKodi%5Cportable_data%5Caddons%5Cplugin.program.downloader19%5Cfanart.jpg&description=&name2=&version=")')







Kodi_version = float(xbmc.getInfoLabel("System.BuildVersion")[:4])

def advanced_qui_set():
    selection = xbmcgui.Dialog().select('[COLOR orange]Caching[/COLOR]',
                                       ['[B][COLOR white]Μέγεθος Μνήμης[/COLOR][/B]',
                                        '[B][COLOR white]Επαναφορά στην Προεπιλογή (20MB)[/COLOR][/B]'])
    if 19.9 <= Kodi_version <= 21.0:
        if selection==0:
            xbmc.executebuiltin("ActivateWindowAndFocus(ServiceSettings, -94, )")
            xbmc.sleep(500)
            xbmc.executebuiltin('SendClick(-78)')
        elif selection==1:
            xbmc.executebuiltin("ActivateWindowAndFocus(ServiceSettings, -94, )")
            xbmc.sleep(500)
            xbmc.executebuiltin('SendClick(-72)')

    if 21.0 <= Kodi_version <= 22.0:
        if selection==0:
            xbmc.executebuiltin("ActivateWindowAndFocus(ServiceSettings, -194, )")
            xbmc.sleep(500)
            xbmc.executebuiltin('SendClick(-178)')
        elif selection==1:
            xbmc.executebuiltin("ActivateWindowAndFocus(ServiceSettings, -194, )")
            xbmc.sleep(500)
            xbmc.executebuiltin('SendClick(-172)')


AdvancedSettings()
