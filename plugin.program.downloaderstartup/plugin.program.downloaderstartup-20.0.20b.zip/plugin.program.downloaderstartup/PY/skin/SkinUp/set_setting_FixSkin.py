﻿import xbmc, xbmcgui

xbmcgui.Dialog().ok('[B][COLOR blue]Skin World[/COLOR][/B]', 'Με αυτή την επιλογή τα Settings του Skin (Ρυθμίσεις - HOME)[CR]θα επενέλθουν στην τελευταία ενημέρωση.[CR]Στη συνέχεια... θα ακολουθήσει Επαναφόρτωση Προφίλ[CR](Επανεκκίνηση του build)..')
def SkinMenuLAST():
    choice = xbmcgui.Dialog().yesno('[B][COLOR orange]Skin Menu Settings[/COLOR][/B]', '[COLOR white]Θέλετε να επαναφέρετε τα Settings του Skin [CR](Ρυθμίσεις - HOME) [CR]στην τελευταία ενημέρωση?[/COLOR]',
                                            nolabel='[COLOR white]Όχι[/COLOR]',yeslabel='[COLOR white]Ναι[/COLOR]')
    if choice == 1: service_Skin_Up()
    # if choice == 0: xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/skin/SkinMenuTools.py")')
xbmcgui.Dialog().notification("[B][COLOR blue]Skin World[/COLOR][/B]", "Ρυθμίσεις - HOME", icon='special://home/addons/skin.19MatrixWorld/resources/icon.png', sound=False)

from resources.lib.modules import check

from updatervar import *
def service_Skin_Up():

    ##  plugin.program.downloader19   ###


    addon_downloader19       = xbmcaddon.Addon('plugin.program.downloader19')
    setting_downloader19     = addon_downloader19.getSetting
    setting_set_downloader19 = addon_downloader19.setSetting
    if not setting_downloader19('xmlskinversion')=='0':
        xbmc.sleep(1000)
        setting_set_downloader19('xmlskinversion', '0')
        xbmc.sleep(2000)
        xbmcgui.Dialog().notification("[B][COLOR orange]xmlskinversion[/COLOR][/B]", "[COLOR white]Παρακαλώ περιμένετε...[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/FixBuild.png', sound=False)




        xbmcgui.Dialog().notification("[B][COLOR orange]Ok...[/COLOR][/B]", "[COLOR white]Παρακαλώ περιμένετε...[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/FixBuild2.png')
        xbmc.sleep(4000)

    # xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloader19/service Skin Up.py")')


    if __name__ == '__main__':
        if not setting('updaterversion') == 'false':
           # xbmcgui.Dialog().notification("[B][COLOR orange]Ελεγχος για ενημερώσεις[/COLOR][/B]", "...", icon='special://home/addons/plugin.program.downloader19/icon.gif', sound=False)

            check.xmlskin()

SkinMenuLAST()
