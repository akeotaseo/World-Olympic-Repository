import os, xbmc, xbmcvfs, xbmcgui


def CheckFix():
    funcs = (click1, click2, click3)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]~ Check Fix ~[/COLOR][/B]', 

[ '[B][COLOR gold]Fix [/COLOR]build update[/B]',

 '[COLOR blue][B]gui fix [/B][/COLOR]'

 # '[COLOR yellow][B]NemesisAio[/COLOR] [B]Fix [/B]',
 #'[COLOR white][B]Alphatv.gr & Antenna.gr[/COLOR] [B]Fix [/B]',
 
 ])
 #'[B][COLOR=white][B][COLOR grey]Fix build update [/COLOR][/B]',
 
 #'Check Fix [COLOR=red]delete_files[/COLOR]',
 #'Check Fix [COLOR=green]addons_list_installation[/COLOR]',
 #'Check Fix [COLOR=orange]Database_Addons33[/COLOR]',
 

    if call:
        if call < 0:
            return
        func = funcs[call-3]
        return func()
    else:
        func = funcs[call]
        return func()
    return 




def click1():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/FixBuild/FixBuild.py")')

def click2(): guifix()
             
        

def click3(): streamarmy()


# def click4():
    # xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/UpdaterMatrix_7.py")')

#def click1():
    #xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/FixBuildTEST/FixBuildOLD.py")')


#def click3():
    #xbmc.executebuiltin('RunScript("special://home/userdata/addon_data/plugin.program.downloader19/delete_files.py")')

#def click4():
    #xbmc.executebuiltin('RunScript("special://home/userdata/addon_data/plugin.program.downloader19/addons_list_installation.py")')

#def click5():
    #xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/Tools/Database_Addons33_Fix.py")')







def guifix():
    funcs = (click_1, click_2)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]Gui fix[/COLOR][/B]', 
['[COLOR=white]Gui fix [COLOR=blue](Omega[/COLOR]'])



    if call:
        if call < 0:
            return
        func = funcs[call-2]
        return func()
    else:
        func = funcs[call]
        return func()
    return 0






def click_1():
    xbmc.executebuiltin('PlayMedia("plugin://plugin.program.G.K.N.Wizard/?mode=install&name=World+-Omega-&url=gui")')

def click_2():
    xbmc.executebuiltin('PlayMedia("plugin://plugin.program.G.K.N.Wizard/?mode=install&name=World+-Omega-&url=gui")')


def streamarmy():
        choice = xbmcgui.Dialog().yesno('[COLOR orange]Fix NemesisAio[/COLOR]', 'Επιλέξτε [COLOR green]Remove Data[/COLOR][CR]Στην συνέχεια ανοίξτε τo πρόσθετo [COLOR orange]NemesisAio[/COLOR][CR]απο το SubMenu στις κατηγορίες[CR]MOVIES & TV (StreamArmy) - SPORTS (Live Now)',
                                        nolabel='[B][COLOR white]Όχι τώρα...[/COLOR][/B]',yeslabel='[B][COLOR green]Remove Data[/COLOR][/B]')

        # if choice == 1: xbmcvfs.delete('special://home/userdata/addon_data/plugin.program.downloader/settings.xml'),xbmc.sleep(1000),xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/UpdaterMatrix_12.py")'),


        if choice == 1: xbmcvfs.delete('special://home/userdata/addon_data/plugin.program.downloader/settings.xml'),xbmc.sleep(1000),xbmc.executebuiltin('Addon.Opensettings(plugin.program.downloader)'),xbmc.sleep(1000),xbmc.executebuiltin('SendClick(28)'),






CheckFix()
