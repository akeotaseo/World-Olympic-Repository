import xbmc, xbmcgui
import urllib.request
import os, re, sys, json, time, glob, xbmc, xbmcvfs, xbmcgui, xbmcaddon, sqlite3, random, requests

def Changelog():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]Changelog[/COLOR][/B]',
['[COLOR=orange]Changelog[/COLOR]',

 '[COLOR=orange]Changelog 2[/COLOR]',
 '[COLOR=orange]Changelog 3[/COLOR]',
 '[COLOR=orange]Changelog 4[/COLOR]',
 '[COLOR=orange]Changelog 5[/COLOR]',
 '[B][COLOR red]TEST[/COLOR][/B]'])


    if call:
        if call < 1:
            return
        func = funcs[call-6]
        return func()
    else:
        func = funcs[call]
        return func()
    return 




def click_1():
    change()

def click_2():
    change2()

def click_3():
    change3()

def click_4():
    change4()

def click_5():
    change5()

def click_6():
    xbmc.executebuiltin('Action(Back)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.downloaderstartup")')




def textBox(heading, announce):
    class TextBox():

        def __init__(self, *args, **kwargs):
            self.WINDOW = 10147
            self.CONTROL_LABEL = 1
            self.CONTROL_TEXTBOX = 5
            xbmc.executebuiltin("ActivateWindow(%d)" % (self.WINDOW, ))
            self.win = xbmcgui.Window(self.WINDOW)
            xbmc.sleep(500)
            self.setControls()

        def setControls(self):
            self.win.getControl(self.CONTROL_LABEL).setLabel(heading)
            try:
                f = open(announce)
                text = f.read()
            except:
                text = announce
            self.win.getControl(self.CONTROL_TEXTBOX).setText(str(text))
            return

    TextBox()
    while xbmc.getCondVisibility('Window.IsVisible(10147)'):
        xbmc.sleep(500)

def change():
    changelog = xbmcvfs.translatePath(os.path.join('special://home/addons/plugin.program.downloaderstartup/PY/Changelog/changelog.txt'))
    heading = '[B][COLOR orange]*** 1 ***[/COLOR][/B]'
    f = open(changelog, 'r', encoding='utf-8')
    lines = f.readlines()
    announce = ''
    for line in lines:
        if not line.strip():
            break

        announce += line
    f.close()
    textBox(heading, announce)

def change2():
    changelog = xbmcvfs.translatePath(os.path.join('special://home/addons/plugin.program.downloaderstartup/PY/Changelog/changelog2.txt'))
    heading = '[B][COLOR orange]*** 2 ***[/COLOR][/B]'
    f = open(changelog, 'r', encoding='utf-8')
    lines = f.readlines()
    announce = ''
    for line in lines:
        if not line.strip():
            break

        announce += line
    f.close()
    textBox(heading, announce)

def change3():
    changelog = xbmcvfs.translatePath(os.path.join('special://home/addons/plugin.program.downloaderstartup/PY/Changelog/changelog3.txt'))
    heading = '[B][COLOR orange]*** 3 ***[/COLOR][/B]'
    f = open(changelog, 'r', encoding='utf-8')
    lines = f.readlines()
    announce = ''
    for line in lines:
        if not line.strip():
            break

        announce += line
    f.close()
    textBox(heading, announce)

def change4():
    changelog = xbmcvfs.translatePath(os.path.join('special://home/addons/plugin.program.downloaderstartup/PY/Changelog/changelog4.txt'))
    heading = '[B][COLOR orange]*** 4 ***[/COLOR][/B]'
    f = open(changelog, 'r', encoding='utf-8')
    lines = f.readlines()
    announce = ''
    for line in lines:
        if not line.strip():
            break

        announce += line
    f.close()
    textBox(heading, announce)

def change5():
    changelog = xbmcvfs.translatePath(os.path.join('special://home/addons/plugin.program.downloaderstartup/PY/Changelog/changelog5.txt'))
    heading = '[B][COLOR orange]*** 5 ***[/COLOR][/B]'
    f = open(changelog, 'r', encoding='utf-8')
    lines = f.readlines()
    announce = ''
    for line in lines:
        if not line.strip():
            break

        announce += line
    f.close()
    textBox(heading, announce)





Changelog()
