import os, xbmc, xbmcgui


def Kodi_Installer():
    funcs = (click_1, click_2)
    call = xbmcgui.Dialog().select('[B][COLOR=blue]KODI INSTALLER[/COLOR][/B]', 
['[B][COLOR=cadetblue]Kodi Windows Installer[/COLOR][/B]',

 '[B][COLOR=cornflowerblue]Kodi Android Installer[/COLOR][/B]'])


    if call:
        if call < 0:
            return
        func = funcs[call-2]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    if xbmc.getCondVisibility('System.Platform.Windows'): xbmc.executebuiltin('ActivateWindow(10001,"plugin://script.kodi.windows.update/")')
    else: xbmcgui.Dialog().notification("[B][COLOR=blue]KODI INSTALLER[/COLOR][/B]", "[B][COLOR red]Το σύστημά σας δεν είνα windows[/COLOR][/B]", sound=True, icon='special://home/addons/skin.19MatrixWorld/media/kodired.png'), xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/Kodi_Installer.py")')
    


def click_2():
    if xbmc.getCondVisibility('System.Platform.Android'): xbmc.executebuiltin('ActivateWindow(10001,"plugin://script.kodi.android.update/")')
    else: xbmcgui.Dialog().notification("[B][COLOR=blue]KODI INSTALLER[/COLOR][/B]", "[B][COLOR red]Το σύστημά σας δεν είναι Android[/COLOR][/B]", sound=True, icon='special://home/addons/skin.19MatrixWorld/media/kodired.png'), xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/Kodi_Installer.py")')


Kodi_Installer()
