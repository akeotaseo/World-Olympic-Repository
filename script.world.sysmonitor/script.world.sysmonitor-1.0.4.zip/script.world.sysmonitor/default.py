# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs
import threading
import urllib.request
import json
import os
import tempfile
import base64
import time
import platform
import ssl

ADDON = xbmcaddon.Addon()
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
ICONS_DIR = os.path.join(ADDON_PATH, 'resources', 'icons')

LANG_SYS = (xbmc.getInfoLabel('System.Language') or '').lower()
IS_EL = ('greek' in LANG_SYS or 'ελλην' in LANG_SYS)

STRINGS = {
    'title': 'Έλεγχος Συστήματος & Δικτύου' if IS_EL else 'System & Network Monitor',
    'net': 'Δίκτυο' if IS_EL else 'Network',
    'country_vpn': 'Χώρα & VPN' if IS_EL else 'Country & VPN',
    'isp': 'Πάροχος (ISP)' if IS_EL else 'Provider (ISP)',
    'ping_speed': 'Ping & Ταχύτητα' if IS_EL else 'Ping & Speed',
    'video': 'Βίντεο' if IS_EL else 'Video',
    'cpu': 'CPU',
    'temp': 'Θερμοκρασία' if IS_EL else 'Temperature',
    'skin_prof': 'Skin & Προφίλ' if IS_EL else 'Skin & Profile',
    'ram': 'Μνήμη RAM' if IS_EL else 'RAM Memory',
    'storage': 'Αποθήκευση' if IS_EL else 'Storage',
    'kodi_ver': 'Έκδοση Kodi' if IS_EL else 'Kodi Version',
    'os': 'Λειτουργικό (OS)' if IS_EL else 'Operating System',
    'uptime': 'Λειτουργία' if IS_EL else 'Uptime',
    'refresh': 'Ανανέωση' if IS_EL else 'Refresh',
    'close': 'Κλείσιμο' if IS_EL else 'Close',
    'checking': 'Έλεγχος...' if IS_EL else 'Checking...',
    'measuring': 'Μέτρηση ταχύτητας...' if IS_EL else 'Measuring speed...',
    'usage': 'Χρήση:' if IS_EL else 'Usage:',
    'free': 'Ελεύθερα:' if IS_EL else 'Free:',
    'p_exc': 'Άριστη' if IS_EL else 'Excellent',
    'p_good': 'Καλή' if IS_EL else 'Good',
    'p_fair': 'Μέτρια' if IS_EL else 'Fair',
    'p_slow': 'Αργή' if IS_EL else 'Slow',
}


def get_icon(filename):
    p = os.path.join(ICONS_DIR, filename)
    return p if os.path.exists(p) else filename


def get_solid_black_png():
    img_path = os.path.join(ICONS_DIR, "kodi_solid_black_1x1.png")
    if not os.path.exists(img_path) or os.path.getsize(img_path) < 50:
        b64_png = (
            "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII="
        )
        try:
            if not os.path.exists(ICONS_DIR):
                os.makedirs(ICONS_DIR)
            with open(img_path, 'wb') as f:
                f.write(base64.b64decode(b64_png))
        except Exception:
            return "black.png"
    return img_path


def get_solid_white_png():
    img_path = os.path.join(ICONS_DIR, "kodi_solid_white_1x1.png")
    if not os.path.exists(img_path) or os.path.getsize(img_path) < 50:
        b64_png = (
            "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+ip1sAAAAASUVORK5CYII="
        )
        try:
            if not os.path.exists(ICONS_DIR):
                os.makedirs(ICONS_DIR)
            with open(img_path, 'wb') as f:
                f.write(base64.b64decode(b64_png))
        except Exception:
            return "white.png"
    return img_path



def _fetch_geo(ctx):
    headers = {'User-Agent': 'Mozilla/5.0'}

    # 1η Πηγή: ipwho.is (HTTPS - Πολύ γρήγορο και ακριβές σε VPN)
    try:
        req = urllib.request.Request('https://ipwho.is/', headers=headers)
        raw = urllib.request.urlopen(req, timeout=5.0, context=ctx).read().decode('utf-8')
        d = json.loads(raw)
        if d.get('success'):
            conn = d.get('connection') or {}
            return {
                'ip': d.get('ip', 'N/A'),
                'country': d.get('country', ''),
                'code': d.get('country_code', '').upper(),
                'city': d.get('city', ''),
                'isp': conn.get('isp') or conn.get('org') or 'N/A',
                'hosting': False
            }
    except Exception:
        pass

    # 2η Πηγή (Fallback): ipapi.co (HTTPS)
    try:
        req = urllib.request.Request("https://ipapi." + "co/json/", headers=headers)

        raw = urllib.request.urlopen(req, timeout=5.0, context=ctx).read().decode('utf-8')
        d = json.loads(raw)
        if d.get('country_name') and not d.get('error'):
            return {
                'ip': d.get('ip', 'N/A'),
                'country': d.get('country_name', ''),
                'code': d.get('country_code', '').upper(),
                'city': d.get('city', ''),
                'isp': d.get('org') or 'N/A',
                'hosting': False
            }
    except Exception:
        pass

    # 3η Πηγή (Fallback): ip-api.com (με σπασμένο string για να μην κόβεται)
    try:
        url = "http://ip-api." + "com/json?fields=status,country,countryCode,city,isp,hosting,query"
        req = urllib.request.Request(url, headers=headers)
        raw = urllib.request.urlopen(req, timeout=5.0).read().decode('utf-8')
        d = json.loads(raw)
        if d.get('status') == 'success':
            return {
                'ip': d.get('query', 'N/A'),
                'country': d.get('country', ''),
                'code': d.get('countryCode', '').upper(),
                'city': d.get('city', ''),
                'isp': d.get('isp', 'N/A'),
                'hosting': d.get('hosting', False)
            }
    except Exception:
        pass

    return None


def fetch_network_info():
    win = xbmcgui.Window(10000)

    win.setProperty('MyPingMS', '...')
    win.setProperty('MyDownMbps', '...')
    win.setProperty('MyUpMbps', '...')

    ctx = ssl._create_unverified_context()

    # 0. Πραγματικό Ping (TCP Socket στο 1.1.1.1:443)
    try:
        import socket
        t_p = time.time()
        s = socket.create_connection(("1.1.1.1", 443), timeout=3.0)
        real_ping = int((time.time() - t_p) * 1000)
        s.close()
        win.setProperty('MyPingMS', str(real_ping))
    except Exception:
        win.setProperty('MyPingMS', 'Timeout')

    # 1. GeoIP (Χώρα, VPN, ISP)
    info = _fetch_geo(ctx)
    if info and info['code'] and len(info['code']) == 2:
        ip_addr = info['ip']
        country = info['country'] or info['code']
        country_code = info['code']
        city = info['city'] or ''
        isp_raw = info['isp'] or 'N/A'
        is_hosting = info['hosting']
        isp_low = isp_raw.lower()

        if ip_addr and ip_addr != 'N/A':
            win.setProperty('MyWANIP', ip_addr)

        win.setProperty('MyCountryCode', country_code.lower())
        win.setProperty('MyISP', isp_raw[:24])
        win.setProperty('MyCity', city[:22])

        vpn_keywords = (
            'datacamp', 'vpn', 'hostroyale', 'm247', 'cdn77', 'hetzner',
            'ovh', 'digitalocean', 'vultr', 'linode', 'choopa', 'leaseweb',
            'tzulo', 'packethub', 'privax', 'nord', 'surfshark', 'proton',
            'mullvad', 'expressvpn', 'cyberghost', 'purevpn', 'private internet'
        )

        if country_code != 'GR' or is_hosting or any(k in isp_low for k in vpn_keywords):
            win.setProperty('MyVPNState', ' [COLOR lime](VPN)[/COLOR]')
            win.setProperty('MyVPNActive', 'true')
        else:
            win.setProperty('MyVPNState', '')
            win.setProperty('MyVPNActive', 'false')

        color = 'cornflowerblue' if country_code == 'GR' else 'orange'
        win.setProperty('MyRealCountry', f'[COLOR {color}]{country}[/COLOR]')

    cf_host = "speed.cloudflare." + "com"

    # 2. Download
    dl_ok = False
    for dl_url in (
        "https://" + cf_host + "/__down?bytes=1500000",
        "http://ovh.net"
    ):
        try:
            dl_req = urllib.request.Request(dl_url, headers={'User-Agent': 'Mozilla/5.0'})
            open_kwargs = {'timeout': 6.0}
            if dl_url.startswith('https'):
                open_kwargs['context'] = ctx
            with urllib.request.urlopen(dl_req, **open_kwargs) as resp:
                _ = resp.read(16384)
                t_dl = time.time()
                data_dl = resp.read()
                dt_dl = time.time() - t_dl
                if data_dl and dt_dl > 0:
                    dl_mbps = (len(data_dl) * 8) / (dt_dl * 1000000.0)
                    win.setProperty('MyDownMbps', f"{dl_mbps:.1f}")
                    dl_ok = True
                    break
        except Exception:
            continue
    if not dl_ok:
        win.setProperty('MyDownMbps', 'N/A')

    # 3. Upload
    try:
        payload = b"0" * 250000
        ul_url = "https://" + cf_host + "/__up"
        ul_req = urllib.request.Request(
            ul_url,
            data=payload,
            headers={
                'User-Agent': 'Mozilla/5.0',
                'Content-Type': 'application/octet-stream'
            },
            method='POST'
        )
        t_ul = time.time()
        with urllib.request.urlopen(ul_req, timeout=6.0, context=ctx) as resp:
            _ = resp.read()
            dt_ul = time.time() - t_ul
            if resp.status in (200, 201, 204) and dt_ul > 0:
                ul_mbps = (len(payload) * 8) / (dt_ul * 1000000.0)
                win.setProperty('MyUpMbps', f"{ul_mbps:.1f}")
            else:
                win.setProperty('MyUpMbps', 'N/A')
    except Exception:
        win.setProperty('MyUpMbps', 'N/A')



def download_flag_temp(code):
    if not code or len(code) != 2:
        return ""
    code = code.lower()
    tmp_path = os.path.join(ICONS_DIR, f"kodi_flag_{code}.png")

    if os.path.exists(tmp_path) and os.path.getsize(tmp_path) > 100:
        return tmp_path
    try:
        url = "https://flagcdn." + f"com/w160/{code}.png"
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        data = urllib.request.urlopen(req, timeout=3.0).read()
        if data:
            with open(tmp_path, 'wb') as f:
                f.write(data)
            return tmp_path
    except Exception:
        pass
    return ""
def download_isp_logo(isp_name):
    if not isp_name:
        return ""
    low = isp_name.lower()
    domain_map = [
        ("ote", "cosmote.gr"),
        ("cosmote", "cosmote.gr"),
        ("vodafone", "vodafone.gr"),
        ("nova", "nova.gr"),
        ("wind", "nova.gr"),
        ("forthnet", "nova.gr"),
        ("infinium", "infinium.gr"),
        ("hcn", "hcn.gr"),
        ("starlink", "starlink.com"),
        ("spacex", "starlink.com"),
        ("nord", "nordvpn.com"),
        ("surfshark", "surfshark.com"),
        ("proton", "protonvpn.com"),
        ("mullvad", "mullvad.net"),
        ("express", "expressvpn.com"),
        ("cyberghost", "cyberghostvpn.com"),
        ("private internet", "privateinternetaccess.com"),
        ("hostroyale", "hostroyale.com"),
        ("vultr", "vultr.com"),
        ("linode", "linode.com"),
        ("leaseweb", "leaseweb.com"),
        ("datacamp", "cdn77.com"),
        ("cdn77", "cdn77.com"),
        ("cloudflare", "cloudflare.com"),
        ("m247", "m247.com"),
        ("hetzner", "hetzner.com"),
        ("ovh", "ovhcloud.com"),
        ("digitalocean", "digitalocean.com"),
    ]
    matched_domain = ""
    for key, dom in domain_map:
        if key in low:
            matched_domain = dom
            break
    if not matched_domain:
        return ""

    safe_name = matched_domain.replace(".", "_")
    tmp_path = os.path.join(ICONS_DIR, f"kodi_isp_{safe_name}.png")

    if os.path.exists(tmp_path) and os.path.getsize(tmp_path) > 100:
        return tmp_path
    try:
        url = "https://www.google." + f"com/s2/favicons?domain={matched_domain}&sz=128"
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        data = urllib.request.urlopen(req, timeout=3.0).read()
        if data:
            with open(tmp_path, 'wb') as f:
                f.write(data)
            return tmp_path
    except Exception:
        pass
    return ""


def get_cpu_temperature():
    # 1. Έλεγχος μέσω Kodi InfoLabel
    cpu_t = xbmc.getInfoLabel('System.CPUTemperature') or ''
    unavail = ('', 'N/A', '?', 'Μη διαθέσιμος πόρος', 'Not available', 'Busy', 'Απασχολημένο')
    if cpu_t and not any(u.lower() in cpu_t.lower() for u in unavail):
        return cpu_t

    # 2. Fallback για Android TV Boxes / Linux (/sys/class/thermal)
    try:
        for i in range(10):
            t_path = f"/sys/class/thermal/thermal_zone{i}/temp"
            if os.path.exists(t_path):
                with open(t_path, 'r') as f:
                    val_str = f.read().strip()
                if val_str.lstrip('-').isdigit():
                    val = float(val_str)
                    if val > 1000:
                        val = val / 1000.0
                    if 15.0 <= val <= 115.0:
                        return f"{val:.1f} °C"
    except Exception:
        pass

    return ""


def _fmt_bytes(b):
    gb = 1024.0 ** 3
    mb = 1024.0 ** 2
    if b >= gb:
        return f"{b / gb:.2f} GB"
    return f"{b / mb:.0f} MB"


def get_storage_info():
    import shutil
    for path in (
        xbmcvfs.translatePath('special://home'),
        '/storage/emulated/0',
        '/sdcard'
    ):
        try:
            if path and os.path.exists(path):
                total, used, free = shutil.disk_usage(path)
                if total > 500 * 1024 * 1024:
                    lbl_free = 'Ελεύθερα' if IS_EL else 'Free'
                    lbl_tot = 'Σύνολο' if IS_EL else 'Total'
                    return f"{_fmt_bytes(free)} {lbl_free}", f"{_fmt_bytes(total)} {lbl_tot}"
        except Exception:
            pass

    hdd_free = xbmc.getInfoLabel('System.FreeSpace') or '...'
    hdd_total = xbmc.getInfoLabel('System.TotalSpace') or '...'
    return hdd_free, hdd_total


def force_network_recovery():
    win = xbmcgui.Window(10000)
    win.clearProperty('IPServiceRunning')
    win.clearProperty('SysMonBusy')
    try:
        import socket
        socket.setdefaulttimeout(5)
    except Exception:
        pass
    try:
        if not xbmc.Player().isPlaying():
            xbmc.executebuiltin('Playlist.Clear')
            xbmc.executebuiltin('PlayerControl(Stop)')
    except Exception:
        pass


class SystemMonitorDialog(xbmcgui.WindowDialog):
    def __init__(self):
        super().__init__()
        self.controls_list = []

        screen_w = self.getWidth() or 1280
        screen_h = self.getHeight() or 720
        black_tex = get_solid_black_png()
        white_tex = get_solid_white_png()

        # 100% Solid Black Background (full screen)
        self._add(xbmcgui.ControlImage(0, 0, screen_w, screen_h, black_tex))

        # Centered 4x3 Panel (1040 x 585)
        pw, ph = 1040, 585
        px = int((screen_w - pw) / 2)
        py = int((screen_h - ph) / 2)

        self._add(xbmcgui.ControlImage(px - 2, py - 2, pw + 4, ph + 4, white_tex, colorDiffuse='88FFA500'))
        self._add(xbmcgui.ControlImage(px, py, pw, ph, black_tex))
        self._add(xbmcgui.ControlImage(px, py, pw, 40, white_tex, colorDiffuse='FF1E1E1E'))

        # Date & Time
        self.lbl_date = xbmcgui.ControlLabel(px + 20, py + 8, 280, 26, '', font='font12', alignment=0)
        self._add(self.lbl_date)

        self.lbl_time = xbmcgui.ControlLabel(px + pw - 300, py + 8, 280, 26, '', font='font12', alignment=1)
        self._add(self.lbl_time)

        # Window Title
        self._add(xbmcgui.ControlLabel(
            px + 15, py + 6, pw - 30, 28,
            f"[B][COLOR orange]{STRINGS['title']}[/COLOR][/B]",
            font='font13_title', alignment=2
        ))

        # 12 Cards Grid (4 cols x 3 rows)
        box_w, box_h = 240, 148
        gap_x, gap_y = 14, 12
        start_x = px + 19
        row1_y = py + 50
        row2_y = row1_y + box_h + gap_y
        row3_y = row2_y + box_h + gap_y

        cols_x = [start_x + i * (box_w + gap_x) for i in range(4)]

        for ry in (row1_y, row2_y, row3_y):
            for cx in cols_x:
                self._add(xbmcgui.ControlImage(cx - 1, ry - 1, box_w + 2, box_h + 2, white_tex, colorDiffuse='44FFFFFF'))
                self._add(xbmcgui.ControlImage(cx, ry, box_w, box_h, white_tex, colorDiffuse='FF181818'))

        def make_card(cx, ry, icon_file, title_markup, is_flag=False):
            icon_path = get_icon(icon_file)
            if is_flag:
                img = xbmcgui.ControlImage(cx + 84, ry + 8, 72, 42, icon_path, aspectRatio=2)
            else:
                img = xbmcgui.ControlImage(cx + 98, ry + 6, 44, 44, icon_path, aspectRatio=2)
            self._add(img)
            self._add(xbmcgui.ControlLabel(
                cx + 6, ry + 52, box_w - 12, 22,
                title_markup, font='font12', alignment=2
            ))
            lbl = xbmcgui.ControlLabel(
                cx + 8, ry + 75, box_w - 16, 68, '', font='font10', alignment=2
            )
            self._add(lbl)
            return img, lbl

        # Row 1
        _, self.lbl_net = make_card(cols_x[0], row1_y, 'network1.png', f"[B][COLOR deepskyblue]{STRINGS['net']}[/COLOR][/B]")
        self.img_flag, self.lbl_vpn = make_card(cols_x[1], row1_y, 'earth.png', f"[B][COLOR orange]{STRINGS['country_vpn']}[/COLOR][/B]", is_flag=True)
        self.img_isp, self.lbl_isp = make_card(cols_x[2], row1_y, 'icon.png', f"[B][COLOR lightskyblue]{STRINGS['isp']}[/COLOR][/B]")
        _, self.lbl_ping = make_card(cols_x[3], row1_y, 'Speedtest.png', f"[B][COLOR springgreen]{STRINGS['ping_speed']}[/COLOR][/B]")

        # Row 2 (Video, RAM, CPU, Temperature / Skin & Profile)
        _, self.lbl_vid = make_card(cols_x[0], row2_y, 'monitor.png', f"[B][COLOR plum]{STRINGS['video']}[/COLOR][/B]")
        _, self.lbl_ram = make_card(cols_x[1], row2_y, 'ram.png', f"[B][COLOR lawngreen]{STRINGS['ram']}[/COLOR][/B]")
        _, self.lbl_cpu = make_card(cols_x[2], row2_y, 'cpu.png', f"[B][COLOR salmon]{STRINGS['cpu']}[/COLOR][/B]")
        self.lbl_temp_title = xbmcgui.ControlLabel(
            cols_x[3] + 6, row2_y + 52, box_w - 12, 22,
            f"[B][COLOR coral]{STRINGS['skin_prof']}[/COLOR][/B]", font='font12', alignment=2
        )
        self.img_temp = xbmcgui.ControlImage(cols_x[3] + 98, row2_y + 6, 44, 44, get_icon('Profile.png'), aspectRatio=2)
        self._add(self.img_temp)
        self._add(self.lbl_temp_title)
        self.lbl_temp = xbmcgui.ControlLabel(
            cols_x[3] + 8, row2_y + 75, box_w - 16, 68, '', font='font10', alignment=2
        )
        self._add(self.lbl_temp)

        # Row 3
        _, self.lbl_hdd = make_card(cols_x[0], row3_y, 'hdd.png', f"[B][COLOR gold]{STRINGS['storage']}[/COLOR][/B]")
        _, self.lbl_ver = make_card(cols_x[1], row3_y, 'kodi.webp', f"[B][COLOR cornflowerblue]{STRINGS['kodi_ver']}[/COLOR][/B]")
        _, self.lbl_os = make_card(cols_x[2], row3_y, 'set.png', f"[B][COLOR violet]{STRINGS['os']}[/COLOR][/B]")
        _, self.lbl_upt = make_card(cols_x[3], row3_y, 'uptime.png', f"[B][COLOR turquoise]{STRINGS['uptime']}[/COLOR][/B]")

        # Bottom Buttons with visible border and dark fill
        btn_y = py + ph - 48
        self._add(xbmcgui.ControlImage(px + 299, btn_y - 1, 202, 38, white_tex, colorDiffuse='88FFA500'))
        self._add(xbmcgui.ControlImage(px + 539, btn_y - 1, 202, 38, white_tex, colorDiffuse='88FFA500'))

        self.btn_refresh = xbmcgui.ControlButton(
            px + 300, btn_y, 200, 36, f"[B]{STRINGS['refresh']}[/B]",
            focusTexture=black_tex, noFocusTexture=black_tex,
            alignment=6, font='font12', textColor='FFFFFFFF', focusedColor='FFFFA500'
        )
        self.btn_close = xbmcgui.ControlButton(
            px + 540, btn_y, 200, 36, f"[B]{STRINGS['close']}[/B]",
            focusTexture=black_tex, noFocusTexture=black_tex,
            alignment=6, font='font12', textColor='FFFFFFFF', focusedColor='FFFFA500'
        )

        self.addControl(self.btn_refresh)
        self.addControl(self.btn_close)

        self.btn_refresh.controlRight(self.btn_close)
        self.btn_refresh.controlLeft(self.btn_close)
        self.btn_close.controlLeft(self.btn_refresh)
        self.btn_close.controlRight(self.btn_refresh)
        self.setFocus(self.btn_close)

        self._closing = False
        self._job_id = 0
        self.refresh_ui()
        self.trigger_async_refresh()


    def _add(self, ctrl):
        self.controls_list.append(ctrl)
        self.addControl(ctrl)

    def _clean_busy(self, val, fallback='...'):
        if not val or 'απασχ' in val.lower() or 'busy' in val.lower():
            return fallback
        return val

    def refresh_ui(self):
        if getattr(self, '_closing', False):
            return
        win = xbmcgui.Window(10000)

        # Date & Time
        cur_date = xbmc.getInfoLabel('System.Date(DDD, DD MMM YYYY)') or xbmc.getInfoLabel('System.Date')
        cur_time = xbmc.getInfoLabel('System.Time') or ''
        self.lbl_date.setLabel(f"[COLOR silver]{cur_date}[/COLOR]")
        self.lbl_time.setLabel(f"[COLOR orange][B]{cur_time}[/B][/COLOR]")

        # 1. Network
        inet_raw = xbmc.getInfoLabel('System.InternetState') or ''
        connected_str = xbmc.getLocalizedString(13296)
        is_online = (inet_raw == connected_str)
        inet_state = self._clean_busy(inet_raw, STRINGS['checking'])
        lan_ip = self._clean_busy(xbmc.getInfoLabel('Network.IPAddress'), '...')
        dns1 = self._clean_busy(xbmc.getInfoLabel('Network.DNS1Address'), '...')
        status_color = 'limegreen' if is_online else ('grey' if inet_state == STRINGS['checking'] else 'coral')
        self.lbl_net.setLabel(
            f"[COLOR {status_color}][B]{inet_state}[/B][/COLOR][CR]"
            f"[COLOR silver]LAN:[/COLOR] [COLOR white]{lan_ip}[/COLOR][CR]"
            f"[COLOR silver]DNS:[/COLOR] [COLOR white]{dns1}[/COLOR]"
        )

        # 2. Country & VPN + Flag
        country = win.getProperty('MyRealCountry') or '[COLOR cornflowerblue]Greece[/COLOR]'
        vpn_state = win.getProperty('MyVPNState') or ''
        wan_ip = win.getProperty('MyWANIP') or STRINGS['checking']
        code = win.getProperty('MyCountryCode') or 'gr'
        self.lbl_vpn.setLabel(
            f"{country}{vpn_state}[CR]"
            f"[COLOR silver]WAN:[/COLOR] [COLOR white]{wan_ip}[/COLOR]"
        )
        flag_file = download_flag_temp(code)
        if flag_file:
            self.img_flag.setImage(flag_file, False)
        else:
            self.img_flag.setImage(get_icon('earth.png'), False)

        # 3. ISP & City + Logo
        isp = win.getProperty('MyISP') or STRINGS['checking']
        city = win.getProperty('MyCity') or ''
        self.lbl_isp.setLabel(
            f"[COLOR white]{isp}[/COLOR][CR]"
            f"[COLOR grey]{city}[/COLOR]"
        )
        isp_logo = download_isp_logo(isp)
        if isp_logo:
            self.img_isp.setImage(isp_logo, False)
        else:
            self.img_isp.setImage(get_icon('icon.png'), False)

        # 4. Ping, Download & Upload
        ping_val = win.getProperty('MyPingMS') or '...'
        dl_val = win.getProperty('MyDownMbps') or '...'
        ul_val = win.getProperty('MyUpMbps') or '...'

        if ping_val.isdigit():
            ms = int(ping_val)
            if ms < 45:
                p_col, p_txt = 'limegreen', STRINGS['p_exc']
            elif ms < 90:
                p_col, p_txt = 'deepskyblue', STRINGS['p_good']
            elif ms < 160:
                p_col, p_txt = 'orange', STRINGS['p_fair']
            else:
                p_col, p_txt = 'coral', STRINGS['p_slow']
            line1 = f"[COLOR {p_col}][B]{ms} ms ({p_txt})[/B][/COLOR]"
        else:
            line1 = f"[COLOR coral]{ping_val}[/COLOR]"

        try:
            dl_f = float(dl_val)
            dl_col = 'limegreen' if dl_f >= 25.0 else ('orange' if dl_f >= 10.0 else 'coral')
            line2 = f"[COLOR silver]Down:[/COLOR] [COLOR {dl_col}][B]{dl_val} Mbps[/B][/COLOR]"
        except Exception:
            line2 = f"[COLOR silver]Down:[/COLOR] [COLOR white]{dl_val}[/COLOR]"

        try:
            ul_f = float(ul_val)
            ul_col = 'limegreen' if ul_f >= 10.0 else ('orange' if ul_f >= 3.0 else 'coral')
            line3 = f"[COLOR silver]Up:[/COLOR] [COLOR {ul_col}][B]{ul_val} Mbps[/B][/COLOR]"
        except Exception:
            line3 = f"[COLOR silver]Up:[/COLOR] [COLOR white]{ul_val}[/COLOR]"

        self.lbl_ping.setLabel(f"{line1}[CR]{line2}[CR]{line3}")

        # 5. Video (Dynamic Codec & Cache when playing)
        scr_w = xbmc.getInfoLabel('System.ScreenWidth') or ''
        scr_h = xbmc.getInfoLabel('System.ScreenHeight') or ''
        fps = xbmc.getInfoLabel('System.FPS') or ''
        if xbmc.getCondVisibility('Player.HasVideo'):
            v_res = xbmc.getInfoLabel('VideoPlayer.VideoResolution') or f"{scr_w}x{scr_h}"
            v_cod = xbmc.getInfoLabel('VideoPlayer.VideoCodec') or ''
            a_cod = xbmc.getInfoLabel('VideoPlayer.AudioCodec') or ''
            cache_lvl = xbmc.getInfoLabel('Player.CacheLevel') or ''
            codecs_txt = f"{v_cod} • {a_cod}".strip(' •')
            if cache_lvl.isdigit():
                c_val = int(cache_lvl)
                c_col = 'limegreen' if c_val >= 50 else ('orange' if c_val >= 20 else 'coral')
                cache_markup = f"[COLOR silver]Cache:[/COLOR] [COLOR {c_col}][B]{c_val}%[/B][/COLOR]"
            else:
                cache_markup = f"[COLOR silver]{fps} FPS[/COLOR]"
            self.lbl_vid.setLabel(
                f"[COLOR white]{v_res} ({fps} FPS)[/COLOR][CR]"
                f"[COLOR gold]{codecs_txt}[/COLOR][CR]"
                f"{cache_markup}"
            )
        else:
            self.lbl_vid.setLabel(
                f"[COLOR white]{scr_w}x{scr_h}[/COLOR][CR]"
                f"[COLOR silver]{fps} FPS[/COLOR]"
            )

        # 6. RAM
        ram_used = self._clean_busy(xbmc.getInfoLabel('System.Memory(used.percent)'), '...')
        ram_free = self._clean_busy(xbmc.getInfoLabel('System.FreeMemory'), '...')
        self.lbl_ram.setLabel(
            f"[COLOR silver]{STRINGS['usage']}[/COLOR] [COLOR orange]{ram_used}[/COLOR][CR]"
            f"[COLOR silver]{STRINGS['free']}[/COLOR] [COLOR white]{ram_free}[/COLOR]"
        )

        # 7. CPU
        cpu_use = self._clean_busy(xbmc.getInfoLabel('System.CPUUsage'), '')
        cpu_freq = self._clean_busy(xbmc.getInfoLabel('System.CpuFrequency'), '')
        cores = os.cpu_count() or 0
        cores_txt = f"{cores} Cores" if cores else ''

        if not cpu_use or any(w in cpu_use.lower() for w in ('μη διαθέσιμος', 'not available', 'n/a', '?')):
            cpu_use = cores_txt if cores_txt else 'N/A'
        if not cpu_freq or any(w in cpu_freq.lower() for w in ('μη διαθέσιμος', 'not available', 'n/a', '?')):
            cpu_freq = ''

        self.lbl_cpu.setLabel(
            f"[COLOR silver]{STRINGS['usage']}[/COLOR] [COLOR white]{cpu_use}[/COLOR][CR]"
            f"[COLOR grey]{cpu_freq}[/COLOR]"
        )

        # 8. Temperature or Skin & Profile
        cpu_t = get_cpu_temperature()
        unavail = ('', 'N/A', '?', 'Μη διαθέσιμος πόρος', 'Not available', 'Busy', 'Απασχολημένο')
        if cpu_t:
            self.lbl_temp_title.setLabel(f"[B][COLOR coral]{STRINGS['temp']}[/COLOR][/B]")
            self.img_temp.setImage(get_icon('cpu2.png'), False)
            gpu_t = xbmc.getInfoLabel('System.GPUTemperature') or ''
            if gpu_t and not any(u.lower() in gpu_t.lower() for u in unavail):
                self.lbl_temp.setLabel(f"[COLOR silver]CPU:[/COLOR] [COLOR white]{cpu_t}[/COLOR][CR][COLOR silver]GPU:[/COLOR] [COLOR white]{gpu_t}[/COLOR]")
            else:
                self.lbl_temp.setLabel(f"[COLOR silver]CPU:[/COLOR] [COLOR white]{cpu_t}[/COLOR]")
        else:
            self.lbl_temp_title.setLabel(f"[B][COLOR coral]{STRINGS['skin_prof']}[/COLOR][/B]")
            self.img_temp.setImage(get_icon('Profile.png'), False)
            skin_name = xbmc.getSkinDir() or 'N/A'
            profile_name = xbmc.getInfoLabel('System.ProfileName') or 'Master user'
            self.lbl_temp.setLabel(
                f"[COLOR white]{skin_name}[/COLOR][CR]"
                f"[COLOR grey]{profile_name}[/COLOR]"
            )

        # 9. Αποθήκευση / Storage
        hdd_free, hdd_total = get_storage_info()
        self.lbl_hdd.setLabel(
            f"[COLOR white]{hdd_free}[/COLOR][CR]"
            f"[COLOR grey]{hdd_total}[/COLOR]"
        )

        # 10. Kodi Version
        ver = xbmc.getInfoLabel('System.BuildVersion') or 'N/A'
        ver_short = ver.split(' Git:')[0].strip()
        bdate = xbmc.getInfoLabel('System.BuildDate') or ''
        self.lbl_ver.setLabel(
            f"[COLOR white]{ver_short}[/COLOR][CR]"
            f"[COLOR grey]{bdate}[/COLOR]"
        )

        # 11. OS
        os_info = self._clean_busy(xbmc.getInfoLabel('System.OSVersionInfo'), '...')
        os_short = os_info.split(' (kernel:')[0].strip()
        arch = platform.machine() or ''
        bits = '64-bit' if ('64' in arch or 'arm64' in arch.lower() or 'aarch64' in arch.lower()) else '32-bit'
        arch_txt = f"{bits} ({arch})" if arch else bits
        self.lbl_os.setLabel(f"[COLOR white]{os_short}[/COLOR][CR][COLOR grey]{arch_txt}[/COLOR]")

        # 12. Uptime
        uptime = self._clean_busy(xbmc.getInfoLabel('System.Uptime'), '...')
        self.lbl_upt.setLabel(f"[COLOR white]{uptime}[/COLOR]")


    def trigger_async_refresh(self):
        win = xbmcgui.Window(10000)
        if win.getProperty('SysMonBusy') == 'true':
            return
        self._job_id += 1
        current_job = self._job_id

        def _worker():
            win.setProperty('SysMonBusy', 'true')
            try:
                fetch_network_info()
            finally:
                win.clearProperty('SysMonBusy')
            if not getattr(self, '_closing', False) and self._job_id == current_job:
                try:
                    self.refresh_ui()
                except Exception:
                    pass

        t = threading.Thread(target=_worker)
        t.daemon = True
        t.start()

    def start_live_ticker(self):
        def _tick():
            for _ in range(120):
                if getattr(self, '_closing', False):
                    break
                xbmc.sleep(1000)
                if getattr(self, '_closing', False):
                    break
                try:
                    self.refresh_ui()
                except Exception:
                    break
        t = threading.Thread(target=_tick)
        t.daemon = True
        t.start()

    def _close_and_resume(self):
        if getattr(self, '_closing', False):
            return
        self._closing = True
        xbmc.sleep(150)
        self.close()
        if xbmc.getCondVisibility('Player.HasVideo + Player.Paused'):
            xbmc.executebuiltin('Action(Play)')

    def onInit(self):
        try:
            self.setFocus(self.btn_close)
        except Exception:
            pass

    def _do_refresh(self):
        win = xbmcgui.Window(10000)
        if win.getProperty('SysMonBusy') == 'true':
            return
        force_network_recovery()
        xbmcgui.Dialog().notification(
    f"[B][COLOR orange]{STRINGS['title']}[/COLOR][/B]",
    'Γίνεται ανανέωση & έλεγχος δικτύου...' if IS_EL else 'Refreshing & checking network...',
    get_icon('icon.png'),
    2500
        )

        win.setProperty('MyPingMS', '...')
        win.setProperty('MyDownMbps', '...')
        win.setProperty('MyUpMbps', '...')
        win.setProperty('MyISP', STRINGS['checking'])
        win.setProperty('MyCity', '')
        win.setProperty('MyWANIP', STRINGS['checking'])
        self.img_isp.setImage(get_icon('icon.png'), False)

        self.btn_refresh.setLabel(f"[B]{STRINGS['checking']}[/B]")
        self.lbl_ping.setLabel(f"[COLOR grey]{STRINGS['measuring']}[/COLOR]")
        self.trigger_async_refresh()

        def _restore_btn():
            while win.getProperty('SysMonBusy') == 'true' and not getattr(self, '_closing', False):
                xbmc.sleep(250)
            if not getattr(self, '_closing', False):
                try:
                    self.btn_refresh.setLabel(f"[B]{STRINGS['refresh']}[/B]")
                except Exception:
                    pass
        threading.Thread(target=_restore_btn, daemon=True).start()


    def onControl(self, control):
        if control == self.btn_close or control.getId() == self.btn_close.getId():
            self._close_and_resume()
        elif control == self.btn_refresh or control.getId() == self.btn_refresh.getId():
            self._do_refresh()

    def onAction(self, action):
        aid = action.getId()
        # Back / Escape / Previous Menu / Stop
        if aid in (9, 10, 13, 92, 110):
            self._close_and_resume()
            return
        # ΜΟΝΟ πάτημα Enter / OK / Select (7) ή Αριστερό Κλικ Ποντικιού (100) — ΟΧΙ hover (107)
        if aid in (7, 100):
            try:
                fid = self.getFocusId()
                if fid == self.btn_close.getId():
                    self._close_and_resume()
                    return
                elif fid == self.btn_refresh.getId():
                    self._do_refresh()
                    return
            except Exception:
                pass

if __name__ == '__main__':
    force_network_recovery()
    dlg = SystemMonitorDialog()
    dlg.start_live_ticker()
    dlg.doModal()
    del dlg


