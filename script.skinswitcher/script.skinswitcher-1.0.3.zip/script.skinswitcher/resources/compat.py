import re
import xbmc


def getKodiVersion():
    match = re.match(r'(\d+)(?:\.(\d+))?', xbmc.getInfoLabel("System.BuildVersion"))
    if not match: return 19.0
    return float('%s.%s' % (match.group(1), match.group(2) or '0'))
