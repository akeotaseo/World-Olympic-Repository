﻿###  TMDb Helper (Settings Wipe & Recreate Fix - WIPE IF NOT 10 / LOCK 12)  ###
if xbmc.getCondVisibility('System.HasAddon({})'.format('plugin.video.themoviedb.helper')):
    try:
        import xbmcgui, xbmcvfs, os
        
        tmdbh_id = 'plugin.video.themoviedb.helper'
        # 📂 Καθαρό μονοπάτι για το settings.xml του TMDb Helper
        tmdbh_settings_xml = xbmcvfs.translatePath(f'special://profile/addon_data/{tmdbh_id}/settings.xml')
        
        # 🎯 ΟΙ ΔΥΟ ΓΡΑΜΜΕΣ-ΣΤΟΧΟΙ ΓΙΑ ΤΟΝ ΕΛΕΓΧΟ
        target_string_10 = '<setting id="language">10</setting>'
        target_string_12 = '<setting id="language">12</setting>'
        
        execute_wipe = False
        
        # 🔍 1. Έλεγχος: Διαβάζουμε το αρχείο κειμενικά
        if xbmcvfs.exists(tmdbh_settings_xml):
            with open(tmdbh_settings_xml, 'r', encoding='utf-8', errors='ignore') as f:
                xml_content = f.read()
            
            if target_string_12 in xml_content:
                # 🤫 ΑΠΟΛΥΤΟ SKIP: Αν η τιμή είναι ήδη 12, ΔΕΝ κάνει Wipe και προσπερνάει αθόρυβα
                execute_wipe = False
            elif target_string_10 not in xml_content:
                # 🔥 FORCE CLEAN: Επειδή ΔΕΝ είναι 10, σβήνει τα πάντα για να καθαρίσουν οι παλιές ρυθμίσεις!
                execute_wipe = True
            else:
                execute_wipe = False
        else:
            # Αν το αρχείο λείπει τελείως από τον δίσκο, πάμε να το φτιάξουμε με το 12
            execute_wipe = True
            
        # 🧼 2. ΕΚΤΕΛΕΣΗ WIPE ΚΑΙ ΧΕΙΡΟΚΙΝΗΤΗ ΑΝΑΔΗΜΙΟΥΡΓΙΑ XML ΜΕ ΤΗΝ ΤΙΜΗ 12
        if execute_wipe:
            # 🔔 Ειδοποίηση έναρξης Fix (Θα βγει ΜΟΝΟ αυτή τη μία φορά του καθαρισμού)
            xbmcgui.Dialog().notification("[COLOR red]TMDbH Fix[/COLOR]", "[B]Καθαρισμός παλιών ρυθμίσεων...[/B]", icon='special://home/addons/plugin.program.downloader19/resources/media/FixBuild2.png', sound=False)
            
            # 🧼 ΟΛΟΚΛΗΡΩΤΙΚΟ WIPE: Διαγραφή του αρχείου settings από τον δίσκο
            if xbmcvfs.exists(tmdbh_settings_xml):
                try:
                    xbmcvfs.delete(tmdbh_settings_xml)
                except:
                    pass
            
            xbmc.sleep(300) # ⏳ Χρόνος για να κλείσει καθαρά το I/O του δίσκου
            
            # 📂 Σιγουρεύουμε ότι ο φάκελος υπάρχει
            tmdbh_settings_dir = os.path.dirname(tmdbh_settings_xml)
            if not os.path.exists(tmdbh_settings_dir):
                os.makedirs(tmdbh_settings_dir)

            # 📝 ΚΑΤΑΣΚΕΥΗ ΚΑΘΑΡΟΥ XML TEMPLATE ΜΕ ΤΗΝ ΤΙΜΗ 12
            clean_xml_content = (
                '<?xml version="1.0" encoding="utf-8" standalone="yes"?>\n'
                '<settings version="1">\n'
                '    <setting id="language">12</setting>\n'
                '</settings>\n'
            )

            # ✍️ ΕΓΓΡΑΦΗ ΑΡΧΕΙΟΥ
            with open(tmdbh_settings_xml, 'w', encoding='utf-8') as f:
                f.write(clean_xml_content)
            
            xbmc.sleep(200) # ⏳ Μικρή αναμονή για να κάτσει το αρχείο στον δίσκο
            
            # 🔔 Ειδοποίηση επιτυχίας (Βγαίνει μόνο τη μία φορά που κλειδώνει το 12)
            xbmcgui.Dialog().notification("[COLOR lime]TMDbH Fix[/COLOR]", "[B]League and Country! Greek (Greece) [/B]", icon='special://home/addons/plugin.program.downloader19/resources/media/FixBuild2.png', sound=False)
            
    except Exception as tmdbh_error:
        xbmc.log(f"[Master_Build] Αποτυχία κατά το κειμενικό Wipe του TMDbH XML: {str(tmdbh_error)}", xbmc.LOGERROR)
