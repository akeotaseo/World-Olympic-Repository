﻿import xbmc
import xbmcgui
import json

# 🎯 Ορίζουμε το ID του πρόσθετου που θέλουμε να ελέγξουμε
addon_id = "plugin.video.the-loop"

try:
    # 🔍 1. Στέλνουμε ερώτημα στο Kodi για να δούμε την κατάσταση του πρόσθετου
    rpc_query = '{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","id":1,"params":{"addonid":"%s","properties":["enabled"]}}' % addon_id
    rpc_response = xbmc.executeJSONRPC(rpc_query)
    response_data = json.loads(rpc_response)
    
    # 🛠️ 2. Αν το πρόσθετο βρεθεί, ελέγχουμε αν είναι ενεργό (enabled)
    if "result" in response_data and "addon" in response_data["result"]:
        is_enabled = response_data["result"]["addon"]["enabled"]
        
        if is_enabled:
            # 📴 3. Απενεργοποίηση του πρόσθετου
            rpc_disable = '{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s","enabled":false}}' % addon_id
            xbmc.executeJSONRPC(rpc_disable)
            
            # 🔔 4. Εμφάνιση της δικής σου Custom ειδοποίησης
            xbmcgui.Dialog().notification(
                "[COLOR red]Απενεργοποίηση του Πρόσθετου[/COLOR]", 
                "[B][COLOR lime]The Loop[/COLOR][/B]", 
                sound=False, 
                icon='special://home/addons/plugin.video.the-loop/icon.png'
            )
            
except Exception as e:
    # Σε περίπτωση οποιουδήποτε σφάλματος (π.χ. αν δεν υπάρχει καν το πρόσθετο), 
    # ο κώδικας προσπερνάει αθόρυβα χωρίς κρασάρισμα
    pass
