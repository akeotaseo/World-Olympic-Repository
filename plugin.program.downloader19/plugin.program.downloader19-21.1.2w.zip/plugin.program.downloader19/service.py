﻿import xbmc, xbmcgui, xbmcvfs, sys, json, os, re, glob, shutil, xbmcaddon, urllib.request

# 🛑 ΤΟ ΑΚΑΡΙΑΙΟ ΜΠΛΟΚΑΡΙΣΜΑ ΣΟΥ (ΠΑΝΩ-ΠΑΝΩ):
# Προσθέσαμε τον έλεγχο για ανοιχτό παράθυρο ειδοποίησης (notification)
if xbmc.getCondVisibility('Window.IsActive(10040)') or xbmc.getCondVisibility('Window.IsActive(2139)') or xbmc.getCondVisibility('Window.IsActive(progressdialog)') or xbmc.getCondVisibility('Window.IsActive(notification)'):
	xbmc.log("[World_Updater] Εντοπίστηκε ανοιχτό παράθυρο ή ειδοποίηση στην εκκίνηση. Ακαριαίο μπλοκάρισμα.", xbmc.LOGINFO)
	xbmc.executebuiltin('ActivateWindow(10040,"addons://outdated/")')
	import sys
	sys.exit()

def disable_screensaver():
	""" 🔒 ΑΠΕΝΕΡΓΟΠΟΙΗΣΗ SCREENSAVER ΓΙΑ ΠΡΟΣΤΑΣΙΑ ΤΩΝ BACKGROUND UPDATES (ZIP, REPOS) """
	try:
		profile_dir = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.program.downloader19')
		if not os.path.exists(profile_dir):
			os.makedirs(profile_dir)

		backup_file = os.path.join(profile_dir, 'screensaver_backup.txt')

		# 1. Διαβάζουμε την τρέχουσα ρύθμιση του χρήστη
		req_get = '{"jsonrpc":"2.0","method":"Settings.GetSettingValue","params":{"setting":"screensaver.mode"},"id":1}'
		res_get = json.loads(xbmc.executeJSONRPC(req_get))
		current_ss = res_get['result']['value']
		
		# 2. Την αποθηκεύουμε στο αρχείο αν δεν υπάρχει ήδη εκκρεμές backup
		if not os.path.exists(backup_file):
			with open(backup_file, 'w', encoding='utf-8') as f:
				f.write(current_ss)
				
		# 3. Απενεργοποιούμε τον screensaver προσωρινά
		xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"screensaver.mode","value":""},"id":1}')
		xbmc.log(f"[World_Updater] Ο screensaver απενεργοποιήθηκε στην έναρξη. Backup: {current_ss}", xbmc.LOGINFO)
	except Exception as e:
		xbmc.log(f"[World_Updater] Αποτυχία διαχείρισης screensaver στο service: {str(e)}", xbmc.LOGERROR)

# 🛑 ΑΠΕΝΕΡΓΟΠΟΙΗΣΗ ΜΕ ΤΗΝ ΕΝΑΡΞΗ
disable_screensaver()


# 🟢 [ΔΙΚΛΕΙΔΑ ΑΣΦΑΛΕΙΑΣ]: Ακαριαίος καθαρισμός παλιών locks
profile_dir = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.program.downloader19')
lock_files = ['delete_lock.txt', 'database_lock.txt', 'install_lock.txt']

for lock_name in lock_files:
	full_lock_path = os.path.join(profile_dir, lock_name)
	if os.path.exists(full_lock_path):
		try:
			os.remove(full_lock_path)
			xbmc.log(f"[World_Updater] [Δικλείδα Ασφαλείας] Το παλιό αρχείο {lock_name} σβήστηκε επιτυχώς.", xbmc.LOGINFO)
		except:
			pass


# PVR
xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.stalker","enabled":false}}')
xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.iptvsimple","enabled":false}}')
xbmc.sleep(200)

# ADDONS UPDATE
xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"addons.updatemode","value":1}}')
xbmc.sleep(200)
xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"general.addonupdates","value":1}}')

xbmcvfs.delete('special://home/userdata/addon_data/plugin.video.myiptv/cache.db')
xbmc.sleep(200) 
xbmcgui.Dialog().notification("[B][COLOR orange]...[/COLOR][/B]", "   ", sound=False, icon='special://home/addons/plugin.program.downloader19/resources/media/autoexec.png')
xbmc.sleep(2000)
xbmc.executebuiltin('RunScript("special://home/addons/skin.19MatrixWorld/xml/_get_ip.py")')
xbmc.sleep(3000) 
xbmcgui.Dialog().notification("[COLOR white]Έναρξη World Updater...[/COLOR]", "[B][COLOR orange]Καλώς ήρθατε![/COLOR][/B]", sound=False, icon='special://home/addons/plugin.program.downloader19/resources/media/World.png')

from resources.lib.modules import check
from updatervar import *

if __name__ == '__main__':
	if setting('notifyversion') == '0':
		xbmcgui.Dialog().ok('[B][COLOR blue]Πρώτη Εγκατάσταση[/COLOR][/B]', 'Περιμένετε να ολοκληρωθούν [COLOR lime]οι ενημερώσεις των Προσθέτων[/COLOR][CR]και η Εγκατάσταση των [B]binary add-ons[/B].')
		check.notifyT()
		xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"general.addonupdates","value":0}}')
		xbmc.sleep(1000)
		xbmc.executebuiltin('UpdateAddonRepos()')
		xbmc.executebuiltin('UpdateLocalAddons()')
		xbmc.executebuiltin('ActivateWindow(AddonBrowser)')
	else:
		if not setting('updaterversion') == 'false':
			xbmcgui.Dialog().notification("[B][COLOR orange]Ελεγχος για ενημερώσεις[/COLOR][/B]", "...", icon='special://home/addons/plugin.program.downloader19/icon.gif', sound=False)
			check.notifyT()
			check.autoenable()
			check.var()
			check.delete()
			check.installation()
			check.zip2() 
			check.players()
			check.zip1()
			check.zip3()
			check.zip4()
			check.zip5()
			check.pvr()
			check.setsetting()
			check.database()
			from resources.lib.modules.check import wait_for_kodi
			wait_for_kodi("Ενημέρωση Αποθετηρίων Database")
			check.xmlskin()
			check.UpdateAddonRepos()
		else:
			dialog.notification('[B][COLOR orange]Καλά να περάσετε![/COLOR][/B]', Dialog_not_Updater, icon_Build, sound=False)
			xbmc.sleep(2000)
			xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"general.addonupdates","value":0}}')
			xbmc.sleep(2000)
			xbmc.executebuiltin('UpdateLocalAddons()')
			xbmc.executebuiltin('UpdateAddonRepos()')
			xbmc.executebuiltin('ActivateWindow(AddonBrowser)')

##Tk & GKoBu & TRAILER MONITOR MULTI-MERGE LAYER ______________________________________
monitor = xbmc.Monitor()
update_interval = 2 * 60 * 60
time_counter = 0

while not monitor.abortRequested():
	if xbmc.getCondVisibility('Window.IsVisible(home)') and not xbmc.getCondVisibility('Window.IsVisible(6199)'):
		if xbmc.getInfoLabel('Skin.String(TrailerCheckID)') != '':
			xbmc.executebuiltin('Skin.ResetString(HubFromWidget)')
			xbmc.executebuiltin('Skin.ResetString(TrailerCheckID)')
			xbmc.executebuiltin('Skin.ResetString(HubMovieTitle)')
			xbmc.executebuiltin('Skin.ResetString(HubMoviePlot)')
			xbmc.executebuiltin('Skin.ResetString(HubMovieCast)')
			xbmc.executebuiltin('Skin.ResetString(HubMovieDirector)')
			xbmc.executebuiltin('Skin.ResetString(HubMovieWriter)')
			xbmc.executebuiltin('Skin.ResetString(HubMovieGenre)')
			xbmc.executebuiltin('Skin.ResetString(HubMovieYear)')
			xbmc.executebuiltin('Skin.ResetString(HubMovieRating)')
			xbmc.executebuiltin('Skin.ResetString(HubMovieStudio)')
			xbmc.executebuiltin('Skin.ResetString(HubMovieCountry)')
			xbmc.executebuiltin('Skin.ResetString(HubMoviePoster)')
			xbmc.executebuiltin('Skin.ResetString(HubMovieFanart)')
			xbmc.executebuiltin('Skin.ResetString(HubMovieTagLine)')
			xbmc.executebuiltin('Skin.ResetString(HubMovieDuration)')
			xbmc.executebuiltin('Skin.ResetString(HubMovieEndTime)')

	time_counter += 0.1 
	if time_counter >= update_interval:
		time_counter = 0 
		xbmc.executebuiltin('UpdateAddonRepos()')

	if monitor.waitForAbort(0.1):
		break
