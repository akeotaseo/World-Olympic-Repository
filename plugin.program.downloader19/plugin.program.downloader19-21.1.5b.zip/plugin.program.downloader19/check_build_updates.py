﻿# -*- coding: utf-8 -*-
import xbmc, xbmcgui
from resources.lib.modules import check
from updatervar import *

# 🎯 ΔΥΝΑΜΙΚΟ BLOCK ΕΛΕΓΧΩΝ (ΜΕ ΔΙΚΛΕΙΔΑ ΑΣΦΑΛΕΙΑΣ ΓΙΑ ΤΟ LOAD PROFILE)
if not setting('updaterversion') == 'false':
	xbmcgui.Dialog().notification("[B][COLOR orange]Ελεγχος για ενημερώσεις[/COLOR][/B]", "...", icon='special://home/addons/plugin.program.downloader19/icon.gif', sound=False)
	check.notifyT()
	check.autoenable()
	check.var()
	check.delete()
	check.installation()
	check.zip2() 
	check.players()
	# check.zip1()
	check.zip3()
	check.zip4()
	check.zip5()
	check.pvr()
	check.setsetting()
	check.database()
	
	from resources.lib.modules.check import wait_for_kodi
	wait_for_kodi("Ενημέρωση Αποθετηρίων Database")
	
	# ----------------------------------------------------------------------
	# 🎯 ΤΟ ΑΥΤΟΝΟΜΟ ΒΗΜΑ: Εκτέλεση και των 6 Fixes (fix1 έως fix6)
	# ----------------------------------------------------------------------
	check.run_pre_update_fixes()
	
	# ⏳ ΕΞΥΠΝΟ ΦΡΕΝΟ ΟΘΟΝΗΣ: Καθυστερούμε 4 δευτερόλεπτα αμέσως μετά τα fixes,
	# ώστε να προλάβουν να σβήσουν όλα τα notifications (όπως του TMDbH) 
	# και να καθαρίσει τελείως η οθόνη πριν ανοίξουν τα Progress Bars!
	xbmc.log("[Master_Build] Αναμονή 4 δευτερολέπτων για να καθαρίσει η οθόνη από τα Fixes...", xbmc.LOGINFO)
	xbmc.sleep(4000)
	
	# ----------------------------------------------------------------------
	# ⚙️ ΕΚΤΕΛΕΣΗ SKIN ΚΑΙ ΕΝΗΜΕΡΩΣΕΩΝ (ΣΩΣΤΗ ΑΡΧΙΤΕΚΤΟΝΙΚΗ)
	# ----------------------------------------------------------------------
	# 1. Εκτελούμε πρώτα τον έλεγχο του μενού.
	# Αν ο χρήστης πατήσει "ΝΑΙ" στο κλείσιμο, το script θα πεθάνει εκεί (os._exit).
	check.xmlskin()
	
	# 2. Αφού προσπεράσει το skin (είτε επειδή δεν είχε update, είτε επειδή ο χρήστης πάτησε "ΟΧΙ"),
	# προχωράμε ΚΑΝΟΝΙΚΑ και ΠΑΝΤΑ στην κεντρική ενημέρωση των προσθέτων!
	check.UpdateAddonRepos()




else:
	xbmcgui.Dialog().notification('[B][COLOR orange]Καλά να περάσετε![/COLOR][/B]', Dialog_not_Updater, icon_Build, sound=False)
	xbmc.sleep(2000)
	xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"general.addonupdates","value":0}}')
	xbmc.sleep(2000)
	xbmc.executebuiltin('UpdateLocalAddons()')
	xbmc.executebuiltin('UpdateAddonRepos()')
	xbmc.executebuiltin('ActivateWindow(AddonBrowser)')
