﻿# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import xbmcvfs
import os
import re

# 🔒 ΜΑΖΙΚΗ ΑΠΕΝΕΡΓΟΠΟΙΗΣΗ BACKGROUND SERVICES (AUTORUNS METHOD)
try:
    # 🎯 ΟΡΙΖΟΥΜΕ ΤΑ ADDONS ΚΑΙ ΤΗΝ ΑΝΩΤΑΤΗ ΠΡΟΒΛΗΜΑΤΙΚΗ ΕΚΔΟΣΗ ΤΟΥΣ
    target_addons = {
        "plugin.video.the-loop": "8.3",
        "plugin.video.madtitansports": "2.0.45"
    }
    
    def parse_version(v_str):
        return [int(x) for x in re.sub(r'[^\d.]', '', v_str).split('.') if x.isdigit()]

    # 🚩 ΣΗΜΑΙΑ: Γίνεται True ΜΟΝΟ αν κλείσουμε ενεργό service
    service_was_disabled = False
    disabled_names = []

    for addon_id, max_buggy_version in target_addons.items():
        xml_path = xbmcvfs.translatePath(f'special://home/addons/{addon_id}/addon.xml')
        
        # Ο κώδικας προχωράει ΜΟΝΟ αν το πρόσθετο είναι εγκατεστημένο
        if os.path.exists(xml_path):
            with open(xml_path, 'r', encoding='utf-8') as f:
                xml_content = f.read()
            
            # 🔍 1. ΑΝΑΓΝΩΣΗ ΕΚΔΟΣΗΣ από το XML
            current_version_str = ""
            version_match = re.search(r'<addon\s+.*?version="(.*?)".*?>', xml_content)
            if version_match:
                current_version_str = version_match.group(1)
                
            current_v = parse_version(current_version_str)
            max_buggy_v = parse_version(max_buggy_version)
            
            # 🎯 ΚΡΙΤΗΡΙΟ: Εκτέλεση ΜΟΝΟ αν η έκδοση του χρήστη είναι <= της προβληματικής έκδοσης
            if current_v and max_buggy_v and current_v <= max_buggy_v:
                
                # 🎯 ΕΛΕΓΧΟΣ: Αν το service έχει ως library το "service.py" (άρα είναι ΕΝΕΡΓΟ)
                if 'point="xbmc.service"' in xml_content and 'library="service.py.disabled"' not in xml_content:
                    xbmc.log(f"[Master_Build] Εντοπίστηκε ενεργό service (v{current_version_str}) στο {addon_id}. Αυτόματη απενεργοποίηση...", xbmc.LOGINFO)
                    
                    # Κλέβουμε το επίσημο όνομα του Addon από το XML για το notification
                    addon_name = addon_id
                    name_match = re.search(r'<addon\s+.*?name="(.*?)".*?>', xml_content)
                    if name_match:
                        addon_name = name_match.group(1)
                    
                    disabled_names.append(f"[COLOR lime]{addon_name}[/COLOR]")

                    # 🔄 ΑΝΤΙΚΑΤΑΣΤΑΣΗ AUTORUNS: Μετατρέπουμε το library σε .disabled
                    xml_content = xml_content.replace('library="service.py"', 'library="service.py.disabled"')
                    xml_content = xml_content.replace("library='service.py'", "library='service.py.disabled'")
                    
                    # Εγγραφή του τροποποιημένου XML πίσω στο δίσκο
                    with open(xml_path, 'w', encoding='utf-8') as f:
                        f.write(xml_content)
                    
                    # Ενεργοποιούμε τη σημαία για να βγει το μήνυμα στο τέλος
                    service_was_disabled = True
                    xbmc.log(f"[Master_Build] Το service του {addon_id} απενεργοποιήθηκε επιτυχώς.", xbmc.LOGINFO)
                else:
                    xbmc.log(f"[Master_Build] Το service του {addon_id} είναι ήδη απενεργοποιημένο (.disabled) ή δεν βρέθηκε.", xbmc.LOGINFO)
            else:
                xbmc.log(f"[Master_Build] Παράκαμψη: Το {addon_id} έχει νεότερη έκδοση {current_version_str}.", xbmc.LOGINFO)
        else:
            xbmc.log(f"[Master_Build] Παράκαμψη: Το {addon_id} δεν είναι εγκατεστημένο.", xbmc.LOGINFO)
            
    # 🔔 ΕΜΦΑΝΙΣΗ ΜΗΝΥΜΑΤΟΣ (ΜΟΝΟ ΑΝ ΑΠΕΝΕΡΓΟΠΟΙΗΘΗΚΕ ΕΣΤΩ ΚΑΙ ΕΝΑ SERVICE!)
    if service_was_disabled:
        names_str = " / ".join(disabled_names)
        xbmcgui.Dialog().notification(
            "[COLOR red]Απενεργοποίηση[/COLOR] [B]service[/B]", 
            f"των Πρόσθετων {names_str}", 
            sound=False, 
            icon='special://home/addons/plugin.program.downloader19/icon.png'
        )
        # ⏳ ΣΤΑΤΙΚΟ ΦΡΕΝΟ: Κρατάμε το script ενεργό για 4 δευτερόλεπτα
        xbmc.sleep(4000)
			
except Exception as e:
    xbmc.log(f"[Master_Build] Σφάλμα κατά τη μεθοδευμένη απενεργοποίηση services: {str(e)}", xbmc.LOGERROR)

xbmc.sleep(100)
