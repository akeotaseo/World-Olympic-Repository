﻿# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import xbmcvfs
import os

def fix7():
    try:
        # Ορισμός των IDs
        Gismeteo_id = 'weather.gismeteo'
        downloader_id = 'plugin.program.downloader19'

        if not xbmc.getCondVisibility(f'System.HasAddon({Gismeteo_id})'):
            xbmc.executebuiltin(f'InstallAddon({Gismeteo_id})')
        else:
            # Ορίζουμε τη διαδρομή για τον φάκελο addon_data του Downloader 19
            downloader_profile_dir = xbmcvfs.translatePath(f'special://profile/addon_data/{downloader_id}')
            
            if not os.path.exists(downloader_profile_dir):
                try: os.makedirs(downloader_profile_dir)
                except: pass

            # Νέα σημαία v4 για τη δοκιμή διαγραφής μόνο του settings.xml
            flag_file_path = os.path.join(downloader_profile_dir, '.Gismeteo_first_reset_v4')

            # Έλεγχος αν υπάρχει ήδη η σημαία: Τρέχει ΜΟΝΟ μια φορά στη ζωή του build!
            if not os.path.exists(flag_file_path):
                xbmc.log("[Master] Εκτέλεση: Στόχευση και καθαρισμός ρυθμίσεων Gismeteo...", xbmc.LOGINFO)
                
                # 🔔 ΕΜΦΑΝΙΣΗ ΜΗΝΥΜΑΤΟΣ (Βγαίνει ΜΟΝΟ αν εκτελείται το reset!)
                xbmcgui.Dialog().notification(
                    "[COLOR orange]Gismeteo Fix[/COLOR]", 
                    "[B]Καθαρισμός παλιών ρυθμίσεων Gismeteo![/B]", 
                    sound=False, 
                    icon='special://home/addons/skin.19MatrixWorld/media/Weather.ico'
                )
                
                # Εντοπισμός της ακριβούς διαδρομής του αρχείου settings.xml του Gismeteo
                Gismeteo_settings_file = xbmcvfs.translatePath(f'special://profile/addon_data/{Gismeteo_id}/settings.xml')
                Gismeteo_settings_dir = os.path.dirname(Gismeteo_settings_file)
                
                # 1. 🧼 WIPE: Αν υπάρχει το αρχείο, το διαγράφουμε απευθείας
                if xbmcvfs.exists(Gismeteo_settings_file):
                    try: xbmcvfs.delete(Gismeteo_settings_file)
                    except: pass
                
                xbmc.sleep(400)
                xbmc.executebuiltin('UpdateLocalAddons') # Καθαρίζουμε τη RAM cache του Kodi Core
                xbmc.sleep(400)
                
                # 2. 📝 ΚΑΤΑΣΚΕΥΗ ΠΛΗΡΟΥΣ XML: Του «γεννάμε» έτοιμες τις 4 ελληνικές πόλεις στον δίσκο!
                full_xml_content = (
                    '<?xml version="1.0" encoding="utf-8" standalone="yes"?>\n'
                    '<settings version="1">\n'
                    '    <setting id="CurrentLocation">false</setting>\n'
                    '    <setting id="Location1">Athens</setting>\n'
                    '    <setting id="Location1ID">3673</setting>\n'
                    '    <setting id="Location2">Thessaloniki</setting>\n'
                    '    <setting id="Location2ID">3635</setting>\n'
                    '    <setting id="Location3">Patra</setting>\n'
                    '    <setting id="Location3ID">3672</setting>\n'
                    '    <setting id="Location4">Heraklion</setting>\n'
                    '    <setting id="Location4ID">3679</setting>\n'
                    '</settings>\n'
                )
                
                if not os.path.exists(Gismeteo_settings_dir):
                    os.makedirs(Gismeteo_settings_dir)
                    
                with open(Gismeteo_settings_file, 'w', encoding='utf-8') as f:
                    f.write(full_xml_content)
                
                xbmc.sleep(400)
                xbmc.executebuiltin('UpdateLocalAddons') # Αναγκάζουμε το kodi να διαβάσει το νέο XML
                xbmc.executebuiltin('Container.Refresh')
                
                # 🔒 Δημιουργία της σημαίας v4 στον Downloader 19
                try:
                    with open(flag_file_path, 'w') as f: f.write('done')
                except: pass

                # ⏳ ΣΤΑΤΙΚΟ ΦΡΕΝΟ: Κρατάμε το script ενεργό για 4 δευτερόλεπτα
                xbmc.sleep(4000)
                
    except Exception as e:
        xbmc.log(f"[Master] Αποτυχία στο Fix7: {str(e)}", xbmc.LOGERROR)

# Εκτέλεση συναρτήσης
fix7()
