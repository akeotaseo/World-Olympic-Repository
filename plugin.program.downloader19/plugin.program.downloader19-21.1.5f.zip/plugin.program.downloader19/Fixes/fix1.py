﻿# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import json

# 🎯 Ορίζουμε το ID του πρόσθετου που θέλουμε να ελέγξουμε
addon_id = "plugin.video.the-loop"

try:
    # 🔍 1. Στέλνουμε ερώτημα στο Kodi για να δούμε αν είναι εγκατεστημένο και την κατάσταση του
    rpc_query = '{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","id":1,"params":{"addonid":"%s","properties":["enabled"]}}' % addon_id
    rpc_response = xbmc.executeJSONRPC(rpc_query)
    response_data = json.loads(rpc_response)
    
    # 🛠️ 2. ΕΛΕΓΧΟΣ ΕΓΚΑΤΑΣΤΑΣΗΣ: Αν το πρόσθετο υπάρχει στο αποτέλεσμα
    if "result" in response_data and "addon" in response_data["result"]:
        is_enabled = response_data["result"]["addon"]["enabled"]
        
        # 🛠️ 3. ΕΛΕΓΧΟΣ ΚΑΤΑΣΤΑΣΗΣ: Εκτέλεση ΜΟΝΟ αν είναι αυτή τη στιγμή Ενεργό (True)
        if is_enabled:
            # 📴 4. Απενεργοποίηση του πρόσθετου
            rpc_disable = '{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s","enabled":false}}' % addon_id
            xbmc.executeJSONRPC(rpc_disable)
            xbmc.sleep(500)
            
            # 🔔 5. ΕΜΦΑΝΙΣΗ ΜΗΝΥΜΑΤΟΣ (Βγαίνει ΜΟΝΟ αν ίσχυαν οι παραπάνω συνθήκες!)
            xbmcgui.Dialog().notification(
                "[COLOR red]Απενεργοποίηση του Πρόσθετου[/COLOR]", 
                "[B][COLOR lime]The Loop[/COLOR][/B]", 
                sound=False, 
                icon='special://home/addons/plugin.video.the-loop/icon.png'
            )
            
            # ⏳ ΣΤΑΤΙΚΟ ΦΡΕΝΟ: Κρατάμε το script ενεργό για 4 δευτερόλεπτα, ώστε
            # το μήνυμα να προλάβει να κάτσει στην οθόνη ΠΡΙΝ ξεκινήσει το επόμενο fix!
            xbmc.sleep(4000)
            
except Exception as e:
    # Σε περίπτωση οποιουδήποτε σφάλματος (π.χ. αν δεν υπάρχει καν το πρόσθετο),
    # ο κώδικας προσπερνάει αθόρυβα χωρίς κρασάρισμα
    pass
