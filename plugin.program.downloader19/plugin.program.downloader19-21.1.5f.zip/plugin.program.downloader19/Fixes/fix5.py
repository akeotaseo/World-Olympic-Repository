﻿# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import xbmcvfs
import os
import re

if xbmc.getCondVisibility('System.HasAddon(plugin.video.themoviedb.helper)'):
    try:
        tmdbh_id = 'plugin.video.themoviedb.helper'
        tmdbh_settings_xml = xbmcvfs.translatePath(f'special://profile/addon_data/{tmdbh_id}/settings.xml')
        tmdbh_settings_dir = os.path.dirname(tmdbh_settings_xml)
        
        my_addon_id = 'plugin.program.downloader19'
        my_addon_dir = xbmcvfs.translatePath(f'special://profile/addon_data/{my_addon_id}/')
        flag_file = os.path.join(my_addon_dir, 'tmdbh_first_reset.txt')
        
        # 🔍 ΕΛΕΓΧΟΣ ΣΗΜΑΙΑΣ: Αν υπάρχει, το script κάνει skip αμέσως και αθόρυβα
        if not os.path.exists(flag_file):
            xbmc.log("[Master_Build] [Fix5] Έναρξη TMDbH Smart Full Setup...", xbmc.LOGINFO)
            
            # 1. 🧼 WIPE: Σβήνουμε το παλιό αρχείο
            if xbmcvfs.exists(tmdbh_settings_xml):
                try: xbmcvfs.delete(tmdbh_settings_xml)
                except: pass
            
            xbmc.sleep(400)
            
            # 2. 🚀 GENERATION: Ανοίγουμε και κλείνουμε αμέσως τα Settings.
            xbmc.executebuiltin('Addon.OpenSettings(plugin.video.themoviedb.helper)')
            xbmc.sleep(1500)
            
            if xbmc.getCondVisibility('Window.IsVisible(addonsettings)'):
                xbmc.executebuiltin('SendClick(10140,28)') # Πατάει αυτόματα το "Εντάξει"
                xbmc.sleep(1000)
            
            # ⏳ 3. ΘΩΡΑΚΙΣΜΕΝΟ ΦΡΕΝΟ (THREAD LOCK)
            wait_disk = 0
            file_ready = False
            while wait_disk < 30: 
                if xbmcvfs.exists(tmdbh_settings_xml):
                    try:
                        with open(tmdbh_settings_xml, 'r', encoding='utf-8', errors='ignore') as f:
                            current_content = f.read()
                        if len(current_content) > 1000:
                            file_ready = True
                            break
                    except:
                        pass
                xbmc.sleep(200)
                wait_disk += 1

            # 4. 📝 DYNAMIC INJECTION: Αλλάζουμε ΜΟΝΟ τη γλώσσα στο έτοιμο, πλήρες αρχείο
            if file_ready:
                if '<setting id="language"' in current_content:
                    current_content = re.sub(r'<setting id="language".*?>.*?</setting>', '<setting id="language">12</setting>', current_content)
                else:
                    current_content = current_content.replace('</settings>', '    <setting id="language">12</setting>\n</settings>')
                
                # Γράφουμε πίσω το πλήρες αρχείο
                with open(tmdbh_settings_xml, 'w', encoding='utf-8') as f:
                    f.write(current_content)
                
                xbmc.sleep(400)
                
                # 🧠 5. ΑΣΦΑΛΗΣ ΑΝΑΝΕΩΣΗ (ΧΩΡΙΣ ΚΡΑΣΑΡΙΣΜΑΤΑ)
                xbmc.executebuiltin('UpdateLocalAddons')
                xbmc.executebuiltin('Container.Refresh')
                xbmc.sleep(200)
            
            # 🔒 ΚΛΕΙΔΩΜΑ ΣΗΜΑΙΑΣ
            if not os.path.exists(my_addon_dir):
                os.makedirs(my_addon_dir)
            with open(flag_file, 'w', encoding='utf-8') as f:
                f.write('TMDbH Full Settings Created and Language Locked')
            
            # 🔔 ΕΜΦΑΝΙΣΗ ΜΗΝΥΜΑΤΟΣ (Βγαίνει ΜΟΝΟ αν εκτελέστηκε το fix!)
            xbmcgui.Dialog().notification("[COLOR lime]TMDbH Fix[/COLOR]", "[B]Greek Language LOCKED![/B]", icon='special://home/addons/plugin.program.downloader19/resources/media/FixBuild2.png', sound=False)
            
            # ⏳ ΣΤΑΤΙΚΟ ΦΡΕΝΟ: Κρατάμε το script ενεργό για 4 δευτερόλεπτα, ώστε
            # το μήνυμα να κάτσει καθαρά στην οθόνη ΠΡΙΝ ξεκινήσει το επόμενο fix!
            xbmc.sleep(4000)
            
    except Exception as tmdbh_error:
        xbmc.log(f"[Master_Build] [Fix5] Αποτυχία κατά το Smart Reset του TMDbH: {str(tmdbh_error)}", xbmc.LOGERROR)
