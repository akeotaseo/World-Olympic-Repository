﻿# -*- coding: utf-8 -*-
import os
import sys
import glob
import shutil
import sqlite3
import xbmc
import xbmcgui
import xbmcvfs

ADDON_ROOT = xbmcvfs.translatePath('special://home/addons/plugin.program.downloader19/')
if ADDON_ROOT not in sys.path:
    sys.path.insert(0, ADDON_ROOT)

def restore_widgets_and_optimizer():
    xbmcgui.Dialog().notification(
        "[B][COLOR orange]Επαναφορά Build[/COLOR][/B]",
        "Εκκίνηση επαναφοράς Widgets & Optimizer...",
        icon="special://home/addons/skin.19MatrixWorld/media/Widgets.png",
        sound=False
    )
    
    # 1. Επαναφορά ρυθμίσεων optimizer (thegroove360, YouTube, TMDb, Context Menu)
    try:
        import addon_optimizer
        addon_optimizer.restore_heavy_settings()
    except Exception as e:
        xbmc.log(f"[Master_Build] Recovery Optimizer Error: {e}", xbmc.LOGERROR)

    # 2. Επαναφορά Widgets & ReloadSkin
    try:
        import World_widget_OnOff
        World_widget_OnOff.restore_widgets(do_reload=True)
    except Exception as e:
        xbmc.log(f"[Master_Build] Recovery Widgets Error: {e}", xbmc.LOGERROR)
        xbmc.executebuiltin('Skin.SetString(CustomWidgets,100)')
        xbmc.executebuiltin('ReloadSkin()')

    # 3. Επαναφορά Screensaver & καθαρισμός σημαίας
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"screensaver.mode","value":"screensaver.xbmc.builtin.dim"}}')
    xbmc.executebuiltin('Skin.ResetString(UpdaterWorking)')


def restore_skin_settings():
    reset_script = xbmcvfs.translatePath('special://home/addons/skin.19MatrixWorld/xml/ReSetDataSkin.py')
    if os.path.exists(reset_script):
        xbmc.executebuiltin(f'RunScript("{reset_script}")')
        return

    # Fallback αν λείπει το ReSetDataSkin.py: Επαναφορά από το backup/skin.19MatrixWorld/settings.xml
    backup_xml = xbmcvfs.translatePath('special://home/backup/skin.19MatrixWorld/settings.xml')
    target_xml = xbmcvfs.translatePath('special://home/userdata/addon_data/skin.19MatrixWorld/settings.xml')
    if os.path.exists(backup_xml):
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"lookandfeel.skin","value":"skin.estuary"},"id":1}')
        xbmc.sleep(1500)
        xbmc.executebuiltin('SendClick(yesnodialog, 11)')
        xbmc.sleep(2000)
        shutil.copyfile(backup_xml, target_xml)
        xbmc.sleep(1000)
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"lookandfeel.skin","value":"skin.19MatrixWorld"},"id":1}')
        xbmc.sleep(1500)
        xbmc.executebuiltin('SendClick(yesnodialog, 11)')


def force_unblock_and_update():
    """ 🔓 Ξεμπλοκάρει κολλημένα repositories / packages και εκκινεί καθαρό έλεγχο ενημερώσεων """
    xbmcgui.Dialog().notification(
        "[B][COLOR aqua]Ξεμπλοκάρισμα Ενημερώσεων[/COLOR][/B]",
        "Καθαρισμός cache αποθετηρίων...",
        icon="special://home/addons/skin.19MatrixWorld/media/update.png",
        sound=False
    )

    # 1. Καθαρισμός cache της Addons33.db (μηδενισμός checksums στα repos & καθαρισμός packages/rules)
    db_path = xbmcvfs.translatePath('special://database/Addons33.db')
    if os.path.exists(db_path):
        try:
            conn = sqlite3.connect(db_path, timeout=15)
            cur = conn.cursor()
            cur.execute("UPDATE repo SET checksum = '', lastcheck = ''")
            cur.execute("DELETE FROM package")
            cur.execute("DELETE FROM update_rules")
            conn.commit()
            conn.close()
            xbmc.log("[Master_Build] Καθαρίστηκαν τα checksums των repositories στην Addons33.db.", xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"[Master_Build] Σφάλμα καθαρισμού Addons33.db: {e}", xbmc.LOGERROR)

    # 2. Διαγραφή κολλημένων .zip στον φάκελο addons/packages
    packages_dir = xbmcvfs.translatePath('special://home/addons/packages')
    if os.path.exists(packages_dir):
        for zip_file in glob.glob(os.path.join(packages_dir, '*.zip')):
            try:
                os.remove(zip_file)
            except:
                pass

    # 3. Ενεργοποίηση αυτόματων ενημερώσεων & αναγκαστικός επανέλεγχος τοπικών + αποθετηρίων
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"general.addonupdates","value":0}}')
    xbmc.sleep(300)
    xbmc.executebuiltin('UpdateLocalAddons()')
    xbmc.sleep(1000)
    xbmc.executebuiltin('UpdateAddonRepos()')
    xbmc.sleep(1500)

    # 4. Ανοίγουμε το παράθυρο των διαθέσιμων ενημερώσεων
    xbmc.executebuiltin('ActivateWindow(10040,"addons://outdated/")')


def Recovery_Menu():
    # ⚠️ Ειδοποίηση με ήχο & υποχρεωτικός διάλογος OK
    xbmcgui.Dialog().notification(
        "[B][COLOR orange]ΠΡΟΣΟΧΗ - ΕΝΗΜΕΡΩΣΕΙΣ BUILD[/COLOR][/B]",
        "Διαβάστε προσεκτικά πριν προχωρήσετε!",
        icon="special://home/addons/skin.19MatrixWorld/media/danger.png",
        time=4500,
        sound=True
    )
    xbmcgui.Dialog().ok(
        "[B][COLOR orange]Προσοχή — Κέντρο Διάσωσης[/COLOR][/B]",
        "Σε περίπτωση που τρέχουν [B][COLOR orange]ενημερώσεις του Build[/COLOR][/B], [B][COLOR red]ΜΗΝ πατήσετε τίποτα[/COLOR][/B] μέχρι να ολοκληρωθούν.[CR][CR]"
        "Χρησιμοποιήστε τα εργαλεία επαναφοράς [B]μόνο[/B] αν [B]εκκρεμούν[/B] ή [B]έχει κολλήσει[/B] κάποια ενημέρωση προσθέτων, αν λείπουν τα [B]Widgets[/B] ή αν έχει χαθεί το [B]αρχικό μενού[/B]."
    )


    menu_items = [

        {
            "label": "[COLOR lime]Επαναφορά Widgets & Optimizer[/COLOR]",
            "subtitle": "Ξεμπλοκάρισμα Αρχικής Οθόνης",
            "icon": "special://home/addons/skin.19MatrixWorld/media/Widgets.png",
            "plot": (
                "[B][COLOR lime]Πότε χρησιμοποιείται:[/COLOR][/B][CR]"
                "Αν η υπηρεσία ενημέρωσης κόλλησε ή τερματίστηκε πρόωρα και έμειναν κλειστά τα Widgets στην αρχική οθόνη.[CR][CR]"
                "[B][COLOR orange]Τι κάνει:[/COLOR][/B][CR]"
                "• Επαναφέρει όλα τα Widgets στην αρχική οθόνη.[CR]"
                "• Ενεργοποιεί ξανά τις ρυθμίσεις των προσθέτων (Optimizer).[CR]"
                "• Επαναφέρει τον Screensaver και ανανεώνει το κέλυφος."
            ),
            "function": restore_widgets_and_optimizer
        },
        {
            "label": "[COLOR orange]Επαναφορά Ρυθμίσεων Skin[/COLOR]",
            "subtitle": "ReSet Data Skin",
            "icon": "special://home/addons/skin.19MatrixWorld/resources/icon.png",
            "plot": (
                "[B][COLOR orange]Πότε χρησιμοποιείται:[/COLOR][/B][CR]"
                "Αν το κέλυφος γύρισε στις εργοστασιακές ρυθμίσεις (Xonfluence) και χάθηκαν τα μενού ή η διάταξη του World Build.[CR][CR]"
                "[B][COLOR aqua]Τι κάνει:[/COLOR][/B][CR]"
                "• Επαναφέρει το αρχείο ρυθμίσεων του κελύφους (settings.xml) από το ασφαλές αντίγραφο ασφαλείας του Build."
            ),
            "function": restore_skin_settings,
            "notification": {
                "title": "[B][COLOR orange]Επαναφορά Skin[/COLOR][/B]",
                "msg": "Εκτέλεση επαναφοράς ρυθμίσεων κελύφους...",
                "icon": "special://home/addons/skin.19MatrixWorld/resources/icon.png"
            }
        },
        {
            "label": "[COLOR aqua]Ξεμπλοκάρισμα & Ενημέρωση Add-ons[/COLOR]",
            "subtitle": "Καθαρισμός Cache Repos & Έλεγχος",
            "icon": "special://home/addons/skin.19MatrixWorld/media/update.png",
            "plot": (
                "[B][COLOR aqua]Πότε χρησιμοποιείται:[/COLOR][/B][CR]"
                "Όταν το κουμπί FIX ανάβει [COLOR gold]χρυσό[/COLOR] (διαθέσιμες ενημερώσεις) ή όταν κάποιο πρόσθετο/repository κολλάει και δεν κατεβάζει τη νέα έκδοση.[CR][CR]"
                "[B][COLOR lime]Τι κάνει:[/COLOR][/B][CR]"
                "• Μηδενίζει την cache των repositories στη βάση (Addons33.db).[CR]"
                "• Καθαρίζει κολλημένα πακέτα και αναγκάζει το Kodi να κατεβάσει τις νέες εκδόσεις χωρίς επανεκκίνηση."
            ),
            "function": force_unblock_and_update
        }
    ]

    movie_page = []
    for item in menu_items:
        selected_title = f"[B]{item['label']}[/B]  [COLOR blue]{item['subtitle']}[/COLOR]"
        liz = xbmcgui.ListItem(selected_title)
        liz.setInfo(type="Video", infoLabels={"Title": item["label"], "Plot": item["plot"]})
        liz.setArt({'thumb': item["icon"], 'icon': item["icon"]})
        movie_page.append(liz)

    ret = xbmcgui.Dialog().select('[B][COLOR=orange]Κέντρο Διάσωσης & Επαναφοράς[/COLOR][/B]', movie_page, useDetails=True)

    if ret >= 0:
        chosen = menu_items[ret]
        xbmc.sleep(300)

        if "notification" in chosen:
            notif = chosen["notification"]
            xbmcgui.Dialog().notification(notif["title"], notif["msg"], sound=False, icon=notif["icon"])

        if "function" in chosen:
            chosen["function"]()
        elif "builtin" in chosen:
            xbmc.executebuiltin(chosen["builtin"])
        elif "script" in chosen:
            xbmc.executebuiltin(f'RunScript("{chosen["script"]}")')


if __name__ == '__main__':
    Recovery_Menu()
