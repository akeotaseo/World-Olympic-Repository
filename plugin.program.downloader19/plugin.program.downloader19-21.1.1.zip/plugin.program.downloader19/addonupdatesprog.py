﻿# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcvfs, sys, json, os, re, glob, shutil, xbmcaddon
from threading import Thread
# 🟢 Ο ΑΥΘΕΝΤΙΚΟΣ ΣΟΥ ΚΩΔΙΚΑΣ (100% ΚΑΘΑΡΟΣ & ΕΛΑΦΡΥΣ)
xbmc.sleep(200)
# Install updates automatically
xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"general.addonupdates","value":0}}')
xbmc.sleep(1000)
xbmcgui.Dialog().notification("Add-ons Updates...", "[COLOR green]Enable[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/auto5.png', sound=False)
xbmc.sleep(4000)
xbmcgui.Dialog().notification("Check...", "Ελεγχος για ενημερώσεις προσθέτων", icon='special://home/addons/plugin.program.downloader19/resources/media/auto3.png', sound=False)
xbmc.sleep(4000)


xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"screensaver.mode","value":"screensaver.xbmc.builtin.dim"},"id":"1"}')
dp = xbmcgui.DialogProgressBG()

HOME           = xbmcvfs.translatePath('special://home/')
ADDONS         = os.path.join(HOME,     'addons')
ADDONPATH      = os.path.join(ADDONS, 'plugin.program.downloader19')
FANART         = os.path.join(ADDONPATH, 'fanart.jpg')
ICON           = os.path.join(ADDONPATH, 'icon.png')
SKINFOLD       = os.path.join(ADDONPATH, 'resources', 'skins', 'DefaultSkin', 'media')
ADDONTITLE     = '[B]World Υπηρεσία Ενημέρωσης[/B]'

class MainMonitor(xbmc.Monitor):
    def __init__(self):
        super(MainMonitor, self).__init__()

monitor = MainMonitor()

ACTION_PREVIOUS_MENU            =  10   ## ESC action
ACTION_NAV_BACK                 =  92   ## Backspace action
ACTION_MOVE_LEFT                =   1   ## Left arrow key
ACTION_MOVE_RIGHT               =   2   ## Right arrow key
ACTION_MOVE_UP                  =   3   ## Up arrow key
ACTION_MOVE_DOWN                =   4   ## Down arrow key
ACTION_MOUSE_WHEEL_UP           = 104   ## Mouse wheel up
ACTION_MOVE_MOUSE               = 107   ## Down arrow key
ACTION_SELECT_ITEM              =   7   ## Number Pad Enter
ACTION_BACKSPACE                = 110   ## ?
ACTION_MOUSE_LEFT_CLICK         = 100
ACTION_MOUSE_LONG_CLICK         = 108


##########################
### Converted to XML
##########################

def progress(msg="", t=1, image=ICON, dw='Progress.xml'):
        class MyWindow(xbmcgui.WindowXMLDialog):
            def __init__(self, *args, **kwargs):
                if monitor.waitForAbort(0.5):
                    sys.exit()
                # xbmc.sleep(500)
                self.title = '[COLOR white]%s[/COLOR]' % ADDONTITLE
                self.image = image
                if "ERROR" in kwargs["msg"]:
                    self.image = os.path.join(SKINFOLD, 'Icons', 'defaulticonerror.png')
                self.fanart = FANART
                self.msg = '[COLOR darkorange]%s[/COLOR]' % kwargs["msg"]
                if "ERROR" in kwargs["msg"]:
                    self.msg = '[COLOR red]%s[/COLOR]' % kwargs["msg"]


            def onInit(self):
                self.fanartimage = 101
                self.titlebox = 102
                self.imagecontrol = 103
                self.textbox = 104
                self.showdialog()

            def showdialog(self):
                self.getControl(self.imagecontrol).setImage(self.image)
                self.getControl(self.fanartimage).setImage(os.path.join(SKINFOLD, 'Background', 'progress-dialog-bg.png'))
                self.getControl(self.fanartimage).setColorDiffuse('9FFFFFFF')
                self.getControl(self.textbox).setText(self.msg)
                self.getControl(self.titlebox).setLabel(self.title)
                w_id = str(xbmcgui.getCurrentWindowDialogId())
                x_ = 0
                while x_ < t and xbmc.getCondVisibility("Window.isVisible({})".format(w_id)) and not monitor.abortRequested():
                    x_ += 1
                    if monitor.waitForAbort(1):
                        sys.exit()
                self.close()
                
            def onAction(self,action):
                if   action == ACTION_PREVIOUS_MENU: self.close()
                elif action == ACTION_NAV_BACK: self.close()

        cw = MyWindow( dw , ADDONPATH, 'DefaultSkin', title=ADDONTITLE, fanart=FANART, image=image, msg='[B]'+msg+'[/B]', t=t)
        cw.doModal()
        del cw

def percentage(part, whole):
    return 100 * float(part)/float(whole)

def UpdatesStatus():
    request='{"jsonrpc":"2.0","method":"XBMC.GetInfoLabels","params":{"labels": ["System.AddonUpdateCount"] },"id":1}'
    response = xbmc.executeJSONRPC(request)
    response_result = json.loads(response)
    num = response_result['result']['System.AddonUpdateCount']
    return num

def updateprogress():
    xbmc.executebuiltin('ActivateWindow(2139)')
    progress('Παρακαλώ περιμένετε!', t=2)
    
    # 🎯 ΔΙΟΡΘΩΣΗ: Καλούμε τις επίσημες εντολές του συστήματος του Kodi χωρίς () στο τέλος
    xbmc.executebuiltin('UpdateAddonRepos')   # 👈 Χωρίς παρενθέσεις στο τέλος!
    xbmc.executebuiltin('UpdateLocalAddons')  # 👈 Χωρίς παρενθέσεις στο τέλος!

    
    # ... (όλος ο υπόλοιπος κώδικας του αρχείου συνεχίζει κανονικά όπως τον έχεις) ...

    while not UpdatesStatus() >= '0':
        if monitor.waitForAbort(1):
            xbmc.executebuiltin('Dialog.Close(all,true)')
            sys.exit()
    totalupdates = int(UpdatesStatus())
    free_mem = int(re.sub(r'\D', '', xbmc.getInfoLabel('System.FreeMemory')))
    if UpdatesStatus() > '0':
        if free_mem > 200:
            xbmc.executebuiltin('Dialog.Close(all,true)')
            if monitor.waitForAbort(0.5):
                sys.exit()
            xbmc.executebuiltin('ActivateWindow(10040,"addons://outdated/")')
            if UpdatesStatus() > '0':
                progress('Υπάρχουν %s [CR]ενημερώσεις' % UpdatesStatus())
                dp.create('Ενημερώσεις προσθέτων', 'Διαθέσιμες %s ενημερώσεις' % UpdatesStatus())
            else:
                dp.create('Ενημερώσεις προσθέτων', 'Οι ενημερώσεις ολοκληρώθηκαν')
                if monitor.waitForAbort(2):
                    dp.close()
                    sys.exit()
                dp.close()
                if xbmc.getCondVisibility("Window.isVisible(10040)"):
                    # xbmc.executebuiltin('Dialog.Close(all,true)')
                    xbmc.executebuiltin('Action(Back)')
                if monitor.waitForAbort(0.5):
                    sys.exit()
                xbmc.executebuiltin('Dialog.Close(all,true)')
                xbmc.executebuiltin('ActivateWindow(10000)')
                xbmc.sleep(4000)
                xbmcgui.Dialog().notification("To Build φαίνεται ενημερωμένο...", "   ", icon='special://home/addons/plugin.program.downloader19/resources/media/ok3.png', sound=False)
                xbmc.sleep(4000)
                xbmcgui.Dialog().notification("Για να δούμε τι θα  δούμε...", "   ", icon='special://home/addons/plugin.program.downloader19/resources/media/thinking_face.png', sound=False)
                xbmc.sleep(4000)
                return True
            Thread(target=progress_notification, daemon=True).start()
            if monitor.waitForAbort(2):
                dp.close()
                sys.exit()
            x = 0
            dismiss = 1080
            w_id = str(xbmcgui.getCurrentWindowDialogId())
            while not UpdatesStatus() == '0'  and x < dismiss and not monitor.abortRequested() and xbmc.getCondVisibility("Window.isVisible({})".format(w_id)):
                x += 1
                msg1 = 'Εκκρεμούν %s ενημερώσεις - κλείνω σε %s' % (UpdatesStatus(), str(dismiss-x))
                msg2 = 'Επιστρέφετε με το πλήκτρο back - κλείνω σε %s' % str(dismiss-x)
                if (x % 2) == 0:
                    msg = msg1
                else:
                    msg = msg2
                updateperc = int(percentage(int(UpdatesStatus()), totalupdates))
                dp.update(updateperc, 'Ενημερώσεις προσθέτων', msg)
                if monitor.waitForAbort(1):
                    dp.close()
                    break
                    sys.exit()
            if UpdatesStatus() == '0':
                dp.update(0, 'Ενημερώσεις προσθέτων', 'Οι ενημερώσεις ολοκληρώθηκαν')
                if monitor.waitForAbort(2):
                    dp.close()
                    sys.exit()
                if xbmc.getCondVisibility("Window.isVisible({})".format(w_id)):
                    xbmc.executebuiltin('Action(Back)')
                    if monitor.waitForAbort(0.5):
                        dp.close()
                        sys.exit()
                dp.close()
            elif x == 1080:
                dp.update(0, 'Ενημερώσεις προσθέτων', 'Λήξη χρόνου, οι ενημερώσεις δεν έχουν ολοκληρωθει')
                if monitor.waitForAbort(2):
                    dp.close()
                    sys.exit()
                if xbmc.getCondVisibility("Window.isVisible({})".format(w_id)):
                    xbmc.executebuiltin('Action(Back)')
                    if monitor.waitForAbort(0.5):
                        dp.close()
                        sys.exit()
                dp.close()
            else:
                dp.update(0, 'Ενημερώσεις προσθέτων', 'Οι ενημερώσεις θα συνεχιστούν στο background')
                if not xbmc.getCondVisibility("Window.isVisible({})".format(w_id)):
                    if monitor.waitForAbort(2):
                        dp.close()
                        sys.exit()
                    dp.close()
                    sys.exit()
                elif xbmc.getCondVisibility("Window.isVisible({})".format(w_id)):
                    if monitor.waitForAbort(2):
                        dp.close()
                        sys.exit()
                    xbmc.executebuiltin('Action(Back)')
                    if monitor.waitForAbort(0.5):
                        dp.close()
                        sys.exit()
            if xbmc.getCondVisibility("Window.isVisible({})".format(w_id)):
                xbmc.executebuiltin('Action(Back)')
                if monitor.waitForAbort(0.5):
                    sys.exit()
            if xbmc.getCondVisibility("Window.isVisible(10040)"):
                xbmc.executebuiltin('Action(Back)')
            if monitor.waitForAbort(0.5):
                sys.exit()
            xbmc.executebuiltin('Dialog.Close(all,true)')
            xbmc.executebuiltin('ActivateWindow(10000)')
            xbmc.sleep(4000)
            xbmcgui.Dialog().notification("To Build φαίνεται ενημερωμένο...", "   ", icon='special://home/addons/plugin.program.downloader19/resources/media/ok3.png', sound=False)
            xbmc.sleep(4000)
            xbmcgui.Dialog().notification("Για να δούμε τι θα  δούμε...", "   ", icon='special://home/addons/plugin.program.downloader19/resources/media/thinking_face.png', sound=False)
            xbmc.sleep(4000)
            return True
    else:
        progress('Δεν υπάρχουν[CR]ενημερώσεις προσθέτων', t=2)
        xbmc.executebuiltin('Dialog.Close(all,true)')
        xbmc.sleep(2000)
        xbmcgui.Dialog().notification("To Build είναι ενημερωμένο...", "   ", icon='special://home/addons/plugin.program.downloader19/resources/media/ok.gif', sound=False)
        xbmc.sleep(4000)
        xbmcgui.Dialog().notification("Καλή διασκέδαση!", "   ", icon='special://home/addons/plugin.program.downloader19/resources/media/hi.gif', sound=False)
        return False

def progress_notification():
    progress('Περιμένετε να ολοκληρωθούν[CR]οι ενημερώσεις προσθέτων', t=1620, dw='Progress2.xml')

def clean_house():
    """ 🧹 ΕΝΟΤΗΤΑ ΚΑΘΑΡΙΣΜΟΥ: Εκτελείται ΑΠΟΛΥΤΑ στο τέλος του αρχείου """
    try:
        # 🧼 ΣΒΗΣΙΜΟ ΤΟΥ REPO LOCK (Με Physical Path)
        lock_file = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.program.downloader19/installation_lock.txt')
        if os.path.exists(lock_file):
            os.remove(lock_file)
            xbmc.log("[Master_Build] Το installation_lock.txt εξαφανίστηκε οριστικά.", xbmc.LOGINFO)

        # 🧼 ΣΒΗΣΙΜΟ ΤΟΥ ZIP2 LOCK (Με Physical Path για να σταματήσει το πινγκ-πονγκ)
        lock_file_zip2 = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.program.downloader19/zip2_lock.txt')
        if os.path.exists(lock_file_zip2):
            os.remove(lock_file_zip2)
            xbmc.log("[Master_Build] Το zip2_lock.txt εξαφανίστηκε οριστικά από τον δίσκο.", xbmc.LOGINFO)

        # Καθαρισμός vnmedia service
        vn_service = xbmcvfs.translatePath('special://home/addons/plugin.video.vnmedia/service.py')
        if os.path.exists(vn_service):
            os.remove(vn_service)
        xbmc.sleep(1000)

        pack = xbmcvfs.translatePath('special://home/addons/packages')
        if not os.path.exists(pack):
            os.makedirs(pack)

        # Εκκαθάριση Cache του ArtistSlideshow
        base_path = xbmcvfs.translatePath('special://home/userdata/addon_data/script.artistslideshow')
        for folder_name in ["ArtistInformation", "ArtistSlideshow"]:
            target_path = os.path.join(base_path, folder_name)
            if os.path.exists(target_path) and os.path.isdir(target_path):
                shutil.rmtree(target_path)
    except Exception as e:
        xbmc.log(f"[Master_Build] Σφάλμα στην clean_house: {str(e)}", xbmc.LOGERROR)
# 🔥 ΕΝΙΑΙΟ ENTRY POINT: Αυτό δίνει την εντολή εκκίνησης μόλις καλέσει το Kodi το RunScript!
if __name__ == '__main__':
    # 1. Εκτελούμε πρώτα τη διαδικασία ελέγχου και εμφάνισης των updates
    updateprogress()
    
    # 2. Μόλις ολοκληρωθεί, εκτελείται αυτόματα ο καθαρισμός και το σβήσιμο των lock αρχείων
    clean_house()

