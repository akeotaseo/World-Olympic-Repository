﻿import xbmc, xbmcgui, xbmcvfs, sys, json, os, re, glob, shutil, xbmcaddon, urllib.request

# PVR
xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.stalker","enabled":false}}')
xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.iptvsimple","enabled":false}}')
xbmc.sleep(200)

# ADDONS UPDATE
xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"addons.updatemode","value":1}}')
xbmc.sleep(200)
xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"general.addonupdates","value":1}}')

######################################################################################
xbmcvfs.delete('special://home/userdata/addon_data/plugin.video.myiptv/cache.db')
######################################################################################

# 🎨 ΕΔΩ ΞΕΚΙΝΑΕΙ Η ΑΙΣΘΗΤΙΚΗ ΑΝΑΜΟΝΗ (Σύνολο: 5 δευτερόλεπτα)
xbmc.sleep(1000) 
xbmcgui.Dialog().notification("[B][COLOR orange]...[/COLOR][/B]", "   ", sound=False, icon='special://home/addons/plugin.program.downloader19/resources/media/autoexec.png')

xbmc.sleep(2000) 
xbmcgui.Dialog().notification("[COLOR white]Έναρξη World Updater...[/COLOR]", "[B][COLOR orange]Καλώς ήρθατε![/COLOR][/B]", sound=False, icon='special://home/addons/plugin.program.downloader19/resources/media/World.png')

xbmc.sleep(2000) 

from resources.lib.modules import check
from updatervar import *

# 🔥 Η ΣΚΟΥΠΑ ΣΤΗΝ ΕΚΚΙΝΗΣΗ (Καρφωτά Paths για σιγουριά)
try:
	lock1 = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.program.downloader19/installation_lock.txt')
	lock2 = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.program.downloader19/zip2_lock.txt')
	
	if xbmcvfs.exists(lock1):
		xbmcvfs.delete(lock1)
	if xbmcvfs.exists(lock2):
		xbmcvfs.delete(lock2)
except Exception:
	pass


def check_online_update():
	""" 🌐 Διαβάζει το addons.xml απευθείας από το GitHub για 100% σιγουριά """
	try:
		# 🎯 Το RAW URL του δικού σου World-Olympic-Repository
		repo_xml_url = "https://githubusercontent.com"
		
		req = urllib.request.Request(repo_xml_url, headers={'User-Agent': 'Mozilla/5.0'})
		with urllib.request.urlopen(req, timeout=7) as response:
			xml_data = response.read().decode('utf-8')
		
		# Ψάχνουμε στο xml τη γραμμή του plugin.program.downloader19 για να βρούμε το version="..."
		match = re.search(r'id\s*=\s*"plugin\.program\.downloader19".*?version\s*=\s*"([^"]+)"', xml_data, re.DOTALL)
		if match:
			online_version = match.group(1)
			local_version = xbmcaddon.Addon('plugin.program.downloader19').getAddonInfo('version')
			
			# Μετατρέπουμε τις εκδόσεις σε αριθμούς (π.χ. '1.0.5' -> 105) για ασφαλή σύγκριση
			v_online = int(online_version.replace('.', ''))
			v_local  = int(local_version.replace('.', ''))
			
			if v_online > v_local:
				return True
	except Exception:
		pass
	return False


if __name__ == '__main__':
	if setting('notifyversion') == '0': # για την πρώτη εγκατάσταση
		xbmcgui.Dialog().ok('[B][COLOR blue]Πρώτη Εγκατάσταση[/COLOR][/B]', 'Περιμένετε να ολοκληρωθούν [COLOR lime]οι ενημερώσεις των Προσθέτων[/COLOR][CR]και η Εγκατάσταση των [B]binary add-ons[/B].')
		check.notifyT()
		xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"general.addonupdates","value":0}}')
		xbmc.sleep(1000)
		xbmc.executebuiltin('UpdateAddonRepos()')
		xbmc.executebuiltin('UpdateLocalAddons()')
		xbmc.executebuiltin('ActivateWindow(AddonBrowser)')
        
	else:
		# 🔍 ONLINE CHECK: Μαθαίνουμε αν υπάρχει update πριν προλάβει να απαντήσει το Kodi
		has_plugin_update = check_online_update()

		# 🚀 ΑΜΕΣΟ ΦΡΕΝΟ: Αν υπάρχει update στο GitHub, σταματάμε τα πάντα ΕΔΩ!
		if has_plugin_update:
			xbmcgui.Dialog().notification("[B][COLOR orange]World Updater[/COLOR][/B]", "[COLOR lime]Εντοπίστηκε νέα έκδοση! Λήψη...[/COLOR]", icon='special://home/addons/plugin.program.downloader19/icon.gif', sound=False)
			
			# Δίνουμε εντολή στο Kodi να ανανεώσει τα repos και να κατεβάσει το update
			xbmc.executebuiltin('UpdateAddonRepos')
			xbmc.sleep(2000)
			
			# Κλείνουμε ακαριαία το service. Το πεδίο μένει ελεύθερο, η μπάρα ξεκολλάει και το update περνιέται σωστά!
			import sys
			sys.exit()
		
		# 🟢 Αν ΔΕΝ υπάρχει update, συνεχίζουν κανονικά όλα τα checks του Build σου
		elif not setting('updaterversion') == 'false':
			xbmcgui.Dialog().notification("[B][COLOR orange]Ελεγχος για ενημερώσεις[/COLOR][/B]", "...", icon='special://home/addons/plugin.program.downloader19/icon.gif', sound=False)
			check.notifyT()
			check.autoenable()
			check.var()
			check.delete()
			check.installation()
			check.players()
			check.zip1()
			check.zip2()
			check.zip3()
			check.zip4()
			check.zip5()
			check.pvr()
			check.setsetting()
			check.database()
			check.xmlskin()

			check.UpdateAddonRepos()

		else:
			dialog.notification('[B][COLOR orange]Καλά να περάσετε![/COLOR][/B]', Dialog_not_Updater, icon_Build, sound=False)
			xbmc.sleep(2000)
			xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"general.addonupdates","value":0}}')
			xbmc.sleep(2000)
			xbmc.executebuiltin('UpdateLocalAddons()')
			xbmc.executebuiltin('UpdateAddonRepos()')
			xbmc.executebuiltin('ActivateWindow(AddonBrowser)')


##Tk & GKoBu & TRAILER MONITOR MULTI-MERGE LAYER ______________________________________
		monitor = xbmc.Monitor()
		update_interval = 2 * 60 * 60
		time_counter = 0

		# 🔥 ΤΟ ΕΝΙΑΙΟ BACKGROUND LOOP - THE OSD STOP INTERCEPTOR (CHECKMATE)
		while not monitor.abortRequested():
			
			if xbmc.getCondVisibility('Window.IsVisible(home)') and not xbmc.getCondVisibility('Window.IsVisible(6199)'):
				if xbmc.getInfoLabel('Skin.String(TrailerCheckID)') != '':
					xbmc.executebuiltin('Skin.ResetString(TrailerCheckID)')
					xbmc.executebuiltin('Skin.ResetString(HubMovieTitle)')
					xbmc.executebuiltin('Skin.ResetString(HubMoviePlot)')
					xbmc.executebuiltin('Skin.ResetString(HubMovieCast)')
					xbmc.executebuiltin('Skin.ResetString(HubMovieDirector)')
					xbmc.executebuiltin('Skin.ResetString(HubMovieWriter)')
					xbmc.executebuiltin('Skin.ResetString(HubMovieGenre)')
					xbmc.executebuiltin('Skin.ResetString(HubMovieYear)')
					xbmc.executebuiltin('Skin.ResetString(HubMovieRating)')
					xbmc.executebuiltin('Skin.ResetString(HubMovieStudio)')
					xbmc.executebuiltin('Skin.ResetString(HubMovieCountry)')
					xbmc.executebuiltin('Skin.ResetString(HubMoviePoster)')
					xbmc.executebuiltin('Skin.ResetString(HubMovieFanart)')
					xbmc.executebuiltin('Skin.ResetString(HubMovieTagLine)')
					xbmc.executebuiltin('Skin.ResetString(HubMovieDuration)')
					xbmc.executebuiltin('Skin.ResetString(HubMovieEndTime)')

			# 🟢 ΕΝΟΤΗΤΑ Β: ΔΙΑΧΕΙΡΙΣΗ WORLD UPDATER (Κάθε 2 ώρες)
			time_counter += 0.1 
			if time_counter >= update_interval:
				time_counter = 0 
				xbmc.executebuiltin('UpdateAddonRepos()')

			# 😴 SLEEP LAYER: 100ms για 0% επιβάρυνση στην CPU
			if monitor.waitForAbort(0.1):
				break
