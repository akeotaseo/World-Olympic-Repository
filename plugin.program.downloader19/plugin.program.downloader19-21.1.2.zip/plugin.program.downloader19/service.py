﻿import xbmc, xbmcgui, xbmcvfs, sys, json, os, re, glob, shutil, xbmcaddon, urllib.request

# PVR
xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.stalker","enabled":false}}')
xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.iptvsimple","enabled":false}}')
xbmc.sleep(200)

# ADDONS UPDATE
xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"addons.updatemode","value":1}}')
xbmc.sleep(200)
xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"general.addonupdates","value":1}}')

######################################################################################
xbmcvfs.delete('special://home/userdata/addon_data/plugin.video.myiptv/cache.db')
######################################################################################

# 🎨 ΕΔΩ ΞΕΚΙΝΑΕΙ Η ΑΙΣΘΗΤΙΚΗ ΑΝΑΜΟΝΗ (Σύνολο: 5 δευτερόλεπτα για να προλάβει το Kodi να δει τα Updates)
xbmc.sleep(1000) 
xbmcgui.Dialog().notification("[B][COLOR orange]...[/COLOR][/B]", "   ", sound=False, icon='special://home/addons/plugin.program.downloader19/resources/media/autoexec.png')

xbmc.sleep(2000) 
xbmcgui.Dialog().notification("[COLOR white]Έναρξη World Updater...[/COLOR]", "[B][COLOR orange]Καλώς ήρθατε![/COLOR][/B]", sound=False, icon='special://home/addons/plugin.program.downloader19/resources/media/World.png')

xbmc.sleep(2000) 

from resources.lib.modules import check
from updatervar import *

# 🔥 Η ΣΚΟΥΠΑ ΣΤΗΝ ΕΚΚΙΝΗΣΗ (Καρφωτά Paths για σιγουριά)
try:
	lock1 = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.program.downloader19/installation_lock.txt')
	lock2 = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.program.downloader19/zip2_lock.txt')
	
	if xbmcvfs.exists(lock1):
		xbmcvfs.delete(lock1)
	if xbmcvfs.exists(lock2):
		xbmcvfs.delete(lock2)
except Exception:
	pass


if __name__ == '__main__':
	if setting('notifyversion') == '0': # για την πρώτη εγκατάσταση
		xbmcgui.Dialog().ok('[B][COLOR blue]Πρώτη Εγκατάσταση[/COLOR][/B]', 'Περιμένετε να ολοκληρωθούν [COLOR lime]οι ενημερώσεις των Προσθέτων[/COLOR][CR]και η Εγκατάσταση των [B]binary add-ons[/B].')
		check.notifyT()
		xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"general.addonupdates","value":0}}')
		xbmc.sleep(1000)
		xbmc.executebuiltin('UpdateAddonRepos()')
		xbmc.executebuiltin('UpdateLocalAddons()')
		xbmc.executebuiltin('ActivateWindow(AddonBrowser)')
        
	else:
		# 🔍 100% ΑΚΡΙΒΗΣ ΕΛΕΓΧΟΣ: Ψάχνουμε στα Repos για εκκρεμές Update του Downloader
		has_plugin_update = False
		try:
			# Χρησιμοποιούμε το installed: false για να ελέγξουμε τις διαθέσιμες ενημερώσεις των αποθετηρίων
			rpc_req = '{"jsonrpc":"2.0","method":"Addons.GetAddons","id":1,"params":{"properties":["updateavailable"],"installed":false}}'
			rpc_res = xbmc.executeJSONRPC(rpc_req)
			res_data = json.loads(rpc_res)
			
			if 'result' in res_data and 'addons' in res_data['result']:
				for addon in res_data['result']['addons']:
					if addon.get('addonid') == 'plugin.program.downloader19' and addon.get('updateavailable') is True:
						has_plugin_update = True
						break
		except Exception as e:
			xbmc.log(f"[Master_Build] Σφάλμα στον έλεγχο JSON-RPC: {str(e)}", xbmc.LOGERROR)
			has_plugin_update = False

		# 🚀 ΤΟ ΣΩΣΤΟ ΠΑΓΩΜΑ: Αν βρεθεί update, φρενάρουμε τη ροή και αφήνουμε το Kodi να το περάσει
		if has_plugin_update:
			xbmcgui.Dialog().notification("[B][COLOR orange]World Updater[/COLOR][/B]", "[COLOR lime]Λήψη νέας έκδοσης... Παρακαλώ περιμένετε.[/COLOR]", icon='special://home/addons/plugin.program.downloader19/icon.gif', sound=False)
			xbmc.sleep(5000)
			
			xbmcgui.Dialog().notification("[B][COLOR orange]World Updater[/COLOR][/B]", "[COLOR lime]Εγκατάσταση... Το Kodi θα ανανεώσει το πρόσθετο.[/COLOR]", icon='special://home/addons/plugin.program.downloader19/icon.gif', sound=False)
			xbmc.sleep(4000)
			
			import sys
			sys.exit()
		
		# 🟢 Αν ΔΕΝ υπάρχει update, συνεχίζουν κανονικά όλα τα checks του Build σου
		elif not setting('updaterversion') == 'false':
			xbmcgui.Dialog().notification("[B][COLOR orange]Ελεγχος για ενημερώσεις[/COLOR][/B]", "...", icon='special://home/addons/plugin.program.downloader19/icon.gif', sound=False)
			check.notifyT()
			check.autoenable()
			check.var()
			check.delete()
			check.installation()
			check.players()
			check.zip1()
			check.zip2()
			check.zip3()
			check.zip4()
			check.zip5()
			check.pvr()
			check.setsetting()
			check.database()
			check.xmlskin()

			check.UpdateAddonRepos()

		else:
			dialog.notification('[B][COLOR orange]Καλά να περάσετε![/COLOR][/B]', Dialog_not_Updater, icon_Build, sound=False)
			xbmc.sleep(2000)
			xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"general.addonupdates","value":0}}')
			xbmc.sleep(2000)
			xbmc.executebuiltin('UpdateLocalAddons()')
			xbmc.executebuiltin('UpdateAddonRepos()')
			xbmc.executebuiltin('ActivateWindow(AddonBrowser)')


##Tk & GKoBu & TRAILER MONITOR MULTI-MERGE LAYER ______________________________________
		monitor = xbmc.Monitor()
		update_interval = 2 * 60 * 60
		time_counter = 0

		# 🔥 ΤΟ ΕΝΙΑΙΟ BACKGROUND LOOP - THE OSD STOP INTERCEPTOR (CHECKMATE)
		while not monitor.abortRequested():
			
			if xbmc.getCondVisibility('Window.IsVisible(home)') and not xbmc.getCondVisibility('Window.IsVisible(6199)'):
				if xbmc.getInfoLabel('Skin.String(TrailerCheckID)') != '':
					xbmc.executebuiltin('Skin.ResetString(TrailerCheckID)')
					xbmc.executebuiltin('Skin.ResetString(HubMovieTitle)')
					xbmc.executebuiltin('Skin.ResetString(HubMoviePlot)')
					xbmc.executebuiltin('Skin.ResetString(HubMovieCast)')
					xbmc.executebuiltin('Skin.ResetString(HubMovieDirector)')
					xbmc.executebuiltin('Skin.ResetString(HubMovieWriter)')
					xbmc.executebuiltin('Skin.ResetString(HubMovieGenre)')
					xbmc.executebuiltin('Skin.ResetString(HubMovieYear)')
					xbmc.executebuiltin('Skin.ResetString(HubMovieRating)')
					xbmc.executebuiltin('Skin.ResetString(HubMovieStudio)')
					xbmc.executebuiltin('Skin.ResetString(HubMovieCountry)')
					xbmc.executebuiltin('Skin.ResetString(HubMoviePoster)')
					xbmc.executebuiltin('Skin.ResetString(HubMovieFanart)')
					xbmc.executebuiltin('Skin.ResetString(HubMovieTagLine)')
					xbmc.executebuiltin('Skin.ResetString(HubMovieDuration)')
					xbmc.executebuiltin('Skin.ResetString(HubMovieEndTime)')

			# 🟢 ΕΝΟΤΗΤΑ Β: ΔΙΑΧΕΙΡΙΣΗ WORLD UPDATER (Κάθε 2 ώρες)
			time_counter += 0.1 
			if time_counter >= update_interval:
				time_counter = 0 
				xbmc.executebuiltin('UpdateAddonRepos()')

			# 😴 SLEEP LAYER: 100ms για 0% επιβάρυνση στην CPU
			if monitor.waitForAbort(0.1):
				break
