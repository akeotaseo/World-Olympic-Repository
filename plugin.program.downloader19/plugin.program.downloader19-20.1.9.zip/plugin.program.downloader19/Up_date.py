﻿import xbmc, xbmcgui
xbmc.sleep(2000)
xbmcgui.Dialog().select('[B][COLOR orange]Check Updates Addons[/COLOR][/B]', ['[COLOR lime]Περιμένετε  χωρίς να πατήσετε κάτι...[/COLOR]'])