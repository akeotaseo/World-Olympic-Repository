﻿import xbmc
from updatervar import *
from resources.lib.modules import check


##########
# from xbmc import executebuiltin
# from xbmcaddon import Addon
# from os.path import exists,join
# from os import makedirs
# from xbmcvfs import translatePath

# xbmcvfs.delete('special://home/addons/plugin.video.vnmedia/service.py')

# pack = translatePath('special://home/addons/packages')

# if not exists(pack):
	# makedirs(pack)
# packfolders = 'packages'
##########

xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"general.addonupdates","value":1}}')
xbmc.sleep(200)
xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.stalker","enabled":false}}')
xbmc.sleep(200)
xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.iptvsimple","enabled":false}}')
xbmc.sleep(200)

# servis.... downloaderstartup
xbmcvfs.delete('special://home/addons/plugin.program.downloaderstartup/service.py')
xbmc.sleep(200)
xbmcvfs.delete('special://home/addons/plugin.video.vnmedia/service.py')
xbmc.sleep(200)
xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/Tools/ArtistslideshowCleanUp.py")')
xbmc.sleep(200)
# Old.... Folders Autowidget
xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/DeleteFoldersAutowidget.py")')




if __name__ == '__main__':
	if not setting('updaterversion') == 'false':
		dialog.notification(Dialog_welcome, Dialog_Update, icon_Build, sound=False)
		xbmc.sleep(4000)
		xbmcgui.Dialog().notification("[B][COLOR orange]Ελεγχος για ενημερώσεις[/COLOR][/B]", "...", icon=		'special://home/addons/plugin.program.downloader19/icon.gif', sound=False)
		xbmc.sleep(5000)
		check.notifyT()
		check.autoenable()
		check.var()
		check.delete()
		check.installation()
		check.players()
		check.zip1()
		check.zip2()
		check.zip3()
		check.zip4()
		check.zip5()
		check.pvr()
		check.setsetting()
		check.database()
		check.xmlskin()
		# xbmc.sleep(5000)
		check.UpdateAddonRepos()



	else:
		dialog.notification(Dialog_welcome, Dialog_not_Updater, icon_Build, sound=False)
		check.UpdateAddonRepos()


	monitor = xbmc.Monitor()

	while not monitor.abortRequested():
		if monitor.waitForAbort(2*60*60):#διάστημα 2ωρών μεταξύ των ενημερώσεων
			break
		xbmc.executebuiltin('UpdateAddonRepos()')
		dialog.notification('Υπηρεσία ενημέρωσης', 'Εκκίνηση ενημερώσεων προσθέτων', icon_auto, sound=False)
