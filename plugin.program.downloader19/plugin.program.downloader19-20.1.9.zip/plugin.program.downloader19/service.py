﻿import xbmc, xbmcgui, xbmcvfs, sys, json, os, re, glob, shutil, xbmcaddon

xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.stalker","enabled":false}}')
xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.iptvsimple","enabled":false}}')
xbmc.sleep(500)


# Official repositories only (default)
xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"addons.updatemode","value":0}}')
# Any repositories
# xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"addons.updatemode","value":1}')
# xbmc.sleep(500)
xbmc.sleep(500)


# Install updates automatically
# xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"general.addonupdates","value":0}}')
# Notifay, but don't install updates
xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"general.addonupdates","value":1}}')
# Never check for updates
# xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"general.addonupdates","value":2}}')




######################################################################################

# base_path = xbmcvfs.translatePath('special://home/addons')

# dir_list = glob.iglob(os.path.join(base_path, "packages"))
# for path in dir_list:
    # if os.path.isdir(path):
        # shutil.rmtree(path)


# dir_list = glob.iglob(os.path.join(base_path, "temp"))
# for path in dir_list:
    # if os.path.isdir(path):
        # shutil.rmtree(path)


# base_path = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.program.downloader19')

# dir_list = glob.iglob(os.path.join(base_path, "__pycache__"))
# for path in dir_list:
    # if os.path.isdir(path):
        # shutil.rmtree(path)

# xbmc.sleep(1000)


# from xbmc import executebuiltin
# from xbmcaddon import Addon
# from os.path import exists,join
# from os import makedirs
# from xbmcvfs import translatePath


# pack = translatePath('special://home/addons/packages')

# if not exists(pack):
    # makedirs(pack)
# packfolders = 'packages'


# temp= translatePath('special://home/addons/temp')

# if not exists(temp):
    # makedirs(temp)
# tempfolders = 'temp'
#############################################################################


xbmc.sleep(4000)
xbmcgui.Dialog().notification("[B][COLOR orange]...[/COLOR][/B]", "   ", sound=False, icon='special://home/addons/plugin.program.downloader19/resources/media/autoexec.png')
xbmc.sleep(4000)
xbmcgui.Dialog().notification("[COLOR white]Έναρξη World Updater...[/COLOR]", "[B][COLOR orange]Καλώς ήρθατε![/COLOR][/B]", sound=False, icon='special://home/addons/plugin.program.downloader19/resources/media/World.png')

# xbmc.sleep(1000)
# xbmc.executebuiltin("ReloadSkin()")
from resources.lib.modules import check

from updatervar import *


if __name__ == '__main__':
	if not setting('updaterversion') == 'false':
		xbmcgui.Dialog().notification("[B][COLOR orange]Ελεγχος για ενημερώσεις[/COLOR][/B]", "...", icon='special://home/addons/plugin.program.downloader19/icon.gif', sound=False)
		xbmc.sleep(5000)
		check.notifyT()
		check.autoenable()
		check.var()
		check.delete()
		check.installation()
		check.players()
		check.zip1()
		check.zip2()
		check.zip3()
		check.zip4()
		check.zip5()
		check.pvr()
		check.setsetting()
		check.database()
		check.xmlskin()
		# xbmc.sleep(5000)
		check.UpdateAddonRepos()




	else:
		dialog.notification('[B][COLOR orange]Καλά να περάσετε![/COLOR][/B]', Dialog_not_Updater, icon_Build, sound=False)
		xbmc.sleep(2000)
		xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"general.addonupdates","value":0}}')
		# check.UpdateAddonRepos()
		xbmc.sleep(2000)
		xbmc.executebuiltin('UpdateLocalAddons()')
		xbmc.executebuiltin('UpdateAddonRepos()')
		xbmc.executebuiltin('ActivateWindow(AddonBrowser)')

	monitor = xbmc.Monitor()

	while not monitor.abortRequested():
		if monitor.waitForAbort(2*60*60):#διάστημα 2ωρών μεταξύ των ενημερώσεων
			break
		xbmc.executebuiltin('UpdateAddonRepos()')
		dialog.notification('Υπηρεσία ενημέρωσης', 'Εκκίνηση ενημερώσεων προσθέτων', icon_auto, sound=False)
