#=> TechNEWSology <=#
import xbmc, xbmcgui
icon_down = 'special://home/addons/plugin.program.downloader19/icon.gif'

class authorize:
    def auth():
        dp = xbmcgui.Dialog()
        select = dp.select('[COLOR lime]Εξουσιοδότηση => [COLOR white] Derbid - Trakt[/COLOR]',
                          ['[B][COLOR white]Real-Derbid[/COLOR][/B]',
                           '[B][COLOR white]Trakt[/COLOR][/B]',
                           '[B][COLOR white]Premiumize[/COLOR][/B]',
                           '[B][COLOR white]All Debrid[/COLOR][/B]',
                           '[B][COLOR white]Link Snappy[/COLOR][/B]',
                           '[B][COLOR white]Debrid Link[/COLOR][/B]'])

        if select   == 0: return authorize.Real_Derbid()
        elif select == 1: return authorize.Trakt()
        elif select == 2: return authorize.Premiumize()
        elif select == 3: return authorize.All_Debrid()
        elif select == 4: return authorize.Link_Snappy()
        elif select == 5: return authorize.Debrid_Link()

        else:
        #    xbmcgui.Dialog().notification('[B][COLOR lime]Εξουσιοδότηση Derbid - Trakt[/COLOR][/B]',
        #                                  '[B][COLOR orange]Ακύρωση![/COLOR][/B]' , icon_down)
            return

    def Real_Derbid():
        dp = xbmcgui.Dialog()
        select = dp.select('[COLOR lime]Real-Debrid[/COLOR]',
                          ['[B][COLOR white]Authorize ResolveURL Real-Debrid[/COLOR][/B]',
                           '[B][COLOR white]Authorize Realizer Cloud[/COLOR][/B]',
                           '[B][COLOR white]Authorize Seren Real Debrid[/COLOR][/B]',
                           '[B][COLOR white]Authorize Shadow Real Debrid[/COLOR][/B]',
                           '[B][COLOR white]Authorize Umbrella Real Debrid[/COLOR][/B]',
                           '[B][COLOR white]Authorize FEN Real Debrid[/COLOR][/B]',
                           '[B][COLOR white]Authorize EZRA Real Debrid[/COLOR][/B]',
                           '[B][COLOR white]Revoke ResolveURL Real-Debrid[/COLOR][/B]',
                           '[B][COLOR white]Revoke Umbrella Real-Debrid[/COLOR][/B]',
                           '[B][COLOR white]Revoke FEN Real-Debrid[/COLOR][/B]',
                           '[B][COLOR white]Revoke EZRA Real-Debrid[/COLOR][/B]',
                           '[B][COLOR white]Check If your VPN is compatible with Real Debrid[/COLOR][/B]'])

        if select   == 0: return xbmc.executebuiltin('RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)')
        elif select == 1: return xbmc.executebuiltin('RunPlugin(plugin://plugin.video.realizerx/?action=authRealdebrid)')
        elif select == 2: return xbmc.executebuiltin('RunPlugin(plugin://plugin.video.seren/?action=authRealDebrid)')
        elif select == 3: return xbmc.executebuiltin('RunPlugin(plugin://plugin.video.shadow?mode=138&url=www)')
        elif select == 4: return xbmc.executebuiltin('RunPlugin(plugin://plugin.video.umbrella/?action=rd_Authorize)')
        elif select == 5: return xbmc.executebuiltin('RunPlugin(plugin://plugin.video.fen/?mode=real_debrid.authenticate)')
        elif select == 6: return xbmc.executebuiltin('RunScript(script.module.myaccounts, action=realdebridAuth)')
        elif select == 7: return xbmc.executebuiltin('RunPlugin(plugin://script.module.resolveurl/?mode=reset_rd)')
        elif select == 8: return xbmc.executebuiltin('RunPlugin(plugin://plugin.video.umbrella/?action=rd_Revoke)')
        elif select == 9: return xbmc.executebuiltin('RunPlugin(plugin://plugin.video.fen/?mode=real_debrid.revoke_authentication)')
        elif select == 10: return xbmc.executebuiltin('RunScript(script.module.myaccounts, action=realdebridRevoke)')
        elif select == 11: return xbmc.executebuiltin('ActivateWindow(10001,plugin://script.RealDebrid.vpn/,return)')

        else:
            return

    def Trakt():
        dp = xbmcgui.Dialog()
        select = dp.select('[COLOR lime]                                                                            Trakt[/COLOR]',
                          ['[B][COLOR white]Authorize Trakt Addon[/COLOR][/B]',
                           '[B][COLOR white]Authorize TMDBH Trakt[/COLOR][/B]',
                           '[B][COLOR white]Authorize Blacklodge Trakt[/COLOR][/B]',
                           '[B][COLOR white]Authorize Scrubs V2 Trakt[/COLOR][/B]',
                           '[B][COLOR white]Authorize Seren Trakt[/COLOR][/B]',
                           '[B][COLOR white]Authorize Shadow Trakt[/COLOR][/B]',
                           '[B][COLOR white]Authorize Umbrella Trakt[/COLOR][/B]',
                           '[B][COLOR white]Authorize FEN Trakt[/COLOR][/B]',
                           '[B][COLOR white]Authorize EZRA Trakt[/COLOR][/B]',
                           '[B][COLOR white]Authorize Premiumizer Cloud Trakt[/COLOR][/B]',
                           '[B][COLOR white]Authorize The Crew Trakt[/COLOR][/B]',
                           '[B][COLOR white]Authorize The Promise Trakt[/COLOR][/B]',
                           '[B][COLOR white]Authorize Homelander Trakt[/COLOR][/B]',
                           '[B][COLOR white]Authorize Magic Dragon Trakt[/COLOR][/B]',
                           '[B][COLOR white]Authorize Asgard Trakt[/COLOR][/B]',
                           '[B][COLOR white]Authorize Kodiverse Trakt[/COLOR][/B]',
                           '[B][COLOR white]Authorize The Chains Trakt[/COLOR][/B]',
                           '[B][COLOR white]Authorize Ghost Trakt[/COLOR][/B]',
                           '[B][COLOR white]Authorize Moria Trakt[/COLOR][/B]',
                           '[B][COLOR white]Authorize METV Trakt[/COLOR][/B]',
                           '[B][COLOR white]Authorize Patriot Trakt[/COLOR][/B]',
                           '[B][COLOR white]Authorize Genocide Trakt[/COLOR][/B]',
                           '[B][COLOR white]Authorize Black Lightning Trakt[/COLOR][/B]',
                           '[B][COLOR white]Authorize 4K Trakt[/COLOR][/B]',
                           '[B][COLOR white]Revoke Seren Trakt[/COLOR][/B]',
                           '[B][COLOR white]Revoke EZRA Trakt[/COLOR][/B]',
                           '[B][COLOR white]Revoke Umbrella Trakt[/COLOR][/B]',
                           '[B][COLOR white]Revoke FEN Trakt[/COLOR][/B]'])

        if select   == 0: return xbmc.executebuiltin('RunScript(script.trakt,action=auth_info)')
        elif select == 1: return xbmc.executebuiltin('RunScript(plugin.video.themoviedb.helper,authenticate_trakt)')
        elif select == 2: return xbmc.executebuiltin('RunPlugin(plugin://plugin.video.blacklodge/?action=authTrakt)')
        elif select == 3: return xbmc.executebuiltin('RunPlugin(plugin://plugin.video.scrubsv2/?action=auth_trakt)')
        elif select == 4: return xbmc.executebuiltin('RunPlugin(plugin://plugin.video.seren/?action=authTrakt)')
        elif select == 5: return xbmc.executebuiltin('RunPlugin(plugin://plugin.video.shadow?mode=157&url=False)')
        elif select == 6: return xbmc.executebuiltin('RunPlugin(plugin://plugin.video.umbrella/?action=traktAuth)')
        elif select == 7: return xbmc.executebuiltin('RunPlugin(plugin://plugin.video.fen/?mode=trakt.trakt_authenticate)')
        elif select == 8: return xbmc.executebuiltin('RunScript(script.module.myaccounts, action=traktAuth)')
        elif select == 9: return xbmc.executebuiltin('RunPlugin(plugin://plugin.video.premiumizerx/?action=authTrakt)')
        elif select == 10: return xbmc.executebuiltin('RunPlugin(plugin://plugin.video.thecrew/?action=authTrakt)')
        elif select == 11: return xbmc.executebuiltin('RunPlugin(plugin://plugin.video.thepromise/?action=authTrakt)')
        elif select == 12: return xbmc.executebuiltin('RunPlugin(plugin://plugin.video.homelander/?action=authTrakt)')
        elif select == 13: return xbmc.executebuiltin('RunPlugin(plugin://plugin.video.magicdragon?mode=157&url=False)')
        elif select == 14: return xbmc.executebuiltin('RunPlugin(plugin://plugin.video.asgard?mode=157&url=False)')
        elif select == 15: return xbmc.executebuiltin('RunPlugin(plugin://plugin.video.KodiVerse?mode=157&url=False)')
        elif select == 16: return xbmc.executebuiltin('RunPlugin(plugin://plugin.video.thechains?mode=157&url=False)')
        elif select == 17: return xbmc.executebuiltin('RunPlugin(plugin://plugin.video.ghost?mode=157&url=False)')
        elif select == 18: return xbmc.executebuiltin('RunPlugin(plugin://plugin.video.moria/?action=authTrakt)')
        elif select == 19: return xbmc.executebuiltin('RunPlugin(plugin://plugin.video.metv19?mode=157&url=False)')
        elif select == 20: return xbmc.executebuiltin('RunPlugin(plugin://plugin.video.patriot?mode=157&url=False)')
        elif select == 21: return xbmc.executebuiltin('RunPlugin(plugin://plugin.video.Genocide?mode=157&url=False)')
        elif select == 22: return xbmc.executebuiltin('RunPlugin(plugin://plugin.video.blacklightning?mode=157&url=False)')
        elif select == 23: return xbmc.executebuiltin('RunPlugin(plugin://plugin.video.4k?mode=157&url=False)')
        elif select == 24: return xbmc.executebuiltin('RunPlugin(plugin://plugin.video.seren/?action=revokeTrakt)')
        elif select == 25: return xbmc.executebuiltin('RunScript(script.module.myaccounts, action=traktRevoke)')
        elif select == 26: return xbmc.executebuiltin('RunPlugin(plugin://plugin.video.umbrella/?action=traktRevoke)')
        elif select == 27: return xbmc.executebuiltin('RunPlugin(plugin://plugin.video.fen/?mode=trakt.trakt_revoke_authentication)')

        else:
            return

    def Premiumize():
        dp = xbmcgui.Dialog()
        select = dp.select('[COLOR orange]Premiumize[/COLOR]',
                          ['[B][COLOR white]Authorize ResolveURL Premiumize.me[/COLOR][/B]',
                           '[B][COLOR white]Authorize Premiumizer Cloud[/COLOR][/B]',
                           '[B][COLOR white]Authorize Seren Premiumize[/COLOR][/B]',
                           '[B][COLOR white]Authorize Umbrella Premiumize[/COLOR][/B]',
                           '[B][COLOR white]Authorize FEN Premiumize[/COLOR][/B]',
                           '[B][COLOR white]Authorize EZRA Premiumize[/COLOR][/B]',
                           '[B][COLOR white]Revoke ResolveURL Premiumize.me[/COLOR][/B]',
                           '[B][COLOR white]Revoke Umbrella Premiumize.me[/COLOR][/B]',
                           '[B][COLOR white]Revoke EZRA Premiumize.me[/COLOR][/B]',
                           '[B][COLOR white]Revoke FEN Premiumize.me[/COLOR][/B]'])

        if select   == 0: return xbmc.executebuiltin('RunPlugin(plugin://script.module.resolveurl/?mode=auth_pm)')
        elif select == 1: return xbmc.executebuiltin('RunPlugin(plugin://plugin.video.premiumizerx/?action=authPremiumize)')
        elif select == 2: return xbmc.executebuiltin('RunPlugin(plugin://plugin.video.seren/?action=authPremiumize)')
        elif select == 3: return xbmc.executebuiltin('RunPlugin(plugin://plugin.video.umbrella/?action=pm_Authorize)')
        elif select == 4: return xbmc.executebuiltin('RunPlugin(plugin://plugin.video.fen/?mode=premiumize.authenticate)')
        elif select == 5: return xbmc.executebuiltin('RunScript(script.module.myaccounts, action=premiumizeAuth)')
        elif select == 6: return xbmc.executebuiltin('RunPlugin(plugin://script.module.resolveurl/?mode=reset_pm)')
        elif select == 7: return xbmc.executebuiltin('RunPlugin(plugin://plugin.video.umbrella/?action=pm_Revoke)')
        elif select == 8: return xbmc.executebuiltin('RunScript(script.module.myaccounts, action=premiumizeRevoke)')
        elif select == 9: return xbmc.executebuiltin('RunPlugin(plugin://plugin.video.fen/?mode=premiumize.revoke_authentication)')

        else:
            return

    def All_Debrid():
        dp = xbmcgui.Dialog()
        select = dp.select('[COLOR orange]All Debrid[/COLOR]',
                          ['[B][COLOR white]Authorize ResolveURL AllDebrid[/COLOR][/B]',
                           '[B][COLOR white]Authorize Seren Alldebrid[/COLOR][/B]',
                           '[B][COLOR white]Authorize Umbrella Alldebrid[/COLOR][/B]',
                           '[B][COLOR white]Authorize FEN Alldebrid[/COLOR][/B]',
                           '[B][COLOR white]Authorize EZRA Alldebrid[/COLOR][/B]',
                           '[B][COLOR white]Revoke ResolveURL AllDebrid[/COLOR][/B]',
                           '[B][COLOR white]Revoke FEN AllDebrid[/COLOR][/B]',
                           '[B][COLOR white]Revoke EZRA AllDebrid[/COLOR][/B]',
                           '[B][COLOR white]Revoke Umbrella AllDebrid[/COLOR][/B]'])

        if select   == 0: return xbmc.executebuiltin('RunPlugin(plugin://script.module.resolveurl/?mode=auth_ad)')
        elif select == 1: return xbmc.executebuiltin('RunPlugin(plugin://plugin.video.seren/?action=authAllDebrid)')
        elif select == 2: return xbmc.executebuiltin('RunPlugin(plugin://plugin.video.umbrella/?action=ad_Authorize)')
        elif select == 3: return xbmc.executebuiltin('RunPlugin(plugin://plugin.video.fen/?mode=alldebrid.authenticate)')
        elif select == 4: return xbmc.executebuiltin('RunScript(script.module.myaccounts, action=alldebridAuth)')
        elif select == 5: return xbmc.executebuiltin('RunPlugin(plugin://script.module.resolveurl/?mode=reset_ad)')
        elif select == 6: return xbmc.executebuiltin('RunPlugin(plugin://plugin.video.fen/?mode=alldebrid.revoke_authentication)')
        elif select == 7: return xbmc.executebuiltin('RunScript(script.module.myaccounts, action=alldebridRevoke)')
        elif select == 8: return xbmc.executebuiltin('RunPlugin(plugin://plugin.video.umbrella/?action=ad_Revoke)')

        else:
            return

    def Link_Snappy():
        dp = xbmcgui.Dialog()
        select = dp.select('[COLOR orange]Link Snappy[/COLOR]',
                          ['[B][COLOR white]Authorize ResolveURL Link Snappy[/COLOR][/B]',
                           '[B][COLOR white]Revoke ResolveURL Link Snappy[/COLOR][/B]'])

        if select   == 0: return xbmc.executebuiltin('RunPlugin(plugin://script.module.resolveurl/?mode=auth_ls)')
        elif select == 1: return xbmc.executebuiltin('RunPlugin(plugin://script.module.resolveurl/?mode=reset_ls)')

        else:
            return

    def Debrid_Link():
        dp = xbmcgui.Dialog()
        select = dp.select('[COLOR orange]Debrid Link[/COLOR]',
                          ['[B][COLOR white]Authorize ResolveURL Debrid-Link.fr[/COLOR][/B]',
                           '[B][COLOR white]Revoke ResolveURL Debrid-Link.fr[/COLOR][/B]'])

        if select   == 0: return xbmc.executebuiltin('RunPlugin(plugin://script.module.resolveurl/?mode=auth_dl)')
        elif select == 1: return xbmc.executebuiltin('RunPlugin(plugin://script.module.resolveurl/?mode=reset_dl)')

        else:
            return

authorize.auth()


