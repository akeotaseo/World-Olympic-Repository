
import xbmc
from updatervar import *
from resources.lib.GUIcontrol import notify
from resources.lib.GUIcontrol.notify import get_notifyversion
from resources.lib.GUIcontrol.txt_updater import get_addonsrepos, get_xmlskin, get_players, get_set_setting, get_var
from resources.lib.GUIcontrol.txt_updater import get_addons_list_installation, get_delete_files, get_zip1, get_zip2, get_zip3, get_zip4, get_zip5
from resources.lib.GUIcontrol.txt_updater import get_pvr
from resources.lib.modules import addonsEnable
from resources.lib.modules import db, addonsEnable
from resources.lib.modules.addonsEnable import enable_addons

addons_list_installation_version = get_addons_list_installation()
notify_version       = get_notifyversion()
addons_repos_version = get_addonsrepos()
xmlskin_version      = get_xmlskin()
players_version      = get_players()
set_setting_version  = get_set_setting()
delete_files_version = get_delete_files()
var_version          = get_var()
zip1_version         = get_zip1()
zip2_version         = get_zip2()
zip3_version         = get_zip3()
zip4_version         = get_zip4()
zip5_version         = get_zip5()
pvr_version          = get_pvr()




def autoenable():
    if setting('autoenable') == 'true':
        addonsEnable.enable_addons()
        setting_set('autoenable','false')
        dialog.notification(Dialog_enable_on, Dialog_enable, icon_Build, sound=False)


def notifyT():
    if not setting('firstrunNotify')=='false':
        if notify_version > int(setting('notifyversion')):
            setting_set('notifyversion', str(notify_version))
            d=notify.notify()
            d.doModal()
            del d
            BG.create(Dialog_U8, Dialog_U6)
            xbmc.sleep(5000)
            BG.close()


def var():
    if var_version > int(setting('varversion')):
        BG.create(Dialog_U12, Dialog_U2)
        BG.update(5, Dialog_U12, Dialog_U2)
        xbmc.sleep(200)
        BG.update(15, Dialog_U12, Dialog_U3)
        xbmc.sleep(200)
        xbmc.executebuiltin(Var_startup)
        xbmc.sleep(1000)
        BG.update(25, Dialog_U12, Dialog_U3)
        xbmc.sleep(500)
        setting_set('varversion', str(var_version))
        BG.update(55, Dialog_U12, '[COLOR green]Var...[/COLOR]')
        xbmc.sleep(1000)
        BG.update(75, Dialog_U12, '[COLOR green]Var...[/COLOR]')
        xbmc.sleep(1000)
        BG.update(100, Dialog_U12, Dialog_U9)
        xbmc.sleep(1000)
        BG.close()


def delete():
    if delete_files_version > int(setting('deleteversion')):
        xbmc.executebuiltin(Delete_startup)
        BG.create(Dialog_U2, Dialog_U11)
        xbmc.sleep(3000)
        BG.update(33, Dialog_U2, Dialog_U11)
        xbmc.sleep(5000)
        BG.update(63, Dialog_U2, Dialog_U11)
        xbmc.sleep(7000)
        BG.update(100, Dialog_U2, Dialog_U10)
        xbmc.sleep(10000)
        xbmc.executebuiltin(del_startup)
        setting_set('deleteversion', str(delete_files_version))
        BG.update(100, Dialog_U12, Dialog_U2)
        xbmc.sleep(15000)
        BG.close()


def installation():
    if addons_list_installation_version > int(setting('installationversion')):
        xbmc.executebuiltin(Installation_startup)
        BG.create(Dialog_U12, Dialog_U6)
        xbmc.sleep(1000)
        BG.update(30, Dialog_U12, Dialog_U2)
        xbmc.sleep(2000)
        BG.update(50, Dialog_U12, 'Έλεγχος εγκατάστασης νέων πρόσθετων...')
        xbmc.sleep(4000)
        BG.update(70, Dialog_U12, 'Έλεγχος εγκατάστασης νέων πρόσθετων...')
        xbmc.sleep(6000)
        BG.update(85, Dialog_U1, 'Ο έλεγχος ολοκληρώθηκε...')
        xbmc.sleep(8000)
        xbmc.executebuiltin(install_startup)
        setting_set('installationversion', str(addons_list_installation_version))
        BG.update(100, Dialog_U12, Dialog_U2)
        xbmc.sleep(25000)
        BG.close()


def setsetting():
    if set_setting_version > int(setting('setsettingversion')):
        xbmc.executebuiltin(SetSetting_startup)
        xbmc.sleep(5000)
        xbmc.executebuiltin(set_setting_startup)
        xbmc.sleep(5000)
        setting_set('setsettingversion', str(set_setting_version))
        dialog.notification('[B][COLOR orange]Γίνεται έλεγχος![/COLOR][/B]', '[COLOR white]Παρακαλώ περιμένετε...[/COLOR]', icon_ok2, sound=False)
        xbmc.sleep(15000)


def players():
    if players_version > int(setting('playersversion')):
        BG.create(Dialog_U12, Dialog_Players)
        xbmc.sleep(200)
        BG.update(5, Dialog_U12, Dialog_Players)
        xbmc.sleep(200)
        BG.update(15, Dialog_U12, Dialog_Players)
        xbmc.executebuiltin(Players_startup)
        xbmc.sleep(1500)
        BG.update(25, Dialog_U12, Dialog_Players)
        xbmc.sleep(500)
        setting_set('playersversion', str(players_version))
        BG.update(55, Dialog_U12, Dialog_Players)
        xbmc.sleep(200)
        BG.update(75, Dialog_U12, Dialog_Players)
        xbmc.sleep(200)
        BG.update(100, Dialog_U12, Dialog_U9)
        xbmc.sleep(1000)
        BG.close()


def zip1():
    if zip1_version > int(setting('zip1version')):
        BG.create(Dialog_U12, Dialog_U2)
        BG.update(5, Dialog_U12, Dialog_U2)
        xbmc.sleep(200)
        BG.update(15, Dialog_U12, Dialog_U3)
        xbmc.sleep(200)
        xbmc.executebuiltin(Zip1_startup)
        xbmc.sleep(1000)
        BG.update(25, Dialog_U12, Dialog_U3)
        xbmc.sleep(500)
        setting_set('zip1version', str(zip1_version))
        BG.update(55, Dialog_U12, '[COLOR green]Zip1...[/COLOR]')
        xbmc.sleep(500)
        BG.update(75, Dialog_U12, '[COLOR green]Zip1...[/COLOR]')
        xbmc.sleep(500)
        BG.update(100, Dialog_U12, Dialog_U9)
        xbmc.sleep(1000)
        BG.close()


def zip2():
    if zip2_version > int(setting('zip2version')):
        BG.create(Dialog_U12, Dialog_U2)
        BG.update(5, Dialog_U12, Dialog_U2)
        xbmc.sleep(1000)
        BG.update(15, Dialog_U12, Dialog_U3)
        xbmc.sleep(1000)
        xbmc.executebuiltin(Zip2_startup)
        xbmc.sleep(1000)
        BG.update(25, Dialog_U12, Dialog_U3)
        xbmc.sleep(1000)
        setting_set('zip2version', str(zip2_version))
        BG.update(35, Dialog_U12, 'install addons')
        xbmc.sleep(1000)
        BG.update(45, Dialog_U12, 'install addons')
        xbmc.sleep(2000)
        BG.update(55, Dialog_U12, 'Παρακαλώ περιμένετε...')
        xbmc.sleep(2000)
        BG.update(65, Dialog_U12, 'Παρακαλώ περιμένετε...')
        xbmc.sleep(2000)
        BG.update(75, Dialog_U12, 'Παρακαλώ περιμένετε...')
        addonsEnable.enable_addons()
        xbmc.sleep(500)
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.stalker","enabled":false}}')
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.iptvsimple","enabled":false}}')
        BG.update(85, Dialog_U12, '[COLOR green]enable_addons...[/COLOR]')
        xbmc.sleep(3000)
        BG.update(100, Dialog_U12, Dialog_U9)
        xbmc.sleep(3000)
        dialog.notification('[B][COLOR orange]Γίνεται έλεγχος![/COLOR][/B]', '[COLOR white]Παρακαλώ περιμένετε...[/COLOR]', icon_ok2, sound=False)
        BG.close()

def zip3():
    if zip3_version > int(setting('zip3version')):
        BG.create(Dialog_U12, Dialog_U2)
        BG.update(5, Dialog_U12, Dialog_U2)
        xbmc.sleep(1000)
        BG.update(15, Dialog_U12, Dialog_U3)
        xbmc.sleep(1000)
        xbmc.executebuiltin(Zip3_startup)
        xbmc.sleep(1000)
        BG.update(25, Dialog_U12, Dialog_U3)
        xbmc.sleep(1000)
        setting_set('zip3version', str(zip3_version))
        BG.update(55, Dialog_U12, 'addon_data')
        xbmc.sleep(1000)
        BG.update(75, Dialog_U12, 'addon_data')
        xbmc.sleep(1000)
        BG.update(100, Dialog_U12, Dialog_U9)
        xbmc.sleep(1000)
        BG.close()


def zip4():
    if zip4_version > int(setting('zip4version')):
        BG.create(Dialog_U12, Dialog_U2)
        BG.update(5, Dialog_U12, Dialog_U2)
        xbmc.sleep(200)
        BG.update(15, Dialog_U12, Dialog_U3)
        xbmc.sleep(200)
        xbmc.executebuiltin(Zip4_startup)
        xbmc.sleep(1000)
        BG.update(25, Dialog_U12, Dialog_U3)
        xbmc.sleep(500)
        setting_set('zip4version', str(zip4_version))
        BG.update(55, Dialog_U12, Dialog_U3)
        xbmc.sleep(200)
        BG.update(75, Dialog_U12, Dialog_U3)
        xbmc.sleep(200)
        BG.update(100, Dialog_U12, Dialog_U9)
        xbmc.sleep(1000)
        BG.close()


def zip5():
    if zip5_version > int(setting('zip5version')):
        BG.create(Dialog_U12, Dialog_U2)
        BG.update(5, Dialog_U12, Dialog_U2)
        xbmc.sleep(200)
        BG.update(15, Dialog_U12, Dialog_U3)
        xbmc.sleep(200)
        xbmc.executebuiltin(Zip5_startup)
        xbmc.sleep(1000)
        BG.update(25, Dialog_U12, Dialog_U3)
        xbmc.sleep(500)
        setting_set('zip5version', str(zip5_version))
        BG.update(40, Dialog_U12, '[COLOR green]manually update addons...[/COLOR]')
        xbmc.sleep(1000)
        BG.update(50, Dialog_U12, '[COLOR lime]manually fix addons...[/COLOR]')
        xbmc.sleep(1000)
        BG.update(60, Dialog_U12, 'Παρακαλώ περιμένετε...')
        xbmc.sleep(500)
        BG.update(70, Dialog_U12, Dialog_U3)
        xbmc.sleep(200)
        BG.update(80, Dialog_U12, Dialog_U3)
        xbmc.sleep(200)
        BG.update(100, Dialog_U12, Dialog_U9)
        xbmc.sleep(1000)
        BG.close()


def pvr():
    if pvr_version > int(setting('pvrversion')):
        BG.create(Dialog_U12, Dialog_U2)
        BG.update(5, Dialog_U12, Dialog_U2)
        xbmc.sleep(1000)
        BG.update(15, Dialog_U12, Dialog_U3)
        xbmc.sleep(1000)
        xbmc.executebuiltin(Pvr_startup)
        xbmc.sleep(1000)
        BG.update(25, Dialog_U12,'IPTV Simple Client')
        xbmc.sleep(1000)
        BG.update(35, Dialog_U12,'Stalker Client')
        xbmc.sleep(1000)
        BG.update(45, Dialog_U12,'mac_list')
        xbmc.sleep(1000)
        setting_set('pvrversion', str(pvr_version))
        BG.update(50, Dialog_U12, Dialog_U3)
        xbmc.sleep(1000)
        BG.update(60, Dialog_U12, 'Παρακαλώ περιμένετε...')
        xbmc.sleep(2000)
        BG.update(70, Dialog_U12, 'Παρακαλώ περιμένετε...')
        xbmc.sleep(2000)
        BG.update(80, Dialog_U12, 'Παρακαλώ περιμένετε...')
        xbmc.sleep(2000)
        BG.update(90, Dialog_U12, 'Παρακαλώ περιμένετε...')
        # addonsEnable.enable_addons()
        # xbmc.sleep(2000)
        # xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.stalker","enabled":false}}')
        # xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.iptvsimple","enabled":false}}')
        # BG.update(95, Dialog_U12, '[COLOR green]enable_addons...[/COLOR]')
        xbmc.sleep(2000)
        BG.update(100, Dialog_U12, Dialog_U9)
        xbmc.sleep(1000)
        BG.close()


def database():
    if addons_repos_version > int(setting('addonsreposversion')):
        xbmc.executebuiltin(AddonsRepos_startup)
        BG.create(Dialog_U6, Dialog_Database)
        xbmc.sleep(4000)
        BG.update(33, Dialog_U6, Dialog_Database)
        xbmc.sleep(4000)
        BG.update(63, Dialog_U12, Dialog_Database)
        xbmc.sleep(4000)
        BG.update(76, Dialog_U12, Dialog_Database)
        xbmc.sleep(4000)
        xbmc.executebuiltin(database_startup)
        xbmc.sleep(5000)
        addonsEnable.enable_addons()
        xbmc.sleep(500)
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.stalker","enabled":false}}')
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.iptvsimple","enabled":false}}')
        setting_set('addonsreposversion', str(addons_repos_version))
        BG.update(85, Dialog_U12, '[COLOR lime]enable_addons...[/COLOR]')
        xbmc.sleep(5000)
        BG.update(100, Dialog_U12, Dialog_U9)
        xbmc.sleep(5000)
        dialog.notification('[B][COLOR orange]Γίνεται έλεγχος![/COLOR][/B]', '[COLOR white]Παρακαλώ περιμένετε...[/COLOR]', icon_ok2, sound=False)
        BG.close()







def xmlskin():
    if not setting('xmlskinversion') == 'false':
        if xmlskin_version > int(setting('xmlskinversion')):
            BG.create(Dialog_U12, Dialog_Xml_Skin)
            BG.update(5, Dialog_U12, Dialog_Xml_Skin)
            xbmc.sleep(200)
            BG.update(15, Dialog_U12, Dialog_Xml_Skin)
            xbmc.sleep(200)
            xbmc.executebuiltin(XmlSkin_startup)
            xbmc.sleep(1000)
            BG.update(25, Dialog_U12, Dialog_Xml_Skin)
            xbmc.sleep(500)
            setting_set('xmlskinversion', str(xmlskin_version))
            BG.update(55, Dialog_U12, Dialog_Xml_Skin)
            xbmc.sleep(200)
            BG.update(75, Dialog_U12, Dialog_Xml_Skin)
            xbmc.sleep(200)
            BG.update(80, Dialog_U12, Dialog_U9)
            xbmc.sleep(1000)
            BG.update(90, Dialog_U1, 'Ενημέρωση μενού skin.')
            xbmc.sleep(5000)
            BG.update(95, Dialog_U4, 'Θα ακολουθήσει... επαναφόρτωση του προφίλ')
            xbmc.sleep(3000)
            BG.update(100, Dialog_U4, 'Θα ακολουθήσει... και πάγωμα της εικόνας')
            dialog.notification('[B][COLOR orange]Reload Profile[/COLOR][/B]', '[COLOR white]Παρακαλώ περιμένετε...[/COLOR]', icon_reloadprofile, sound=False)
            xbmc.sleep(4000)
            xbmc.executebuiltin("LoadProfile(Master user)")
            BG.close()
            xbmc.sleep(12000)





def UpdateAddonRepos():
        #xbmc.executebuiltin('PlayMedia("special://home/media/Bamako.mp4")')
        # xbmc.executebuiltin('PlayMedia("special://home/media/Join_file.mp4")')
        # xbmc.sleep(12000)
        # xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"general.addonupdates","value":0}}')

        xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloader19/addonupdatesprog.py")')



#        xbmc.executebuiltin('UpdateLocalAddons()')
#        xbmc.sleep(4000)
#        xbmc.executebuiltin('UpdateAddonRepos()')