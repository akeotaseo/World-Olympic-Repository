﻿import os
import json
import xbmc
import xbmcgui
import xbmcvfs

dialog = xbmcgui.Dialog()
PROFILE_DIR = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.program.downloader19/')
BACKUP_FILE = os.path.join(PROFILE_DIR, 'widgets_backup.json')

WIDGET_KEYS = [f"HomeItem.{i}.Widget" for i in range(1, 17)] + [f"HomeItem.{i}.Widget.2" for i in range(1, 17)]

def backup_and_disable_widgets(keep_weather=True, do_reload=True):
    if not os.path.exists(PROFILE_DIR):
        os.makedirs(PROFILE_DIR)
        
    saved_widgets = {}
    for key in WIDGET_KEYS:
        val = xbmc.getInfoLabel(f"Skin.String({key})").strip()
        if val and val.lower() != "none":
            if keep_weather and "weather" in val.lower():
                continue
            saved_widgets[key] = val
            xbmc.executebuiltin(f"Skin.SetString({key}, None)")
            
    # Ενημερώνουμε το backup ΜΟΝΟ αν βρήκαμε ενεργά widgets (ποτέ με άδεια λίστα)
    if saved_widgets:
        try:
            with open(BACKUP_FILE, 'w', encoding='utf-8') as f:
                json.dump(saved_widgets, f, ensure_ascii=False, indent=2)
        except:
            pass
            
    xbmc.executebuiltin('Skin.SetString(CustomWidgets,0)')
    if do_reload:
        xbmc.executebuiltin("ReloadSkin()")

def restore_widgets(do_reload=True):
    if not os.path.exists(BACKUP_FILE):
        return False
    try:
        with open(BACKUP_FILE, 'r', encoding='utf-8') as f:
            saved_widgets = json.load(f)
            
        changed = False
        for key, val in saved_widgets.items():
            if val:
                current = xbmc.getInfoLabel(f"Skin.String({key})").strip()
                if current != val:
                    xbmc.executebuiltin(f"Skin.SetString({key}, {val})")
                    changed = True
                    
        if xbmc.getInfoLabel("Skin.String(CustomWidgets)") != "100":
            xbmc.executebuiltin('Skin.SetString(CustomWidgets,100)')
            changed = True
            
        # Κάνουμε ReloadSkin ΜΟΝΟ αν όντως επαναφέραμε widgets (όχι 2η φορά)
        if do_reload and changed:
            xbmc.executebuiltin("ReloadSkin()")
        return True
    except:
        return False

def World_widget_OnOff():
    widget_list = [
        'World - [COLOR red]No[/COLOR] Widgets (Απενεργοποίηση)',
        'World - [COLOR green]Yes[/COLOR] Widgets (Επαναφορά)'
    ]
    select = dialog.select('World Widget On / Off', widget_list)
    if select == -1 or select is None:
        return
        
    if select == 0:
        backup_and_disable_widgets(keep_weather=True, do_reload=True)
        dialog.notification("World Skin", "Τα Widgets απενεργοποιήθηκαν (κρατήθηκε ο Καιρός).", xbmcgui.NOTIFICATION_INFO, 2500)
    elif select == 1:
        ok = restore_widgets(do_reload=True)
        if ok:
            dialog.notification("World Skin", "Τα Widgets επαναφέρθηκαν!", xbmcgui.NOTIFICATION_INFO, 2500)
        else:
            dialog.notification("World Skin", "Δεν βρέθηκε αποθηκευμένο backup widgets.", xbmcgui.NOTIFICATION_WARNING, 2500)

if __name__ == '__main__':
    World_widget_OnOff()
