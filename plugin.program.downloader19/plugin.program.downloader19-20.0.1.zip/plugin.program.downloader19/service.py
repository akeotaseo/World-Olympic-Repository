﻿# -*- coding: utf-8 -*-
import xbmc, xbmcgui
from updatervar import *
from resources.lib.modules import check


if __name__ == '__main__':
    if not setting('updaterversion') == 'false':
        dialog.notification(Dialog_welcome, Dialog_Update, icon_Build, sound=False)
        check.notifyT()
        check.autoenable()
        check.var()
        check.updater()
        check.delete()
        check.players()
        check.zip1()
        check.zip2()
        check.zip3()
        check.zip4()
        check.zip5()
        check.installation()
        check.setsetting()
        check.database()
        check.UpdateAddonRepos()
        check.xmlskin()


    else:
        dialog.notification(Dialog_welcome, Dialog_not_Updater, icon_Build, sound=False)
        check.UpdateAddonRepos()
    xbmc.sleep(5000)
    dialog.notification('Check Updates', 'Ελεγχος για ενημερώσεις προσθέτων', icon_auto2, sound=False)


    
    monitor = xbmc.Monitor()

    while not monitor.abortRequested():
        if monitor.waitForAbort(2*60*60):#διάστημα 2ωρών μεταξύ των ενημερώσεων
            break
        xbmc.executebuiltin('UpdateAddonRepos()')
        dialog.notification('Υπηρεσία ενημέρωσης', 'Εκκίνηση ενημερώσεων προσθέτων', icon_auto, sound=False)
