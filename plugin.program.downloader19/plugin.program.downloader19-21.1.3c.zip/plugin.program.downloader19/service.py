﻿import xbmc, xbmcgui, xbmcvfs, sys, json, os, re, glob, shutil, xbmcaddon, urllib.request

# 🛑 ΤΟ ΑΚΑΡΙΑΙΟ ΜΠΛΟΚΑΡΙΣΜΑ ΣΟΥ (ΠΑΝΩ-ΠΑΝΩ):
if xbmc.getCondVisibility('Window.IsActive(10040)') or xbmc.getCondVisibility('Window.IsActive(2139)') or xbmc.getCondVisibility('Window.IsActive(progressdialog)') or xbmc.getCondVisibility('Window.IsActive(notification)'):
	xbmc.log("[World_Updater] Εντοπίστηκε ανοιχτό παράθυρο ή ειδοποίηση στην εκκίνηση. Ακαριαίο μπλοκάρισμα.", xbmc.LOGINFO)
	xbmc.executebuiltin('ActivateWindow(10040,"addons://outdated/")')
	import sys
	sys.exit()


# 🛡️ THE GLOBAL DYNAMIC BOOT SHIELD (Η ΠΡΟΣΤΑΣΙΑ ΣΟΥ)
monitor = xbmc.Monitor()
boot_timeout = 30
elapsed_time = 0

while not xbmc.getCondVisibility('Window.IsVisible(home)') and elapsed_time < boot_timeout and not monitor.abortRequested():
	xbmc.sleep(500)
	elapsed_time += 0.5

xbmc.log(f"[World_Updater] Η αρχική οθόνη φορτώθηκε σε {elapsed_time}s. Έναρξη Updater...", xbmc.LOGINFO)


# 🟢 [ΔΙΚΛΕΙΔΑ ΑΣΦΑΛΕΙΑΣ]: Ακαριαίος καθαρισμός παλιών locks και της σημαίας
profile_dir = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.program.downloader19')
addons_dir = xbmcvfs.translatePath('special://home/addons/plugin.program.downloader19')

# 1. Καθαρισμός locks στο userdata/addon_data
lock_files = ['delete_lock.txt', 'database_lock.txt', 'install_lock.txt']
for lock_name in lock_files:
	full_lock_path = os.path.join(profile_dir, lock_name)
	if os.path.exists(full_lock_path):
		try:
			os.remove(full_lock_path)
			xbmc.log(f"[World_Updater] [Δικλείδα Ασφαλείας] Το παλό αρχείο {lock_name} σβήστηκε επιτυχώς.", xbmc.LOGINFO)
		except:
			pass

# 🛑 ΑΦΑΙΡΕΘΗΚΕ Ο ΚΑΘΑΡΙΣΜΟΣ ΤΟΥ check_build_updates.py ΑΠΟ ΕΔΩ ΓΙΑ ΝΑ ΜΗΝ ΤΟ ΣΒΗΝΕΙ ΤΟ ANDROID!

# 🧼 3. ΚΑΘΑΡΙΣΜΟΣ ΣΗΜΑΙΑΣ: Την αφήνουμε κανονικά για ασφάλεια από κρασαρίσματα
old_trigger = os.path.join(addons_dir, 'build_update_trigger.txt')
if os.path.exists(old_trigger):
	try: os.remove(old_trigger)
	except: pass



def disable_screensaver():
	""" 🔒 ΑΠΕΝΕΡΓΟΠΟΙΗΣΗ SCREENSAVER ΓΙΑ ΠΡΟΣΤΑΣΙΑ ΤΩΝ BACKGROUND UPDATES """
	try:
		profile_dir = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.program.downloader19')
		if not os.path.exists(profile_dir):
			os.makedirs(profile_dir)

		backup_file = os.path.join(profile_dir, 'screensaver_backup.txt')

		req_get = '{"jsonrpc":"2.0","method":"Settings.GetSettingValue","params":{"setting":"screensaver.mode"},"id":1}'
		res_get = json.loads(xbmc.executeJSONRPC(req_get))
		current_ss = res_get['result']['value']
		
		if not os.path.exists(backup_file):
			with open(backup_file, 'w', encoding='utf-8') as f:
				f.write(current_ss)
				
		xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"screensaver.mode","value":""},"id":1}')
		xbmc.log(f"[World_Updater] Ο screensaver απενεργοποιήθηκε στην έναρξη. Backup: {current_ss}", xbmc.LOGINFO)
	except Exception as e:
		xbmc.log(f"[World_Updater] Αποτυχία διαχείρισης screensaver στο service: {str(e)}", xbmc.LOGERROR)

disable_screensaver()


# PVR Κλείσιμο στην εκκίνηση
xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.stalker","enabled":false}}')
xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.iptvsimple","enabled":false}}')
xbmc.sleep(200)

# ANY REPOSITORIES UPDATE MODE
xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"addons.updatemode","value":1}}')
xbmc.sleep(200)
# NOTIFY, BUT DON'T INSTALL UPDATES
xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"general.addonupdates","value":1}}')

xbmc.sleep(200) 
xbmcgui.Dialog().notification("[B][COLOR orange]...[/COLOR][/B]", "   ", sound=False, icon='special://home/addons/plugin.program.downloader19/resources/media/autoexec.png')
xbmc.sleep(2000)
xbmc.executebuiltin('RunScript("special://home/addons/skin.19MatrixWorld/xml/_get_ip.py")')
xbmc.sleep(3000) 
xbmcgui.Dialog().notification("[COLOR white]Έναρξη World Updater...[/COLOR]", "[B][COLOR orange]Καλώς ήρθατε![/COLOR][/B]", sound=False, icon='special://home/addons/plugin.program.downloader19/resources/media/World.png')

from resources.lib.modules import check
from updatervar import *

if __name__ == '__main__':
	if setting('notifyversion') == '0':
		xbmcgui.Dialog().ok('[B][COLOR blue]Πρώτη Εγκατάσταση[/COLOR][/B]', 'Περιμένετε να ολοκληρωθούν [COLOR lime]οι ενημερώσεις των Προσθέτων[/COLOR][CR]και η Εγκατάσταση των [B]binary add-ons[/B].')
		check.notifyT()
		xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"general.addonupdates","value":0}}')
		xbmc.sleep(1000)
		xbmc.executebuiltin('UpdateAddonRepos()')
		xbmc.executebuiltin('UpdateLocalAddons()')
		xbmc.executebuiltin('ActivateWindow(AddonBrowser)')
	else:
		# 🚀 1. Εκτελείται ο έλεγχος της συνάρτησής σου για το Build Update (Zip1)
		check.zip1()
		
		# Ορίζουμε τα paths για το script και την έξυπνη σημαία .txt
		external_script = xbmcvfs.translatePath('special://home/addons/plugin.program.downloader19/check_build_updates.py')
		update_trigger = xbmcvfs.translatePath('special://home/addons/plugin.program.downloader19/build_update_trigger.txt')
		
		# 1️⃣ ΠΕΡΙΠΤΩΣΗ: Υπάρχει νέα έκδοση ολόκληρου του Build (Ανιχνεύτηκε η σημαία .txt)
		if os.path.exists(update_trigger):
			xbmc.log("[World_Updater] Η σημαία build_update_trigger.txt ανιχνεύτηκε! Έναρξη Dynamic Waiter για το Android...", xbmc.LOGINFO)
			
			# 🧼 Σβήνουμε αμέσως το .txt για να μην ξαναμπει σε loop
			try: os.remove(update_trigger)
			except: pass
			
			# 🔔 Notification για να γεμίσει το χρονικό κενό render της οθόνης
			xbmcgui.Dialog().notification('[B][COLOR orange]Γίνεται έλεγχος![/COLOR][/B]', '[COLOR white]Παρακαλώ περιμένετε...[/COLOR]', icon_ok2, sound=False)
			
			# ⏱️ 🎯 DYNAMIC FILE WAITER (ANDROID REVOLUTION):
			# Περιμένει dynamic μέχρι να γραφτεί το .py αρχείο στο δίσκο, με μέγιστο όριο (timeout) τα 8 δευτερόλεπτα.
			file_timeout = 8.0
			file_elapsed = 0.0
			while not os.path.exists(external_script) and file_elapsed < file_timeout and not monitor.abortRequested():
				xbmc.sleep(200)
				file_elapsed += 0.2
			
			# Μόλις εμφανιστεί το αρχείο, δίνουμε ένα μικρό «φρένο» 1 δευτερολέπτου για να κλείσει το I/O stream του Android
			if os.path.exists(external_script):
				xbmc.sleep(1000)
				xbmc.log(f"[World_Updater] Το check_build_updates.py βρέθηκε έτοιμο σε {file_elapsed}s. Εκτέλεση RunScript...", xbmc.LOGINFO)
				xbmc.executebuiltin(f'RunScript("{external_script}")')
			else:
				xbmc.log("[World_Updater] Κρίσιμο Σφάλμα: Το check_build_updates.py δεν εμφανίστηκε ποτέ στο Android (Timeout).", xbmc.LOGERROR)

		# 2️⃣ ΠΕΡΙΠΤΩΣΗ: Το Build είναι ήδη ενημερωμένο
		elif not setting('updaterversion') == 'false':
			xbmc.log("[World_Updater] Το Build είναι ενημερωμένο. Έναρξη καθημερινού ελέγχου μέσω της check.UpdateAddonRepos()...", xbmc.LOGINFO)
			xbmc.sleep(200)
			check.UpdateAddonRepos()
			
		# 3️⃣ ΠΕΡΙΠΤΩΣΗ: Ο χρήστης έχει επιλέξει "Απενεργοποίηση"
		else:
			xbmc.log("[World_Updater] Οι αυτόματες ενημερώσεις έχουν απενεργοποιηθεί από τον χρήστη. Ακαριαίο bypass.", xbmc.LOGINFO)
			xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"general.addonupdates","value":0}}')
			xbmc.sleep(500)
			xbmc.executebuiltin('UpdateLocalAddons()')
			xbmc.executebuiltin('UpdateAddonRepos()')


	##Tk & GKoBu & TRAILER MONITOR MULTI-MERGE LAYER ______________________________________
	monitor = xbmc.Monitor()
	update_interval = 2 * 60 * 60
	time_counter = 0

	while not monitor.abortRequested():
		if xbmc.getCondVisibility('Window.IsVisible(home)') and not xbmc.getCondVisibility('Window.IsVisible(6199)'):
			if xbmc.getInfoLabel('Skin.String(TrailerCheckID)') != '':
				xbmc.executebuiltin('Skin.ResetString(HubFromWidget)')
				xbmc.executebuiltin('Skin.ResetString(TrailerCheckID)')
				xbmc.executebuiltin('Skin.ResetString(HubMovieTitle)')
				xbmc.executebuiltin('Skin.ResetString(HubMoviePlot)')
				xbmc.executebuiltin('Skin.ResetString(HubMovieCast)')
				xbmc.executebuiltin('Skin.ResetString(HubMovieDirector)')
				xbmc.executebuiltin('Skin.ResetString(HubMovieWriter)')
				xbmc.executebuiltin('Skin.ResetString(HubMovieGenre)')
				xbmc.executebuiltin('Skin.ResetString(HubMovieYear)')
				xbmc.executebuiltin('Skin.ResetString(HubMovieRating)')
				xbmc.executebuiltin('Skin.ResetString(HubMovieStudio)')
				xbmc.executebuiltin('Skin.ResetString(HubMovieCountry)')
				xbmc.executebuiltin('Skin.ResetString(HubMoviePoster)')
				xbmc.executebuiltin('Skin.ResetString(HubMovieFanart)')
				xbmc.executebuiltin('Skin.ResetString(HubMovieTagLine)')
				xbmc.executebuiltin('Skin.ResetString(HubMovieDuration)')
				xbmc.executebuiltin('Skin.ResetString(HubMovieEndTime)')

		time_counter += 0.1 
		if time_counter >= update_interval:
			time_counter = 0 
			xbmc.executebuiltin('UpdateAddonRepos()')

		if monitor.waitForAbort(0.1):
			break
