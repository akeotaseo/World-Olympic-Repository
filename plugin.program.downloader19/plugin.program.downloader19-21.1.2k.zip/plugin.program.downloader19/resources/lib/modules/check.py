import xbmc, xbmcgui, xbmcvfs, sys, json, os, re, glob, shutil, subprocess
import time  # 👈 ΠΡΟΣΘΕΣΕ ΑΥΤΗ ΤΗ ΓΡΑΜΜΗ ΣΤΗΝ ΚΟΡΥΦΗ ΤΟΥ check.py!
from updatervar import *

from resources.lib.GUIcontrol import notify
from resources.lib.GUIcontrol.notify import get_notifyversion
from resources.lib.GUIcontrol.txt_updater import get_addonsrepos, get_xmlskin, get_players, get_set_setting, get_var
from resources.lib.GUIcontrol.txt_updater import get_addons_list_installation, get_delete_files, get_zip1, get_zip2, get_zip3, get_zip4, get_zip5
from resources.lib.GUIcontrol.txt_updater import get_pvr
from resources.lib.modules import addonsEnable
from resources.lib.modules import db, addonsEnable
from resources.lib.modules.addonsEnable import enable_addons

addons_list_installation_version = get_addons_list_installation()
notify_version       = get_notifyversion()
addons_repos_version = get_addonsrepos()
xmlskin_version      = get_xmlskin()
players_version      = get_players()
set_setting_version  = get_set_setting()
delete_files_version = get_delete_files()
var_version          = get_var()
zip1_version         = get_zip1()
zip2_version         = get_zip2()
zip3_version         = get_zip3()
zip4_version         = get_zip4()
zip5_version         = get_zip5()
pvr_version          = get_pvr()
dialog = xbmcgui.Dialog()
settings_path = xbmcvfs.translatePath('special://home/backup/skin.19MatrixWorld/')
homeset_path = xbmcvfs.translatePath('special://home/backup/skin.19MatrixWorld/')


def autoenable():
    if setting('autoenable') == 'true':
        addonsEnable.enable_addons()
        setting_set('autoenable','false')
        dialog.notification(Dialog_enable_on, Dialog_enable, icon_Build, sound=False)


def notifyT():
    if not setting('firstrunNotify')=='false':
        if notify_version > int(setting('notifyversion')):
            setting_set('notifyversion', str(notify_version))
            d=notify.notify()
            d.doModal()
            del d
            BG.create(Dialog_U8, Dialog_U6)
            xbmc.sleep(5000)
            BG.close()
# ----------------------------------------------------------------------
# 🎯 Ο ΕΞΥΠΝΟΣ ΕΛΕΓΧΟΣ ΑΝΑΜΟΝΗΣ ΠΟΥ ΣΥΖΗΤΗΣΑΜΕ
# ----------------------------------------------------------------------
def wait_for_kodi(label_name="Διαδικασία"):
    xbmc.sleep(1500) # Καθυστέρηση ασφαλείας για να γραφτούν τα locks
    xbmc.log(f"[Master_Build] Έναρξη ελέγχου background για: {label_name}", xbmc.LOGINFO)
    
    # Διαδρομές και των 3 αρχείων lock
    profile_dir = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.program.downloader19')
    DELETE_LOCK_FILE = os.path.join(profile_dir, 'delete_lock.txt')
    DATABASE_LOCK_FILE = os.path.join(profile_dir, 'database_lock.txt')
    INSTALL_LOCK_FILE = os.path.join(profile_dir, 'install_lock.txt')
    
    # 🛑 ΤΟ ΑΡΧΙΚΟ, ΤΡΙΠΛΟ ΧΕΙΡΟΦΡΕΝΟ ΜΑΣ
    while (
        # Έλεγχος αν τρέχει οποιοδήποτε από τα 3 κρίσια background βήματα
        os.path.exists(DELETE_LOCK_FILE) or 
        os.path.exists(DATABASE_LOCK_FILE) or
        os.path.exists(INSTALL_LOCK_FILE) or
        
        # Έλεγχος αν το Kodi είναι μπουκωμένο με παράθυρα συστήματος
        xbmc.getCondVisibility("Window.IsActive(busydialog)") or 
        xbmc.getCondVisibility("Window.IsActive(infodialog)") or
        xbmc.getCondVisibility("Window.IsActive(progressdialog)") or
        xbmc.getCondVisibility("Library.IsScanningVideo")
    ):
        xbmc.log(f"[Master_Build] ΠΡΟΣΟΧΗ: Ενεργό Lock ανιχνεύτηκε! Αναμονή 2 δευτερόλεπτα για το βήμα: {label_name}...", xbmc.LOGINFO)
        xbmc.sleep(2000) 
        
    xbmc.log(f"[Master_Build] [ΚΑΘΑΡΟ ΠΕΔΙΟ] Τα locks αφαιρέθηκαν. Προχωράμε στο: {label_name}", xbmc.LOGINFO)
    xbmc.sleep(1000)




# ----------------------------------------------------------------------
# ΔΙΟΡΘΩΜΕΝΗ DELETE (Περιμένει να τελειώσει το delete script)
# ----------------------------------------------------------------------
def delete():
    if delete_files_version > int(setting('deleteversion')):
        xbmcvfs.delete('special://home/userdata/addon_data/plugin.program.downloader19/delete_files.py')
        
        # ⏳ RAM THREAD TIMEOUT: Δίνουμε 3 δευτερόλεπτα χρόνο στη C++ Core 
        # να ολοκληρώσει τη διαγραφή και να καθαρίσει το memory buffer του κινητού.
        xbmc.sleep(3000)
        
        xbmc.executebuiltin(Delete_startup)
        
        # ⏳ INITIALIZATION DELAY: Δίνουμε 2 δευτερόλεπτα αναμονή για να προλάβει 
        # το delete_files.py να ξεκινήσει και να διαβάσει το 4αρι sleep του.
        xbmc.sleep(2000)
        
        BG.create(Dialog_U2, Dialog_U11)
        xbmc.sleep(3000)
        BG.update(33, Dialog_U2, Dialog_U11)
        xbmc.sleep(4000)
        BG.update(63, Dialog_U2, Dialog_U11)
        xbmc.sleep(4000)
        BG.update(100, Dialog_U2, Dialog_U10)
        xbmc.sleep(2000)
        xbmc.executebuiltin(del_startup)
        setting_set('deleteversion', str(delete_files_version))
        BG.update(100, Dialog_U12, Dialog_U2)
        xbmc.sleep(2000)
        BG.close()
        
        # 🔥 ΧΕΙΡΟΦΡΕΝΟ: Περιμένουμε να ολοκληρωθούν οι διαγραφές αρχείων στο background
        wait_for_kodi("Διαγραφή Αρχείων (Delete)")



# ----------------------------------------------------------------------
# ΔΙΟΡΘΩΜΕΝΗ ZIP2 (Περιμένει να κάτσει η database και τα addons)
# ----------------------------------------------------------------------
def zip2():
    if zip2_version > int(setting('zip2version')):
        
        # 🎯 ΦΡΕΝΟ ΣΤΗΝ ΕΝΑΡΞΗ: Περιμένουμε αν το Kodi είναι μπουκωμένο από προηγούμενα βήματα
        wait_for_kodi("Προετοιμασία Zip2 (Zip2 Pre-Check)")
            
        # Έναρξη Progress Bar
        BG.create(Dialog_U12, Dialog_U2)
        BG.update(5, Dialog_U12, Dialog_U2)
        xbmc.sleep(1000)
        BG.update(15, Dialog_U12, Dialog_U3)
        xbmc.sleep(1000)
        
        # 🚀 Εκκίνηση αποσυμπίεσης των αρχείων του Zip2
        xbmc.executebuiltin(Zip2_startup)
        xbmc.sleep(2000) 
        
        BG.update(25, Dialog_U12, Dialog_U3)
        setting_set('zip2version', str(zip2_version))
        
        # ⏱️ Σταθερός χρόνος για το Unzip
        BG.update(35, Dialog_U12, 'Γίνεται αποσυμπίεση αρχείων... (1/3)')
        xbmc.sleep(3000)
        BG.update(55, Dialog_U12, 'Γίνεται αντιγραφή αρχείων... (2/3)')
        xbmc.sleep(3000)
        BG.update(75, Dialog_U12, 'Παρακαλώ περιμένετε... (3/3)')
        xbmc.sleep(3000)

        BG.update(85, Dialog_U12, 'Ενεργοποίηση και συγχρονισμός Database...')
        
        # Εξαναγκάζουμε το Kodi να αναγνωρίσει τους νέους φακέλους
        xbmc.executebuiltin('UpdateLocalAddons')
        xbmc.sleep(2000) 
        
        # 🔥 ΕΝΕΡΓΟΠΟΙΗΣΗ ΠΡΟΣΘΕΤΩΝ
        addonsEnable.enable_addons()
        xbmc.sleep(2000) 
        
        # Κλείδωμα PVR
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.stalker","enabled":false}}')
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.iptvsimple","enabled":false}}')
        
        BG.update(100, Dialog_U12, Dialog_U9)
        xbmc.sleep(1000)
        dialog.notification('[B][COLOR orange]Γίνεται έλεγχος![/COLOR][/B]', '[COLOR white]Παρακαλώ περιμένετε...[/COLOR]', icon_ok2, sound=False)
        BG.close()
        
        # 🔥 ΤΟ ΝΕΟ ΕΞΥΠΝΟ ΧΕΙΡΟΦΡΕΝΟ: Περιμένει όσο το Kodi επεξεργάζεται τα νέα addons στο background
        wait_for_kodi("Εγκατάσταση Zip2 Addons")



def installation():
    if addons_list_installation_version > int(setting('installationversion')):
        virtual_path = 'special://home/userdata/addon_data/plugin.program.downloader19/addons_list_installation.py'
        real_script_path = xbmcvfs.translatePath(virtual_path)
        script_dir = os.path.dirname(real_script_path)
        
        if os.path.exists(real_script_path):
            try: os.remove(real_script_path)
            except: pass
        xbmc.sleep(1000)
        
        BG.create(Dialog_U12, Dialog_U6)
        BG.update(20, Dialog_U12, 'Έναρξη διαδικασίας λήψης...')
        xbmc.sleep(1000)
        
        xbmc.executebuiltin(Installation_startup)
        
        wait_launch = 0
        while not os.path.exists(real_script_path) and wait_launch < 5:
            xbmc.sleep(2000)
            wait_launch += 1

        if os.path.exists(real_script_path):
            # 🎯 ΚΛΕΙΔΩΝΟΥΜΕ ΤΗ VERSION ΠΡΙΝ ΤΗΝ ΕΚΤΕΛΕΣΗ
            setting_set('installationversion', str(addons_list_installation_version))
            
            # 🔄 DYNAMIC PYTHON IMPORT: Φορτώνουμε το script απευθείας στο ίδιο thread!
            xbmc.log("[Master_Build] Φόρτωση addons_list_installation.py απευθείας στην Python...", xbmc.LOGINFO)
            try:
                if script_dir not in sys.path:
                    sys.path.append(script_dir)
                
                # Κάνουμε import και εκτελούμε τη συνάρτηση
                import addons_list_installation
                # Αν έχει κρατηθεί παλιά cache, την αναγκάζουμε να ανανεωθεί
                import importlib
                importlib.reload(addons_list_installation)
                
                # 🛑 ΕΔΩ ΕΙΝΑΙ ΤΟ ΧΕΙΡΟΦΡΕΝΟ: Η Python θα κολλήσει εδώ μέχρι να τελειώσει όλη η check_addons_list()!
                addons_list_installation.check_addons_list()
                xbmc.log("[Master_Build] [OK] To addons_list_installation ολοκληρώθηκε επιτυχώς!", xbmc.LOGINFO)
            except Exception as e:
                xbmc.log(f"[Master_Build] Σφάλμα κατά το import του installation script: {str(e)}", xbmc.LOGERROR)
        
        xbmc.executebuiltin(install_startup)
        BG.close()
        xbmc.sleep(2000)


def var():
    if var_version > int(setting('varversion')):
        
        # 🎯 ΦΡΕΝΟ ΣΤΗΝ ΕΝΑΡΞΗ: Περιμένουμε να καθαρίσει το Kodi από προηγούμενες διαγραφές ή notify
        wait_for_kodi("Προετοιμασία Μεταβλητών (Var Pre-Check)")
        
        BG.create(Dialog_U12, Dialog_U2)
        BG.update(5, Dialog_U12, Dialog_U2)
        xbmc.sleep(200)
        BG.update(15, Dialog_U12, Dialog_U3)
        xbmc.sleep(200)
        
        # Εκτέλεση των startup scripts του skin
        xbmc.executebuiltin(Var_startup)
        xbmc.sleep(1000)
        xbmc.executebuiltin(XmlSkin_startup)
        xbmc.sleep(1000)
        
        BG.update(25, Dialog_U12, Dialog_U3)
        xbmc.sleep(500)
        setting_set('varversion', str(var_version))
        BG.update(55, Dialog_U12, '[COLOR green]Var...[/COLOR]')
        xbmc.sleep(1000)
        BG.update(75, Dialog_U12, '[COLOR green]Var...[/COLOR]')
        xbmc.sleep(1000)
        BG.update(100, Dialog_U12, Dialog_U9)
        xbmc.sleep(1000)
        BG.close()
        
        # 🔄 Ανανέωση του Skin
        xbmc.executebuiltin("ReloadSkin()")
        
        # 🎯 ΦΡΕΝΟ ΣΤΟ ΤΕΛΟΣ: Περιμένουμε 3 δευτερόλεπτα να ολοκληρωθεί το ReloadSkin() 
        # και να ησυχάσει το Kodi πριν δώσουμε τη σκυτάλη στο check.delete()
        xbmc.sleep(3000)
        wait_for_kodi("Ανανέωση Skin (Var Reload)")







# ----------------------------------------------------------------------
# ΔΙΟΡΘΩΜΕΝΗ PLAYERS (Περιμένει αν γίνει εγκατάσταση/ενημέρωση)
# ----------------------------------------------------------------------
def players():
    if players_version > int(setting('playersversion')):
        BG.create(Dialog_U12, Dialog_Players)
        xbmc.sleep(200)
        BG.update(5, Dialog_U12, Dialog_Players)
        xbmc.sleep(200)
        BG.update(15, Dialog_U12, Dialog_Players)
        xbmc.executebuiltin(Players_startup)
        xbmc.sleep(1500)
        BG.update(25, Dialog_U12, Dialog_Players)
        xbmc.sleep(500)
        setting_set('playersversion', str(players_version))
        BG.update(55, Dialog_U12, Dialog_Players)
        xbmc.sleep(200)
        BG.update(75, Dialog_U12, Dialog_Players)
        xbmc.sleep(200)
        BG.update(100, Dialog_U12, Dialog_U9)
        xbmc.sleep(1000)
        BG.close()
        
        # 🔥 ΧΕΙΡΟΦΡΕΝΟ: Αναμονή για την εγκατάσταση των Core Players
        wait_for_kodi("Εγκατάσταση Players")


# ----------------------------------------------------------------------
# ΔΙΟΡΘΩΜΕΝΗ ZIP1
# ----------------------------------------------------------------------
def zip1():
    if zip1_version > int(setting('zip1version')):
        BG.create(Dialog_U12, Dialog_U2)
        BG.update(5, Dialog_U12, Dialog_U2)
        xbmc.sleep(200)
        BG.update(15, Dialog_U12, Dialog_U3)
        xbmc.sleep(200)
        xbmc.executebuiltin(Zip1_startup)
        xbmc.sleep(1000)
        BG.update(25, Dialog_U12, Dialog_U3)
        xbmc.sleep(500)
        setting_set('zip1version', str(zip1_version))
        BG.update(55, Dialog_U12, '[COLOR green]Zip1...[/COLOR]')
        xbmc.sleep(500)
        BG.update(75, Dialog_U12, '[COLOR green]Zip1...[/COLOR]')
        xbmc.sleep(500)
        BG.update(100, Dialog_U12, Dialog_U9)
        xbmc.sleep(1000)
        BG.close()
        
        # 🔥 ΧΕΙΡΟΦΡΕΝΟ: Αναμονή για την αποσυμπίεση του Zip1
        wait_for_kodi("Εγκατάσταση Zip1")


# ----------------------------------------------------------------------
# ΔΙΟΡΘΩΜΕΝΗ ZIP3
# ----------------------------------------------------------------------
def zip3():
    if zip3_version > int(setting('zip3version')):
        BG.create(Dialog_U12, Dialog_U2)
        BG.update(5, Dialog_U12, Dialog_U2)
        xbmc.sleep(1000)
        BG.update(15, Dialog_U12, Dialog_U3)
        xbmc.sleep(1000)
        xbmc.executebuiltin(Zip3_startup)
        xbmc.sleep(1000)
        BG.update(25, Dialog_U12, Dialog_U3)
        xbmc.sleep(1000)
        setting_set('zip3version', str(zip3_version))
        BG.update(55, Dialog_U12, 'addon_data')
        xbmc.sleep(1000)
        BG.update(75, Dialog_U12, 'addon_data')
        xbmc.sleep(1000)
        BG.update(100, Dialog_U12, Dialog_U9)
        xbmc.sleep(1000)
        BG.close()
        
        # 🔥 ΧΕΙΡΟΦΡΕΝΟ: Αναμονή για τη μεταφορά αρχείων addon_data
        wait_for_kodi("Εγκατάσταση Zip3 (Addon Data)")


# ----------------------------------------------------------------------
# ΔΙΟΡΘΩΜΕΝΗ ZIP4
# ----------------------------------------------------------------------
def zip4():
    if zip4_version > int(setting('zip4version')):
        BG.create(Dialog_U12, Dialog_U2)
        BG.update(5, Dialog_U12, Dialog_U2)
        xbmc.sleep(200)
        BG.update(15, Dialog_U12, Dialog_U3)
        xbmc.sleep(200)
        xbmc.executebuiltin(Zip4_startup)
        xbmc.sleep(1000)
        BG.update(25, Dialog_U12, Dialog_U3)
        xbmc.sleep(500)
        setting_set('zip4version', str(zip4_version))
        BG.update(55, Dialog_U12, Dialog_U3)
        xbmc.sleep(200)
        BG.update(75, Dialog_U12, Dialog_U3)
        xbmc.sleep(200)
        BG.update(100, Dialog_U12, Dialog_U9)
        xbmc.sleep(1000)
        BG.close()
        
        # 🔥 ΧΕΙΡΟΦΡΕΝΟ: Αναμονή για το Zip4
        wait_for_kodi("Εγκατάσταση Zip4")


# ----------------------------------------------------------------------
# ΔΙΟΡΘΩΜΕΝΗ ZIP5
# ----------------------------------------------------------------------
# ----------------------------------------------------------------------
# ΔΙΟΡΘΩΜΕΝΗ ZIP5 (Αλλάζει την τιμή και περιμένει να τελειώσει το background fix)
# ----------------------------------------------------------------------
def zip5():
    if zip5_version > int(setting('zip5version')):
        BG.create(Dialog_U12, Dialog_U2)
        BG.update(5, Dialog_U12, Dialog_U2)
        xbmc.sleep(200)
        BG.update(15, Dialog_U12, Dialog_U3)
        xbmc.sleep(200)
        
        # 🚀 Εκκίνηση του background script για τα fixes/updates των addons
        xbmc.executebuiltin(Zip5_startup)
        xbmc.sleep(1000)
        
        BG.update(25, Dialog_U12, Dialog_U3)
        xbmc.sleep(500)
        
        # 🎯 ΕΓΓΡΑΦΗ ΤΗΣ ΝΕΑΣ ΕΚΔΟΣΗΣ: Γράφεται κανονικά τώρα
        setting_set('zip5version', str(zip5_version))
        
        BG.update(40, Dialog_U12, '[COLOR green]manually update addons...[/COLOR]')
        xbmc.sleep(1000)
        BG.update(50, Dialog_U12, '[COLOR lime]manually fix addons...[/COLOR]')
        xbmc.sleep(1000)
        BG.update(60, Dialog_U12, 'Παρακαλώ περιμένετε...')
        xbmc.sleep(500)
        BG.update(70, Dialog_U12, Dialog_U3)
        xbmc.sleep(500)
        BG.update(80, Dialog_U12, Dialog_U3)
        xbmc.sleep(500)
        BG.update(100, Dialog_U12, Dialog_U9)
        xbmc.sleep(1000)
        BG.close()
        
        # 🔥 ΤΟ ΚΛΕΙΔΙ: Περιμένουμε να ολοκληρωθούν όλες οι χειροκίνητες διορθώσεις των addons
        # στο παρασκήνιο, ώστε να προλάβει το Kodi να αποθηκεύσει και τη νέα τιμή στα settings!
        wait_for_kodi("Χειροκίνητες Διορθώσεις Addons (Zip5)")



# ----------------------------------------------------------------------
# ΔΙΟΡΘΩΜΕΝΗ PVR (Πολύ σημαντικό γιατί πειράζει clients και mac_list)
# ----------------------------------------------------------------------
def pvr():
    if pvr_version > int(setting('pvrversion')):
        BG.create(Dialog_U12, Dialog_U2)
        BG.update(5, Dialog_U12, Dialog_U2)
        xbmc.sleep(1000)
        BG.update(15, Dialog_U12, Dialog_U3)
        xbmc.sleep(1000)
        xbmc.executebuiltin(Pvr_startup)
        xbmc.sleep(1000)
        BG.update(25, Dialog_U12,'IPTV Simple Client')
        xbmc.sleep(1000)
        BG.update(35, Dialog_U12,'Stalker Client')
        xbmc.sleep(1000)
        BG.update(45, Dialog_U12,'mac_list')
        xbmc.sleep(1000)
        setting_set('pvrversion', str(pvr_version))
        BG.update(50, Dialog_U12, Dialog_U3)
        xbmc.sleep(1000)
        BG.update(60, Dialog_U12, 'Παρακαλώ περιμένετε...')
        xbmc.sleep(2000)
        BG.update(70, Dialog_U12, 'Παρακαλώ περιμένετε...')
        xbmc.sleep(2000)
        BG.update(80, Dialog_U12, 'Παρακαλώ περιμένετε...')
        xbmc.sleep(2000)
        BG.update(90, Dialog_U12, 'Παρακαλώ περιμένετε...')
        xbmc.sleep(2000)
        BG.update(100, Dialog_U12, Dialog_U9)
        xbmc.sleep(1000)
        BG.close()
        
        # 🔥 ΧΕΙΡΟΦΡΕΝΟ: Αναμονή για τη ρύθμιση των PVR Clients
        wait_for_kodi("Ρύθμιση PVR")


# ----------------------------------------------------------------------
# ΔΙΟΡΘΩΜΕΝΗ SETSETTING
# ----------------------------------------------------------------------
def setsetting():
    if set_setting_version > int(setting('setsettingversion')):
        xbmcvfs.delete('special://home/userdata/addon_data/plugin.program.downloader19/set_setting.py')
        xbmc.sleep(4000)
        xbmc.executebuiltin(SetSetting_startup)
        xbmc.sleep(5000)
        setting_set('setsettingversion', str(set_setting_version))
        dialog.notification('[B][COLOR orange]Γίνεται έλεγχος![/COLOR][/B]', '[COLOR white]Παρακαλώ περιμένετε...[/COLOR]', icon_ok2, sound=False)
        xbmc.sleep(5000)
        
        # 🔥 ΧΕΙΡΟΦΡΕΝΟ: Αναμονή για την ολοκλήρωση του set_setting script
        wait_for_kodi("Ενημέρωση Ρυθμίσεων (SetSetting)")



def database():
    if addons_repos_version > int(setting('addonsreposversion')):
        
        # 🎯 ΦΡΕΝΟ ΣΤΗΝ ΕΝΑΡΞΗ: Μην αγγίζεις τη βάση αν το Kodi είναι απασχολημένο με προηγούμενα zip/addons
        wait_for_kodi("Προετοιμασία Βάσης Δεδομένων (Database Pre-Check)")
        
        xbmcvfs.delete('special://home/userdata/addon_data/plugin.program.downloader19/Database_Addons33.py')
        xbmc.sleep(4000)
        
        # 🚀 Εκκίνηση της λήψης των Repos
        xbmc.executebuiltin(AddonsRepos_startup)
        
        BG.create(Dialog_U8, Dialog_Database)
        xbmc.sleep(2000)
        BG.update(33, Dialog_U8, Dialog_Database)
        xbmc.sleep(2000)
        BG.update(63, Dialog_U12, Dialog_Database)
        xbmc.sleep(2000)
        BG.update(76, Dialog_U12, Dialog_Database)
        xbmc.sleep(2000)
        
        # Εκτέλεση του δικού σου database script [σε μορφή built-in]
        xbmc.executebuiltin(database_startup)
        xbmc.sleep(1500)
        
        # 🎯 Ενεργοποίηση των Repositories
        addonsEnable.enable_addons()
        
        BG.update(85, Dialog_U12, '[COLOR lime]enable_addons...[/COLOR]')
        xbmc.sleep(500)
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.stalker","enabled":false}}')
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.iptvsimple","enabled":false}}')
        setting_set('addonsreposversion', str(addons_repos_version))
        xbmc.sleep(2000)
        BG.update(100, Dialog_U1, '[B][COLOR red]Περιμένετε χωρίς να πατήσετε κάτι...[/COLOR][/B]')
        xbmc.sleep(2000)
        BG.update(100, Dialog_U1, '[B][COLOR cornflowerblue]Περιμένετε λίγο ακόμα...[/COLOR][/B]')
        xbmc.sleep(2000)
        BG.update(95, Dialog_U9, Dialog_U2)
        xbmc.sleep(2000)
        dialog.notification('[B][COLOR orange]Γίνεται έλεγχος![/COLOR][/B]', '[COLOR white]Παρακαλώ περιμένετε...[/COLOR]', icon_ok2, sound=False) 
        xbmc.sleep(2000)
        BG.close()
        
        # ----------------------------------------------------------------------
        # 🔥 ΤΟ ΣΩΣΤΟ ΧΕΙΡΟΦΡΕΝΟ ΣΤΟ ΤΕΛΟΣ: 
        # Περιμένουμε το database_lock.txt να σβηστεί από το Database_Addons33.py
        # ----------------------------------------------------------------------
        profile_dir = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.program.downloader19')
        DATABASE_LOCK_FILE = os.path.join(profile_dir, 'database_lock.txt')
        
        # Αν το Database_Addons33.py πρόλαβε και έφτιαξε το lock, περιμένουμε να το σβήσει
        while os.path.exists(DATABASE_LOCK_FILE):
            xbmc.log("[Master_Build] Το Database_Addons33.py επεξεργάζεται τη βάση (database_lock.txt ενεργό). Αναμονή 2 δευτερόλεπτα...", xbmc.LOGINFO)
            xbmc.sleep(2000)
            
        xbmc.log("[Master_Build] [ΚΑΘΑΡΟ ΠΕΔΙΟ] Η βάση δεδομένων ολοκληρώθηκε πλήρως!", xbmc.LOGINFO)
        xbmc.sleep(1000)



def xmlskin():
    if not setting('xmlskinversion') == 'false':
        if xmlskin_version > int(setting('xmlskinversion')):
            BG.create(Dialog_U12, Dialog_Xml_Skin)
            BG.update(5, Dialog_U12, Dialog_Xml_Skin)
            xbmc.sleep(200)
            BG.update(15, Dialog_U12, Dialog_Xml_Skin)
            xbmc.sleep(200)
            xbmc.executebuiltin(XmlSkin_startup)
            xbmc.sleep(1000)
            BG.update(25, Dialog_U12, Dialog_Xml_Skin)
            xbmc.sleep(500)
            setting_set('xmlskinversion', str(xmlskin_version))
            BG.update(55, Dialog_U12, Dialog_Xml_Skin)
            xbmc.sleep(200)
            BG.update(75, Dialog_U12, Dialog_Xml_Skin)
            xbmc.sleep(200)
            BG.update(80, Dialog_U12, Dialog_U9)
            xbmc.sleep(1000)
            BG.update(90, Dialog_U1, 'Ενημέρωση μενού skin.')
            xbmc.sleep(5000)
            BG.update(95, Dialog_U4, 'Θα ακολουθήσει... επαναφόρτωση του προφίλ')
            xbmc.sleep(3000)
            BG.update(100, Dialog_U4, 'Θα ακολουθήσει... και πάγωμα της εικόνας')
            dialog.notification('[B][COLOR orange]Reload Profile[/COLOR][/B]', '[COLOR white]Παρακαλώ περιμένετε...[/COLOR]', icon_reloadprofile, sound=False)
            xbmc.sleep(4000)
            xbmc.executebuiltin("LoadProfile(Master user)")
            BG.close()
            xbmc.sleep(15000)








#TEST
def xmlskinTest():
    if not setting('xmlskinversion') == 'false':
        if xmlskin_version > int(setting('xmlskinversion')):
            BG.create(Dialog_U12, Dialog_Xml_Skin)
            BG.update(5, Dialog_U12, Dialog_Xml_Skin)
            xbmc.sleep(200)
            BG.update(15, Dialog_U12, Dialog_Xml_Skin)
            xbmc.sleep(200)
            xbmc.executebuiltin(XmlSkin_startup)
            xbmc.sleep(1000)
            BG.update(25, Dialog_U12, Dialog_Xml_Skin)
            xbmc.sleep(500)
            setting_set('xmlskinversion', str(xmlskin_version))
            BG.update(55, Dialog_U12, Dialog_Xml_Skin)
            xbmc.sleep(1000)
            BG.update(75, Dialog_U12, Dialog_Xml_Skin)
            xbmc.sleep(2000)
            BG.update(80, Dialog_U12, Dialog_U9)
            xbmc.sleep(3000)
            BG.update(90, Dialog_U1, '   ')
            xbmc.sleep(4000)
            BG.update(95, 'Ενημέρωση μενού skin' '   ')
            xbmc.sleep(5000)
            BG.update(100, Dialog_U4, '   ')
            # dialog.notification('[B][COLOR orange]Reload Profile[/COLOR][/B]', '[COLOR white]Παρακαλώ περιμένετε...[/COLOR]', icon_reloadprofile, sound=False)
            xbmc.sleep(5000)
            # xbmc.executebuiltin("LoadProfile(Master user)")
            BG.close()
            xbmc.executebuiltin("ReloadSkin()")
            # xbmcgui.Dialog().ok('Skin World', 'Για να εφαρμοστούν οι αλλαγές, το Kodi πρέπει να κλείσει.')
            # xbmc.sleep(15000)
            # os._exit(1)
            


def xmlskin3():
    if not setting('xmlskinversion') == 'false':
        if xmlskin_version > int(setting('xmlskinversion')):
            BG.create('Skin World', 'Αντιγραφή.')
            xbmc.sleep(500)
            setting_set('xmlskinversion', str(xmlskin_version))
            BG.close()
            xbmcgui.Dialog().ok('Skin World', 'Για να εφαρμοστούν οι αλλαγές, το Kodi πρέπει να κλείσει.')
            os._exit(1)



def Backup_Skin_Set():
    src_settings = xbmcvfs.translatePath('special://home/userdata/addon_data/skin.19MatrixWorld/settings.xml')
    dst_settings = xbmcvfs.translatePath('special://home/backup/skin.19MatrixWorld/settings.xml')
    addon_downloader19       = xbmcaddon.Addon('plugin.program.downloader19')
    setting_downloader19     = addon_downloader19.getSetting
    # setting_set_downloader19 = addon_downloader19.setSetting
    if not setting_downloader19('xmlskinversion')=='2046':
        xbmc.sleep(500)
        # setting_set_downloader19('xmlskinversion', '2046')
        shutil.copyfile(src_settings, dst_settings)


def Backup_Home_Set():
    src_homeset = xbmcvfs.translatePath('special://home/addons/skin.19MatrixWorld/xml/Home.xml')
    dst_homeset = xbmcvfs.translatePath('special://home/backup/skin.19MatrixWorld/Home.xml')
    addon_downloader19       = xbmcaddon.Addon('plugin.program.downloader19')
    setting_downloader19     = addon_downloader19.getSetting
    # setting_set_downloader19 = addon_downloader19.setSetting
    if not setting_downloader19('xmlskinversion')=='2046':
        xbmc.sleep(500)
        # setting_set_downloader19('xmlskinversion', '2046')
        shutil.copyfile(src_homeset, dst_homeset)

def UpdateAddonRepos():        # Install updates automatically
    xbmc.sleep(200)
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"general.addonupdates","value":0}}')
    xbmc.sleep(2000)
    xbmcgui.Dialog().notification("Add-ons Updates...", "[COLOR green]Enable[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/auto5.png', sound=False)
    xbmc.sleep(2000)
    xbmcgui.Dialog().notification("Check...", "Ελεγχος για ενημερώσεις προσθέτων", icon='special://home/addons/plugin.program.downloader19/resources/media/auto3.png', sound=False)
    xbmc.sleep(200)
    xbmc.log("[Master_Build] Έλεγχος background διεργασιών πριν το UpdateAddonRepos...", xbmc.LOGINFO)
    
    # 🎯 Αντί για τα αρχεία lock, καλούμε τη wait_for_kodi για να σιγουρευτούμε 
    # ότι δεν τρέχει καμία εγκατάσταση addon ή unzip από τα προηγούμενα βήματα
    wait_for_kodi("Τελικός Έλεγχος Updater")

    while xbmc.getCondVisibility('Window.IsActive(yesnodialog)') or xbmc.getCondVisibility('Window.IsActive(progressdialog)'):
        xbmc.sleep(1000)
        
    xbmc.log("[Master_Build] [RELEASE] Όλα καθαρά! Εκκίνηση του Updater.", xbmc.LOGINFO)
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloader19/addonupdatesprog.py")')
    xbmc.sleep(20000)
    Backup_Skin_Set()
    Backup_Home_Set()





    # else: dialog.notification('[B][COLOR orange]Γίνεται έλεγχος![/COLOR][/B]', '[COLOR white]Παρακαλώ περιμένετε...[/COLOR]', icon_ok2, sound=False)
    

    # xbmc.executebuiltin('ActivateWindow(2139)')
    #xbmc.executebuiltin('PlayMedia("special://home/media/Bamako.mp4")')
    # xbmc.executebuiltin('PlayMedia("special://home/media/Join_file.mp4")')
    # xbmc.sleep(12000)
        
    # xbmc.executebuiltin('ActivateWindow(2139)')
    # xbmc.sleep(4000)
    # UpdatesStatus()
    
    
    



    # xbmc.executebuiltin('UpdateLocalAddons()')
    # xbmc.sleep(4000)
    # xbmc.executebuiltin('UpdateAddonRepos()')

