﻿import xbmc, xbmcgui, xbmcvfs, sys, json, os, re, glob, shutil, xbmcaddon, urllib.request

# 🛑 ΤΟ ΑΚΑΡΙΑΙΟ ΜΠΛΟΚΑΡΙΣΜΑ ΣΟΥ (ΠΑΝΩ-ΠΑΝΩ):
# Αν το service ξαναξεκινήσει σφήνα και δει το παράθυρο ανοιχτό, το φρεσκάρει και πεθαίνει αμέσως!
if xbmc.getCondVisibility('Window.IsActive(10040)') or xbmc.getCondVisibility('Window.IsActive(2139)') or xbmc.getCondVisibility('Window.IsActive(progressdialog)'):
	xbmc.log("[World_Updater] Εντοπίστηκε ανοιχτό παράθυρο στην εκκίνηση. Ακαριαίο μπλοκάρισμα.", xbmc.LOGINFO)
	xbmc.executebuiltin('ActivateWindow(10040,"addons://outdated/")')
	import sys
	sys.exit() # 👈 Αυτό εγγυάται ότι ΔΕΝ θα προχωρήσει τίποτα από κάτω


# 🟢 [ΔΙΚΛΕΙΔΑ ΑΣΦΑΛΕΙΑΣ]: Ακαριαίος καθαρισμός παλιών locks σε κάθε φρέσκια εκκίνηση
profile_dir = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.program.downloader19')
lock_files = ['delete_lock.txt', 'database_lock.txt', 'install_lock.txt']

for lock_name in lock_files:
	full_lock_path = os.path.join(profile_dir, lock_name)
	if os.path.exists(full_lock_path):
		try:
			os.remove(full_lock_path)
			xbmc.log(f"[World_Updater] [Δικλείδα Ασφαλείας] Το παλιό αρχείο {lock_name} σβήστηκε επιτυχώς.", xbmc.LOGINFO)
		except:
			pass


# 🟢 ΑΝ ΤΟ ΠΑΡΑΘΥΡΟ ΔΕΝ ΕΙΝΑΙ ΑΝΟΙΧΤΟ, ΤΟΤΕ ΚΑΙ ΜΟΝΟ ΤΟΤΕ ΞΕΚΙΝΑΕΙ Η ΡΟΗ:

# PVR
xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.stalker","enabled":false}}')
xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.iptvsimple","enabled":false}}')
xbmc.sleep(200)

# ADDONS UPDATE (Διορθώθηκε και το }} στο τέλος)
xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"addons.updatemode","value":1}}')
xbmc.sleep(200)
xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"general.addonupdates","value":1}}')

######################################################################################
xbmcvfs.delete('special://home/userdata/addon_data/plugin.video.myiptv/cache.db')
######################################################################################

xbmc.sleep(200) 
xbmcgui.Dialog().notification("[B][COLOR orange]...[/COLOR][/B]", "   ", sound=False, icon='special://home/addons/plugin.program.downloader19/resources/media/autoexec.png')
xbmc.sleep(1000) 
xbmcgui.Dialog().notification("[COLOR white]Έναρξη World Updater...[/COLOR]", "[B][COLOR orange]Καλώς ήρθατε![/COLOR][/B]", sound=False, icon='special://home/addons/plugin.program.downloader19/resources/media/World.png')



from resources.lib.modules import check
from updatervar import *


if __name__ == '__main__':
	if setting('notifyversion') == '0': # για την πρώτη εγκατάσταση

		xbmcgui.Dialog().ok('[B][COLOR blue]Πρώτη Εγκατάσταση[/COLOR][/B]', 'Περιμένετε να ολοκληρωθούν [COLOR lime]οι ενημερώσεις των Προσθέτων[/COLOR][CR]και η Εγκατάσταση των [B]binary add-ons[/B].')
		check.notifyT()
		xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"general.addonupdates","value":0}}')
		xbmc.sleep(1000)
		xbmc.executebuiltin('UpdateAddonRepos()')
		xbmc.executebuiltin('UpdateLocalAddons()')
		xbmc.executebuiltin('ActivateWindow(AddonBrowser)')

	else:
		if not setting('updaterversion') == 'false':
			xbmcgui.Dialog().notification("[B][COLOR orange]Ελεγχος για ενημερώσεις[/COLOR][/B]", "...", icon='special://home/addons/plugin.program.downloader19/icon.gif', sound=False)
			
			# 1. Παράθυρο αλλαγών (Notify) - Κλειδώνει αυτόματα με το doModal()
			check.notifyT()
			check.autoenable()
			
			# 2. Ρύθμιση Var
			check.var()
			
			# 3. Διαγραφή παλιών Addons (Περιμένει πλέον το background)
			check.delete()
			
			# 4. Εγκατάσταση Zip2 
			check.zip2() 
			
			# 5. Λίστα Εγκατάστασης Addons
			check.installation() 
			
			# 6. Τα υπόλοιπα αρχεία τρέχουν τώρα με ασφάλεια σε καθαρό πεδίο
			check.players()
			check.zip1()
			check.zip3()
			check.zip4()
			check.zip5()
			check.pvr()
			check.setsetting()
			
			# 7. Ενημέρωση Database Repositories
			check.database()
			# Περιμένουμε και τη βάση δεδομένων να «κάτσει» σωστά
			from resources.lib.modules.check import wait_for_kodi
			wait_for_kodi("Ενημέρωση Αποθετηρίων Database")
			
			# 8. Τελευταίο και καταϊδρωμένο το Skin Update
			check.xmlskin()

			check.UpdateAddonRepos()


		else:
			dialog.notification('[B][COLOR orange]Καλά να περάσετε![/COLOR][/B]', Dialog_not_Updater, icon_Build, sound=False)
			xbmc.sleep(2000)
			xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"general.addonupdates","value":0}}')
			xbmc.sleep(2000)
			xbmc.executebuiltin('UpdateLocalAddons()')
			xbmc.executebuiltin('UpdateAddonRepos()')
			xbmc.executebuiltin('ActivateWindow(AddonBrowser)')

##Tk & GKoBu & TRAILER MONITOR MULTI-MERGE LAYER ______________________________________
##Tk & GKoBu & TRAILER MONITOR MULTI-MERGE LAYER ______________________________________
		monitor = xbmc.Monitor()
		update_interval = 2 * 60 * 60
		time_counter = 0




		while not monitor.abortRequested():
			if xbmc.getCondVisibility('Window.IsVisible(home)') and not xbmc.getCondVisibility('Window.IsVisible(6199)'):
				if xbmc.getInfoLabel('Skin.String(TrailerCheckID)') != '':
					# 🧼 FLUSH RAM: Μηδενίζουμε dynamic την property του Widget κατά την έξοδο!
					xbmc.executebuiltin('Skin.ResetString(HubFromWidget)')
					
					xbmc.executebuiltin('Skin.ResetString(TrailerCheckID)')
					xbmc.executebuiltin('Skin.ResetString(HubMovieTitle)')
					xbmc.executebuiltin('Skin.ResetString(HubMoviePlot)')
					xbmc.executebuiltin('Skin.ResetString(HubMovieCast)')
					xbmc.executebuiltin('Skin.ResetString(HubMovieDirector)')
					xbmc.executebuiltin('Skin.ResetString(HubMovieWriter)')
					xbmc.executebuiltin('Skin.ResetString(HubMovieGenre)')
					xbmc.executebuiltin('Skin.ResetString(HubMovieYear)')
					xbmc.executebuiltin('Skin.ResetString(HubMovieRating)')
					xbmc.executebuiltin('Skin.ResetString(HubMovieStudio)')
					xbmc.executebuiltin('Skin.ResetString(HubMovieCountry)')
					xbmc.executebuiltin('Skin.ResetString(HubMoviePoster)')
					xbmc.executebuiltin('Skin.ResetString(HubMovieFanart)')
					xbmc.executebuiltin('Skin.ResetString(HubMovieTagLine)')
					xbmc.executebuiltin('Skin.ResetString(HubMovieDuration)')
					xbmc.executebuiltin('Skin.ResetString(HubMovieEndTime)')

			time_counter += 0.1 
			if time_counter >= update_interval:
				time_counter = 0 
				xbmc.executebuiltin('UpdateAddonRepos()')

			if monitor.waitForAbort(0.1):
				break
