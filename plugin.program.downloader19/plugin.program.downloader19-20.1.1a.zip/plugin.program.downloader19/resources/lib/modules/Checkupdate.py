﻿import xbmc, xbmcgui

def Checkupdate():
    xbmcgui.Dialog().notification("[B][COLOR orange]Ελεγχος για ενημέρωση του build[/COLOR][/B]", "[COLOR white][B]Παρακαλώ περιμένετε...[/B][/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/Pleasewait.png')
    xbmc.sleep(500)
    xbmc.executebuiltin("ActivateWindow(Home)")
    xbmc.sleep(500)
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloader19/Checkforupdate.py")')

Checkupdate()
