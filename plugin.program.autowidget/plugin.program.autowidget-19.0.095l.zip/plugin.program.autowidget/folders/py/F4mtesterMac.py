import xbmc, xbmcgui


def F4mtesterMac():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7, click_8, click_9, click_10)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]~ F4mtesterMac ~[/COLOR][/B]', 
['[COLOR aquamarine]l[/COLOR] [COLOR white][B]SERVIDOR 3[/B][/COLOR] [COLOR white]l[/COLOR] [COLOR aquamarine]CANAIS[/COLOR] - [COLOR white]F4MTESTER[/COLOR]',
 ' [B][COLOR orange]IPTV [/COLOR][COLOR lime]...  [/COLOR][COLOR khaki]:::: ROOM :::: [/COLOR][/B]',
 '[B][COLOR orange]IPTV [/COLOR][COLOR lime]...  [/COLOR][COLOR khaki]:::: SOTER :::: [/COLOR][/B]',
 '[B][COLOR white]NEO tv[/COLOR][/B] F4mtester',
 '[B][COLOR lime]Krypton TV[/COLOR][/B] F4mtester',
 '[COLOR white]FLIXTVON[/COLOR] F4mtester',
 '[COLOR white]FlixTvON MAC[/COLOR]',
 '[COLOR grey]IPTV Stalker[/COLOR]',
   #'[COLOR white]IPTV Europa[/COLOR] F4mtester',
 '[COLOR gold]XC MAC M3U[/COLOR]'
 
 ])


    if call:
        if call < 0:
            return
        func = funcs[call-10]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.OnePlay.Matrix/?action=oneplay&description=%5bB%5dSERVIDOR%203%20-%5b%2fB%5d%20F4MTESTE%2c%20Esse%20%c3%a9%20um%20servidor%20dedicado%20Ao%20F4MTESTE%2c%20Pode%20Apresentar%20Problemas%20s%c3%b3%20aguardar...&fanart&iconimage=https%3a%2f%2fi.imgur.com%2fnzValEy.png&name=%5bCOLOR%20aquamarine%5dl%5b%2fCOLOR%5d%20%5bCOLOR%20white%5d%5bB%5dSERVIDOR%203%5b%2fB%5d%5b%2fCOLOR%5d%20%5bCOLOR%20white%5dl%5b%2fCOLOR%5d%20%5bCOLOR%20aquamarine%5dCANAIS%5b%2fCOLOR%5d%20-%20%5bCOLOR%20white%5dF4MTESTER%5b%2fCOLOR%5d&url=aHR0cHM6Ly93d3cub25lcGxheWhkLmNvbS9BY2Vzc29Qcm9pYmlkby9BZGRvbi9PbmVQbGF5L1RWL1NlcnZpZG9yLTMvTWVudS5odG1s",return)')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.thegroove360/thegroove/scripters/Danhiel29/path%3DLIST_tv.php",return)')

def click_3():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.thegroove360/thegroove/scripters/Soter/path%3Diptv_IPTV.php",return)')

def click_4():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.neo.tv/",return)')

def click_5():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.Krypton.tv/",return)')

def click_6():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.flixon/",return)')
    
def click_7():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.flix-mac/",return)')

def click_8():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.stalker/",return)')

def click_9():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.macvod/",return)')
def click_10():
    xbmc.executebuiltin('ActivateWindow(10001,"plugin://plugin.program.simple.favourites/index_of/special%3A%2F%2Fhome%2Faddons%2Fplugin.program.simple.favourites%2Ffolders%2FIPTV+Europa%2F",return)')


F4mtesterMac()
