import xbmc, xbmcgui


def tainiesonline():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]                             Tainies-Online by Cartoons.gr [/COLOR][/B]', 
['[B][COLOR=white]                                                     Νέες 2021[/COLOR][/B]',
 '[B][COLOR=white]                                                          Έτος[/COLOR][/B]',
 '[B][COLOR=white]                                                    Κατηγορίες[/COLOR][/B]',
 '[B][COLOR=white]                                                      Δημοφιλή[/COLOR][/B]',
 '[B][COLOR=white]                                                     Ελληνικές[/COLOR][/B]',
 '[B][COLOR=white]                                                     Αναζήτηση[/COLOR][/B]'])


    if call:
        if call < 0:
            return
        func = funcs[call-6]
        return func()
    else:
        func = funcs[call]
        return func()
    return 


def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/release/2021/,return)')

def click_2():
    xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.autowidget/folders/py/TainiesOnline_year.py)')

def click_3():
    xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.autowidget/folders/py/TainiesOnline_genre.py)')

def click_4():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/trending/,return)')

def click_5():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=34&amp;url=https://tenies-online1.gr/genre/ellinikes/,return)')

def click_6():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=35&amp;url=https://tenies-online1.gr/,return)')
tainiesonline()
