import xbmc, xbmcgui


def daddylive():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7, click_8, click_9)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]~ Daddylive ~[/COLOR][/B]', 
['[B][COLOR=white]Daddylive[/COLOR][/B]',
 '[COLOR=white]Sports Genres[/COLOR] (vstream)',
 '[COLOR=white]Live Sports[/COLOR] (gratis)',
 '[COLOR red][B]Daddylive(test)[/COLOR][/B] (microjen)',
 '[COLOR white]Daddylive[/COLOR] (the-loop)',
 '[COLOR=white]Daddylive[/COLOR] (Μadtitansports)'])
 #'[B][COLOR=white][COLOR lightcyan][B]AGENDA[/COLOR][COLOR lightblue] DADDYLIVE[/COLOR][/B]  [COLOR lightslategray]DaddyLive [/COLOR][/COLOR](The Black Ghost)','[B][COLOR=white][COLOR orchid]¤[/COLOR] [B][COLOR white] DADDYLIVE FULL SITE [/COLOR] [COLOR orchid][/COLOR][/B] [COLOR orchid]¤[/COLOR] (The Crew)', '[B][COLOR=white][COLOR orange][B]Schedule[/COLOR][/B][/COLOR] (Sport LIVE)',#



    if call:
        if call < 0:
            return
        func = funcs[call-9]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.daddylive/?mode=menu&serv_type=sched",return)')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.vstream/?function=showGenres&sFav=showGenres&site=daddyhd&siteUrl=%2f&title=Sports%20",return)')

def click_3():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.gratis/?_id&description=Live%20Sports&episode_number&fanart=C%3a%5cPortableApps%5ckodi%5cMy%20KODI%2021%5cKodi%5cportable_data%5caddons%5cplugin.video.gratis%5cfanart.jpg&foldername&icon=C%3a%5cPortableApps%5ckodi%5cMy%20KODI%2021%5cKodi%5cportable_data%5caddons%5cplugin.video.gratis%5cicon.png&mediatype&mode=live_main&name=Live%20Sports&name2&page&season_number&url",return)')

def click_4():xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.microjen/sportjetextractors/games/Daddylive",return)')

def click_5():xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.the-loop/sportjetextractors/games/Daddylive",return)')

def click_6():xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.madtitansports/sportjetextractors/games/Daddylive",return)')

def click_7():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.live.streamspro/?iconimage=http%3a%2f%2fbgapp.live%2fblack%2fimg%2fdeportes.png&mode=17&regexs=%7b%27makelist3%27%3a%20%7b%27name%27%3a%20%27makelist3%27%2c%20%27listrepeat%27%3a%20%27%5cn%20%20%3ctitle%3e%5bCOLOR%20orange%5d%5bmakelist3.param1%5d%5b%2fCOLOR%5d%20%5bCOLOR%20yellow%5d%5bmakelist3.param2%5d%5b%2fCOLOR%5d%5bCOLOR%20skyblue%5d%5bB%5d%5bmakelist3.param3%5d%20%5bmakelist3.param4%5d%5b%2fB%5d%5b%2fCOLOR%5d%20%20%20%20%20%20%20%20%5bI%5d%5bmakelist3.param6%5d%5b%2fI%5d%20%5bCOLOR%20lightslategray%5d%5bI%5d%20%5bmakelist3.param5%5d%20%5b%2fI%5d%5b%2fCOLOR%5d%3c%2ftitle%3e%5cn%3clink%3e%24doregex%5bid3%5d%7cuser-agent%3dMozilla%2f5.0%26amp%3bReferer%3dhttp%3a%2f%2fplayer.licenses4.me%2f%3c%2flink%3e%5cn%3cthumbnail%3ehttp%3a%2f%2fbgapp.live%2fblack%2fimg%2fdeportes.png%3c%2fthumbnail%3e%5cn%27%2c%20%27expres%27%3a%20%27%3ch3%3e%3cstrong%3e(.%2a%3f)%3c%7ch4%3e.%2a%3f%22%3e(.%2a%3f)%3c%7chr%3e(%5b0-9%5d%7b0%2c2%7d%3a%5b0-9%5d%2b)%5c%5cs(.%2a%3f)%3c%7c%5c%5c%2fstream%5c%5c-(.%2a%3f)%5c%5c.p.%2a%3fnoopener%5c%5c%22%3e(.%2a%3f)%3c%27%2c%20%27page%27%3a%20%27https%3a%2f%2fdaddylive.me%2f%27%2c%20%27cookiejar%27%3a%20%27%27%7d%2c%20%27id3%27%3a%20%7b%27name%27%3a%20%27id3%27%2c%20%27expres%27%3a%20%22source%3a%5b%5c%5cw%5c%5cW%5d%2a%3fsource%3a.%2a%3f%27(.%2b%3f.m3u8.%2a%3f)%27%22%2c%20%27page%27%3a%20%27http%3a%2f%2fplayer.licenses4.me%2fplayer.php%3fid%3dpremium%5bmakelist3.param5%5d%26test%3dtrue%27%2c%20%27referer%27%3a%20%27https%3a%2f%2frkc.primetubsub.xyz%2f%27%2c%20%27agent%27%3a%20%27Mozilla%2f5.0%20(Windows%20NT%2010.0%3b%20Win64%3b%20x64%3b%20rv%3a92.0)%20Gecko%2f20100101%20Firefox%2f92.0%27%2c%20%27cookiejar%27%3a%20%27%27%7d%7d&url=%24doregex%5bmakelist3%5d",return)')

def click_8():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.thecrew/?action=xdirectory&content=addons&url=%24doregex%5bmakelist%5d%7cregex%3d84fabffa5a69698d071f999730171de2",return)')

def click_9():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.sportliveevents/?ilabel=%7b%27plot%27%3a%20%27Daddylive%20-%20schedule%27%2c%20%27title%27%3a%20%27Schedule%27%7d&image=C%3a%5cPortableApps%5ckodi%5cKodi%20World%5cKodi%5cportable_data%5caddons%5cplugin.video.sportliveevents%5c%2fresources%2fimages%2fschedule.png&mode=listschedule%3adaddy&page=1&title=Schedule&url=dzien",return)')

daddylive()
