﻿import xbmc



xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.AliveGR/?action=live_tv&title=%ce%96%cf%89%ce%bd%cf%84%ce%b1%ce%bd%ce%ae%20%ce%a4%ce%b7%ce%bb%ce%b5%cf%8c%cf%81%ce%b1%cf%83%ce%b7",return)')