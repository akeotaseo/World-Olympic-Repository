import xbmc, xbmcgui


def live_now():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7, click_8, click_9, click_10, click_11, click_12, click_13, click_14)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]       Live Now...[/COLOR][/B]',
['[COLOR=white][COLOR deepskyblue]Search Game[COLOR skyblue] (Live) [/COLOR] [/COLOR][COLOR=lime](THE LOOP)[/COLOR]',
 '[COLOR=white]LIVE EVENTS [COLOR=orange](SportHD)[/COLOR]',

 '[COLOR=white]USA SPORTS [COLOR=lime](The Endzone 19)[/COLOR]',
 '[B][COLOR=red]Rising Tides[/COLOR][/B]',
 '[COLOR=white]Mr. Dupont [/COLOR] [COLOR=green](Thegroove360)[/COLOR]',
 '[COLOR=grey]WEB STREAM SPORT AGENDA [/COLOR][COLOR=green](Thegroove360)[/COLOR]',
 '[COLOR=white][COLOR gold]TheANONYMOUS[/COLOR][COLOR cyan] EVENTOS DESPORTIVOS  [/COLOR]',
 '[COLOR=white]AO VIVO AGORA [COLOR lime](SHOW DE BOLA)[/COLOR]',
 '[COLOR=white]Daddylive [COLOR=olive](All)[/COLOR]',
  '[COLOR=white]Live TV[/COLOR] [COLOR=purple](vstream)[/COLOR]',
 '[COLOR=white]Live Sports[/COLOR] (Livetv.sx - Dracarys)',
 '[COLOR=white]Ver Agenda [/COLOR] [COLOR=red](Winner 2)[/COLOR] ACE...',
 '[COLOR yellow]NemesisAIO Live Sports & Replays[/COLOR]',
 '[COLOR=white]Αναζήτηση Ζωντανών Αγώνων[/COLOR]'])




    if call:
        if call < 1:
            return
        func = funcs[call-14]
        return func()
    else:
        func = funcs[call]
        return func()
    return 





def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.the-loop/sportjetextractors/search_dialog/*")')
    xbmcgui.Dialog().notification("[B][COLOR orange]Loop[/COLOR][/B]",'[COLOR white]Για ευκολία, πληκτρολογήστε NBA ή Basket ή FOOTBALL ή Soccer κ.τ.λ (πεζά ή κεφαλαία) και περιμένετε ...[/COLOR]' , icon ='special://home/addons/plugin.image.World/resources/media/addonset foto/the-loop.png')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.sporthdme/?description&iconimage=C%3a%5cPortableApps%5ckodi%5ckodi%20World%2020%5cKodi%5cportable_data%5caddons%5cplugin.video.sporthdme%5cicon.png&mode=5&name=%5bB%5d%5bCOLOR%20white%5dLIVE%20EVENTS%5b%2fCOLOR%5d%5b%2fB%5d&url=https%3a%2f%2f1.livesoccer.sx%2f",return)')

def click_3():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.microjen/get_list/https://l3grthu.com/ez/endzone.xml",return)')

def click_4():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.Rising.Tides)')

def click_5():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.thegroove360/thegroove/scripters/Mr_Dupont/path%3DSport_sport.xml")')

def click_6():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.thegroove360/thegroove/scripters/Soter/path%3Dsport_rojadirecta_rojadirecta.php")')

def click_7():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.desporto.theanonymous/?fanart=http%3a%2f%2fmilhano.pt%2fftp-milhano%2faladotv%2fTheAnonymous.Desporto%2fdesp_fanart.jpg&mode=1&name=%5bCOLOR%20yellow%5d%5bB%5dEVENTOS%20DESPORTIVOS%5b%2fB%5d%5b%2fCOLOR%5d&url=http%3a%2f%2fmilhano.pt%2fftp-milhano%2faladotv%2fTheAnonymous.Desporto%2fsportsonline2%2f")')

def click_8():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.showdebola/?action=aovivo&iconimage=C%3a%5cPortableApps%5ckodi%5cKodi%20World%5cKodi%5cportable_data%5caddons%5cplugin.video.showdebola%5cicon.png&name=AO%20VIVO%20AGORA")')
    
def click_9():
    xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.autowidget/folders/py/Daddylive.py)')

def click_10():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.vstream/?function=load&sFav=load&site=livetv&siteUrl=True&title=Live%20TV",return)')

def click_11():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.dracarys/?category=live_sport&mode=open_site&site=livetv",return)')

def click_12():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.winner/?xVak92ScxFMyASSE90SgkXTcxVak92acx1cwBXQlxmYhRncvBFXcpzQnAiOiQnch5WYmJCIscybP90bw8EMwk2bnAiOi42bpR3YhJye03Jml2ZuUmdpxGXcFWakVWbcx1clNmc192clJHXcJXZu5Wa35yblRWa25ibpdWdsBHXcNnbvRGZhxFXhRXYk9VZsJWY0J3bwxFXpR2bLxFXwIDIJR0TLBSeNxFXpR2brxFXzBHcBVGbiFGdy9GUcxlODdCI6IiclR3cvBnIgwyJdJ0LbFGZuV2ZBBiclZVXCt1JgojIsVmYhxmIgwyJnBnauQnch5WYmxFXhlGZl1GXcNXZjJXdvNXZyxFXyVmbul2du8WZklmdu4WanVHbwxFXz52bkRWYcxVY0FGZfVGbiFGdy9Gcc",return)')

def click_13():
    xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.downloader/resources/okpn.py, ActivateWindow(10025,"plugin://plugin.video.nemesisaio/?description=Sports%20Time%2c%20Come%20On%20You%20Reds%20%23YNWA&fanart=0&iconimage=special://home/addons%5cplugin.video.nemesisaio%5cresources%5cImages%5cSports.gif&mode=1&name=%5bCOLOR%20yellow%5d%5bB%5dLive%20Sports%20%26%20Replays%5b%2fB%5d%5b%2fCOLOR%5d&url=SPORTS"))')
    
def click_14():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.microjen/get_list/http://gknwizard.eu/repo/Builds/GKoBu/xmls/search_matches.json",return)')

live_now()
