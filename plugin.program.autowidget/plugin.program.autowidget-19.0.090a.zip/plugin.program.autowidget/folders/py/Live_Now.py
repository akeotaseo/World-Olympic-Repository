import xbmc, xbmcgui


def live_now():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7, click_8, click_9, click_10, click_11, click_12, click_13, click_14)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]       Live Now...[/COLOR][/B]',
['[COLOR=white]Αναζήτηση Ζωντανών Αγώνων[/COLOR]',
 '[COLOR=white][COLOR deepskyblue]Search Game[COLOR skyblue] (Live) [/COLOR] [/COLOR][COLOR=lime](THE LOOP)[/COLOR]',
 '[B][COLOR=white]LIVE EVENTS [COLOR=orange](SportHD)[/COLOR][/B]',
 '[B][COLOR=white]Sports [COLOR lightcoral](Live)[/COLOR] [COLOR=purple](vstream)[/COLOR][/B]',
 '[B][COLOR=white]USA SPORTS [COLOR=lime](The Endzone 19)[/COLOR][/B]',
 '[B][COLOR=red]Rising Tides[/COLOR][/B]',
 '[B][COLOR=white]Ver Agenda [/COLOR] [COLOR=red](Winner 2)[/COLOR][/B]',
 '[B][COLOR=white]Soccer Streams [/COLOR][COLOR=yellow](Nemesisaio)[/COLOR][/B]*',
 '[B][COLOR=white]Mr. Dupont [/COLOR] [COLOR=green](Thegroove360)[/COLOR][/B]',
 '[B][COLOR=grey]WEB STREAM SPORT AGENDA [/COLOR][COLOR=green](Thegroove360)[/COLOR][/B]',
 '[B][COLOR=white]TODAYS SPORTING EVENTS [COLOR=red](Μadtitansports)[/COLOR][/B]',
 '[B][COLOR=white][COLOR gold][B]TheANONYMOUS[/COLOR][COLOR cyan] EVENTOS DESPORTIVOS  [/B][/COLOR]',
 '[B][COLOR=white]AO VIVO AGORA [COLOR lime](SHOW DE BOLA)[/COLOR][/B]',
 '[B][COLOR=white]LIVE SPORTS [COLOR orange](daddylive)[/COLOR][/B]'])
#'[B][COLOR=white]Daddylive [COLOR=olive](All)[/COLOR][/B]'])



    if call:
        if call < 1:
            return
        func = funcs[call-14]
        return func()
    else:
        func = funcs[call]
        return func()
    return 




def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.microjen/get_list/http://gknwizard.eu/repo/Builds/GKoBu/xmls/search_matches.json",return)')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.the-loop/sportjetextractors/search_dialog/*")')
    xbmcgui.Dialog().notification("[B][COLOR orange]Loop[/COLOR][/B]",'[COLOR white]Για ευκολία, πληκτρολογήστε NBA ή Basket ή FOOTBALL ή Soccer κ.τ.λ (πεζά ή κεφαλαία) και περιμένετε ...[/COLOR]' , icon ='special://home/addons/plugin.image.World/resources/media/addonset foto/the-loop.png')

def click_3():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.sporthdme/?description&iconimage=C%3a%5cPortableApps%5ckodi%5cKodi%20World%5cKodi%5cportable_data%5caddons%5cplugin.video.sporthdme%5cicon.png&mode=5&name=%5bB%5d%5bCOLOR%20white%5dLIVE%20EVENTS%5b%2fCOLOR%5d%5b%2fB%5d&url=https%3a%2f%2f1.livesoccer.sx%2f")')

def click_4():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.vstream/?function=callpluging&sFav=callpluging&site=cHome&siteUrl=SPORT_LIVE&title=Sports%20")')

def click_5():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.microjen/get_list/https://l3grthu.com/ez/endzone.xml",return)')

def click_6():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.Rising.Tides)')

def click_7():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.winner/?lGZvtEXcRGby92VgkGZvtEXclGZvtGXcNHcwFUZsJWY0J3bQxFX6M0JgojI0JXYuFmZiACLnkUSxkWMxkUax8WanAiOi42bpR3YhJye9diZpdmLlZXasxFXhlGZl1GXcNXZjJXdvNXZyxFXyVmbul2du8WZklmdu4WanVHbwxFXz52bkRWYcxVY0FGZfVGbiFGdy9GccxVak92ScxFZsJ3bXBSak92ScxVak92acx1cwBXQlxmYhRncvBFXcpzQnAiOiIXZ0N3bwJCIscSXC9yWhRmbldWQgIXZW1lQbdCI6ICblJWYsJCIscyZwpmL0JXYuFmZcxVYpRWZtxFXzV2YyV3bzVmccxlcl5mbpdnLvVGZpZnLul2Z1xGccx1cu9GZkFGXcFGdhR2XlxmYhRncvBHXc")')

def click_8():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.nemesisaio/?description=%5bCOLOR%20yellow%5dLets%20Watch%20Sports%5b%2fCOLOR%5d&fanart=0&iconimage=C%3a%5cPortableApps%5ckodi%5cKodi%20World%5cKodi%5cportable_data%5caddons%5cplugin.video.nemesisaio%5cresources%5cImages%5cSports.gif&mode=40&name=%5bCOLOR%20lime%5d%5bB%5dSoccer%20Streams%20%5bCOLOR%20red%5d%7c%5bCOLOR%20yellow%5dFootie%20(%20Soccer%20)%5b%2fB%5d%5b%2fCOLOR%5d&url=FOOTIE")')

def click_9():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.thegroove360/thegroove/scripters/Mr_Dupont/path%3DSport_sport.xml")')

def click_10():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.thegroove360/thegroove/scripters/Soter/path%3Dsport_rojadirecta_rojadirecta.php")')

def click_11():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.madtitansports/sportjetextractors/games/SportTVGuide")')

def click_12():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.desporto.theanonymous/?fanart=http%3a%2f%2fmilhano.pt%2fftp-milhano%2faladotv%2fTheAnonymous.Desporto%2fdesp_fanart.jpg&mode=1&name=%5bCOLOR%20yellow%5d%5bB%5dEVENTOS%20DESPORTIVOS%5b%2fB%5d%5b%2fCOLOR%5d&url=http%3a%2f%2fmilhano.pt%2fftp-milhano%2faladotv%2fTheAnonymous.Desporto%2fsportsonline2%2f")')

def click_13():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.showdebola/?action=aovivo&iconimage=C%3a%5cPortableApps%5ckodi%5cKodi%20World%5cKodi%5cportable_data%5caddons%5cplugin.video.showdebola%5cicon.png&name=AO%20VIVO%20AGORA")')
    
def click_14():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.daddylive/?mode=menu&serv_type=sched",return)')



live_now()
