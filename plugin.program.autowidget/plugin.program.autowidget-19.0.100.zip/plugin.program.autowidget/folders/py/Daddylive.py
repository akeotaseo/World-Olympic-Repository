import xbmc, xbmcgui

def daddylive():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7, click_8, click_9, click_10, click_11, click_12, click_13, click_14)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]~ Daddylive ~[/COLOR][/B]', 
['[COLORred][B]Daddylive[/COLOR][/B] (microjen)',
 '[B][COLOR=white]Daddylive[/COLOR][/B]',
 '[COLOR=white]Live Sports[/COLOR] (gratis)',
 '[COLOR=white]Sports Genres[/COLOR] (vstream)',
 '[COLOR red][B]Daddylive(test)[/COLOR][/B] (microjen)',
 '[COLORgoldenrod] Mixed Live Sports Events[/COLOR] (Asgard - microjen)',
 '[COLOR=white]Scheduled Live Events[/COLOR] (DaddyLiveHD)',
 '[COLOR white]Live Sports[/COLOR]  (Atlas)',
 '[COLOR=white]Daddylive[/COLOR] (the-loop)',
 '[COLOR=white]Daddylive[/COLOR] (Μadtitansports)',
 '[COLOR=white]DADDYLIVE[/COLOR] (vnmedia)',
 '[B][COLOR=white]Live Events[/COLOR][/B] (bolt)',
 '[B][COLORwhite][I]>>>> Live Sport--Click >>>>[/I][/COLOR][/B] (blsport)',

 '[B]                                                                                             [COLOR grey]Back[/COLOR][/B]'])


    if call:
        if call < 0:
            return
        func = funcs[call-14]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.microjen/daddylive?mode=menu&serv_type=sched",return)')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.daddylive/?mode=menu&serv_type=sched",return)')

def click_3():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.gratis/?_id&description=Live%20Sports&episode_number&fanart=C%3a%5cPortableApps%5ckodi%5cMy%20KODI%2021%5cKodi%5cportable_data%5caddons%5cplugin.video.gratis%5cfanart.jpg&foldername&icon=C%3a%5cPortableApps%5ckodi%5cMy%20KODI%2021%5cKodi%5cportable_data%5caddons%5cplugin.video.gratis%5cicon.png&mediatype&mode=live_main&name=Live%20Sports&name2&page&season_number&url",return)')

def click_4():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.vstream/?function=showGenres&sFav=showGenres&site=daddyhd&siteUrl=%2f&title=Sports%20",return)')

def click_5():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.microjen/sportjetextractors/games/Daddylive",return)')

def click_6():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://script.module.mixedsports/?mode=menu&serv_type=sched",return)')

def click_7():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.daddylivehd/?mode=menu&serv_type=sched",return)')

def click_8():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.atlas/?mode=menu&serv_type=sched",return)')

def click_9():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.the-loop/sportjetextractors/games/Daddylive",return)')

def click_10():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.madtitansports/sportjetextractors/games/Daddylive",return)')

def click_11():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.vnmedia/resources/lib/mkd/onthethao/daddylive/index_daddy/?_pickle_=80049531000000000000007d94288c075f7469746c655f948c0944414444594c495645948c076974656d5f6964948c0964616464796c69766594752e",return)')


def click_12():
    xbmcgui.Dialog().notification("[B][COLOR orange]Επιλέξτε[/COLOR][/B]", "[COLOR white][B]Live Events...[/B][/COLOR]", sound=False, icon=
    'special://home/addons/plugin.program.downloader19/resources/media/Notify.png')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.bolt/",return)')


def click_13():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.blsport/")')
    xbmcgui.Dialog().notification("[B][COLOR orange]Επιλέξτε[/COLOR][/B]", "[COLOR white][B][COLORwhite][I]>>>> Live Sport--Click >>>>[/I][/COLOR][/B][/COLOR]", sound=False, icon=
    'special://home/addons/plugin.program.downloader19/resources/media/Notify.png')



def click_14():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.autowidget/folders/py/Live_Now.py")')
daddylive()
