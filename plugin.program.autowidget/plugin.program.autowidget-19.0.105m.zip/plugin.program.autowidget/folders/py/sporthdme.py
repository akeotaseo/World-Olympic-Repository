import xbmc, xbmcgui


def sporthdme():
    funcs = (click_1, click_2, click_3)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]~ sporthdme ~[/COLOR][/B]', 
['[B][COLOR gold]Alternative LIVE EVENTS[/COLOR][/B]',
 '[B][COLOR white]LIVE EVENTS[/COLOR][/B]',
 
 '[B]                                                                                             [COLOR grey]Back[/COLOR][/B]'])

    if call:
        if call < 0:
            return
        func = funcs[call-3]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.sporthdme/?description&iconimage=C%3a%5cPortableApps%5ckodi%5cMy%20KODI%2020%5cKodi%5cportable_data%5caddons%5cplugin.video.sporthdme%5cicon.png&mode=15&name=%5bB%5d%5bCOLOR%20gold%5dAlternative%20LIVE%20EVENTS%5b%2fCOLOR%5d%5b%2fB%5d&url=https%3a%2f%2fliveon.sx%2fprogram",return)')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.sporthdme/?description&iconimage=C%3a%5cPortableApps%5ckodi%5cMy%20KODI%2020%5cKodi%5cportable_data%5caddons%5cplugin.video.sporthdme%5cicon.png&mode=5&name=%5bB%5d%5bCOLOR%20white%5dLIVE%20EVENTS%5b%2fCOLOR%5d%5b%2fB%5d&url=https%3a%2f%2fmy.livesoccer.sx%2f",return)')

def click_3():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.autowidget/folders/py/Live_Now.py")')

sporthdme()
