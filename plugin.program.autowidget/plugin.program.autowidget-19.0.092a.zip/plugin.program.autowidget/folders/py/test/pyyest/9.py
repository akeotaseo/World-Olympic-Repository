﻿import xbmc



xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.youtube/kodion/search/list/",return)')