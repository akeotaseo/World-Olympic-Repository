import xbmc, xbmcgui


def search_movies():
    funcs = (click_1, click_2, click_3, click_4)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]Αναζήτηση ... [/COLOR][/B]', 
['[B][COLOR=orange]Atlas[/COLOR][/B]',
 '[B][COLOR=blue]Alive[COLOR=white]GR[/COLOR][/B]',
 '[B][COLOR=yellow]CartoonsGR[/COLOR][/B]',
 '[B][COLOR=cyan]E-Radio[/COLOR][/B]'])

    if call:
        if call < 0:
            return
        func = funcs[call-4]
        return func()
    else:
        func = funcs[call]
        return func()
    return 


def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&mode=4&url=new)')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.AliveGR/?action=search_index)')

def click_3():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&mode=18)')

def click_4():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.audio.eradio.gr/?action=search)')

search_movies()