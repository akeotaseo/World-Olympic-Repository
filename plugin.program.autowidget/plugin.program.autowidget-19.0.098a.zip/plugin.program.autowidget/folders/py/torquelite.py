import xbmc, xbmcgui


def torquelite():
    funcs = (click_1, click_2, click_3, click_4, click_5)
    call = xbmcgui.Dialog().select('[B][COLOR=green]~ Torque Lite ~[/COLOR][/B]', 
['[I][COLORlime] --- [COLORyellow] Search Scrapers [COLORlime] --- [/COLOR][/I]',
 '[I][COLORlime] --- [COLORyellow] Soccer LIVE [COLORlime] --- [/COLOR][/I]',
 '[I][COLORlime] --- [COLORyellow] Basket Live [COLORlime] --- [/COLOR][/I]'])


    if call:
        if call < 0:
            return
        func = funcs[call-5]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.torquelite/pvr_sport_search/search/*?include=16",return)')
    xbmcgui.Dialog().notification("[B][COLOR orange]Αναζήτηση Ζωντανών Αγώνων[/COLOR][/B]",'[COLOR white] Πληκτρολογήστε NBA ή Basket ή FOOTBALL ή Soccer ή Tennis ή το όνομα του Αθλητή ή της Ομάδας κ.τ.λ (πεζά ή κεφαλαία) και περιμένετε ...[/COLOR]' , icon ='special://home/addons/plugin.image.World/resources/media/addonset foto/sports-app.png')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.torquelite/sportjetextractors/games/StrikeEurope",return)')

def click_3():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.torquelite/sportjetextractors/games/BoxNBA",return)')

def click_4():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.tvone1112)')
    
def click_5():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.tvone112/")')

torquelite()
