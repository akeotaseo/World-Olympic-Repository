import xbmc, xbmcgui


def extraaddons():
    funcs = (click_1, click_2, click_3, click_4, click_5)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]~ ExtraAddons ~[/COLOR][/B]', 
['[B][COLOR=white]Extra Addons[/COLOR][/B] MicroJen',
 '[B][COLOR=white]Navy Seal[/COLOR][/B] Movies',
 '[B][COLOR=white]Navy Seal[/COLOR][/B] Series',
 '[B][COLOR=white]Extra Addons[/COLOR][/B] TheCrew',
 '[B][COLOR=red]Wolf[/COLOR][/B] '])


    if call:
        if call < 0:
            return
        func = funcs[call-5]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('ActivateWindow(Videos,"plugin://plugin.video.microjen/get_list/http://gknwizard.eu/repo/Builds/TechNEWsology/UpdaterMatrix/Extra_Addons_Xml/extra_addons.json")')

def click_2():
    xbmc.executebuiltin('ActivateWindow(Videos,"plugin://plugin.video.microjen/get_list/https://southpawlefty2468rocky.com/southpaw/navyseal19/movies/movies main19.json")')

def click_3():
    xbmc.executebuiltin('ActivateWindow(Videos,"plugin://plugin.video.microjen/get_list/https://southpawlefty2468rocky.com/southpaw/navyseal19/tvshows/one click tv shows/one click tv shows main19.json")')

def click_4():
    xbmc.executebuiltin('ActivateWindow(Videos,"plugin://plugin.program.autowidget/?mode=group&group=05addons-1620588071.6954536&refresh=&reload=")')
    
def click_5():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.autowidget/folders/py/Wolf/DialogWolf.py")')


extraaddons()
