import xbmc, xbmcgui


def ShortCut():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7, click_8, click_9, click_10, click_11, click_12)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]~ Mix~[/COLOR][/B]', 
['[COLOR=white]New Movies - One Click[/COLOR] (mj-Halcyon)',
 '[COLOR=white]Ταινιες - Προβολές[/COLOR] (blacklodge)',
 '[COLOR=white]Σειρές -  Με πολλούς ψήφους[/COLOR] (blacklodge)',
 '[COLOR=white]Alternative LIVE EVENTS[/COLOR] (sporthdme)',
 '[COLOR=white]Live Sports[/COLOR] (Gratis-daddylive)',
 '[COLOR=white]SPORTS TV[/COLOR] (tvone112)',
 '[COLOR=white]LIVE TV[/COLOR] (daddylive)',
 '[COLOR=white]Xrysoi - Παιδικά Μεταγλωτισμένα[/COLOR] (mj-cartoonsgr)',
 '[COLOR=white]Xrysoi - Παιδικά Υπότιτλοι[/COLOR] (mj-cartoonsgr)',
 '[COLOR=white]Ζωντανή Τηλεόραση[/COLOR] (AliveGR)',
 '[COLOR=white]Sophisticated[/COLOR] (eradio)',
 '[COLOR=white]Αναζήτηση[/COLOR] (YouTube)'])


    if call:
        if call < 0:
            return
        func = funcs[call-12]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.microjen/get_list/https://mfirepo.github.io/hal/newrels.json",return)') 

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.blacklodge/?action=movies&url=trending")') 

def click_3():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.blacklodge/?action=tvshows&url=views")')

def click_4():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.sporthdme/?description&iconimage=C%3a%5cPortableApps%5ckodi%5ckodi%20World%2020%5cKodi%5cportable_data%5caddons%5cplugin.video.sporthdme%5cicon.png&mode=15&name=%5bB%5d%5bCOLOR%20gold%5dAlternative%20LIVE%20EVENTS%5b%2fCOLOR%5d%5b%2fB%5d&url=https%3a%2f%2fliveon.sx%2fprogram")')

def click_5():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.gratis/?_id&description=Live%20Sports&episode_number&fanart=C%3a%5cPortableApps%5ckodi%5cMy%20KODI%2020%5cKodi%5cportable_data%5caddons%5cplugin.video.gratis%5cfanart.jpg&foldername&icon=C%3a%5cPortableApps%5ckodi%5cMy%20KODI%2020%5cKodi%5cportable_data%5caddons%5cplugin.video.gratis%5cicon.png&mediatype&mode=live_main&name=Live%20Sports&name2&page&season_number&url",return)')

def click_6():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.tvone112/list_channels/38",return)')

def click_7():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.daddylive/?mode=menu&serv_type=live_tv",return)')

def click_8():
    xbmc.executebuiltin('PlayMedia("plugin://plugin.video.microjen/run_plug/plugin.video.cartoonsgr%2F%3Fdescription%26amp%3Biconimage%3Dnone%26amp%3Bmode%3Dxrysoiposts%26amp%3Bname%3D%2520%26amp%3Burl%3Dhttps%3A%2F%2Fxrysoi.pro%2Fcategory%2F%25ce%25ba%25ce%25b9%25ce%25bd-%25cf%2583%25cf%2587%25ce%25ad%25ce%25b4%25ce%25b9%25ce%25b1%2F")')

def click_9():
    xbmc.executebuiltin('PlayMedia("plugin://plugin.video.microjen/run_plug/plugin.video.cartoonsgr%2F%3Fdescription%26amp%3Biconimage%3Dnone%26amp%3Bmode%3Dxrysoiposts%26amp%3Bname%3D%2520%26amp%3Burl%3Dhttps%3A%2F%2Fxrysoi.pro%2Fcategory%2F%25ce%25ba%25ce%25b9%25ce%25bd-%25cf%2583%25cf%2587%25ce%25ad%25ce%25b4%25ce%25b9%25ce%25b1-subs%2F")')

def click_10():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.AliveGR/?action=live_tv&title=%ce%96%cf%89%ce%bd%cf%84%ce%b1%ce%bd%ce%ae%20%ce%a4%ce%b7%ce%bb%ce%b5%cf%8c%cf%81%ce%b1%cf%83%ce%b7")')

def click_11():
    xbmc.executebuiltin('ActivateWindow(10502,"plugin://plugin.audio.eradio.gr/?action=radios&title=Sophisticated&url=http%3a%2f%2feradio.mobi%2fcache%2f1%2f1%2fmedialist_categoryID11.json")')

def click_12():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.youtube/kodion/search/list/")')

ShortCut()
