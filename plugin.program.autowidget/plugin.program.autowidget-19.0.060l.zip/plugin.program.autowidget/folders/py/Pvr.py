import xbmc, xbmcgui


def pvr():
    funcs = (click_1, click_2, click_3)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]~ PVR~[/COLOR][/B]', 
['[B][COLOR=white][COLOR green]Ιστότοποι[/COLOR][/COLOR][/B]',
 '[B][COLOR=white]Καθαρισμός δεδομένων[/COLOR][/B]',
 '[B][COLOR=white][COLOR blue]Προσθήκη/Αλλαγή πύλης[/COLOR] [/COLOR][/B]'],)


    if call:
        if call < 0:
            return
        func = funcs[call-3]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.autowidget/folders/py/Browser_Portal_Stalker.py")')

def click_2():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.autowidget/folders/py/ClearingPvrData.py")')

def click_3():
    xbmc.executebuiltin('Addon.Opensettings(pvr.stalker)')



pvr()
