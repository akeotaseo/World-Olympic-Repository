import xbmc, xbmcgui


def OneClick():
    funcs = (click_1, click_2, click_3)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]~ OneClick ~[/COLOR][/B]', 
['[B][COLOR=white][COLORyellow][B]New Movies Free[/COLOR][/COLOR][/B]',
 '[B][COLOR crimson][B]Patriot [/B][COLOR white][B] New Free Linked [/B][COLOR dodgerblue][B] Movies[/B][/COLOR]][/B]',
 '[B][COLOR=white][COLORyellow][B]TV Shows[/COLOR][/COLOR][/B]'])


    if call:
        if call < 0:
            return
        func = funcs[call-3]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.microjen/get_list/https://mad-eric.bitbucket.io/newrels.xml")')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.microjen/get_list/https://bitbucket.org/Mad-Eric/textfiles/raw/master/tvsel.json")')

def click_3():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.patriot/?all_w=%7b%7d&data=%20&dates=%20&description=New%20Releases&eng_name=%20&episode=%20&fanart=http%3a%2f%2fdjaythemes.xyz%2fPatriot%2fPatriot%20icons%2ffanart.jpg&fav_status=false&heb_name=%20&iconimage=http%3a%2f%2fdjaythemes.xyz%2fPatriot%2fPatriot%20icons%2fMovies%2ffreemovies.png&id&image_master&isr=0&last_id&mode=189&mypass&name=%5bCOLOR%20crimson%5d%5bB%5dPatriot%20%5b%2fB%5d%5bCOLOR%20white%5d%5bB%5d%20New%20Free%20Linked%20%5b%2fB%5d%5bCOLOR%20dodgerblue%5d%5bB%5d%20Movies%5b%2fB%5d%5b%2fCOLOR%5d&original_title=%20&search_db&season=%20&show_original_year=%20&tmdbid=%20&url=http%3a%2f%2fdjaythemes.xyz%2fPatriot%2fjson%2fMovies%2ffree2021.json&video_data=%7b%22title%22%3a%20%22%5bCOLOR%20crimson%5d%5bB%5dPatriot%20%5b%2fB%5d%5bCOLOR%20white%5d%5bB%5d%20New%20Free%20Linked%20%5b%2fB%5d%5bCOLOR%20dodgerblue%5d%5bB%5d%20Movies%5b%2fB%5d%5b%2fCOLOR%5d%22%2c%20%22mediatype%22%3a%20%22movie%22%2c%20%22TVshowtitle%22%3a%20%22%22%2c%20%22season%22%3a%200%2c%20%22episode%22%3a%200%2c%20%22OriginalTitle%22%3a%20%22%20%22%2c%20%22rating%22%3a%20%220%22%2c%20%22plot%22%3a%20%22New%20Releases%22%2c%20%22Tag%22%3a%20%22189%22%2c%20%22trailer%22%3a%20%22%22%2c%20%22id%22%3a%20%22%22%7d",)')

OneClick()
