import os, xbmc, xbmcvfs, xbmcgui, webbrowser


def browser_portal_stalker():
        choice = xbmcgui.Dialog().yesno('[COLOR orange]Tk[/COLOR]', '[COLOR white]Για καλύτερα αποτελέσματα προσθέστε νέους                     διακομιστές στις πύλες, αντιγράφοντας την [COLOR lime]Διεύθυνση MAC[COLOR white] και την [COLOR lime]Διεύθυνση Διακομιστή[COLOR white] από τους παρακάτω ιστότοπους.[/COLOR]',
                                        nolabel='[COLOR orange]Άκυρο[/COLOR]',yeslabel='[COLOR lime]Ιστότοποι[/COLOR]')

        if choice == 1: SitesMenu()

def SitesMenu():
    dialog = xbmcgui.Dialog()
    funcs = (site1, site2, site3)
    xbmcgui.Dialog().ok("[COLOR orange]Αλλαγή πύλης [/COLOR]", "[B][COLOR white]Ρυθμίσεις Stalker > Πύλη προς αλλαγή > Προσθήκη [COLOR lime]Διεύθυνσης MAC[COLOR white] και [COLOR lime]Διεύθυνσης Διακομιστή[COLOR white].                        Μετά από κάθε αλλαγή χρησιμοποιούμε τον καθαρισμό δεδομένων.[/COLOR][/B]")
    call = dialog.select('[B][COLOR=orange]Ιστότοποι Portal Stalker...[/COLOR][/B]', 
['[B][COLOR=white]iptvlinkseuro[/COLOR][/B]', '[B][COLOR=white]iptvxtreamcodes[/COLOR][/B]','[B][COLOR=white]iptvrun[/COLOR][/B]'])

    if call:
        if call < 0:
            return
        func = funcs[call-3]
        return func()
    else:
        func = funcs[call]
        return func()
    return 

def platform():
    if xbmc.getCondVisibility('system.platform.android'):
        return 'android'
    elif xbmc.getCondVisibility('system.platform.linux'):
        return 'linux'
    elif xbmc.getCondVisibility('system.platform.windows'):
        return 'windows'
    elif xbmc.getCondVisibility('system.platform.osx'):
        return 'osx'
    elif xbmc.getCondVisibility('system.platform.atv2'):
        return 'atv2'
    elif xbmc.getCondVisibility('system.platform.ios'):
        return 'ios'

myplatform = platform()

def site1():
    if myplatform == 'android': opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://iptvlinkseuro.blogspot.com' ) )
    else: opensite = webbrowser . open('https://iptvlinkseuro.blogspot.com')

def site2():
    if myplatform == 'android': opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://iptvxtreamcodes.com' ) )
    else: opensite = webbrowser . open('https://iptvxtreamcodes.com')

def site3():
    if myplatform == 'android': opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://iptvrun.com/' ) )
    else: opensite = webbrowser . open('https://iptvrun.com/')


browser_portal_stalker()
