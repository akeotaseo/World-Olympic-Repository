import os, xbmc, xbmcvfs, xbmcgui, xbmcaddon, shutil, glob


def acechannels():
    funcs = (click_1, click_2)
    call = xbmcgui.Dialog().select('[B][COLOR=blue]~ acechannels ~[/COLOR][/B]', 
['[B][COLOR=blue]Find Channels[/COLOR][/B]',
 '[B][COLOR=o]Find links[/COLOR][/B]'])
 #'[B][COLOR=white]TvOne111[/COLOR][/B]',
 #'[B][COLOR=white]TvOne1112[/COLOR][/B]'])


    if call:
        if call < 0:
            return
        func = funcs[call-2]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.playlistloader/?cache=0&iconimage=C%3a%5cPortableApps%5ckodi%5cMy%20kodi%5cKodi%5cportable_data%5caddons%5cplugin.video.playlistloader%5cresources%5cimages%5cdefault-list-image.png&logos&mode=2&name=%5b1%20OFF...%5d&url=https%3a%2f%2fraw.githubusercontent.com%2fakeotaseo%2fworld_repo%2fmain%2fUpdater_Matrix%2fXML%2fchannels_fulltime.xml&uuid=20f40d40-3174-4247-9013-ee285875f52b",return)')
    xbmcgui.Dialog().notification("[B][COLOR blue]Ace[/COLOR][/B]",'[COLOR white]Με βάση τους αριθμούς, βρείτε ποια κανάλια αντιστοιχούν σε Option  στο [/COLOR][B]Find links[/B]', icon ='https://github.com/akeotaseo/world_repo/blob/main/iloveimg-resized%20(2)/ace.png?raw=true')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10001,"plugin://script.module.horus/?eydhY3Rpb24nOiAnc2VhcmNoJywgJ2ZhbmFydCc6ICdDOlxcUG9ydGFibGVBcHBzXFxrb2RpXFxNeSBrb2RpXFxLb2RpXFxwb3J0YWJsZV9kYXRhXFxhZGRvbnNcXHNjcmlwdC5tb2R1bGUuaG9ydXNcXGZhbmFydC5qcGcnLCAnaWNvbic6ICdDOlxcUG9ydGFibGVBcHBzXFxrb2RpXFxNeSBrb2RpXFxLb2RpXFxwb3J0YWJsZV9kYXRhXFxhZGRvbnNcXHNjcmlwdC5tb2R1bGUuaG9ydXNcXGljb24ucG5nJywgJ2xhYmVsJzogJ0ZpbmQgbGlua3MgLi4uJ30%3d",return)')
    xbmcgui.Dialog().notification("[B][COLOR orange]Horus[/COLOR][/B]",'[COLOR white]Πατήστε Τέλος και επιλέξτε Option  στο [/COLOR][B]Find links...............................[/B]', icon ='https://github.com/akeotaseo/world_repo/blob/main/iloveimg-resized%20(2)/horus.jpg?raw=true')

def click_3():
    xbmc.executebuiltin('PlayMedia("special://home/addons/plugin.program.autowidget/folders/py/ace/acechannels.py,return")')

def click_4():
    xxbmc.executebuiltin('RunScript("special://home/addons/plugin.program.autowidget/folders/py/ace/acechannels.py,return")')


acechannels()

