import xbmc, xbmcgui


def extraaddons():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]~ ExtraAddons ~[/COLOR][/B]', 
['[B][COLOR=white]Extra Addons[/COLOR][/B] MicroJen',
 '[B][COLOR=white]Navy Seal[/COLOR][/B] Movies',
 '[B][COLOR=white]Navy Seal[/COLOR][/B] Series'
 #'[B][COLOR=white]Extra Addons[/COLOR][/B] TheCrew',
 #'[B][COLOR=green]Install[/COLOR][/B] The Crew Repo',
 #'[B][COLOR=red]Wolf[/COLOR][/B]'
 ])


    if call:
        if call < 0:
            return
        func = funcs[call-6]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('ActivateWindow(Videos,"plugin://plugin.video.microjen/get_list/http://gknwizard.eu/repo/Builds/TechNEWsology/UpdaterMatrix/Extra_Addons_Xml/extra_addons.json")')

def click_2():
    xbmc.executebuiltin('ActivateWindow(Videos,"plugin://plugin.video.microjen/get_list/https://southpawlefty2468rocky.com/southpaw/navyseal19/movies/movies main19.json")')

def click_3():
    xbmc.executebuiltin('ActivateWindow(Videos,"plugin://plugin.video.microjen/get_list/https://southpawlefty2468rocky.com/southpaw/navyseal19/tvshows/one click tv shows/one click tv shows main19.json")')

def click_4():
    xbmc.executebuiltin('PlayMedia("plugin://plugin.program.autowidget/?mode=path&group=05addons-05&path_id=color_orchidcolor_bcolor_whitecolorcolor_orchidcolorcolor_whitemad_titancolorb-1620588079.7770407&refresh=&reload=")')
    
def click_5():
    xbmc.executebuiltin('RunScript("special://home/addons/service.World.Build/PY/Wolf/InstalTheCrewRepository.py")')

def click_6():
    xbmc.executebuiltin('RunScript("special://home/addons/service.World.Build/PY/Wolf/DialogWolf.py")')

def click_7():
    xbmc.executebuiltin('ActivateWindow(Videos,"plugin://plugin.video.microjen/get_list/m3ucat|https://documentarys.do.am/youtube/filme/tv_channels_vodstest_plus.m3u|VOD Adults",return)')

extraaddons()
