﻿import xbmc



xbmc.executebuiltin('PlayMedia("plugin://plugin.video.microjen/run_plug/plugin.video.cartoonsgr%2F%3Fdescription%26amp%3Biconimage%3Dnone%26amp%3Bmode%3Dxrysoiposts%26amp%3Bname%3D%2520%26amp%3Burl%3Dhttps%3A%2F%2Fxrysoi.pro%2Fcategory%2F%25ce%25ba%25ce%25b9%25ce%25bd-%25cf%2583%25cf%2587%25ce%25ad%25ce%25b4%25ce%25b9%25ce%25b1-subs%2F")')