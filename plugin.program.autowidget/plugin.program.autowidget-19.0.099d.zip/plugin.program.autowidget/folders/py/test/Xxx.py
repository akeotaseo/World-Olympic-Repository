import xbmc, xbmcgui


def Xxx():
    funcs = (click_1, click_2, click_3, click_4)
    call = xbmcgui.Dialog().select('[B][COLOR=red]                                            ~ XxX ~[/COLOR][/B]', 
['[B][COLOR=white][COLOR aqua]Adult 2021 IPTV Channels[/COLOR][/COLOR][/B]',
 '[B][COLOR=white][COLOR aqua]Adult IPTV Channels - (1)[/COLOR][/COLOR][/B]',
 '[B][COLOR=white]                                                      TvOne111[/COLOR][/B]',
 '[B][COLOR=white]                                                     TvOne1112[/COLOR][/B]'])


    if call:
        if call < 0:
            return
        func = funcs[call-4]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.live.streamspro/?mode=1&url=http%3a%2f%2fwww.mediafire.com%2ffile%2f78tqwk2mfmfoend%2fadult_2021.txt%2ffile&sf_options=fanart%3Dhttps%3A%2F%2Fimgur.com%2FZv6juaL.jpg%26meta%3Dlabel%253D%25255BCOLOR%252Baqua%25255DAdult%252B2021%252BIPTV%252BChannels%25255B%25252FCOLOR%25255D%26_options_sf",return)')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.live.streamspro/?mode=1&url=http%3a%2f%2fwww.mediafire.com%2ffile%2fyty6r20skytvzin%2fadultiptv1.txt%2ffile&sf_options=fanart%3Dhttps%3A%2F%2Fimgur.com%2FZv6juaL.jpg%26meta%3Dlabel%253D%25255BCOLOR%252Baqua%25255DAdult%252BIPTV%252BChannels%252B-%252B%2525281%252529%25255B%25252FCOLOR%25255D%26_options_sf",return)')

def click_3():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.tvone111,return)')

def click_4():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.tvone1112,return)')


Xxx()
