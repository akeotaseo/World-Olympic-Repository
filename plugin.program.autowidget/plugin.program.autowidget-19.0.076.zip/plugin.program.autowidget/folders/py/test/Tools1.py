﻿import xbmc, xbmcgui


def t_menu():
    funcs = (click1, click2, click3, click4, click5, click6, click7, click8, click9, click10, click11, click12, click13, click14, click15, click16, click17, click18, click19, click20, click21)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]                                            ~ Εργαλεία ~[/COLOR][/B]', 
['[B][COLOR=white]                               Έλεγχος Αναβάθμισης Πρόσθετων ...[/COLOR][/B]',
 '[B][COLOR=white]                   Αν δεν εμφανίζονται τα Widgets ή τα Εικονίδια ...[/COLOR][/B]',
 '[B][COLOR=white]                                 Καλύτερο streaming στο Βίντεο ...[/COLOR][/B]',
 '[B][COLOR=white]                                         Επιλογή Api Key [COLOR red]YouTube[/COLOR][/B]',
 '[B][COLOR=white]                                            Διαγραφή PVR Stalker[/COLOR][/B]',
 '[B][COLOR=white]                                    Επαναφορά Ενημέρωσης Μενού[/COLOR][/B]',
# '[B][COLOR=white]                                   Έληξε η Συνδρομή μας [COLOR lime]AllDebrid ...[/COLOR][/B]',
# '[B][COLOR=white]                             Έληξε η Συνδρομή μας [COLOR lime]PremiumizeMe ...[/COLOR][/B]',
 '[B][COLOR=white]                                            Εξουσιοδότηση [COLOR lime]Trakt ...[/COLOR][/B]',
 '[B][COLOR=white]                          Έγκριση του λογαριασμού μου [COLOR lime]RealDebrid ...[/COLOR][/B]',
 '[B][COLOR=white]                            Έγκριση του λογαριασμού μου [COLOR lime]AllDebrid ...[/COLOR][/B]',
 '[B][COLOR=white]                       Έγκριση του λογαριασμού μου [COLOR lime]PremiumizeMe ...[/COLOR][/B]',
 '[B][COLOR=white]                                         Εργαλεία G.K.N.Wizard[/COLOR][/B]',
 '[B][COLOR=white]                                              Διαγραφή Indigo...[/COLOR][/B]',
 '[B][COLOR=lime]                            Καθαρή Εγκατάσταση Build [B][COLOR orange]*ΧΩΡΙΣ ΚΩΔΙΚΟ*[/COLOR][/B]',
 '[B][COLOR=white]                                                  G.K.N.Wizard[/COLOR][/B]',
 '[B][COLOR=white]                                          Αφαίρεση πρόσθετων[/COLOR][/B]',
 '[B][COLOR=white]                                    Καθαρισμός παρόχων-Cache[/COLOR][/B]',
 '[B][COLOR=white]                                                    Save Data[/COLOR][/B]',
 '[B][COLOR=white]                                                   Reload Skin[/COLOR][/B]',
 '[B][COLOR=white]                                         Enable/Disable Addons[/COLOR][/B]',
 '[B][COLOR=white]                                                    Speed Test[/COLOR][/B]',
 '[B][COLOR=white]                                              Εργαλεία AliveGR[/COLOR][/B]'])

    if call:
        if call < 0:
            return
        func = funcs[call-21]
        return func()
    else:
        func = funcs[call]
        return func()
    return 


def click1():
    xbmc.executebuiltin('RunPlugin(plugin://plugin.program.G.K.N.Wizard/?mode=kodi17fix)')

def click2():
    xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.autowidget/folders/py/FixWidget.py)')

def click3():
    xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.autowidget/folders/py/AdvancedSettings.py)')

def click4():
    xbmc.executebuiltin('ActivateWindow(10001,plugin://plugin.program.downloader19/?mode=1,return)')

def click5():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.autowidget/folders/py/StalkerDelete.py")')

def click6():
    xbmc.executebuiltin('RunPlugin(plugin://plugin.program.downloader19/?url=https%3A%2F%2Fgknwizard.eu%2Frepo%2FBuilds%2FTechNEWsology%2FUpdaterMatrix%2FBackgrounds_With_Widgets.zip&mode=16&name=Backgrounds with Widgets)')
    xbmc.sleep(5000)
    xbmc.executebuiltin('RunPlugin(plugin://plugin.program.downloader19/?url=https%3A%2F%2Fgknwizard.eu%2Frepo%2FBuilds%2FTechNEWsology%2FUpdaterMatrix%2Fskinshortcuts_2.zip&mode=9&name=Skinshortcuts with Widgets)')
    xbmc.sleep(10000)
    xbmc.executebuiltin("LoadProfile(Master user)")

#def click7():
#    xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.super.favourites/folders/PY/ResolverOffAllDebrid.py)')

#def click8():
#    xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.super.favourites/folders/PY/ResolverOffPremiumizeMe.py)')

def click7():
    xbmc.executebuiltin('RunPlugin(plugin://plugin.video.theoath/?click=authTrakt)')

def click8():
    xbmc.executebuiltin('RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)')

def click9():
    xbmc.executebuiltin('RunPlugin(plugin://script.module.resolveurl/?mode=auth_ad)')

def click10():
    xbmc.executebuiltin('RunPlugin(plugin://script.module.resolveurl/?mode=auth_pm)')

def click11():
    xbmc.executebuiltin('ActivateWindow(10001,plugin://plugin.program.G.K.N.Wizard/?mode=maint)')

def click12():
    xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.autowidget/folders/py/indigoDel.py)')

def click13():
    xbmc.executebuiltin('RunPlugin(plugin://plugin.program.downloader19/?url=https%3A%2F%2Fgknwizard.eu%2Frepo%2FBuilds%2FTechNEWsology%2FBuilds%2FTechNEWSology_v1.1%28Matrix%29.zip&mode=11&name=TechNEWSolgy%20Build%20%28Matrix%29)')

def click14():
    xbmc.executebuiltin('ActivateWindow(10001,plugin://plugin.program.G.K.N.Wizard)')

def click15():
    xbmc.executebuiltin('RunPlugin(plugin://plugin.program.G.K.N.Wizard/?mode=removeaddons)')

def click16():
    xbmc.executebuiltin('RunPlugin(plugin://plugin.program.G.K.N.Wizard/?mode=clearcache)')

def click17():
    xbmc.executebuiltin('ActivateWindow(10001,plugin://plugin.program.G.K.N.Wizard/?mode=savedata)')

def click18():
    xbmc.executebuiltin('RunPlugin(plugin://plugin.program.G.K.N.Wizard/?mode=forceskin)')

def click19():
    xbmc.executebuiltin('ActivateWindow(10001,plugin://plugin.program.G.K.N.Wizard/?mode=enableaddons)')

def click20():
    xbmc.executebuiltin('ActivateWindow(10001,plugin://plugin.program.G.K.N.Wizard/?mode=speedtest)')

def click21():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.AliveGR/?click=settings,return)')


t_menu()
