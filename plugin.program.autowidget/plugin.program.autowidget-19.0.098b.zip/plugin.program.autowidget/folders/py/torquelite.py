import xbmc, xbmcgui


def torquelite():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7, click_8, click_9)
    call = xbmcgui.Dialog().select('[B][COLOR=green]~ Torque Lite ~[/COLOR][/B]', 
['[I][COLORyellow] --- [COLORlime] Search Scrapers [COLORlime] --- [/COLOR][/I]',
 '[I][COLORlime] --- [COLORyellow] Soccer LIVE [COLORlime] --- [/COLOR][/I]',
 '[I][COLORlime] --- [COLORyellow] Basket Live [COLORlime] --- [/COLOR][/I]',
 'TENNISBox',
 'SportsBox',
 'StrikeEurope',
 'StrikeAmerican',
 'StrikeMisc',
 '[B]FootyBiteTV[/B]'])


    if call:
        if call < 0:
            return
        func = funcs[call-9]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.torquelite/pvr_sport_search/search/*?include=16",return)')
    xbmcgui.Dialog().notification("[B][COLOR orange]Αναζήτηση Ζωντανών Αγώνων[/COLOR][/B]",'[COLOR white] Πληκτρολογήστε NBA ή Basket ή FOOTBALL ή Soccer ή Tennis ή το όνομα του Αθλητή ή της Ομάδας κ.τ.λ (πεζά ή κεφαλαία) και περιμένετε ...[/COLOR]' , icon ='special://home/addons/plugin.image.World/resources/media/addonset foto/sports-app.png')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.torquelite/sportjetextractors/games/StrikeEurope",return)')

def click_3():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.torquelite/sportjetextractors/games/BoxNBA",return)')

def click_4():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.torquelite/sportjetextractors/games/TENNISBox",return)')

def click_5():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.torquelite/sportjetextractors/games/SportsBox",return)')

def click_6():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.torquelite/sportjetextractors/games/StrikeEurope",return)')
    
def click_7():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.torquelite/sportjetextractors/games/StrikeAmerican",return)')

def click_8():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.torquelite/sportjetextractors/games/StrikeMisc",return)')

def click_9():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.torquelite/sportjetextractors/games/FootyBiteTV",return)')
torquelite()
