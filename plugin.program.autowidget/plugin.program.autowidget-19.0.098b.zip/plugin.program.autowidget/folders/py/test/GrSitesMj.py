import xbmc, xbmcgui


def GrSitesMj():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]~ microjen ~[/COLOR][/B]', 
['[B][COLOR=white]Gamato[/COLOR][/B]',
 '[B][COLOR=green]Tainies-online[/COLOR][/B]',
 '[B][COLOR=gold]Xrysoi[/COLOR][/B]',
 '[B][COLOR=darkmagenta]Gamatomovies[/COLOR][/B]',
 '[B][COLOR=orange]Tainiomania[/COLOR][/B]',
 '[B][COLOR=darkviolet]An1me[/COLOR][/B]'])


    if call:
        if call < 0:
            return
        func = funcs[call-6]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('PlayMedia("plugin://plugin.video.microjen/run_plug/plugin.video.cartoonsgr%2F%3Fdescription%26amp%3Biconimage%3Dnone%26amp%3Bmode%3Dgamatosearch%26amp%3Bname%3D%2520%26amp%3Burl%3Dhttp%3A%2F%2Fgamatotv.info%2F")')

def click_2():
    xbmc.executebuiltin('PlayMedia("plugin://plugin.video.microjen/run_plug/plugin.video.cartoonsgr%2F%3Fdescription%26amp%3Biconimage%3Dnone%26amp%3Bmode%3Dsearchtenies2%26amp%3Bname%3D%2520%26amp%3Burl%3Dhttps%3A%2F%2Ftenies-online.best%2F")')

def click_3():
    xbmc.executebuiltin('PlayMedia("plugin://plugin.video.microjen/run_plug/plugin.video.cartoonsgr%2F%3Fdescription%26amp%3Biconimage%3Dnone%26amp%3Bmode%3Dxrysoisearch%26amp%3Bname%3D%2520%26amp%3Burl%3Dhttps%3A%2F%2Fxrysoi.pro%2F")')

def click_4():
    xbmc.executebuiltin('PlayMedia("plugin://plugin.video.microjen/run_plug/plugin.video.cartoonsgr%2F%3Fdescription%26amp%3Biconimage%3Dnone%26amp%3Bmode%3Dgmoviessearch%26amp%3Bname%3D%2520%26amp%3Burl%3Dhttps%3A%2F%2Fgamatomovies1.gr%2F")')

def click_5():
    xbmc.executebuiltin('PlayMedia("plugin://plugin.video.microjen/run_plug/plugin.video.cartoonsgr%2F%3Fdescription%26amp%3Biconimage%3Dnone%26amp%3Bmode%3Dsearchtmania%26amp%3Bname%3D%2520%26amp%3Burl%3Dhttps%3A%2F%2Ftainio-mania.online%2F")')

def click_6():
    xbmc.executebuiltin('PlayMedia("plugin://plugin.video.microjen/run_plug/plugin.video.cartoonsgr%2F%3Fdescription%26amp%3Biconimage%3Dnone%26amp%3Bmode%3Danimsearch%26amp%3Bname%3D%2520%26amp%3Burl%3Dhttps%3A%2F%2Fan1me.to%2F")')


GrSitesMj()
