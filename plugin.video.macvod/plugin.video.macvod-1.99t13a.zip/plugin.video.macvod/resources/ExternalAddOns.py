import xbmc, xbmcgui


def ExternalAddOns():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7, click_8, click_9, click_10, click_11, click_12, click_13)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]ExternalAddOns[/COLOR][/B]',
['[COLOR=orange]RO[/COLOR] (f4mTester)',
 '[COLOR=orange]RO 1[/COLOR] (live.streamspro)',
 '[COLOR=orange]RO 2[/COLOR] (live.streamspro)',
 '[COLOR=orange]RO 3[/COLOR] (playlistloader)',
 '[COLOR=orange]RO 4[/COLOR] (playlistloader)',
  
  
 '[COLOR=blue]Love4vn[/COLOR] [IPTVSport] (playlistloader)',
 '[COLOR=blue]Love4vn[/COLOR] [Sport] (playlistloader)',
 '[COLOR=blue]Love4vn[/COLOR] [hubsport] (playlistloader)',
 '[COLOR=blue]Love4vn[/COLOR] [VTV_sort] (playlistloader)',

'[COLOR=red]PL[/COLOR] (playlistloader)',

 '[COLOR=yellow]BRAZIL[/COLOR] [aguia.de.fogo] (playlistloader)',
 '[COLOR=aqua]deportes[/COLOR] (live.streamspro)',
  
  
 '[B][COLOR red]XC MAC M3U[/COLOR][/B]'])


    if call:
        if call < 1:
            return
        func = funcs[call-13]
        return func()
    else:
        func = funcs[call]
        return func()
    return 






def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.f4mTester/?mode=playlist&name=IPTV&url=https%3a%2f%2ftinyurl.com%2fmvcwp3k7")')
    #xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.myselect/folders/py/sporthdme.py")')

def click_2():
    xbmc.executebuiltin('ActivateWindow(Videos,"plugin://plugin.video.live.streamspro/?url=http%3A%2F%2Ftinyurl.com%2F56fnkcs3&mode=1&name=Bee+TV&fanart=C%3A%5CUsers%5Cuser%5CAppData%5CRoaming%5CKodi%5Caddons%5Cplugin.video.live.streamspro%5Cfanart.jpg",return)')

def click_3():
    xbmc.executebuiltin('ActivateWindow(Videos,"plugin://plugin.video.live.streamspro/?url=http%3A%2F%2Ftinyurl.com%2F2kv2mvhc&mode=1&name=Bee+TV2&fanart=C%3A%5CUsers%5Cuser%5CAppData%5CRoaming%5CKodi%5Caddons%5Cplugin.video.live.streamspro%5Cfanart.jpg",return)')

def click_4():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.playlistloader/?cache=0&epg&iconimage=C%3a%5cPortableApps%5ckodi%5ckodi%20World%2021%5cKodi%5cportable_data%5caddons%5cplugin.video.playlistloader%5cresources%5cimages%5cdefault-list-image.png&logos&mode=2&name=%5bhttps%3a%2f%2ftinyurl.com%2f24v4rwf8%5d&url=https%3a%2f%2ftinyurl.com%2f24v4rwf8&uuid=9ecc8e59-7972-480c-8b3d-5188583e21de")')

def click_5():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.playlistloader/?cache=0&epg&iconimage=C%3a%5cPortableApps%5ckodi%5ckodi%20World%2021%5cKodi%5cportable_data%5caddons%5cplugin.video.playlistloader%5cresources%5cimages%5cdefault-list-image.png&logos&mode=2&name=%5bhttps%3a%2f%2ftinyurl.com%2f22f874un%5d&url=https%3a%2f%2ftinyurl.com%2f22f874un&uuid=39f27f4a-1029-4a2c-ab6c-87051084903c"))')

def click_6():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.playlistloader/?cache=0&epg&iconimage=C%3a%5cPortableApps%5ckodi%5ckodi%20World%2021%5cKodi%5cportable_data%5caddons%5cplugin.video.playlistloader%5cresources%5cimages%5cdefault-list-image.png&logos&mode=2&name=%5bIPTVSport%5d&url=https%3a%2f%2fraw.githubusercontent.com%2fLove4vn%2flove4vn%2fmain%2fIPTVSport.m3u&uuid=4d1177c3-9304-421d-92e9-88d6b87d75a7")')

def click_7():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.playlistloader/?cache=0&epg&iconimage=C%3a%5cPortableApps%5ckodi%5ckodi%20World%2021%5cKodi%5cportable_data%5caddons%5cplugin.video.playlistloader%5cresources%5cimages%5cdefault-list-image.png&logos&mode=2&name=%5bSport%5d&url=https%3a%2f%2fraw.githubusercontent.com%2fLove4vn%2flove4vn%2fmain%2fSport.m3u&uuid=ac4c5ee9-b0ac-4db3-8815-5201f43cb295")')

def click_8():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.playlistloader/?cache=0&epg&iconimage=C%3a%5cPortableApps%5ckodi%5ckodi%20World%2021%5cKodi%5cportable_data%5caddons%5cplugin.video.playlistloader%5cresources%5cimages%5cdefault-list-image.png&logos&mode=2&name=%5bhubsport%5d&url=https%3a%2f%2fraw.githubusercontent.com%2fLove4vn%2flove4vn%2fmain%2fhubsport.m3u&uuid=36c47370-f55a-4db8-b633-dfdeff0ca03c")')


def click_9():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.playlistloader/?cache=0&epg&iconimage=C%3a%5cPortableApps%5ckodi%5ckodi%20World%2021%5cKodi%5cportable_data%5caddons%5cplugin.video.playlistloader%5cresources%5cimages%5cdefault-list-image.png&logos&mode=2&name=%5bVTV_sort%5d&url=https%3a%2f%2fraw.githubusercontent.com%2fLove4vn%2flove4vn%2fmain%2fVTV_sort.m3u&uuid=8288589e-fa37-40ed-82f2-08bc2eccbc39")')

def click_10():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.playlistloader/?cache=0&epg&iconimage=C%3a%5cPortableApps%5ckodi%5ckodi%20World%2021%5cKodi%5cportable_data%5caddons%5cplugin.video.playlistloader%5cresources%5cimages%5cdefault-list-image.png&logos&mode=2&name=%5bPL%5d&url=https%3a%2f%2fraw.githubusercontent.com%2fpawelbakstosia%2f9.09%2frefs%2fheads%2fmain%2f1.m3u&uuid=7026a2a3-0798-48c3-8ed0-cb0726c9487e")')

def click_11():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.playlistloader/?cache=0&epg&iconimage=C%3a%5cPortableApps%5ckodi%5ckodi%20World%2021%5cKodi%5cportable_data%5caddons%5cplugin.video.playlistloader%5cresources%5cimages%5cdefault-list-image.png&logos&mode=2&name=%5b1%5d&url=https%3a%2f%2fbit.ly%2fblackpvrr&uuid=8a21659d-ddee-405f-bd79-dbe5097268b9")')


def click_12():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.live.streamspro/?fanart=C%3a%5cPortableApps%5ckodi%5ckodi%20World%2021%5cKodi%5cportable_data%5caddons%5cplugin.video.live.streamspro%5cfanart.jpg&mode=1&name=deportes&url=https%3a%2f%2fraw.githubusercontent.com%2fblackghostaddon%2fgray%2fmaster%2fblack%2fdeportes.xml%2f")')


def click_13():
    xbmc.executebuiltin('Dialog.Close(all,true)')



ExternalAddOns()
