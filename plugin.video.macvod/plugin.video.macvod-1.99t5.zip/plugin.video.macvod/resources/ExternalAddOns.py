import xbmc, xbmcgui


def ExternalAddOns():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]ExternalAddOns[/COLOR][/B]',
['[COLOR=orange]RO[/COLOR] (f4mTester)',
 '[COLOR=orange]RO 1[/COLOR] (live.streamspro)',
 '[COLOR=orange]RO 2[/COLOR] (live.streamspro)',
  '[COLOR=orange]RO 3[/COLOR] (playlistloader)',
   '[COLOR=orange]RO 3[/COLOR] (playlistloader)',
 
 '[B]                                                                                             [COLOR grey]Back[/COLOR][/B]'])


    if call:
        if call < 1:
            return
        func = funcs[call-6]
        return func()
    else:
        func = funcs[call]
        return func()
    return 






def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.f4mTester/?mode=playlist&name=IPTV&url=https%3a%2f%2ftinyurl.com%2fmvcwp3k7")')
    #xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.myselect/folders/py/sporthdme.py")')

def click_2():
    xbmc.executebuiltin('ActivateWindow(Videos,"plugin://plugin.video.live.streamspro/?url=http%3A%2F%2Ftinyurl.com%2F56fnkcs3&mode=1&name=Bee+TV&fanart=C%3A%5CUsers%5Cuser%5CAppData%5CRoaming%5CKodi%5Caddons%5Cplugin.video.live.streamspro%5Cfanart.jpg",return)')

def click_3():
    xbmc.executebuiltin('ActivateWindow(Videos,"plugin://plugin.video.live.streamspro/?url=http%3A%2F%2Ftinyurl.com%2F2kv2mvhc&mode=1&name=Bee+TV2&fanart=C%3A%5CUsers%5Cuser%5CAppData%5CRoaming%5CKodi%5Caddons%5Cplugin.video.live.streamspro%5Cfanart.jpg",return)')

def click_4():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.playlistloader/?cache=0&epg&iconimage=C%3a%5cPortableApps%5ckodi%5ckodi%20World%2021%5cKodi%5cportable_data%5caddons%5cplugin.video.playlistloader%5cresources%5cimages%5cdefault-list-image.png&logos&mode=2&name=%5bhttps%3a%2f%2ftinyurl.com%2f24v4rwf8%5d&url=https%3a%2f%2ftinyurl.com%2f24v4rwf8&uuid=9ecc8e59-7972-480c-8b3d-5188583e21de")')

def click_5():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.playlistloader/?cache=0&epg&iconimage=C%3a%5cPortableApps%5ckodi%5ckodi%20World%2021%5cKodi%5cportable_data%5caddons%5cplugin.video.playlistloader%5cresources%5cimages%5cdefault-list-image.png&logos&mode=2&name=%5bhttps%3a%2f%2ftinyurl.com%2f22f874un%5d&url=https%3a%2f%2ftinyurl.com%2f22f874un&uuid=39f27f4a-1029-4a2c-ab6c-87051084903c"))')

def click_6():
    xbmc.executebuiltin('Action(Back)')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.macvod")')


ExternalAddOns()
